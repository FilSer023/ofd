'use strict';
let webpackConfig = require("./webpack.config.js");

module.exports = function karmaConfig(config) {
    config.set({
        autoWatchBatchDelay: 300,

        frameworks: ['jasmine'],

        reporters: ['spec'],

        files: ['**/*.spec.ts'],

        logLevel: config.LOG_INFO,

        preprocessors: {
            '**/*.spec.ts': ['webpack']
        },

        browsers: ['PhantomJS'],

        autoWatch: true,
        singleRun: false,

        webpack: {
            module: webpackConfig.module,
            resolve: webpackConfig.resolve
        },

        plugins: [
            // Note you can also use 'karma-*' in place of below and it will match node_modules/karma-* but it's nice to see exactly what's loaded explicitly
            'karma-webpack',
            'karma-jasmine',
            'karma-phantomjs-launcher',
            'karma-spec-reporter'
        ]
    });
};
