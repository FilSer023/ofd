/* eslint-disable comma-dangle */

const fs = require("fs");
const path = require("path");
const rimraf = require("rimraf");
const parseString = require("xml2js").parseString;

const targetDir = (function getTargetDir() {
  const pomXml = fs.readFileSync("pom.xml", "utf8");

  let artifactId;
  let version;
  parseString(pomXml, (err, result) => {
    artifactId = result.project.artifactId[0];
    version = result.project.version[0];
  });

  return path.resolve(__dirname, "target/" + artifactId + "-" + version);
}());


const dirToClean = targetDir + "/static";
console.log("cleaning " + dirToClean);
rimraf.sync(dirToClean);
