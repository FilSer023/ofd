package threewks.controller;

import com.google.gson.GsonBuilder;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.json.GsonSupport;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.model.ReceiptDocumentStatus;
import threewks.model.ShopOperator;
import threewks.repository.OFDBatchRepository;
import threewks.repository.ReceiptDocumentRepository;
import threewks.service.OFDBatchService;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;
import threewks.service.bigquery.DataManagerService;
import threewks.service.ofd.BaseOFDService;
import threewks.service.ofd.peterservice.PeterServiceOFDServiceStrategy;
import threewks.service.passengerfeed.CobraDataService;
import threewks.service.passengerfeed.PassengerFeedTransformerService;

import java.util.HashMap;
import java.util.Map;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TaskControllerTest {

    @Rule
    public final SetupAppengine setupAppengine = new SetupAppengine();

    @Rule
    public final SetupObjectify setupObjectify = new SetupObjectify(ShopOperator.class, OFDBatch.class);

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Mock
    private TaskService taskService;

    @Mock
    private BaseOFDService baseOFDService;

    @Mock
    private ShopOperatorService shopOperatorService;

    @Mock
    private DataManagerService dataManagerService;

    @Mock
    private CobraDataService cobraDataService;

    @Mock
    private PassengerFeedTransformerService passengerFeedTransformerService;

    @Mock
    private PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy;

    @Mock
    private ReceiptDocumentRepository receiptDocumentRepository;

    @Mock
    private OFDBatchService batchService;

    @Mock
    private OFDBatchRepository batchRepository;

    private TaskController taskController;

    @Before
    public void setUp() throws Exception {
        GsonBuilder gsonBuilder = GsonSupport.createBasicGsonBuilder();
        taskController = new TaskController(taskService, baseOFDService, shopOperatorService, dataManagerService,
            cobraDataService, passengerFeedTransformerService, peterServiceOFDServiceStrategy, receiptDocumentRepository, batchService, batchRepository);
    }


    @Test
    public void exportOFD_willNotSplitExportForNonYarusShopOperator() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("Not Yarus1");
        shopOperator.setOfdProvider(OFDProvider.KONTUR);
        ofy().save().entity(shopOperator);
        when(shopOperatorService.get(shopOperator.getId())).thenReturn(shopOperator);

        taskController.exportOFD(null, shopOperator.getId(), null, "2018-06-30", "10");

        verify(baseOFDService, times(1)).extractAndUploadOFDDocuments(null, shopOperator, "2018-06-30", 10, 10, null);
    }

    @Test
    public void exportOFD_willSplitExportForYarusShopOperatorIfPeriodMoreThan10() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("Yarus Test1");
        shopOperator.setOfdProvider(OFDProvider.YARUS);
        ofy().save().entity(shopOperator);
        when(shopOperatorService.get(shopOperator.getId())).thenReturn(shopOperator);
        when(baseOFDService.extractAndUploadOFDDocuments(null, shopOperator, "2018-06-30", 30, 10, null)).thenReturn("CONTINUE");

        taskController.exportOFD(null, shopOperator.getId(), null, "2018-06-30", "30");

        verify(baseOFDService, times(1)).extractAndUploadOFDDocuments(null, shopOperator, "2018-06-30", 30, 10, null);
        verify(taskService, times(1)).exportOFD("CONTINUE", "2018-06-20", "20");
    }

    @Test
    public void checkReceiptsQueue_willKickOffIngestion_whenReceiptDetailsAreDownloaded() {
        ShopOperator shopOperator = new ShopOperator();
        OFDBatch batch = new OFDBatch(shopOperator);
        batch.setStatus(BatchStatus.RECEIPT_SUMMARIES_RETRIEVED);
        when(batchRepository.get("batchId")).thenReturn(batch);
        Map<String, Integer> stats = new HashMap<>();
        stats.put(ReceiptDocumentStatus.QUEUED.name(), 0);
        stats.put(ReceiptDocumentStatus.DOWNLOADED.name(), 0);
        stats.put(ReceiptDocumentStatus.ERROR.name(), 0);
        when(receiptDocumentRepository.getBatchStats("batchId")).thenReturn(stats);

        taskController.checkReceiptsQueue("batchId");

        verify(batchService, times(1)).finishBatch(batch);
        verify(taskService, times(1)).ingestOFDBatch("batchId");
    }

}
