package threewks.util;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

public class SearchUtilTest {

    @Test
    public void testSearchText() {
        String searchIndex = SearchUtil.getSearchableText(3, "мад хаус совиньон блан 0,75л");
        assertThat(searchIndex, notNullValue());
    }
}
