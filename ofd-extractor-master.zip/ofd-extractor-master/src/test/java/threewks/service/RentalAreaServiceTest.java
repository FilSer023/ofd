package threewks.service;

import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.TestObjectify;
import threewks.model.RentalArea;
import threewks.model.RentalAreaStatus;
import threewks.model.ShopOperator;
import threewks.model.TradePoint;
import threewks.model.dto.RentalAreaDto;
import threewks.repository.RentalAreaRepository;
import threewks.repository.ShopOperatorRepository;

import java.util.ArrayList;
import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RentalAreaServiceTest {
    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();

    @Rule
    public SetupObjectify setupObjectify = new TestObjectify();

    @Mock
    private ShopOperatorRepository shopOperatorRepository;

    @Mock
    private ShopOperatorService shopOperatorService;

    @Mock
    private RentalAreaRepository rentalAreaRepository;

    private RentalAreaService rentalAreaService;

    RentalArea rentalArea1;
    RentalArea rentalArea2;
    ShopOperator shopOperator1;
    TradePoint tradePoint1;

    @Before
    public void before() {

        rentalArea1 = new RentalArea();
        rentalArea1.setName("Площадь 1");
        rentalArea1.setStatus(RentalAreaStatus.ACTIVE);

        rentalArea2 = new RentalArea();
        rentalArea2.setName("Площадь 2");
        rentalArea2.setStatus(RentalAreaStatus.ACTIVE);

        shopOperator1 = new ShopOperator();
        tradePoint1 = new TradePoint();

        tradePoint1.setRentalAreaRef(rentalArea1);
        shopOperator1.setTradePoints(asList(tradePoint1));

        rentalAreaService = new RentalAreaService(rentalAreaRepository, shopOperatorService, shopOperatorRepository);

        ofy().save().entity(rentalArea1).now();
        ofy().save().entity(rentalArea2).now();
        ofy().save().entity(shopOperator1).now();
    }

    @Test
    public void getFreeRentalAreas_willReturnOnlyFreeRentalAreas() {
        List<RentalArea> allRentalAreas = new ArrayList<>();
        allRentalAreas.addAll(asList(rentalArea1, rentalArea2));
        when(rentalAreaRepository.listByStatus(RentalAreaStatus.ACTIVE)).thenReturn(allRentalAreas);
        List<ShopOperator> allOperators = new ArrayList<>();
        allOperators.addAll(asList(shopOperator1));
        when(shopOperatorRepository.listAll()).thenReturn(allOperators);

        List<RentalAreaDto> freeRentalAreas = rentalAreaService.getFreeRentalAreas();

        assertThat(freeRentalAreas, is(notNullValue()));
        assertThat(freeRentalAreas.size(), is(1));
        assertThat(freeRentalAreas.get(0).getName(), is("Площадь 2"));
    }

}
