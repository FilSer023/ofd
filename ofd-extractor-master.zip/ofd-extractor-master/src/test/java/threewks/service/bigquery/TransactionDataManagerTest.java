package threewks.service.bigquery;

import com.google.api.gax.paging.Page;
import com.google.cloud.PageImpl;
import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.JobStatus;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.CopyWriter;
import com.google.cloud.storage.Storage;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.TestObjectify;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.service.OFDBatchService;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;

import java.util.ArrayList;
import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TransactionDataManagerTest {

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();
    @Rule
    public SetupObjectify setupObjectify = new TestObjectify();

    @Mock
    TaskService taskService;

    @Mock
    BigQuery bigQuery;

    @Mock
    Storage storage;

    @Mock
    BQService bqService;

    @Mock
    OFDBatchService ofdBatchService;

    @Mock
    ShopOperatorService shopOperatorService;

    @Mock
    Job job;

    @Mock
    JobStatus jobStatus;

    TransactionDataManager transactionDataManager;
    PageImpl.NextPageFetcher fetcher = new PageImpl.NextPageFetcher() {
        @Override
        public Page getNextPage() {
            return null;
        }
    };
    private Iterable blobList = new ArrayList();

    @Mock
    Page<Blob> samplePageBlob;
    @Mock
    Blob blob;
    @Mock
    CopyWriter copyWriter;
    List<Blob> sampleBlobs = new ArrayList<>();

    @Before
    public void setUp() {
        transactionDataManager = new TransactionDataManager(taskService, bigQuery, storage, bqService, ofdBatchService, shopOperatorService, "defaultBucket");
    }

    @Test
    public void ingestTransactionsDataIntoStaging_willKickOffBQ_whenThereAreTransactionsRetrieved() throws InterruptedException {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("В гостях у сказки");
        OFDBatch batch = new OFDBatch(shopOperator);
        batch.setStatus(BatchStatus.OFD_EXPORT_COMPLETED);
        batch.setReceiptsRetrieved(50);
        ofy().save().entity(shopOperator);
        ofy().save().entity(batch);
        when(ofdBatchService.find(batch.getId())).thenReturn(batch);
        when(bigQuery.create(any(JobInfo.class))).thenReturn(job);
        when(job.waitFor(any(RetryOption.class))).thenReturn(job);
        when(job.getStatus()).thenReturn(jobStatus);
        when(jobStatus.getExecutionErrors()).thenReturn(new ArrayList<>());
        when(blob.getName()).thenReturn("sample");
        when(blob.copyTo(anyString(), anyString())).thenReturn(copyWriter);
        when(copyWriter.getResult()).thenReturn(blob);
        sampleBlobs.add(blob);
        when(samplePageBlob.iterateAll()).thenReturn(sampleBlobs);
        when(storage.list(anyString(), any(Storage.BlobListOption.class))).thenReturn(samplePageBlob);
        transactionDataManager.ingestTransactionsDataIntoStaging(batch.getId());

        verify(bqService, times(1)).createTableIfNeeded(anyString(), anyString(), any(Schema.class));
        verify(taskService, times(1)).collateOFDTransactions(batch.getId());
        assertThat(batch.getStatus(), is(BatchStatus.DATA_IMPORTED_INTO_STAGING));
    }

    @Test
    public void ingestTransactionsDataIntoStaging_willNotKickOffBQ_whenThereAreNoFiles() throws InterruptedException {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("В гостях у сказки");
        OFDBatch batch = new OFDBatch(shopOperator);
        batch.setStatus(BatchStatus.OFD_EXPORT_COMPLETED);
        batch.setReceiptsRetrieved(50);
        ofy().save().entity(shopOperator);
        ofy().save().entity(batch);
        when(ofdBatchService.find(batch.getId())).thenReturn(batch);
        when(samplePageBlob.iterateAll()).thenReturn(sampleBlobs);
        when(storage.list(anyString(), any(Storage.BlobListOption.class))).thenReturn(samplePageBlob);
        transactionDataManager.ingestTransactionsDataIntoStaging(batch.getId());

        verify(bqService, never()).createTableIfNeeded(anyString(), anyString(), any(Schema.class));
        assertThat(batch.getErrorMessages().get(0), containsString("Нет данных для импорта - возможно транзакции отсутствуют"));
        assertThat(batch.getStatus(), is(BatchStatus.NO_TRANSACTIONS_FOUND));
    }
}

