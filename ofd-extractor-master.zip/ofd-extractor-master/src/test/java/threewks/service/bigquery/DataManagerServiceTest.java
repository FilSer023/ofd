package threewks.service.bigquery;

import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.InsertAllResponse;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobStatus;
import com.google.cloud.bigquery.LegacySQLTypeName;
import com.google.cloud.bigquery.QueryResponse;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableId;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.TestObjectify;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;
import threewks.service.UnmatchedCategoryReportService;


@RunWith(MockitoJUnitRunner.class)
public class DataManagerServiceTest {

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();
    @Rule
    public SetupObjectify setupObjectify = new TestObjectify();

    @Mock
    private BigQuery bigQuery;

    @Mock
    private Table table;

    @Mock
    private Job job;

    @Mock
    private JobStatus jobStatus;

    @Mock
    private QueryResponse queryResponse;

    @Mock
    private ShopOperatorService shopOperatorService;

    @Mock
    private UnmatchedCategoryReportService unmatchedCategoryReportService;

    private TableId tableId = TableId.of("dev", "productdata", "products");

    private DataManagerService dataManagerService;

    @Mock
    private InsertAllResponse insertAllResponse;

    @Mock
    private TransactionDataManager transactionDataManager;

    @Mock
    private TradepointsDataManager tradepointsDataManager;

    @Mock
    private CategoriesDataManager categoriesDataManager;

    @Mock
    private PassengerFeedDataManager passengerFeedDataManager;

    @Mock
    private TaskService taskService;

    @Mock
    private BackupDataManager backupDataManager;

    @Before
    public void setUp() {
        dataManagerService = new DataManagerService(transactionDataManager, tradepointsDataManager, categoriesDataManager, passengerFeedDataManager, backupDataManager);

        Field idField = Field.newBuilder("id", LegacySQLTypeName.STRING).build();
        Field nameField = Field.newBuilder("name", LegacySQLTypeName.STRING).build();
        Field skuField = Field.newBuilder("sku", LegacySQLTypeName.STRING).build();
        Field urlField = Field.newBuilder("url", LegacySQLTypeName.STRING).build();
        Field brandField = Field.newBuilder("brand", LegacySQLTypeName.STRING).build();
        Field categoryField = Field.newBuilder("category", LegacySQLTypeName.STRING).build();
        Field merchantField = Field.newBuilder("merchant", LegacySQLTypeName.STRING).build();
        Field priceField = Field.newBuilder("price", LegacySQLTypeName.STRING).build();
        Field salePriceField = Field.newBuilder("salePrice", LegacySQLTypeName.STRING).build();
        Field imagesField = Field.newBuilder("images", LegacySQLTypeName.STRING).setMode(Field.Mode.REPEATED).build();
        Field sizesField = Field.newBuilder("sizes", LegacySQLTypeName.STRING).setMode(Field.Mode.REPEATED).build();
        Field colorsField = Field.newBuilder("colors", LegacySQLTypeName.STRING).setMode(Field.Mode.REPEATED).build();

//        schema = Schema.of(idField, nameField, skuField, urlField, brandField, categoryField, merchantField, priceField,
//            salePriceField, imagesField, sizesField, colorsField);
    }

    @Test
    public void testIngestion() {

    }


}
