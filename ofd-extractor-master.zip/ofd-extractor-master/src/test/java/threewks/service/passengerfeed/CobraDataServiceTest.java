package threewks.service.passengerfeed;

import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.AirportCatalog;
import threewks.model.PassengerFeedBatch;
import threewks.model.PassengerFeedBatchStatus;
import threewks.service.AirportCatalogService;
import threewks.service.ConfigParameterService;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CobraDataServiceTest {

    @Mock
    FTPClient ftpClient;

    @Mock
    ConfigParameterService configParameterService;

    @Mock
    PassengerFeedBatchService passengerFeedBatchService;

    @Mock
    AirportCatalogService airportCatalogService;

    @Mock
    GcsFileWriter gcsFileWriter;

    String ftpServerHost = "ftp.fake.com";
    String ftpServerUser = "user";
    String ftpServerPass = "pass";

    CobraDataService cobraDataService;
    List<AirportCatalog> airports = new ArrayList<>();

    @Before
    public void setUp() {
        cobraDataService = new CobraDataService(airportCatalogService, ftpClient, configParameterService, passengerFeedBatchService,
            ftpServerHost, ftpServerUser, ftpServerPass, gcsFileWriter);
        airports.add(new AirportCatalog().setNameIATA("AER"));
        airports.add(new AirportCatalog().setNameIATA("AAQ"));
        airports.add(new AirportCatalog().setNameIATA("KRR"));
    }

    @Test
    public void fetchPassengerFeedFiles_willAddErrorIfFileIsOldAndWillNotDownloadIt() throws Exception {
        PassengerFeedBatch passengerFeedBatch = new PassengerFeedBatch();
        InputStream isAER = IOUtils.toInputStream("testDataAER");
        InputStream isAAQ = IOUtils.toInputStream("testDataAAQ");

        when(airportCatalogService.list()).thenReturn(airports);
        when(passengerFeedBatchService.startBatch("2018-08-05", CobraDataService.CRON_USERNAME)).thenReturn(passengerFeedBatch);
        when(ftpClient.getModificationTime("CallCenter/KRR_ORNK.csv")).thenReturn("20180805200102");
        when(ftpClient.getModificationTime("CallCenter/AAQ_ORNK.csv")).thenReturn("20180805210102");
        when(ftpClient.getModificationTime("CallCenter/AER_ORNK.csv")).thenReturn("20180805210102");
        when(ftpClient.retrieveFileStream("CallCenter/AER_ORNK.csv")).thenReturn(isAER);
        when(ftpClient.retrieveFileStream("CallCenter/AAQ_ORNK.csv")).thenReturn(isAAQ);
        when(ftpClient.completePendingCommand()).thenReturn(true);

        String batchId = cobraDataService.fetchPassengerFeedFiles("2018-08-05");

        verify(ftpClient, never()).retrieveFileStream("CallCenter/KRR_ORNK.csv");
        verify(ftpClient, times(1)).retrieveFileStream("CallCenter/AER_ORNK.csv");
        verify(ftpClient, times(1)).retrieveFileStream("CallCenter/AAQ_ORNK.csv");
        assertThat(passengerFeedBatch.getErrorMessages().size(), is(1));
        assertThat(passengerFeedBatch.getInfoMessages().size(), is(2));
        assertThat(passengerFeedBatch.getStatus(), is(PassengerFeedBatchStatus.FTP_EXPORT_COMPLETED));
    }

    @Test
    public void fetchPassengerFeedFiles_willWillDownloadFilesIfRecent() throws Exception {
        PassengerFeedBatch passengerFeedBatch = new PassengerFeedBatch();
        InputStream isKRR = IOUtils.toInputStream("testDataKRR");
        InputStream isAER = IOUtils.toInputStream("testDataAER");
        InputStream isAAQ = IOUtils.toInputStream("testDataAAQ");

        when(airportCatalogService.list()).thenReturn(airports);
        when(passengerFeedBatchService.startBatch("2018-08-05", CobraDataService.CRON_USERNAME)).thenReturn(passengerFeedBatch);
        when(ftpClient.completePendingCommand()).thenReturn(true);
        when(ftpClient.getModificationTime("CallCenter/KRR_ORNK.csv")).thenReturn("20180805210102");
        when(ftpClient.getModificationTime("CallCenter/AAQ_ORNK.csv")).thenReturn("20180805210102");
        when(ftpClient.getModificationTime("CallCenter/AER_ORNK.csv")).thenReturn("20180805210102");
        when(ftpClient.retrieveFileStream("CallCenter/KRR_ORNK.csv")).thenReturn(isKRR);
        when(ftpClient.retrieveFileStream("CallCenter/AER_ORNK.csv")).thenReturn(isAER);
        when(ftpClient.retrieveFileStream("CallCenter/AAQ_ORNK.csv")).thenReturn(isAAQ);

        String batchId = cobraDataService.fetchPassengerFeedFiles("2018-08-05");

        verify(ftpClient, times(1)).retrieveFileStream("CallCenter/KRR_ORNK.csv");
        verify(ftpClient, times(1)).retrieveFileStream("CallCenter/AER_ORNK.csv");
        verify(ftpClient, times(1)).retrieveFileStream("CallCenter/AAQ_ORNK.csv");
        assertThat(passengerFeedBatch.getErrorMessages().size(), is(0));
        assertThat(passengerFeedBatch.getInfoMessages().size(), is(3));
        assertThat(passengerFeedBatch.getStatus(), is(PassengerFeedBatchStatus.FTP_EXPORT_COMPLETED));
    }

}
