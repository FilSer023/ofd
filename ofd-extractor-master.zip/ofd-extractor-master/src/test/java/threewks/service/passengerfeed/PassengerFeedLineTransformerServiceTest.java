package threewks.service.passengerfeed;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.core.util.Separators;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.service.passengerfeed.model.PassengerFeedLine;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class PassengerFeedLineTransformerServiceTest {

    private static final char SEMICOLON = ';';
    private static final char SINGLE_QUOTE = '\"';

    @Test
    public void testTransformation() throws IOException {
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("AER_ORNK.csv");
//        CsvSchema bootstrap = CsvSchema.builder()
//            .addColumn("spp_id", CsvSchema.ColumnType.STRING)
//            .build().withHeader();
//        CsvMapper csvMapper = new CsvMapper();
        CsvSchema bootstrapSchema = CsvSchema.emptySchema().withColumnSeparator(';').withoutQuoteChar().withHeader();
        ObjectMapper csvMapper = new CsvMapper();
        MappingIterator<PassengerFeedLine> mappingIterator = csvMapper.readerFor(PassengerFeedLine.class).with(bootstrapSchema).readValues(inputStream);
        List<PassengerFeedLine> passengerFeedLines = new ArrayList<>();
        while (mappingIterator.hasNext()) {
            PassengerFeedLine line = mappingIterator.next();
//            System.out.println("Line: " + line.getFlightNumber() + " " + line.getAirlineName());
            passengerFeedLines.add(line);
        }
        ObjectMapper jsonMapper = new ObjectMapper();
        ObjectWriter writer = jsonMapper.writer(new NewLineDelimitedPrettyPrinter());
        writer.writeValue(System.out, passengerFeedLines);
//        Scanner scanner = new Scanner(inputStream);
//        scanner.useDelimiter(";");
//        while (scanner.hasNext()) {
//            System.out.println(scanner.next() + "|");
//        }
//        scanner.close();
    }

    class NewLineDelimitedPrettyPrinter extends DefaultPrettyPrinter {

        public NewLineDelimitedPrettyPrinter() {
            super();
            this.withSeparators(new Separators(':', ',', '\n'));
            System.out.println("NewLineDelimitedPrettyPrinter - constructor");
        }

        @Override
        public void writeStartArray(JsonGenerator g) throws IOException {
            System.out.println("NewLineDelimitedPrettyPrinter - writeStartArray");
            return;
        }
    }
}
