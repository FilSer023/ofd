package threewks.service.ofd;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.github.tomakehurst.wiremock.matching.EqualToPattern;
import com.github.tomakehurst.wiremock.matching.MatchesJsonPathPattern;
import com.google.gson.GsonBuilder;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.json.GsonSupport;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.KKTFiscalDrive;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.model.TradePoint;
import threewks.repository.OFDBatchRepository;
import threewks.service.ofd.yarus.YarusOFDServiceStrategy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.googlecode.objectify.ObjectifyService.ofy;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class YarusOFDServiceStrategyIT {

    @Rule
    public final SetupAppengine setupAppengine = new SetupAppengine();

    @Rule
    public final SetupObjectify setupObjectify = new SetupObjectify(ShopOperator.class, OFDBatch.class);

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(8089);

    @Mock
    OFDBatchRepository batchRepository;

    @Mock
    private OFDDocumentUploadService ofdDocumentUploadService;

    YarusOFDServiceStrategy yarusOFDServiceStrategy;

    @Before
    public void setUp() {
        try {
            GsonBuilder gsonBuilder = GsonSupport.createBasicGsonBuilder();
            yarusOFDServiceStrategy = new YarusOFDServiceStrategy(gsonBuilder, "http://localhost:8089", batchRepository, ofdDocumentUploadService);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getShiftDocuments_willNotRetrieveReceiptsFromNonmatchingFiscalDrives() throws IOException {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("NuanceBasel");
        shopOperator.setInn("2320163664");
        ofy().save().entity(shopOperator);
        threewks.model.TradePoint tradePoint1 = new TradePoint();
        tradePoint1.setName("Малина");
        List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();
        kktFiscalDrives.add(new KKTFiscalDrive("0001707061045261", "8712000100089731"));
        tradePoint1.setKktFiscalDrives(kktFiscalDrives);
        shopOperator.getTradePoints().add(tradePoint1);
        OFDBatch batch = new OFDBatch(shopOperator);
        batch.setBatchDay("2018-05-20");
        ofy().save().entity(batch);

        when(ofdDocumentUploadService.saveTransactionDocuments(anyString(), anyString(), anyString(), anyList(), any(OFDBatch.class))).thenReturn(batch);

        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v2/KKT"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\n" +
                    "  \"KKT\" : " +
                    "    {\"8712000100089731\" : [ {\n" +
                    "      \"address\" : \"г. Сочи, адлерский район, тер. аэропорт\",\n" +
                    "      \"last\" : \"2018-04-22 19:57:00\",\n" +
                    "      \"kktregid\" : \"0001707061045261\",\n" +
                    "      \"turnover\" : 59751092,\n" +
                    "      \"receiptCount\" : 268\n" +
                    "    } ],\n" +
                    "    \"8712000100062728\" : [ {\n" +
                    "      \"address\" : \"г. Сочи, Адлерский район, тер. Аэропорта\",\n" +
                    "      \"last\" : \"-/-/-\",\n" +
                    "      \"kktregid\" : \"0000509468063026\",\n" +
                    "      \"turnover\" : 0,\n" +
                    "      \"receiptCount\" : 0\n" +
                    "    } ],\n" +
                    "    \"8710000100504829\" : [ {\n" +
                    "      \"address\" : \"г. Сочи, адлерский район, тер. аэропорт\",\n" +
                    "      \"last\" : \"2018-04-22 22:47:00\",\n" +
                    "      \"kktregid\" : \"0000511820047147\",\n" +
                    "      \"turnover\" : 8092503,\n" +
                    "      \"receiptCount\" : 248\n" +
                    "    } ]\n" +
                    "  },\n" +
                    "  \"count\" : 31\n" +
                    "}")));


        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v1/TradePoint"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("yarus-tradepoints-basel.json")))));
        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v1/documents"))
            .withRequestBody(new MatchesJsonPathPattern("fiscalDriveNumber", new EqualToPattern("8712000100089731")))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("yarus-documents-8710000100504636.json")))));

        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v1/KKTbyTradePoint"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\n" +
                    "  \"kkt\" : {\n" +
                    "    \"8712000100089731\" : {\n" +
                    "      \"factory_number_fn\" : \"8712000100089731\",\n" +
                    "      \"register_number_kkt\" : \"0000511370025895\",\n" +
                    "      \"name\" : \"AER Hudson com_1\",\n" +
                    "      \"lastreq\" : \"2018-06-16 06:58:07,717\",\n" +
                    "      \"factory_number_kkt\" : \"1705659\",\n" +
                    "      \"activated\" : true,\n" +
                    "      \"status\" : \"ФД успешно обработан\"\n" +
                    "    },\n" +
                    "    \"8710000100504348\" : {\n" +
                    "      \"factory_number_fn\" : \"8710000100504348\",\n" +
                    "      \"register_number_kkt\" : \"0000511164058400\",\n" +
                    "      \"name\" : \"AER Hudson com_2\",\n" +
                    "      \"lastreq\" : \"2018-05-23 08:59:24,604\",\n" +
                    "      \"factory_number_kkt\" : \"1705660\",\n" +
                    "      \"activated\" : true,\n" +
                    "      \"status\" : \"ФД успешно обработан\"\n" +
                    "    }\n" +
                    "  },\n" +
                    "  \"count\" : 2\n" +
                    "}")));

        OFDBatch result = yarusOFDServiceStrategy.saveOFDDocuments(shopOperator, "2018-05-20", 4, batch);

        verify(ofdDocumentUploadService, never()).saveTradePoints(anyString(), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, never()).saveTradePointKKTs(anyString(), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-20"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-19"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-18"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-17"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, never()).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-20"), eq("8712000100062728"), anyList(), any(OFDBatch.class));
        assertThat(result, notNullValue());
    }

    @Test
    public void getShiftDocuments_willNotFetchDataOutsideRequestedPeriod() throws IOException {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("NuanceBasel");
        shopOperator.setInn("2320163664");
        ofy().save().entity(shopOperator);
        threewks.model.TradePoint tradePoint1 = new TradePoint();
        tradePoint1.setName("Малина");
        List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();
        kktFiscalDrives.add(new KKTFiscalDrive("0001707061045261", "8712000100089731"));
        tradePoint1.setKktFiscalDrives(kktFiscalDrives);
        shopOperator.getTradePoints().add(tradePoint1);
        OFDBatch batch = new OFDBatch(shopOperator);
        batch.setBatchDay("2018-05-20");
        ofy().save().entity(batch);

        when(ofdDocumentUploadService.saveTransactionDocuments(anyString(), anyString(), anyString(), anyList(), any(OFDBatch.class))).thenReturn(batch);

        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v2/KKT"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\n" +
                    "  \"KKT\" : " +
                    "    {\"8712000100089731\" : [ {\n" +
                    "      \"address\" : \"г. Сочи, адлерский район, тер. аэропорт\",\n" +
                    "      \"last\" : \"2018-04-22 19:57:00\",\n" +
                    "      \"kktregid\" : \"0001707061045261\",\n" +
                    "      \"turnover\" : 59751092,\n" +
                    "      \"receiptCount\" : 268\n" +
                    "    } ],\n" +
                    "    \"8712000100062728\" : [ {\n" +
                    "      \"address\" : \"г. Сочи, Адлерский район, тер. Аэропорта\",\n" +
                    "      \"last\" : \"-/-/-\",\n" +
                    "      \"kktregid\" : \"0000509468063026\",\n" +
                    "      \"turnover\" : 0,\n" +
                    "      \"receiptCount\" : 0\n" +
                    "    } ],\n" +
                    "    \"8710000100504829\" : [ {\n" +
                    "      \"address\" : \"г. Сочи, адлерский район, тер. аэропорт\",\n" +
                    "      \"last\" : \"2018-04-22 22:47:00\",\n" +
                    "      \"kktregid\" : \"0000511820047147\",\n" +
                    "      \"turnover\" : 8092503,\n" +
                    "      \"receiptCount\" : 248\n" +
                    "    } ]\n" +
                    "  },\n" +
                    "  \"count\" : 31\n" +
                    "}")));


        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v1/TradePoint"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("yarus-tradepoints-basel.json")))));
        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v1/documents"))
            .withRequestBody(new MatchesJsonPathPattern("fiscalDriveNumber", new EqualToPattern("8712000100089731")))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody(IOUtils.toString(this.getClass().getClassLoader().getResourceAsStream("yarus-documents-8710000100504636.json")))));

        wireMockRule.stubFor(post(urlEqualTo("/ofdapi/v1/KKTbyTradePoint"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\n" +
                    "  \"kkt\" : {\n" +
                    "    \"8712000100089731\" : {\n" +
                    "      \"factory_number_fn\" : \"8712000100089731\",\n" +
                    "      \"register_number_kkt\" : \"0000511370025895\",\n" +
                    "      \"name\" : \"AER Hudson com_1\",\n" +
                    "      \"lastreq\" : \"2018-06-16 06:58:07,717\",\n" +
                    "      \"factory_number_kkt\" : \"1705659\",\n" +
                    "      \"activated\" : true,\n" +
                    "      \"status\" : \"ФД успешно обработан\"\n" +
                    "    },\n" +
                    "    \"8710000100504348\" : {\n" +
                    "      \"factory_number_fn\" : \"8710000100504348\",\n" +
                    "      \"register_number_kkt\" : \"0000511164058400\",\n" +
                    "      \"name\" : \"AER Hudson com_2\",\n" +
                    "      \"lastreq\" : \"2018-05-23 08:59:24,604\",\n" +
                    "      \"factory_number_kkt\" : \"1705660\",\n" +
                    "      \"activated\" : true,\n" +
                    "      \"status\" : \"ФД успешно обработан\"\n" +
                    "    }\n" +
                    "  },\n" +
                    "  \"count\" : 2\n" +
                    "}")));

        OFDBatch result = yarusOFDServiceStrategy.saveOFDDocuments(shopOperator, "2018-05-20", 4, batch);

        verify(ofdDocumentUploadService, never()).saveTradePoints(anyString(), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, never()).saveTradePointKKTs(anyString(), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-20"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-19"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-18"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, times(1)).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-17"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, never()).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-16"), eq("8712000100089731"), anyList(), any(OFDBatch.class));
        verify(ofdDocumentUploadService, never()).saveTransactionDocuments(eq("NuanceBasel"), eq("2018-05-20"), eq("8712000100062728"), anyList(), any(OFDBatch.class));
        assertThat(result, notNullValue());
    }

}
