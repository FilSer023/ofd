package threewks.service.ofd;

import com.google.gson.GsonBuilder;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.json.GsonSupport;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.model.ShopOperator;
import threewks.service.OFDBatchService;
import threewks.service.ofd.kontur.KonturOFDServiceStrategy;
import threewks.service.ofd.peterservice.PeterServiceOFDServiceStrategy;
import threewks.service.ofd.yarus.YarusOFDServiceStrategy;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BaseOFDServiceTest {

    @Rule
    public final SetupAppengine setupAppengine = new SetupAppengine();

    @Rule
    public final SetupObjectify setupObjectify = new SetupObjectify(ShopOperator.class, OFDBatch.class);

    private BaseOFDService baseOFDService;

    @Mock
    private OFDBatchService ofdBatchService;

    @Mock
    private YarusOFDServiceStrategy yarusOFDServiceStrategy;

    @Mock
    private KonturOFDServiceStrategy konturOFDServiceStrategy;

    @Mock
    private PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy;

    @Before
    public void setUp() {
        GsonBuilder gsonBuilder = GsonSupport.createBasicGsonBuilder();
        baseOFDService = new BaseOFDService(gsonBuilder, yarusOFDServiceStrategy, konturOFDServiceStrategy, peterServiceOFDServiceStrategy, ofdBatchService);
    }

    @Test
    public void getShiftDocuments_willSaveJsonFile_whenThereAreDocumentsAvailable() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setOfdProvider(OFDProvider.YARUS);
        OFDBatch batch = new OFDBatch(shopOperator);
        when(ofdBatchService.startBatch(any(ShopOperator.class), eq("2018-05-20"), eq(4), eq("test"))).thenReturn(batch);
        when(ofdBatchService.finishBatch(any(OFDBatch.class))).thenReturn(batch);
        when(yarusOFDServiceStrategy.saveOFDDocuments(any(ShopOperator.class), eq("2018-05-20"), eq(4), any(OFDBatch.class))).thenReturn(batch);

        baseOFDService.extractAndUploadOFDDocuments(null, shopOperator, "2018-05-20", 4, 4, "test");

        verify(yarusOFDServiceStrategy).saveOFDDocuments(shopOperator, "2018-05-20", 4, batch);
    }

    @Test
    public void getShiftDocuments_willContinueBatchIfBatchIdIsPassed() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setOfdProvider(OFDProvider.YARUS);
        OFDBatch batch = new OFDBatch(shopOperator);
        when(ofdBatchService.continueBatch(eq(batch.getId()))).thenReturn(batch);
        when(ofdBatchService.finishBatch(any(OFDBatch.class))).thenReturn(batch);
        when(yarusOFDServiceStrategy.saveOFDDocuments(any(ShopOperator.class), eq("2018-05-20"), eq(4), any(OFDBatch.class))).thenReturn(batch);

        baseOFDService.extractAndUploadOFDDocuments(batch.getId(), shopOperator, "2018-05-20", 4, 4, "test");

        verify(yarusOFDServiceStrategy).saveOFDDocuments(shopOperator, "2018-05-20", 4, batch);
    }

}
