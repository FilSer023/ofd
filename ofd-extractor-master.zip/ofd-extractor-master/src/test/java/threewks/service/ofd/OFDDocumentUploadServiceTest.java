package threewks.service.ofd;

import com.google.gson.GsonBuilder;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.json.GsonSupport;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.repository.OFDBatchRepository;

import java.util.ArrayList;
import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;

@RunWith(MockitoJUnitRunner.class)
public class OFDDocumentUploadServiceTest {

    private static final String GCS_BUCKET = "ofd-extractor-dev.appspot.com";

    @Rule
    public final SetupAppengine setupAppengine = new SetupAppengine();

    @Rule
    public final SetupObjectify setupObjectify = new SetupObjectify(ShopOperator.class, OFDBatch.class);

    private OFDDocumentUploadService ofdDocumentUploadService;

    @Mock
    private OFDBatchRepository batchRepository;

    @Before
    public void setUp() {
        GsonBuilder gsonBuilder = GsonSupport.createBasicGsonBuilder();
        ofdDocumentUploadService = new OFDDocumentUploadService(gsonBuilder, GCS_BUCKET, batchRepository);
    }

    @Test
    public void saveDocuments_willSaveJsonFile_whenThereAreDocumentsAvailable() {
        List<OFDDocument> documents = new ArrayList<>();
        ShopOperator shopOperator = new ShopOperator().setName("Beluga Bar");
        OFDBatch batch = new OFDBatch(shopOperator);
        ofy().save().entity(shopOperator).now();
        ofy().save().entity(batch).now();
        OFDDocument document = new OFDDocument();
        documents.add(document);
        String fiscalDriveNumber = "123";
        ofdDocumentUploadService.saveTransactionDocuments(shopOperator.getName(), fiscalDriveNumber, fiscalDriveNumber, documents, batch);
    }

}
