package threewks.service.ofd;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.google.gson.GsonBuilder;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.json.GsonSupport;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.KKTFiscalDrive;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.model.TradePoint;
import threewks.repository.OFDBatchRepository;
import threewks.service.ConfigParameterService;
import threewks.service.ofd.kontur.KonturOFDServiceStrategy;

import java.util.ArrayList;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.googlecode.objectify.ObjectifyService.ofy;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class KonturOFDServiceStrategyIT {

    @Rule
    public final SetupAppengine setupAppengine = new SetupAppengine();

    @Rule
    public final SetupObjectify setupObjectify = new SetupObjectify(ShopOperator.class, OFDBatch.class);

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(8089);

    @Mock
    private OFDDocumentUploadService ofdDocumentUploadService;

    @Mock
    private ConfigParameterService configParameterService;

    @Mock
    OFDBatchRepository batchRepository;

    KonturOFDServiceStrategy konturOFDServiceStrategy;

    @Before
    public void setUp() {
        try {
            GsonBuilder gsonBuilder = GsonSupport.createBasicGsonBuilder();
            konturOFDServiceStrategy = new KonturOFDServiceStrategy(gsonBuilder, "konturSessionKey", "konturApiKey", "http://localhost:8089", configParameterService, batchRepository, ofdDocumentUploadService);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getShiftDocuments_willRetrieveReceipts_whenThereAreDocumentsAvailable() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("TOY");
        shopOperator.setInn("2320163664");
        ofy().save().entity(shopOperator);
        TradePoint tradePoint1 = new TradePoint();
        tradePoint1.setName("Малина");
        List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();
        kktFiscalDrives.add(new KKTFiscalDrive("0001707061045261", "8710000101355288"));
        tradePoint1.setKktFiscalDrives(kktFiscalDrives);
        shopOperator.getTradePoints().add(tradePoint1);
        OFDBatch batch = new OFDBatch(shopOperator);
        batch.setBatchDay("2018-05-20");
        ofy().save().entity(batch);
        when(ofdDocumentUploadService.saveTransactionDocuments(anyString(), anyString(), anyString(), anyList(), any(OFDBatch.class))).thenReturn(batch);

        wireMockRule.stubFor(get(urlEqualTo("/v1/integration/inns/2320163664/kkts/0001707061045261/fss/8710000101355288/tickets?dateFrom=2018-05-16&dateTo=2018-05-20"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("[\n" +
                    "  {\n" +
                    "    \"fiscalReportCorrection\": {\n" +
                    "      \"code\": 11,\n" +
                    "      \"user\": \"ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \\\"ОЛИМПИНВЕСТ\\\"\",\n" +
                    "      \"userInn\": \"2320163664\",\n" +
                    "      \"taxationType\": 8,\n" +
                    "      \"dateTime\": \"2018-06-08T10:33:00\",\n" +
                    "      \"kktRegId\": \"0000418569025211    \",\n" +
                    "      \"offlineMode\": 0,\n" +
                    "      \"bsoSign\": 0,\n" +
                    "      \"serviceSign\": 0,\n" +
                    "      \"encryptionSign\": 0,\n" +
                    "      \"autoMode\": 0,\n" +
                    "      \"internetSign\": 0,\n" +
                    "      \"fiscalDocumentNumber\": 1,\n" +
                    "      \"fiscalDriveNumber\": \"9289000100057157\",\n" +
                    "      \"operator\": \"СИС. АДМИНИСТРАТОР\",\n" +
                    "      \"retailPlaceAddress\": \"23 - Kраснодарский край, 354340, г. Сочи, тер. Аэропорт, магазин \\\"Babooshka 1\\\"\",\n" +
                    "      \"ofdInn\": \"6663003127\",\n" +
                    "      \"kktNumber\": \"00106204065299\",\n" +
                    "      \"fiscalSign\": 3646486322,\n" +
                    "      \"correctionReasonCodes\": [\n" +
                    "        1\n" +
                    "      ]\n" +
                    "    }\n" +
                    "  },\n" +
                    "  {\n" +
                    "    \"currentStateReport\": {\n" +
                    "      \"code\": 21,\n" +
                    "      \"shiftNumber\": 0,\n" +
                    "      \"offlineMode\": 0,\n" +
                    "      \"notTransmittedDocumentNumber\": 0,\n" +
                    "      \"notTransmittedDocumentsQuantity\": 0,\n" +
                    "      \"notTransmittedDocumentsDateTime\": \"1970-01-01T00:00:00\",\n" +
                    "      \"userInn\": \"2320163664\",\n" +
                    "      \"fiscalDocumentNumber\": 2,\n" +
                    "      \"fiscalDriveNumber\": \"9289000100057157\",\n" +
                    "      \"dateTime\": \"2018-06-08T15:58:00\",\n" +
                    "      \"kktRegId\": \"0000418569025211    \",\n" +
                    "      \"fiscalSign\": 898071703\n" +
                    "    }\n" +
                    "  },\n" +
                    "  {\n" +
                    "    \"openShift\": {\n" +
                    "      \"code\": 2,\n" +
                    "      \"user\": \"ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \\\"ОЛИМПИНВЕСТ\\\"\",\n" +
                    "      \"userInn\": \"2320163664\",\n" +
                    "      \"operator\": \"БАБУШKА-1\",\n" +
                    "      \"retailPlaceAddress\": \"\",\n" +
                    "      \"dateTime\": \"2018-06-08T15:58:00\",\n" +
                    "      \"shiftNumber\": 1,\n" +
                    "      \"kktRegId\": \"0000418569025211    \",\n" +
                    "      \"fiscalDriveNumber\": \"9289000100057157\",\n" +
                    "      \"fiscalDocumentNumber\": 3,\n" +
                    "      \"fiscalSign\": 3602286586\n" +
                    "    }\n" +
                    "  },\n" +
                    "  {\n" +
                    "    \"closeShift\": {\n" +
                    "      \"code\": 5,\n" +
                    "      \"user\": \"ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \\\"ОЛИМПИНВЕСТ\\\"\",\n" +
                    "      \"userInn\": \"2320163664\",\n" +
                    "      \"operator\": \"БАБУШKА-1\",\n" +
                    "      \"dateTime\": \"2018-06-08T16:13:00\",\n" +
                    "      \"shiftNumber\": 1,\n" +
                    "      \"receiptsQuantity\": 0,\n" +
                    "      \"documentsQuantity\": 2,\n" +
                    "      \"notTransmittedDocumentsQuantity\": 2,\n" +
                    "      \"notTransmittedDocumentsDateTime\": \"2018-06-08T15:58:00\",\n" +
                    "      \"ofdResponseTimeoutSign\": 0,\n" +
                    "      \"fiscalDriveReplaceRequiredSign\": 0,\n" +
                    "      \"fiscalDriveMemoryExceededSign\": 0,\n" +
                    "      \"fiscalDriveExhaustionSign\": 0,\n" +
                    "      \"kktRegId\": \"0000418569025211    \",\n" +
                    "      \"fiscalDriveNumber\": \"9289000100057157\",\n" +
                    "      \"fiscalDocumentNumber\": 4,\n" +
                    "      \"fiscalSign\": 623520098\n" +
                    "    }\n" +
                    "  },\n" +
                    "  {\n" +
                    "    \"currentStateReport\": {\n" +
                    "      \"code\": 21,\n" +
                    "      \"shiftNumber\": 0,\n" +
                    "      \"offlineMode\": 0,\n" +
                    "      \"notTransmittedDocumentNumber\": 2,\n" +
                    "      \"notTransmittedDocumentsQuantity\": 3,\n" +
                    "      \"notTransmittedDocumentsDateTime\": \"2018-06-08T15:58:00\",\n" +
                    "      \"userInn\": \"2320163664\",\n" +
                    "      \"fiscalDocumentNumber\": 5,\n" +
                    "      \"fiscalDriveNumber\": \"9289000100057157\",\n" +
                    "      \"dateTime\": \"2018-06-08T18:09:00\",\n" +
                    "      \"kktRegId\": \"0000418569025211    \",\n" +
                    "      \"fiscalSign\": 257914147\n" +
                    "    }\n" +
                    "  },\n" +
                    "  {\n" +
                    "    \"openShift\": {\n" +
                    "      \"code\": 2,\n" +
                    "      \"user\": \"ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \\\"ОЛИМПИНВЕСТ\\\"\",\n" +
                    "      \"userInn\": \"2320163664\",\n" +
                    "      \"operator\": \"БАБУШКА-1\",\n" +
                    "      \"retailPlaceAddress\": \"\",\n" +
                    "      \"dateTime\": \"2018-06-08T18:10:00\",\n" +
                    "      \"shiftNumber\": 2,\n" +
                    "      \"kktRegId\": \"0000418569025211    \",\n" +
                    "      \"fiscalDriveNumber\": \"9289000100057157\",\n" +
                    "      \"fiscalDocumentNumber\": 6,\n" +
                    "      \"fiscalSign\": 4196605157\n" +
                    "    }\n" +
                    "  },\n" +
                    "  {\n" +
                    "    \"receipt\": {\n" +
                    "      \"receiptCode\": 3,\n" +
                    "      \"user\": \"ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \\\"ОЛИМПИНВЕСТ\\\"\",\n" +
                    "      \"userInn\": \"2320163664\",\n" +
                    "      \"requestNumber\": 1,\n" +
                    "      \"dateTime\": \"2018-06-08T18:14:00\",\n" +
                    "      \"shiftNumber\": 2,\n" +
                    "      \"operationType\": 1,\n" +
                    "      \"taxationType\": 4,\n" +
                    "      \"operator\": \"БАБУШКА-1\",\n" +
                    "      \"kktRegId\": \"0000418569025211    \",\n" +
                    "      \"fiscalDriveNumber\": \"9289000100057157\",\n" +
                    "      \"items\": [\n" +
                    "        {\n" +
                    "          \"name\": \"САМСА\",\n" +
                    "          \"price\": 13000,\n" +
                    "          \"quantity\": 1.0,\n" +
                    "          \"sum\": 13000\n" +
                    "        }\n" +
                    "      ],\n" +
                    "      \"totalSum\": 13000,\n" +
                    "      \"cashTotalSum\": 0,\n" +
                    "      \"ecashTotalSum\": 13000,\n" +
                    "      \"fiscalDocumentNumber\": 7,\n" +
                    "      \"fiscalSign\": 3739262599\n" +
                    "    }\n" +
                    "  }]")));


        OFDBatch result = konturOFDServiceStrategy.saveOFDDocuments(shopOperator, "2018-05-20", 4, batch);

        assertThat(result, notNullValue());
    }

}
