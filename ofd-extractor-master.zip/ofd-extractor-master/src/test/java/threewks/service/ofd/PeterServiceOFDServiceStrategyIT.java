package threewks.service.ofd;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.google.gson.GsonBuilder;
import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.json.GsonSupport;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.BatchStatus;
import threewks.model.KKTFiscalDrive;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.model.TradePoint;
import threewks.repository.OFDBatchRepository;
import threewks.repository.ReceiptDocumentRepository;
import threewks.service.ConfigParameterService;
import threewks.service.OFDBatchService;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;
import threewks.service.ofd.peterservice.PeterServiceOFDServiceStrategy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.googlecode.objectify.ObjectifyService.ofy;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PeterServiceOFDServiceStrategyIT {

    @Rule
    public final SetupAppengine setupAppengine = new SetupAppengine();

    @Rule
    public final SetupObjectify setupObjectify = new SetupObjectify(ShopOperator.class, OFDBatch.class);

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(8089);

    @Mock
    OFDBatchRepository batchRepository;

    @Mock
    ShopOperatorService shopOperatorService;

    @Mock
    private OFDDocumentUploadService ofdDocumentUploadService;

    @Mock
    private ReceiptDocumentRepository receiptDocumentRepository;

    @Mock
    private ConfigParameterService configParameterService;

    @Mock
    private OFDBatchService batchService;

    @Mock
    private TaskService taskService;

    PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy;


    @Before
    public void setUp() {
        try {
            GsonBuilder gsonBuilder = GsonSupport.createBasicGsonBuilder();
            peterServiceOFDServiceStrategy = new PeterServiceOFDServiceStrategy(gsonBuilder, "http://localhost:8089",
                "username", "password", shopOperatorService, batchRepository,
                batchService, receiptDocumentRepository, ofdDocumentUploadService, configParameterService, taskService);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void getReceipts_willOnlyDownloadReceiptsFromListedRegisters() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("NuanceBasel");
        shopOperator.setInn("2320163664");
        ofy().save().entity(shopOperator);
        TradePoint tradePoint1 = new TradePoint();
        tradePoint1.setName("Малина");
        List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();
        kktFiscalDrives.add(new KKTFiscalDrive("0001862244038417", "9286000100149133"));
        tradePoint1.setKktFiscalDrives(kktFiscalDrives);
        shopOperator.getTradePoints().add(tradePoint1);
        OFDBatch batch = new OFDBatch(shopOperator);
        ofy().save().entity(batch);

        when(receiptDocumentRepository.notExists("2b4e1320-42ea-9ff7-086c-ecb57e3f99bf")).thenReturn(true);
        when(receiptDocumentRepository.notExists("3d1dab01-ff36-589d-c938-335035243e37")).thenReturn(true);
        when(configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_USERNAME, "username")).thenReturn("username");
        when(configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_PASSWORD, "password")).thenReturn("password");
        wireMockRule.stubFor(post(urlEqualTo("/api/Authorization/CreateAuthToken"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{ \"AuthToken\": \"3e1cabd1c3684c0fae23e738b53398e4\"," +
                    " \"ExpirationDateUtc\": \"2018-12-29T05:17:19\"}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [\n" +
                    "                {\n" +
                    "                  \"Id\": \"e68e54b4-f3e7-4aab-b308-94bae9422655\",\n" +
                    "                  \"KktRegId\": \"0001862244038417\",\n" +
                    "                  \"SerialNumber\": \"009027221\",\n" +
                    "                  \"FnNumber\": \"9286000100149133\",\n" +
                    "                  \"CreateDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"CheckDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"ActivationDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"FirstDocumentDate\": \"2018-05-18T15:40:00\",\n" +
                    "                  \"ContractStartDate\": \"2018-06-03T00:00:00\",\n" +
                    "                  \"LastDocOnKktDateTime\": \"2019-01-03T12:05:00\",\n" +
                    "                  \"LastDocOnOfdDateTimeUtc\": \"2019-01-03T09:06:09\"\n" +
                    "                }," +
                    "                {\n" +
                    "                  \"Id\": \"a123b789-f3e7-4aab-b308-84cbe324ad43\",\n" +
                    "                  \"KktRegId\": \"0001862244056140\",\n" +
                    "                  \"SerialNumber\": \"009027288\",\n" +
                    "                  \"FnNumber\": \"9286000100149951\",\n" +
                    "                  \"CreateDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"CheckDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"ActivationDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"FirstDocumentDate\": \"2018-05-18T15:40:00\",\n" +
                    "                  \"ContractStartDate\": \"2018-06-03T00:00:00\",\n" +
                    "                  \"LastDocOnKktDateTime\": \"2019-01-03T12:05:00\",\n" +
                    "                  \"LastDocOnOfdDateTimeUtc\": \"2019-01-03T09:06:09\"\n" +
                    "                }]}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkt/0001862244038417/receipts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4&dateFrom=2018-05-15&dateTo=2018-05-16"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [{\n" +
                    "      \"Id\": \"2b4e1320-42ea-9ff7-086c-ecb57e3f99bf\",\n" +
                    "      \"CDateUtc\": \"2018-12-05T20:36:45\",\n" +
                    "      \"Tag\": 3,\n" +
                    "      \"IsBso\": false,\n" +
                    "      \"IsCorrection\": false,\n" +
                    "      \"OperationType\": \"Income\",\n" +
                    "      \"UserInn\": \"2320163664\",\n" +
                    "      \"KktRegNumber\": \"0001862244038417\",\n" +
                    "      \"FnNumber\": \"9286000100149133\",\n" +
                    "      \"DocNumber\": 50023,\n" +
                    "      \"DocDateTime\": \"2018-12-05T23:35:00\",\n" +
                    "      \"DocShiftNumber\": 209,\n" +
                    "      \"ReceiptNumber\": 224,\n" +
                    "      \"DocRawId\": \"2b4e1320-42ea-9ff7-086c-ecb57e3f99bf\",\n" +
                    "      \"TotalSumm\": 24900,\n" +
                    "      \"CashSumm\": 0,\n" +
                    "      \"ECashSumm\": 24900,\n" +
                    "      \"PrepaidSumm\": 0,\n" +
                    "      \"CreditSumm\": 0,\n" +
                    "      \"ProvisionSumm\": 0,\n" +
                    "      \"TaxTotalSumm\": 2264,\n" +
                    "      \"Tax10Summ\": 2264,\n" +
                    "      \"Tax18Summ\": 0,\n" +
                    "      \"Depth\": 1\n" +
                    "    }]}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkt/0001862244038417/receipts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4&dateFrom=2018-05-14&dateTo=2018-05-15"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [{\n" +
                    "      \"Id\": \"3d1dab01-ff36-589d-c938-335035243e37\",\n" +
                    "      \"CDateUtc\": \"2018-12-05T20:16:44\",\n" +
                    "      \"Tag\": 3,\n" +
                    "      \"IsBso\": false,\n" +
                    "      \"IsCorrection\": false,\n" +
                    "      \"OperationType\": \"Income\",\n" +
                    "      \"UserInn\": \"2320163664\",\n" +
                    "      \"KktRegNumber\": \"0001862244038417\",\n" +
                    "      \"FnNumber\": \"9286000100149133\",\n" +
                    "      \"DocNumber\": 50022,\n" +
                    "      \"DocDateTime\": \"2018-12-05T23:15:00\",\n" +
                    "      \"DocShiftNumber\": 209,\n" +
                    "      \"ReceiptNumber\": 223,\n" +
                    "      \"DocRawId\": \"3d1dab01-ff36-589d-c938-335035243e37\",\n" +
                    "      \"TotalSumm\": 47900,\n" +
                    "      \"CashSumm\": 47900,\n" +
                    "      \"ECashSumm\": 0,\n" +
                    "      \"PrepaidSumm\": 0,\n" +
                    "      \"CreditSumm\": 0,\n" +
                    "      \"ProvisionSumm\": 0,\n" +
                    "      \"TaxTotalSumm\": 6136,\n" +
                    "      \"Tax10Summ\": 1727,\n" +
                    "      \"Tax18Summ\": 4409,\n" +
                    "      \"Depth\": 3\n" +
                    "    }]}")));

        OFDBatch result = peterServiceOFDServiceStrategy.saveOFDDocuments(shopOperator, "2018-05-16", 1, batch);
        verify(taskService, times(1)).fetchIndividualReceipts(shopOperator.getId(), batch.getId(), "2320163664", "0001862244038417", "2b4e1320-42ea-9ff7-086c-ecb57e3f99bf", "3e1cabd1c3684c0fae23e738b53398e4");
        verify(taskService, times(1)).fetchIndividualReceipts(shopOperator.getId(), batch.getId(), "2320163664", "0001862244038417", "3d1dab01-ff36-589d-c938-335035243e37", "3e1cabd1c3684c0fae23e738b53398e4");
        verify(taskService, never()).fetchIndividualReceipts(eq(shopOperator.getId()), eq(batch.getId()), eq("2320163664"), eq("0001862244056140"), eq("2b4e1320-42ea-9ff7-086c-ecb57e3f99bf"), eq("3e1cabd1c3684c0fae23e738b53398e4"));
    }

    @Test
    public void getReceipts_willScheduleTaskForReceiptDownloading_whenReceiptDocumentDoesntExist() throws IOException {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("NuanceBasel");
        shopOperator.setInn("2320163664");
        ofy().save().entity(shopOperator);
        TradePoint tradePoint1 = new TradePoint();
        tradePoint1.setName("Малина");
        List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();
        kktFiscalDrives.add(new KKTFiscalDrive("0001707061045261", "8712000100089731"));
        tradePoint1.setKktFiscalDrives(kktFiscalDrives);
        shopOperator.getTradePoints().add(tradePoint1);
        OFDBatch batch = new OFDBatch(shopOperator);
        ofy().save().entity(batch);

        when(receiptDocumentRepository.notExists("2b4e1320-42ea-9ff7-086c-ecb57e3f99bf")).thenReturn(true);
        when(receiptDocumentRepository.notExists("3d1dab01-ff36-589d-c938-335035243e37")).thenReturn(true);
        when(configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_USERNAME, "username")).thenReturn("username");
        when(configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_PASSWORD, "password")).thenReturn("password");
        wireMockRule.stubFor(post(urlEqualTo("/api/Authorization/CreateAuthToken"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{ \"AuthToken\": \"3e1cabd1c3684c0fae23e738b53398e4\"," +
                    " \"ExpirationDateUtc\": \"2018-12-29T05:17:19\"}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [\n" +
                    "                {\n" +
                    "                  \"Id\": \"e68e54b4-f3e7-4aab-b308-94bae9422655\",\n" +
                    "                  \"KktRegId\": \"0001862244038417\",\n" +
                    "                  \"SerialNumber\": \"009027221\",\n" +
                    "                  \"FnNumber\": \"9286000100149133\",\n" +
                    "                  \"CreateDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"CheckDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"ActivationDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"FirstDocumentDate\": \"2018-05-18T15:40:00\",\n" +
                    "                  \"ContractStartDate\": \"2018-06-03T00:00:00\",\n" +
                    "                  \"LastDocOnKktDateTime\": \"2019-01-03T12:05:00\",\n" +
                    "                  \"LastDocOnOfdDateTimeUtc\": \"2019-01-03T09:06:09\"\n" +
                    "                }]}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkt/0001862244038417/receipts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4&dateFrom=2018-05-15&dateTo=2018-05-16"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [{\n" +
                    "      \"Id\": \"2b4e1320-42ea-9ff7-086c-ecb57e3f99bf\",\n" +
                    "      \"CDateUtc\": \"2018-12-05T20:36:45\",\n" +
                    "      \"Tag\": 3,\n" +
                    "      \"IsBso\": false,\n" +
                    "      \"IsCorrection\": false,\n" +
                    "      \"OperationType\": \"Income\",\n" +
                    "      \"UserInn\": \"2320163664\",\n" +
                    "      \"KktRegNumber\": \"0001862244038417\",\n" +
                    "      \"FnNumber\": \"9286000100149133\",\n" +
                    "      \"DocNumber\": 50023,\n" +
                    "      \"DocDateTime\": \"2018-12-05T23:35:00\",\n" +
                    "      \"DocShiftNumber\": 209,\n" +
                    "      \"ReceiptNumber\": 224,\n" +
                    "      \"DocRawId\": \"2b4e1320-42ea-9ff7-086c-ecb57e3f99bf\",\n" +
                    "      \"TotalSumm\": 24900,\n" +
                    "      \"CashSumm\": 0,\n" +
                    "      \"ECashSumm\": 24900,\n" +
                    "      \"PrepaidSumm\": 0,\n" +
                    "      \"CreditSumm\": 0,\n" +
                    "      \"ProvisionSumm\": 0,\n" +
                    "      \"TaxTotalSumm\": 2264,\n" +
                    "      \"Tax10Summ\": 2264,\n" +
                    "      \"Tax18Summ\": 0,\n" +
                    "      \"Depth\": 1\n" +
                    "    }]}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkt/0001862244038417/receipts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4&dateFrom=2018-05-14&dateTo=2018-05-15"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [{\n" +
                    "      \"Id\": \"3d1dab01-ff36-589d-c938-335035243e37\",\n" +
                    "      \"CDateUtc\": \"2018-12-05T20:16:44\",\n" +
                    "      \"Tag\": 3,\n" +
                    "      \"IsBso\": false,\n" +
                    "      \"IsCorrection\": false,\n" +
                    "      \"OperationType\": \"Income\",\n" +
                    "      \"UserInn\": \"2320163664\",\n" +
                    "      \"KktRegNumber\": \"0001862244038417\",\n" +
                    "      \"FnNumber\": \"9286000100149133\",\n" +
                    "      \"DocNumber\": 50022,\n" +
                    "      \"DocDateTime\": \"2018-12-05T23:15:00\",\n" +
                    "      \"DocShiftNumber\": 209,\n" +
                    "      \"ReceiptNumber\": 223,\n" +
                    "      \"DocRawId\": \"3d1dab01-ff36-589d-c938-335035243e37\",\n" +
                    "      \"TotalSumm\": 47900,\n" +
                    "      \"CashSumm\": 47900,\n" +
                    "      \"ECashSumm\": 0,\n" +
                    "      \"PrepaidSumm\": 0,\n" +
                    "      \"CreditSumm\": 0,\n" +
                    "      \"ProvisionSumm\": 0,\n" +
                    "      \"TaxTotalSumm\": 6136,\n" +
                    "      \"Tax10Summ\": 1727,\n" +
                    "      \"Tax18Summ\": 4409,\n" +
                    "      \"Depth\": 3\n" +
                    "    }]}")));

        OFDBatch result = peterServiceOFDServiceStrategy.saveOFDDocuments(shopOperator, "2018-05-16", 1, batch);

        assertThat(result.getStatus(), is(BatchStatus.RECEIPT_SUMMARIES_RETRIEVED));
        verify(taskService, times(1)).fetchIndividualReceipts(shopOperator.getId(), batch.getId(), "2320163664", "0001862244038417", "2b4e1320-42ea-9ff7-086c-ecb57e3f99bf", "3e1cabd1c3684c0fae23e738b53398e4");
        verify(taskService, times(1)).fetchIndividualReceipts(shopOperator.getId(), batch.getId(), "2320163664", "0001862244038417", "3d1dab01-ff36-589d-c938-335035243e37", "3e1cabd1c3684c0fae23e738b53398e4");
    }

    @Test
    public void getReceipts_willNotScheduleTaskForReceiptDownloading_whenReceiptDocumentsExist() throws IOException {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("NuanceBasel");
        shopOperator.setInn("2320163664");
        ofy().save().entity(shopOperator);
        TradePoint tradePoint1 = new TradePoint();
        tradePoint1.setName("Малина");
        List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();
        kktFiscalDrives.add(new KKTFiscalDrive("0001707061045261", "8712000100089731"));
        tradePoint1.setKktFiscalDrives(kktFiscalDrives);
        shopOperator.getTradePoints().add(tradePoint1);
        OFDBatch batch = new OFDBatch(shopOperator);
        ofy().save().entity(batch);

        when(receiptDocumentRepository.notExists("2b4e1320-42ea-9ff7-086c-ecb57e3f99bf")).thenReturn(false);
        when(receiptDocumentRepository.notExists("3d1dab01-ff36-589d-c938-335035243e37")).thenReturn(false);
        when(configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_USERNAME, "username")).thenReturn("username");
        when(configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_PASSWORD, "password")).thenReturn("password");
        wireMockRule.stubFor(post(urlEqualTo("/api/Authorization/CreateAuthToken"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{ \"AuthToken\": \"3e1cabd1c3684c0fae23e738b53398e4\"," +
                    " \"ExpirationDateUtc\": \"2018-12-29T05:17:19\"}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [\n" +
                    "                {\n" +
                    "                  \"Id\": \"e68e54b4-f3e7-4aab-b308-94bae9422655\",\n" +
                    "                  \"KktRegId\": \"0001862244038417\",\n" +
                    "                  \"SerialNumber\": \"009027221\",\n" +
                    "                  \"FnNumber\": \"9286000100149133\",\n" +
                    "                  \"CreateDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"CheckDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"ActivationDate\": \"2018-06-03T11:48:41\",\n" +
                    "                  \"FirstDocumentDate\": \"2018-05-18T15:40:00\",\n" +
                    "                  \"ContractStartDate\": \"2018-06-03T00:00:00\",\n" +
                    "                  \"LastDocOnKktDateTime\": \"2019-01-03T12:05:00\",\n" +
                    "                  \"LastDocOnOfdDateTimeUtc\": \"2019-01-03T09:06:09\"\n" +
                    "                }]}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkt/0001862244038417/receipts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4&dateFrom=2018-05-15&dateTo=2018-05-16"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [{\n" +
                    "      \"Id\": \"2b4e1320-42ea-9ff7-086c-ecb57e3f99bf\",\n" +
                    "      \"CDateUtc\": \"2018-12-05T20:36:45\",\n" +
                    "      \"Tag\": 3,\n" +
                    "      \"IsBso\": false,\n" +
                    "      \"IsCorrection\": false,\n" +
                    "      \"OperationType\": \"Income\",\n" +
                    "      \"UserInn\": \"2320163664\",\n" +
                    "      \"KktRegNumber\": \"0001862244038417\",\n" +
                    "      \"FnNumber\": \"9286000100149133\",\n" +
                    "      \"DocNumber\": 50023,\n" +
                    "      \"DocDateTime\": \"2018-12-05T23:35:00\",\n" +
                    "      \"DocShiftNumber\": 209,\n" +
                    "      \"ReceiptNumber\": 224,\n" +
                    "      \"DocRawId\": \"2b4e1320-42ea-9ff7-086c-ecb57e3f99bf\",\n" +
                    "      \"TotalSumm\": 24900,\n" +
                    "      \"CashSumm\": 0,\n" +
                    "      \"ECashSumm\": 24900,\n" +
                    "      \"PrepaidSumm\": 0,\n" +
                    "      \"CreditSumm\": 0,\n" +
                    "      \"ProvisionSumm\": 0,\n" +
                    "      \"TaxTotalSumm\": 2264,\n" +
                    "      \"Tax10Summ\": 2264,\n" +
                    "      \"Tax18Summ\": 0,\n" +
                    "      \"Depth\": 1\n" +
                    "    }]}")));

        wireMockRule.stubFor(get(urlEqualTo("/api/integration/v1/inn/2320163664/kkt/0001862244038417/receipts?AuthToken=3e1cabd1c3684c0fae23e738b53398e4&dateFrom=2018-05-14&dateTo=2018-05-15"))
            .willReturn(aResponse()
                .withStatus(200)
                .withHeader("Content-Type", "application/json")
                .withBody("{\"Status\": \"Success\",\n" +
                    "              \"Data\": [{\n" +
                    "      \"Id\": \"3d1dab01-ff36-589d-c938-335035243e37\",\n" +
                    "      \"CDateUtc\": \"2018-12-05T20:16:44\",\n" +
                    "      \"Tag\": 3,\n" +
                    "      \"IsBso\": false,\n" +
                    "      \"IsCorrection\": false,\n" +
                    "      \"OperationType\": \"Income\",\n" +
                    "      \"UserInn\": \"2320163664\",\n" +
                    "      \"KktRegNumber\": \"0001862244038417\",\n" +
                    "      \"FnNumber\": \"9286000100149133\",\n" +
                    "      \"DocNumber\": 50022,\n" +
                    "      \"DocDateTime\": \"2018-12-05T23:15:00\",\n" +
                    "      \"DocShiftNumber\": 209,\n" +
                    "      \"ReceiptNumber\": 223,\n" +
                    "      \"DocRawId\": \"3d1dab01-ff36-589d-c938-335035243e37\",\n" +
                    "      \"TotalSumm\": 47900,\n" +
                    "      \"CashSumm\": 47900,\n" +
                    "      \"ECashSumm\": 0,\n" +
                    "      \"PrepaidSumm\": 0,\n" +
                    "      \"CreditSumm\": 0,\n" +
                    "      \"ProvisionSumm\": 0,\n" +
                    "      \"TaxTotalSumm\": 6136,\n" +
                    "      \"Tax10Summ\": 1727,\n" +
                    "      \"Tax18Summ\": 4409,\n" +
                    "      \"Depth\": 3\n" +
                    "    }]}")));

        OFDBatch result = peterServiceOFDServiceStrategy.saveOFDDocuments(shopOperator, "2018-05-16", 1, batch);

        assertThat(result.getStatus(), is(BatchStatus.RECEIPT_SUMMARIES_RETRIEVED));
        verify(taskService, never()).fetchIndividualReceipts(shopOperator.getId(), batch.getId(), "2320163664", "0001862244038417", "2b4e1320-42ea-9ff7-086c-ecb57e3f99bf", "3e1cabd1c3684c0fae23e738b53398e4");
        verify(taskService, never()).fetchIndividualReceipts(shopOperator.getId(), batch.getId(), "2320163664", "0001862244038417", "3d1dab01-ff36-589d-c938-335035243e37", "3e1cabd1c3684c0fae23e738b53398e4");
    }

}
