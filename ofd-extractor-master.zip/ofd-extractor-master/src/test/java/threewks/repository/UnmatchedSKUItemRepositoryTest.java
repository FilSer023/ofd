package threewks.repository;

import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import threewks.model.UnmatchedSKUItem;

import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.spy;

@RunWith(MockitoJUnitRunner.class)
public class UnmatchedSKUItemRepositoryTest {

    @Rule
    public SetupObjectify setupObjectify = new SetupObjectify(UnmatchedSKUItem.class);

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();

    UnmatchedSKUItemRepository repository;

    @Before
    public void setup() {
        repository = new UnmatchedSKUItemRepository(null);
        repository = spy(repository);
    }

    @Test
    public void listOperatorsWithUnmatchedItems_willReturnOperatorNames() {
        repository.put(new UnmatchedSKUItem("Пирожок с вишней").setOperatorName("Три пескаря"));
        repository.put(new UnmatchedSKUItem("Пирожок с капустой").setOperatorName("Три пескаря"));
        repository.put(new UnmatchedSKUItem("Календарь-сувенир").setOperatorName("Символ Плюс"));

        List<String> result = repository.listOperatorsWithUnmatchedItems();

        assertThat(result, is(notNullValue()));
        assertThat(result.size(), is(2));
    }
}
