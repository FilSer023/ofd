package threewks.repository;

import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.search.test.MockSearch;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import threewks.model.ReceiptDocument;
import threewks.model.ShopOperator;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static threewks.TestData.testReceiptDocument;
import static threewks.model.ReceiptDocumentStatus.DOWNLOADED;
import static threewks.model.ReceiptDocumentStatus.ERROR;
import static threewks.model.ReceiptDocumentStatus.QUEUED;

public class ReceiptDocumentRepositoryTest {

    @Rule
    public SetupObjectify setupObjectify = new SetupObjectify(ReceiptDocument.class, ShopOperator.class);

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();

    private DateTime now = DateTime.now();
    private ReceiptDocumentRepository repository;

    @Before
    public void setup() {
        DateTimeUtils.setCurrentMillisFixed(now.getMillis());

        repository = new ReceiptDocumentRepository(null);
        repository = spy(repository);
        doReturn(new MockSearch<ReceiptDocument, String>(new ArrayList<ReceiptDocument>(), null)).when(repository).search();
    }

    @Test
    public void getBatchStats_willReturnBatchStats() {
        ShopOperator shopOperator = new ShopOperator();
        ReceiptDocument queued1 = testReceiptDocument(shopOperator, "batchId", "receiptId1", "kktRegId", "230011", QUEUED);
        repository.put(queued1);
        ReceiptDocument queued2 = testReceiptDocument(shopOperator, "batchId", "receiptId2", "kktRegId", "230011", QUEUED);
        repository.put(queued2);
        ReceiptDocument downloaded1 = testReceiptDocument(shopOperator, "batchId", "receiptId3", "kktRegId", "230011", DOWNLOADED);
        repository.put(downloaded1);

        Map<String, Integer> stats = repository.getBatchStats("batchId");

        assertThat(stats, is(notNullValue()));
        assertThat(stats.get(QUEUED.name()), is(2));
        assertThat(stats.get(DOWNLOADED.name()), is(1));
        assertThat(stats.get(ERROR.name()), is(0));
    }

    @Test
    public void deleteOldReceipts_willDeleteOldAndWillKeepRecentReceipts() {
        ShopOperator shopOperator = new ShopOperator();
        LocalDate old = LocalDate.now().minusDays(90);
        Date threeMonthsAgo = Date.from(old.atStartOfDay()
            .atZone(ZoneId.systemDefault())
            .toInstant());
        ReceiptDocument oldDocument = testReceiptDocument(shopOperator, "batchId", "receiptId1", "kktRegId", "230011", threeMonthsAgo, QUEUED);
        repository.put(oldDocument);
        ReceiptDocument recentDocument = testReceiptDocument(shopOperator, "batchId", "newReceiptId1", "kktRegId", "230011", QUEUED);
        repository.put(recentDocument);
        ReceiptDocument recentDocument2 = testReceiptDocument(shopOperator, "batchId", "newReceiptId2", "kktRegId", "230011", QUEUED);
        repository.put(recentDocument2);

        repository.deleteOldReceipts();

        List<ReceiptDocument> current = repository.listAll();
        assertThat(current, is(notNullValue()));
        assertThat(current.size(), is(2));
        assertThat(current.get(0).getDocRawId(), is("newReceiptId1"));
        assertThat(current.get(1).getDocRawId(), is("newReceiptId2"));
    }

    @Test
    public void deleteByShopOperatorAndDateRange_willDeleteSpecificReceipts() {
        ShopOperator shopOperator = new ShopOperator();
        Date ninetyDaysAgo = Date.from(LocalDate.now().minusDays(90).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        Date ninetyOneDayAgo = Date.from(LocalDate.now().minusDays(91).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        Date eightyNineDaysAgo = Date.from(LocalDate.now().minusDays(89).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        Date eightyEightDaysAgo = Date.from(LocalDate.now().minusDays(88).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
        ReceiptDocument downloaded1 = testReceiptDocument(shopOperator, "batchId", "receiptId1", "kktRegId", "230011", ninetyDaysAgo, DOWNLOADED);
        ReceiptDocument downloaded2 = testReceiptDocument(shopOperator, "batchId", "receiptId2", "kktRegId", "230011", ninetyDaysAgo, DOWNLOADED);
        ReceiptDocument downloaded3 = testReceiptDocument(shopOperator, "batchId", "receiptId3", "kktRegId", "230011", ninetyOneDayAgo, DOWNLOADED);
        ReceiptDocument downloaded4 = testReceiptDocument(shopOperator, "batchId", "receiptId4", "kktRegId", "230011", eightyNineDaysAgo, DOWNLOADED);
        ReceiptDocument downloaded5 = testReceiptDocument(shopOperator, "batchId", "receiptId5", "kktRegId", "230011", eightyEightDaysAgo, DOWNLOADED);
        repository.put(downloaded1);
        repository.put(downloaded2);
        repository.put(downloaded3);
        repository.put(downloaded4);
        repository.put(downloaded5);

        repository.deleteByShopOperatorAndDateRange(shopOperator, ninetyDaysAgo, 1);

        //Receipts 3 and 5 should remain, they are outside specified range
        List<ReceiptDocument> current = repository.listAll();
        assertThat(current, is(notNullValue()));
        assertThat(current.size(), is(2));
        assertThat(current.get(0).getDocRawId(), is("receiptId3"));
        assertThat(current.get(1).getDocRawId(), is("receiptId5"));
    }

}
