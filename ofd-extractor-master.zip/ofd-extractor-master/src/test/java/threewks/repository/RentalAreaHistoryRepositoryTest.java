package threewks.repository;

import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.search.test.MockSearch;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import threewks.model.RentalArea;
import threewks.model.RentalAreaHistory;
import threewks.model.ShopOperator;

import java.util.ArrayList;
import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

public class RentalAreaHistoryRepositoryTest {

    @Rule
    public SetupObjectify setupObjectify = new SetupObjectify(ShopOperator.class, RentalArea.class, RentalAreaHistory.class);

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();

    private DateTime now = DateTime.now();
    private RentalAreaHistoryRepository repository;

    @Before
    public void setup() {
        DateTimeUtils.setCurrentMillisFixed(now.getMillis());

        repository = new RentalAreaHistoryRepository(null);
        repository = spy(repository);
        doReturn(new MockSearch<RentalAreaHistory, String>(new ArrayList<RentalAreaHistory>(), null)).when(repository).search();
    }

    @Test
    public void listByRentalArea_willReturnOnlyRelevantAreaHistory() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("Test1");
        ofy().save().entity(shopOperator);

        RentalArea rentalArea1 = new RentalArea();
        rentalArea1.setName("RentalZone1");
        ofy().save().entity(rentalArea1);

        RentalArea rentalArea2 = new RentalArea();
        rentalArea2.setName("RentalZone1");
        ofy().save().entity(rentalArea2);

        RentalAreaHistory rentalAreaHistory1 = new RentalAreaHistory(rentalArea1);
        rentalAreaHistory1.setRentalArea(rentalArea1);
        rentalAreaHistory1.setCurrentShopOperator(shopOperator);
        repository.put(rentalAreaHistory1);

        RentalAreaHistory rentalAreaHistory2 = new RentalAreaHistory(rentalArea2);
        rentalAreaHistory2.setRentalArea(rentalArea2);
        rentalAreaHistory2.setCurrentShopOperator(shopOperator);
        repository.put(rentalAreaHistory2);

        List<RentalAreaHistory> histories = repository.listByRentalArea(rentalArea1);

        assertThat(histories, is(notNullValue()));
        assertThat(histories.size(), is(1));
    }

    @Test
    public void listByShopOperator_willReturnAllAreaHistory() {
        ShopOperator shopOperator = new ShopOperator();
        shopOperator.setName("Test1");
        ofy().save().entity(shopOperator);

        ShopOperator shopOperatorAnother = new ShopOperator();
        shopOperatorAnother.setName("TestA");
        ofy().save().entity(shopOperatorAnother);

        RentalArea rentalArea1 = new RentalArea();
        rentalArea1.setName("RentalZone1");
        ofy().save().entity(rentalArea1);

        RentalArea rentalArea2 = new RentalArea();
        rentalArea2.setName("RentalZone2");
        ofy().save().entity(rentalArea2);

        RentalArea rentalArea3 = new RentalArea();
        rentalArea3.setName("RentalZone3");
        ofy().save().entity(rentalArea3);

        RentalAreaHistory rentalAreaHistory1 = new RentalAreaHistory(rentalArea1);
        rentalAreaHistory1.setRentalArea(rentalArea1);
        rentalAreaHistory1.setCurrentShopOperator(shopOperator);
        repository.put(rentalAreaHistory1);

        RentalAreaHistory rentalAreaHistory2 = new RentalAreaHistory(rentalArea2);
        rentalAreaHistory2.setRentalArea(rentalArea2);
        rentalAreaHistory2.setPreviousShopOperator(shopOperator);
        repository.put(rentalAreaHistory2);

        RentalAreaHistory rentalAreaHistory3 = new RentalAreaHistory(rentalArea3);
        rentalAreaHistory3.setRentalArea(rentalArea3);
        rentalAreaHistory3.setPreviousShopOperator(shopOperatorAnother);
        repository.put(rentalAreaHistory3);

        List<RentalAreaHistory> histories = repository.listByShopOperator(shopOperator);

        assertThat(histories, is(notNullValue()));
        assertThat(histories.size(), is(2));
    }

}
