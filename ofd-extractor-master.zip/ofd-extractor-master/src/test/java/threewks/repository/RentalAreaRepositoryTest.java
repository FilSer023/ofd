package threewks.repository;

import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import threewks.model.AirportCatalog;
import threewks.model.RentalArea;

import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.spy;

public class RentalAreaRepositoryTest {

    @Rule
    public SetupObjectify setupObjectify = new SetupObjectify(RentalArea.class, AirportCatalog.class);

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();

    private DateTime now = DateTime.now();
    private RentalAreaRepository repository;

    @Before
    public void setup() {
        DateTimeUtils.setCurrentMillisFixed(now.getMillis());

        repository = new RentalAreaRepository(null);
        repository = spy(repository);
//        doReturn(new MockSearch<RentalArea, String>(new ArrayList<RentalArea>(), null)).when(repository).search();
    }

    @Test
    public void listByAirport_willFindRelevantAreas() {
        AirportCatalog airportKrr1 = new AirportCatalog();
        ofy().save().entity(airportKrr1.setNameIATA("KRR1").setDescription("Krasnodar1")).now();
        AirportCatalog airportAer1 = new AirportCatalog();
        ofy().save().entity(airportAer1.setNameIATA("AER1").setDescription("Sochi1")).now();

        RentalArea rentalArea1 = new RentalArea();
        repository.put(rentalArea1.setName("2.1 KRR").setAirportCatalog(airportKrr1));

        RentalArea rentalArea2 = new RentalArea();
        repository.put(rentalArea2.setName("2.2 KRR").setAirportCatalog(airportKrr1));

        RentalArea rentalAreaAer1 = new RentalArea();
        repository.put(rentalAreaAer1.setName("1.1 AER").setAirportCatalog(airportAer1));

        List<RentalArea> rentalAreasForKrasnodar = repository.listByAirport(airportKrr1);

        assertThat(rentalAreasForKrasnodar, is(notNullValue()));
        assertThat(rentalAreasForKrasnodar.size(), is(2));
    }


}
