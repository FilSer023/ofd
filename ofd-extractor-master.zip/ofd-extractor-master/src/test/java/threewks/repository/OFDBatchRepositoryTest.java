package threewks.repository;

import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import com.threewks.thundr.search.test.MockSearch;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.util.Arrays.asList;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

public class OFDBatchRepositoryTest {

    @Rule
    public SetupObjectify setupObjectify = new SetupObjectify(OFDBatch.class, ShopOperator.class);

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();

    private DateTime now = DateTime.now();
    private OFDBatchRepository repository;

    @Before
    public void setup() {
        DateTimeUtils.setCurrentMillisFixed(now.getMillis());

        repository = new OFDBatchRepository(null);
        repository = spy(repository);
        doReturn(new MockSearch<OFDBatch, String>(new ArrayList<OFDBatch>(), null)).when(repository).search();
    }

    @Test
    public void getRecentBatches_willReturnOnlyRecentBatches() {
        ShopOperator shopOperator = new ShopOperator();
        OFDBatch batch1 = new OFDBatch(shopOperator);
        batch1.setTimeStarted(Date.from(LocalDate.now().atStartOfDay(ZoneId.of("UTC+3")).minusDays(1).toInstant()));
        batch1.setTimeFinished(Date.from(LocalDate.now().atStartOfDay(ZoneId.of("UTC+3")).minusDays(1).toInstant()));
        repository.put(batch1);

        OFDBatch batch2 = new OFDBatch(shopOperator);
        batch2.setTimeStarted(Date.from(LocalDate.now().minusDays(15).atStartOfDay(ZoneId.of("UTC+3")).toInstant()));
        batch2.setTimeFinished(Date.from(LocalDate.now().minusDays(15).atStartOfDay(ZoneId.of("UTC+3")).toInstant()));
        repository.put(batch2);


        List<OFDBatch> batches = repository.getRecentBatches(0, null);

        assertThat(batches, is(notNullValue()));
        assertThat(batches.size(), is(1));
    }

    @Test
    public void getRecentBatches_willNotReturnOldBatches() {
        ShopOperator shopOperator = new ShopOperator();
        OFDBatch batch1 = new OFDBatch(shopOperator);
        batch1.setTimeStarted(Date.from(LocalDate.now().minusDays(13).atStartOfDay(ZoneId.systemDefault()).toInstant()));
        batch1.setTimeFinished(Date.from(LocalDate.now().minusDays(13).atStartOfDay(ZoneId.systemDefault()).toInstant()));
        repository.put(batch1);

        OFDBatch batch2 = new OFDBatch(shopOperator);
        batch2.setTimeStarted(Date.from(LocalDate.now().minusDays(15).atStartOfDay(ZoneId.systemDefault()).toInstant()));
        batch2.setTimeFinished(Date.from(LocalDate.now().minusDays(15).atStartOfDay(ZoneId.systemDefault()).toInstant()));
        repository.put(batch2);


        List<OFDBatch> batches = repository.getRecentBatches(0, null);

        assertThat(batches, is(notNullValue()));
        assertThat(batches.size(), is(0));
    }

    @Test
    public void getRecentBatchesWithFilter_willReturnOldMatchingBatches_whenSearchingWithOffset() {
        ShopOperator shopOperator = new ShopOperator();
        OFDBatch batch1 = new OFDBatch(shopOperator);
        batch1.setTimeStarted(Date.from(LocalDate.now().atStartOfDay(ZoneId.of("UTC+3")).minusDays(100).toInstant()));
        batch1.setTimeFinished(Date.from(LocalDate.now().atStartOfDay(ZoneId.of("UTC+3")).minusDays(100).toInstant()));
        batch1.setStatus(BatchStatus.ERROR);
        repository.put(batch1);

        OFDBatch batch2 = new OFDBatch(shopOperator);
        batch2.setTimeStarted(Date.from(LocalDate.now().minusDays(15).atStartOfDay(ZoneId.of("UTC+3")).toInstant()));
        batch2.setTimeFinished(Date.from(LocalDate.now().minusDays(15).atStartOfDay(ZoneId.of("UTC+3")).toInstant()));
        repository.put(batch2);


        List<OFDBatch> batches = repository.getRecentBatches(0, asList(BatchStatus.ERROR));

        assertThat(batches, is(notNullValue()));
        assertThat(batches.size(), is(1));
        assertThat(batches.get(0).getId(), is(batch1.getId()));
    }

}
