package threewks.repository;

import com.threewks.thundr.gae.SetupAppengine;
import com.threewks.thundr.gae.objectify.SetupObjectify;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import threewks.model.AirportCatalog;
import threewks.model.RentalArea;
import threewks.model.ShopOperator;
import threewks.model.TradePoint;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static java.util.Arrays.asList;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.spy;

public class ShopOperatorRepositoryTest {

    @Rule
    public SetupObjectify setupObjectify = new SetupObjectify(RentalArea.class, AirportCatalog.class, ShopOperator.class);

    @Rule
    public SetupAppengine setupAppengine = new SetupAppengine();

    private DateTime now = DateTime.now();
    private ShopOperatorRepository repository;

    @Before
    public void setup() {
        DateTimeUtils.setCurrentMillisFixed(now.getMillis());

        repository = new ShopOperatorRepository(null);
        repository = spy(repository);
//        doReturn(new MockSearch<RentalArea, String>(new ArrayList<RentalArea>(), null)).when(repository).search();
    }

    @Test
    public void findByRentalArea_willFindRelevantShopOperator() {
        AirportCatalog airportKrr1 = new AirportCatalog();
        ofy().save().entity(airportKrr1.setNameIATA("KRR1").setDescription("Krasnodar1")).now();
        AirportCatalog airportAer1 = new AirportCatalog();
        ofy().save().entity(airportAer1.setNameIATA("AER1").setDescription("Sochi1")).now();

        RentalArea rentalArea1 = new RentalArea();
        ofy().save().entity(rentalArea1.setName("2.1 KRR").setAirportCatalog(airportKrr1)).now();

        RentalArea rentalArea2 = new RentalArea();
        ofy().save().entity(rentalArea2.setName("2.2 KRR").setAirportCatalog(airportKrr1)).now();

        ShopOperator shopOperator1 = new ShopOperator();
        shopOperator1.setName("Test1");
        shopOperator1.setRentalAreas(asList(rentalArea1));
        TradePoint tradePoint1 = new TradePoint();
        tradePoint1
            .setName("TestPoint1")
            .setRentalAreaRef(rentalArea1);
        shopOperator1.getTradePoints().add(tradePoint1);
        repository.put(shopOperator1);

        List<ShopOperator> shopOperators = repository.listByRentalArea(rentalArea1);
        Map<RentalArea, String> tradePoints = shopOperators.stream().flatMap(shopOperator -> shopOperator.getTradePoints().stream())
            .filter(tradePoint -> tradePoint.getRentalAreaRef() != null && StringUtils.isNotBlank(tradePoint.getName()))
            .collect(Collectors.toMap(TradePoint::getRentalAreaRef, TradePoint::getName));

        assertThat(shopOperators, is(notNullValue()));
        assertThat(shopOperators.size(), is(1));
    }


}
