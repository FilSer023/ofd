package threewks;

import threewks.framework.usermanager.model.AppUser;
import threewks.model.BaseEntity;
import threewks.model.ReceiptDocument;
import threewks.model.ReceiptDocumentStatus;
import threewks.model.ShopOperator;

import java.lang.reflect.Method;
import java.util.Date;

import static java.util.UUID.randomUUID;

public class TestData {

    public static AppUser user() {
        return user("dummy@example.com");
    }

    public static AppUser user(String email) {
        AppUser user = new AppUser(randomUUID().toString());
        user.setEmail(email);
        return user;
    }

    public static ReceiptDocument testReceiptDocument(ShopOperator shopOperator, String batchId, String receiptId, String kktRegId, String inn, ReceiptDocumentStatus status) {
        return testReceiptDocument(shopOperator, batchId, receiptId, kktRegId, inn, new Date(), status);
    }

    public static ReceiptDocument testReceiptDocument(ShopOperator shopOperator, String batchId, String receiptId, String kktRegId, String inn, Date created, ReceiptDocumentStatus status) {
        ReceiptDocument queued1 = new ReceiptDocument();
        queued1.setId(receiptId)
            .setBatchId(batchId)
            .setDocRawId(receiptId)
            .setCreated(created)
            .setKktRegId(kktRegId)
            .setInn(inn)
            .setShopOperator(shopOperator)
            .setStatus(status);
        return queued1;
    }

    public static void setAuditableFieldsOnSave(BaseEntity entity) {
        try {
            Method method = BaseEntity.class.getDeclaredMethod("setAuditableFieldsOnSave");
            method.setAccessible(true);
            method.invoke(entity);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException("Unexpected exception calling setAuditableFieldsOnSave", e);
        }

    }
}
