package threewks.util;

import com.google.common.base.Joiner;
import org.apache.commons.lang3.StringUtils;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import static java.util.Arrays.asList;

public class SearchUtil {

    public static String getSearchableText(int minLength, String... strings) {
        Set<String> allUppercaseSubstrings = new LinkedHashSet<>();

        for (String sourceString : strings) {
            String string = StringUtils.upperCase(StringUtils.trimToNull(sourceString));
            if (string != null) {

                List<String> entries = asList(StringUtils.split(string));
                allUppercaseSubstrings.addAll(entries);
                for (String entry : entries) {
                    Set<String> upperCaseSubstrings = getAllSubstrings(minLength, entry);
                    allUppercaseSubstrings.addAll(upperCaseSubstrings);
                }
            }
        }
        return Joiner.on(" ").join(allUppercaseSubstrings);
    }

    private static Set<String> getAllSubstrings(int minLength, String str) {
        Set<String> substrings = new LinkedHashSet<>();
        for (int length = minLength; length <= str.length(); length++) {

            for (int start = 0; start + length <= str.length(); length++) {
                String subString = str.substring(start, start + length).trim();
                if (StringUtils.isNotEmpty(subString)) {
                    substrings.add(subString);
                }
            }

        }

        return substrings;
    }

}
