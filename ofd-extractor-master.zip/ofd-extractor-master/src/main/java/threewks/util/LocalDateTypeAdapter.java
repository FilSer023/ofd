package threewks.util;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.format.ISODateTimeFormat;

import java.lang.reflect.Type;

public class LocalDateTypeAdapter implements JsonSerializer<LocalDate>, JsonDeserializer<LocalDate> {

    private final boolean dateAsString;
    private final DateTimeZone dateTimeZone;

    private LocalDateTypeAdapter(boolean dateAsString, DateTimeZone dateTimeZone) {
        this.dateAsString = dateAsString;
        this.dateTimeZone = dateTimeZone;
    }

    public static LocalDateTypeAdapter asString() {
        return new LocalDateTypeAdapter(true, null);
    }

    public static LocalDateTypeAdapter asNumber() {
        return new LocalDateTypeAdapter(false, DateTimeZone.getDefault());
    }

    public static LocalDateTypeAdapter asNumber(DateTimeZone timeZone) {
        return new LocalDateTypeAdapter(false, timeZone);
    }

    @Override
    public JsonElement serialize(LocalDate src, Type typeOfSrc, JsonSerializationContext context) {
        return dateAsString
            ? new JsonPrimitive(src.toString())
            : new JsonPrimitive(src.toDateTimeAtStartOfDay(dateTimeZone).getMillis());
    }

    @Override
    public LocalDate deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        return dateAsString ? LocalDateTime.parse(json.getAsString(), ISODateTimeFormat.dateTimeParser()).toLocalDate() : new LocalDate(json.getAsLong(), dateTimeZone);
    }

}
