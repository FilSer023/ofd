package threewks.util;

import com.google.common.collect.Sets;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.request.HttpRequest;
import com.mashape.unirest.request.body.Body;
import com.mashape.unirest.request.body.RequestBodyEntity;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

public class HttpUtils {
    // Add any headers we don't want to log the value for. Be sure to use all lowercase
    private static final Set<String> LOWERCASE_SECURE_REQUEST_HEADERS = Sets.newHashSet(
        "client_secret",
        "apisessiontoken"
    );

    public static void logRequestHeaders(HttpRequest req) {
        StringBuilder stringBuilder = buildRequestHeaders(req);
        Logger.info("Request detail (headers only): %n%s%n", stringBuilder);
    }

    public static void logRequest(HttpRequest req) {
        StringBuilder stringBuilder = buildRequestHeaders(req);

        addLoggableBody(stringBuilder, req.getBody(), "Request Body:");

        Logger.info("Request detail: %n%s%n", stringBuilder);
    }

    public static void logResponseHeaders(HttpResponse response) {
        StringBuilder stringBuilder = buildResponseHeaders(response);
        Logger.info("Response detail (headers only): %n%s%n", stringBuilder);
    }

    public static void logResponse(HttpResponse response) {
        StringBuilder stringBuilder = buildResponseHeaders(response);

        addLoggableBody(stringBuilder, response.getBody(), "Response Body:");

        Logger.info("Response detail: %n%s%n", stringBuilder);
    }

    private static StringBuilder buildRequestHeaders(HttpRequest requestImpl) {
        StringBuilder stringBuilder = new StringBuilder();

        append(stringBuilder, "Request URL:     %s", requestImpl.getUrl());

        appendBody(stringBuilder, "Request Parameters:", requestImpl.getBody(), "-->");
        appendHeaders(stringBuilder, "Request Headers:", requestImpl.getHeaders(), "-->");
        return stringBuilder;
    }

    private static StringBuilder buildResponseHeaders(HttpResponse response) {
        StringBuilder stringBuilder = new StringBuilder();

        append(stringBuilder, "Response Status:       %s", response.getStatus());

        appendHeaders(stringBuilder, "Response Headers:", response.getHeaders(), "<--");
        return stringBuilder;
    }

    private static void appendBody(StringBuilder stringBuilder, String title, Body body, final String separator) {
        RequestBodyEntity requestBodyEntity = (RequestBodyEntity) body;
        if (body != null) {
            append(stringBuilder, "%s", requestBodyEntity.getBody());
        }
    }

    private static void appendHeaders(StringBuilder stringBuilder, String title, Map<String, ?> headersOrParams, final String separator) {
        if (!headersOrParams.isEmpty()) {
            append(stringBuilder, title);

            // Sort keys so it's easier to compare requests as there will be consistent ordering
            TreeSet<String> sortedKeys = new TreeSet<>(headersOrParams.keySet());
            for (String header : sortedKeys) {
                append(stringBuilder, "  %s %s %s", StringUtils.rightPad(header, 25), separator, getValue(headersOrParams, header));
            }
        }
    }

    private static String getValue(Map<String, ?> headersOrParams, String key) {
        return LOWERCASE_SECURE_REQUEST_HEADERS.contains(key.toLowerCase())
            ? "***** masked *****"
            : Objects.toString(headersOrParams.get(key));
    }

    private static void addLoggableBody(StringBuilder stringBuilder, Object bodyObject, String label) {
        String bodyString = Objects.toString(bodyObject, null);
        if (StringUtils.isNotEmpty(bodyString)) {
            append(stringBuilder, label);
            append(stringBuilder, "  %s", StringUtils.abbreviate(bodyString, 10_000));

            append(stringBuilder, "[END BODY]");
        }
    }

    private static void append(StringBuilder stringBuilder, String format, Object... args) {
        stringBuilder.append("    ");
        stringBuilder.append(String.format(format, args));
        stringBuilder.append('\n');
    }

}

