package threewks.util;

import org.apache.commons.lang3.RandomStringUtils;

import java.math.BigInteger;

public class IdUtil {

	public static String generateUniqueId() {
		String result = Base32.crockfords.format(new BigInteger(String.valueOf(System.currentTimeMillis()))).toString();
		String extraRandom = RandomStringUtils.random(3, Base32.crockfordCharacterSet);
		String id = String.format("%s%s", result, extraRandom);
		return id;
	}

}
