package threewks.framework.usermanager.model;

public class AppRoles {

    public static final String Administrator = "admin";

    private AppRoles() {
    }

}
