package threewks.framework.usermanager.controller.dto.transformer;

public class Transformers {
    public static final ToUserDto TO_USER_DTO = new ToUserDto();
}
