package threewks.framework.mail;

import com.atomicleopard.expressive.Expressive;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.mail.Attachment;
import com.threewks.thundr.mail.BaseMailer;
import com.threewks.thundr.mail.MailBuilder;
import com.threewks.thundr.mail.Mailer;
import com.threewks.thundr.request.RequestContainer;
import com.threewks.thundr.view.ViewResolverRegistry;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DivertingMailer extends BaseMailer {
    Mailer delegate;
    List<String> divertEmailsTo;
    boolean disableEmails;
    ViewResolverRegistry viewResolverRegistry;
    RequestContainer requestContainer;

    public DivertingMailer(String divertEmailsTo, boolean disableEmails, Mailer delegate, ViewResolverRegistry viewResolverRegistry, RequestContainer requestContainer) {
        super(viewResolverRegistry, requestContainer);
        this.delegate = delegate;
        String[] stringArray = StringUtils.split(StringUtils.remove(divertEmailsTo, " "), ',');
        this.divertEmailsTo = stringArray == null || stringArray.length < 1 ? null : Arrays.asList(stringArray);
        this.disableEmails = disableEmails;
        if (this.disableEmails) {
            Logger.info("Disabled emails in this environment");
        } else if (this.divertEmailsTo != null) {
            Logger.info("Will divert emails to %s", this.divertEmailsTo);
        }
    }

    @Override
    protected void sendInternal(Map.Entry<String, String> from, Map.Entry<String, String> replyTo, Map<String, String> to, Map<String, String> cc, Map<String, String> bcc, String subject, Object body,
            List<Attachment> attachments) {
        if (!disableEmails) {
            to = rewriteRecipients(to);
            cc = rewriteRecipients(cc);
            bcc = rewriteRecipients(bcc);

            Map.Entry<String, String> replyToEntry = ObjectUtils.firstNonNull(replyTo, from);
            // @formatter:off
		MailBuilder mailBuilder = delegate.mail()
				.from(from.getKey(), from.getValue())
				.replyTo(replyToEntry.getKey(), replyToEntry.getValue())
				.to(to)
				.subject(subject)
				.body(body);
		// @formatter:on
            if (Expressive.isNotEmpty(cc)) {
                mailBuilder = mailBuilder.cc(cc);
            }
            if (Expressive.isNotEmpty(bcc)) {
                mailBuilder = mailBuilder.bcc(bcc);
            }
            for (Attachment attachment : attachments) {
                mailBuilder = mailBuilder.attach(attachment.name(), attachment.view(), attachment.disposition());
            }
            mailBuilder.send();
        }
    }

    Map<String, String> rewriteRecipients(Map<String, String> to) {
        if (to != null && !to.isEmpty() && this.divertEmailsTo != null) {
            String divertedFrom = "Diverted from " + StringUtils.replace(StringUtils.join(to.keySet(), " and "), "@", " at ");
            Map<String, String> result = new LinkedHashMap();
            Iterator var4 = this.divertEmailsTo.iterator();

            while(var4.hasNext()) {
                String newRecipient = (String)var4.next();
                result.put(newRecipient, divertedFrom);
            }

            Logger.info("Diverting email to: %s", new Object[]{result});
            return result;
        } else {
            return to;
        }
    }
}
