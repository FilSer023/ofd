package threewks.controller;

import threewks.model.PassengerFeedBatchStatus;

import java.util.List;

public class DashboardPassengerFeedFilter {

    private String daysOffset;
    private List<PassengerFeedBatchStatus> filteredStatus;

    public String getDaysOffset() {
        return daysOffset;
    }

    public DashboardPassengerFeedFilter setDaysOffset(String daysOffset) {
        this.daysOffset = daysOffset;
        return this;
    }

    public List<PassengerFeedBatchStatus> getFilteredStatus() {
        return filteredStatus;
    }

    public DashboardPassengerFeedFilter setFilteredStatus(List<PassengerFeedBatchStatus> filteredStatus) {
        this.filteredStatus = filteredStatus;
        return this;
    }
}
