package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.User;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.model.dto.PassengerFeedBatchDto;
import threewks.service.passengerfeed.PassengerFeedBatchService;

import java.util.stream.Collectors;

public class PassengerFeedBatchController {

    private final PassengerFeedBatchService passengerFeedBatchService;

    public PassengerFeedBatchController(PassengerFeedBatchService passengerFeedBatchService) {
        this.passengerFeedBatchService = passengerFeedBatchService;
    }

    @Authenticated
    public JsonView list(DashboardPassengerFeedFilter filter) {
        return new JsonView(this.passengerFeedBatchService.getRecentBatches(Integer.valueOf(filter.getDaysOffset()), filter.getFilteredStatus()).stream()
            .map(batch -> PassengerFeedBatchDto.from(batch)).collect(Collectors.toList()));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView toggleReviewed(User user, String batchId) {
        return new JsonView(this.passengerFeedBatchService.toggleReviewed(user, batchId));
    }

}
