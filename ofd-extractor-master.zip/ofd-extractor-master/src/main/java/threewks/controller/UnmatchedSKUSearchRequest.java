package threewks.controller;

import java.util.List;

public class UnmatchedSKUSearchRequest {
    private List<String> operatorNames;
    private String sku;
    private int offset;

    public UnmatchedSKUSearchRequest() {
    }

    public UnmatchedSKUSearchRequest(List<String> operatorNames, String sku, int offset) {
        this.operatorNames = operatorNames;
        this.sku = sku;
        this.offset = offset;
    }

    public UnmatchedSKUSearchRequest setOperatorNames(List<String> operatorNames) {
        this.operatorNames = operatorNames;
        return this;
    }

    public UnmatchedSKUSearchRequest setSku(String sku) {
        this.sku = sku;
        return this;
    }

    public int getOffset() {
        return offset;
    }

    public UnmatchedSKUSearchRequest setOffset(int offset) {
        this.offset = offset;
        return this;
    }

    public List<String> getOperatorNames() {
        return operatorNames;
    }

    public String getSku() {
        return sku;
    }

}
