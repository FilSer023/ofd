package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.framework.usermanager.model.AppUser;
import threewks.model.dto.PassengerFeedManualUploadDTO;
import threewks.service.PassengerFeedManualUploadService;

public class PassengerFeedManualUploadController {
    private final PassengerFeedManualUploadService passengerFeedManualUploadService;

    public PassengerFeedManualUploadController(PassengerFeedManualUploadService passengerFeedManualUploadService) {
        this.passengerFeedManualUploadService = passengerFeedManualUploadService;
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView startUpload(PassengerFeedManualUploadDTO passengerFeedManualUploadDTO, AppUser user) {
        passengerFeedManualUploadService.startPassengerFeedDataUpload(passengerFeedManualUploadDTO, user);
        return new JsonView("ok");
    }
}
