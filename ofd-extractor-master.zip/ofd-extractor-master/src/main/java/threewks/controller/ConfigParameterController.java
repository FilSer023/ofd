package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.model.ConfigParameter;
import threewks.service.ConfigParameterService;

public class ConfigParameterController {
    private final ConfigParameterService configParameterService;

    public ConfigParameterController(ConfigParameterService configParameterService) {
        this.configParameterService = configParameterService;
    }

    @Authenticated
    public JsonView list() {
        return new JsonView(this.configParameterService.list());
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView save(ConfigParameter configParameter) {
        return new JsonView(this.configParameterService.save(configParameter));
    }
}
