package threewks.controller;

import com.google.api.client.extensions.appengine.http.UrlFetchTransport;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.view.json.JsonView;
import threewks.util.RestHelper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

public class SystemController {

    private static final String APPLICATION_NAME = "Google Drive for OFD Extractor";
    private static final List<String> SCOPES = asList(DriveScopes.DRIVE, DriveScopes.DRIVE_READONLY, SheetsScopes.SPREADSHEETS);

    private final Drive driveService;
    private final GoogleCredential driveCredential;

    public SystemController(GoogleCredential driveCredential) {
        this.driveCredential = driveCredential;
        HttpTransport httpTransport = new UrlFetchTransport();
        JsonFactory jsonFactory = new GsonFactory();
        driveService = new Drive.Builder(httpTransport, jsonFactory, driveCredential)
            .setApplicationName(APPLICATION_NAME)
            .build();
    }

    public JsonView displayDriveDocuments() throws IOException {
        FileList fileList = driveService.files().list().execute();
        List<File> files = fileList.getFiles();
        List<String> currentFiles = new ArrayList<>();
        for (File file : files) {
            currentFiles.add(file.getId());
        }
        return RestHelper.response(currentFiles);
    }

    public JsonView deleteDriveDocuments() throws IOException {
        FileList fileList = driveService.files().list().execute();
        fileList.getFiles().forEach(file -> {
            try {
                driveService.files().delete(file.getId());
            } catch (IOException e) {
                Logger.warn("Caught IOException while deleting Drive document");
            }
        });
        return RestHelper.response("ok");
    }
}
