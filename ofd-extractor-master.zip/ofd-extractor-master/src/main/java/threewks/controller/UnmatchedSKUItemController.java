package threewks.controller;

import com.threewks.thundr.http.Header;
import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.csv.CsvView;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.model.PagedResult;
import threewks.model.UnmatchedSKUItem;
import threewks.service.UnmatchedSKUItemService;
import threewks.util.RestHelper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class UnmatchedSKUItemController {

    public static final String DOWNLOAD_CONTENT_DISPOSITION_HEADER_FORMAT = "attachment; filename=\"no-category-%s.csv\"";
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private final UnmatchedSKUItemService unmatchedSKUItemService;

    public UnmatchedSKUItemController(UnmatchedSKUItemService unmatchedSKUItemService) {
        this.unmatchedSKUItemService = unmatchedSKUItemService;
    }

    @Authenticated
    public JsonView search(UnmatchedSKUSearchRequest unmatchedSKUSearchRequest) {
        PagedResult<UnmatchedSKUItem> result = unmatchedSKUItemService.search(unmatchedSKUSearchRequest.getOperatorNames(), unmatchedSKUSearchRequest.getSku(), unmatchedSKUSearchRequest.getOffset());
        return RestHelper.response(result);
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView allocate(List<UnmatchedSKUItem> items) {
        unmatchedSKUItemService.saveAndAllocate(items);
        return RestHelper.noContent();
    }

    @Authenticated
    public JsonView listOperatorsWithUnmatchedItems() {
        List<String> result = unmatchedSKUItemService.listOperatorsWithUnmatchedItems();
        return RestHelper.response(result);
    }

    @Authenticated
    public JsonView getCount() {
        return RestHelper.response(unmatchedSKUItemService.getCount());
    }

    @Authenticated
    public CsvView export() {
        List<List<String>> data = unmatchedSKUItemService.exportUnallocated();

        return CsvView.fromLists(data).withHeader(Header.ContentDisposition,
            String.format(DOWNLOAD_CONTENT_DISPOSITION_HEADER_FORMAT, LocalDate.now().format(TODAY_FORMAT)));
    }

}
