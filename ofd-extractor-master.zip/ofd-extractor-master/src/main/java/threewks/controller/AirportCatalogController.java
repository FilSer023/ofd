package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.model.AirportCatalog;
import threewks.service.AirportCatalogService;

public class AirportCatalogController {
    private final AirportCatalogService airportCatalogService;

    public AirportCatalogController(AirportCatalogService airportCatalogService) {
        this.airportCatalogService = airportCatalogService;
    }

    @Authenticated
    public JsonView list() {
        return new JsonView(this.airportCatalogService.list());
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView save(AirportCatalog airportCatalog) {
        return new JsonView(this.airportCatalogService.save(airportCatalog));
    }

    @Authenticated
    public JsonView get(String id) {
        return new JsonView(this.airportCatalogService.get(id));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView delete(String airportId) {
        return new JsonView(this.airportCatalogService.delete(airportId));
    }

}
