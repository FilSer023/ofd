package threewks.controller;

import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.view.json.JsonView;

import static java.util.Arrays.asList;

public class PropertyVariableController {

    private String host;

    public PropertyVariableController(String host) {
        this.host = host;
    }

    @Authenticated
    public JsonView list() {
        return new JsonView(asList());
    }

}
