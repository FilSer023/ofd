package threewks.controller;

import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.threewks.thundr.http.Cookie;
import com.threewks.thundr.http.MultipartFile;
import com.threewks.thundr.http.exception.ForbiddenException;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;
import threewks.model.dto.ShopOperatorDto;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;
import threewks.util.RestHelper;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ShopOperatorController {

    private static final String WRONG_UPLOAD_KEY_MESSAGE = "Неверное значение ключа загрузки";
    private final ShopOperatorService shopOperatorService;
    private final TaskService taskService;
    private final String gcsDefaultBucket;
    private static final DateTimeFormatter FULL_DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy_HH:mm:ss");
    private final static String SHOP_OPERATOR_TRANSACTIONS_FILE_LOCATION = "manual/%s/%s/transactions/%s";

    public ShopOperatorController(ShopOperatorService shopOperatorService, TaskService taskService, String gcsDefaultBucket) {
        this.shopOperatorService = shopOperatorService;
        this.taskService = taskService;
        this.gcsDefaultBucket = gcsDefaultBucket;
    }

    @Authenticated
    public JsonView list() {
        return new JsonView(shopOperatorService.list());
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView save(ShopOperatorDto shopOperatorDto) {
        return new JsonView(shopOperatorService.save(shopOperatorDto));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView update(String shopOperatorId, ShopOperatorDto shopOperatorDto) {
        return new JsonView(shopOperatorService.update(shopOperatorId, shopOperatorDto));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView changeStatus(String shopOperatorId, ShopOperatorStatus status) {
        ShopOperator shopOperator = shopOperatorService.get(shopOperatorId);
        shopOperator.setStatus(status);
        return new JsonView(shopOperatorService.save(shopOperator));
    }

    @Authenticated
    public JsonView availableOperators() {
        return new JsonView(shopOperatorService.listAvailableOperators());
    }

    public JsonView uploadTransactions(Cookie authenticity, String shopOperatorId, String exportDay, MultipartFile transactionsFile) {
        Logger.info("uploadTransactions: shopOperator %s, export day: %s, file %s",
            shopOperatorId, exportDay, transactionsFile);
        ShopOperator shopOperator = shopOperatorService.get(shopOperatorId);
        GcsFilename fileName = new GcsFilename(gcsDefaultBucket,
            String.format(SHOP_OPERATOR_TRANSACTIONS_FILE_LOCATION, shopOperatorId,
                exportDay, LocalDateTime.now().format(FULL_DATE_FORMAT)));
        String authKey = authenticity.getValue();
        if (shopOperator != null && shopOperator.getUploadKey().equals(authKey)) {
            OFDBatch batch = shopOperatorService.uploadTransactionsFile(shopOperatorId, exportDay, transactionsFile, fileName);
            taskService.ingestShopOperatorTransactionsFile(batch.getId(), fileName.getObjectName());
            return RestHelper.noContent();
        } else {
            throw new ForbiddenException(WRONG_UPLOAD_KEY_MESSAGE);
        }
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView checkNameAvailability(String name) {
        return new JsonView(shopOperatorService.checkNameAvailability(name));
    }

}
