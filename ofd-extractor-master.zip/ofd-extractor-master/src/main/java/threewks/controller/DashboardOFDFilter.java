package threewks.controller;

import threewks.model.BatchStatus;

import java.util.List;

public class DashboardOFDFilter {

    private String daysOffset;
    private List<BatchStatus> filteredStatus;

    public String getDaysOffset() {
        return daysOffset;
    }

    public DashboardOFDFilter setDaysOffset(String daysOffset) {
        this.daysOffset = daysOffset;
        return this;
    }

    public List<BatchStatus> getFilteredStatus() {
        return filteredStatus;
    }

    public DashboardOFDFilter setFilteredStatus(List<BatchStatus> filteredStatus) {
        this.filteredStatus = filteredStatus;
        return this;
    }
}
