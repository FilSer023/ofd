package threewks.controller;

import com.threewks.thundr.view.View;
import com.threewks.thundr.view.redirect.RedirectView;
import com.threewks.thundr.view.string.StringView;
import threewks.service.bootstrap.BootstrapService;
import threewks.service.ofd.OFDDocumentUploadService;
import threewks.service.passengerfeed.CobraDataService;

public class BootstrapController {

    private final BootstrapService bootstrapService;
    private final CobraDataService cobraDataService;
    private final OFDDocumentUploadService ofdDocumentUploadService;

    public BootstrapController(BootstrapService bootstrapService, CobraDataService cobraDataService, OFDDocumentUploadService ofdDocumentUploadService) {
        this.bootstrapService = bootstrapService;
        this.cobraDataService = cobraDataService;
        this.ofdDocumentUploadService = ofdDocumentUploadService;
    }

    public View bootstrap() {
        bootstrapService.createSuperUser();

        return new RedirectView("/system/gmail/setup");  // Initialise gmail
    }

    public View bootstrapData() {
        bootstrapService.bootstrapLocal();

        return new StringView("ok");
    }

}
