package threewks.controller;

import com.threewks.thundr.http.StatusCode;
import com.threewks.thundr.http.exception.HttpStatusException;
import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.User;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.model.ShopOperator;
import threewks.model.dto.OFDBatchDto;
import threewks.service.OFDBatchService;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;
import threewks.util.RestHelper;

import java.util.stream.Collectors;

public class OFDBatchController {

    private static final int MAX_PETER_SERVIS_PERIOD_LENGTH = 35;
    private static final int MAX_OFD_PERIOD_LENGTH = 120;
    private final OFDBatchService batchService;
    private final TaskService taskService;
    private final ShopOperatorService shopOperatorService;

    public OFDBatchController(OFDBatchService batchService, TaskService taskService, ShopOperatorService shopOperatorService) {
        this.batchService = batchService;
        this.taskService = taskService;
        this.shopOperatorService = shopOperatorService;
    }

    @Authenticated
    public JsonView list(DashboardOFDFilter filter) {
        return new JsonView(this.batchService.getRecentBatches(Integer.valueOf(filter.getDaysOffset()), filter.getFilteredStatus()).stream().map(batch -> OFDBatchDto.from(batch)).collect(Collectors.toList()));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView toggleReviewed(User user, String batchId) {
        return new JsonView(this.batchService.toggleReviewed(user, batchId));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView startManualBatch(User user, String shopOperatorId, String batchDay, int periodLength) {
        this.taskService.scheduleShopOperatorBatch(user, batchDay, String.valueOf(periodLength), shopOperatorId);
        return RestHelper.response("ok");
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView checkManualBatch(User user, String shopOperatorId, int periodLength) {
        ShopOperator shopOperator = this.shopOperatorService.get(shopOperatorId);
        boolean validConfiguration = false;
        boolean notInProgress = this.batchService.batchInProgress(shopOperator);
        if (notInProgress) {
            switch (shopOperator.getOfdProvider()) {
                case PETER_SERVIS:
                    validConfiguration = periodLength <= MAX_PETER_SERVIS_PERIOD_LENGTH;
                    break;
                // check if there are queued receipts for this shop operator
                default:
                    validConfiguration = periodLength <= MAX_OFD_PERIOD_LENGTH;
            }
        } else {
            throw new HttpStatusException(StatusCode.InternalServerError, "Дождитесь окончания сеанса загрузки для выбранного арендатора: %s", shopOperator.getName());
        }
        validConfiguration = notInProgress && validConfiguration;
        if (validConfiguration) {
            return RestHelper.response("ok");
        } else {
            throw new HttpStatusException(StatusCode.InternalServerError, "Проверьте параметры запуска (продолжительность периода выгрузки): %s",
                String.valueOf(periodLength));
        }
    }
}
