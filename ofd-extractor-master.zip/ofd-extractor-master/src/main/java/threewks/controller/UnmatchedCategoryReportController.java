package threewks.controller;

import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.view.json.JsonView;
import threewks.service.UnmatchedCategoryReportService;

public class UnmatchedCategoryReportController {
    UnmatchedCategoryReportService unmatchedCategoryReportService;

    public UnmatchedCategoryReportController(UnmatchedCategoryReportService unmatchedCategoryReportService) {
        this.unmatchedCategoryReportService = unmatchedCategoryReportService;
    }

    @Authenticated
    public JsonView getLatest() {
        return new JsonView(unmatchedCategoryReportService.getLatest());
    }

}
