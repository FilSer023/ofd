package threewks.controller;

import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.view.string.StringView;
import threewks.service.TaskService;

public class CronController {
    private final TaskService taskService;

    public CronController(TaskService taskService) {
        this.taskService = taskService;
    }

    public StringView exportOFD(String day, String periodLength) {
        Logger.info("Running exportOFD() cron job");
        taskService.exportOFD(null, day, periodLength);

        return new StringView("ok");
    }

    public StringView findUnmatchedSKUs() {
        Logger.info("Running findUnmatchedSKUs() cron job");
        taskService.findUnmatchedSKUs();
        return new StringView("ok");
    }

    public StringView deleteOldIndividualReceipts() {
        Logger.info("Running deleteOldIndividualReceipts() cron job");
        taskService.deleteOldIndividualReceipts();
        return new StringView("ok");
    }

    public StringView combineCleanTransactions() {
        Logger.info("Running combineCleanTransactions() cron job");
        taskService.combineCleanTransactions();
        return new StringView("ok");
    }

    public StringView updateInsertionTime() {
        Logger.info("Running updateInsertionTime() cron job");
        taskService.updateInsertionTime();
        return new StringView("ok");
    }

    public StringView downloadPassengerFeed(String feedDay) {
        Logger.info("Running downloadPassengerFeed cron job");
        taskService.downloadPassengerFeed(feedDay);
        return new StringView("ok");
    }

    public StringView exportCurrentCategoryMapping() {
        Logger.info("Running exportCurrentCategoryMapping cron job");
        taskService.exportCurrentCategoryMapping();
        return new StringView("ok");
    }

    public StringView ingestBackupData(String year, String month, String day) {
        Logger.info("Running backup data ingesting cron job");
        taskService.ingestBackupDataToBQ(year, month, day);
        return new StringView("ok");
    }

    public StringView combineOperatorInfoData() {
        Logger.info("Running combineOperatorInfoData cron job");
        taskService.combineOperatorInfoData();
        return new StringView("ok");
    }
}
