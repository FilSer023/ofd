package threewks.controller;

import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsInputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.view.View;
import com.threewks.thundr.view.file.FileView;
import sun.nio.ch.ChannelInputStream;
import threewks.model.SKUCategoryMappingFile;
import threewks.service.SKUCategoryMappingFileService;
import threewks.util.RestHelper;

import java.io.IOException;
import java.io.InputStream;

public class CategoriesController {
    private static final String APPLICATION_CSV_CONTENT_TYPE = "application/csv";
    private final String gcsDefaultBucket;
    private final SKUCategoryMappingFileService skuCategoryMappingFileService;
    private final GcsService gcsService =
        GcsServiceFactory.createGcsService(
            new RetryParams.Builder()
                .initialRetryDelayMillis(10)
                .retryMaxAttempts(10)
                .totalRetryPeriodMillis(15000)
                .build());

    public CategoriesController(String gcsDefaultBucket, SKUCategoryMappingFileService skuCategoryMappingFileService) {
        this.gcsDefaultBucket = gcsDefaultBucket;
        this.skuCategoryMappingFileService = skuCategoryMappingFileService;
    }

    @Authenticated
    @Deprecated
    public View download() throws IOException {
        //This method is not used, we are reading mapping files directly from GCS as reading with buffer truncates large files occasionally
        SKUCategoryMappingFile skuCategoryMappingFile = skuCategoryMappingFileService.getLatest();
        if (skuCategoryMappingFile != null) {
            Logger.info("Downloading file %s", skuCategoryMappingFile.getGcsLocation());
            GcsFilename filename = new GcsFilename(gcsDefaultBucket, skuCategoryMappingFile.getGcsLocation());
            GcsInputChannel inputChannel = gcsService.openReadChannel(filename, 0);
            InputStream inputStream = new ChannelInputStream(inputChannel);
            return new FileView("category.csv", inputStream, APPLICATION_CSV_CONTENT_TYPE);
        } else {
            return RestHelper.noContent();
        }
    }

}
