package threewks.controller;

import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.view.View;
import com.threewks.thundr.view.string.StringView;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.model.ShopOperator;
import threewks.repository.OFDBatchRepository;
import threewks.repository.ReceiptDocumentRepository;
import threewks.service.OFDBatchService;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;
import threewks.service.bigquery.DataManagerService;
import threewks.service.ofd.BaseOFDService;
import threewks.service.ofd.peterservice.PeterServiceOFDServiceStrategy;
import threewks.service.passengerfeed.CobraDataService;
import threewks.service.passengerfeed.PassengerFeedTransformerService;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import static threewks.model.BatchStatus.RECEIPT_DETAILS_RETRIEVED;
import static threewks.model.BatchStatus.RECEIPT_SUMMARIES_RETRIEVED;
import static threewks.model.ReceiptDocumentStatus.QUEUED;

public class TaskController {

    public static final int MAX_SINGLE_PERIOD = 10;
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final String EMPTY_STRING = "";

    private final TaskService taskService;
    private final BaseOFDService baseOFDService;
    private final ShopOperatorService shopOperatorService;
    private final DataManagerService dataManagerService;
    private final CobraDataService cobraDataService;
    private final PassengerFeedTransformerService passengerFeedTransformerService;
    private final PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy;
    private final ReceiptDocumentRepository receiptDocumentRepository;
    private final OFDBatchService batchService;
    private final OFDBatchRepository batchRepository;

    public TaskController(TaskService taskService, BaseOFDService baseOFDService, ShopOperatorService shopOperatorService,
        DataManagerService dataManagerService, CobraDataService cobraDataService, PassengerFeedTransformerService passengerFeedTransformerService,
        PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy, ReceiptDocumentRepository receiptDocumentRepository, OFDBatchService batchService,
        OFDBatchRepository batchRepository) {
        this.taskService = taskService;
        this.baseOFDService = baseOFDService;
        this.shopOperatorService = shopOperatorService;
        this.dataManagerService = dataManagerService;
        this.cobraDataService = cobraDataService;
        this.passengerFeedTransformerService = passengerFeedTransformerService;
        this.peterServiceOFDServiceStrategy = peterServiceOFDServiceStrategy;
        this.receiptDocumentRepository = receiptDocumentRepository;
        this.batchService = batchService;
        this.batchRepository = batchRepository;
    }

    public View exportOFD(String username, String shopOperatorId, String batchId, String exportDay, String periodLength) {
        Logger.info("Exporting OFD data - operator %s, batch %s, export day %s, period %s - started by %s",
            shopOperatorId, batchId, exportDay, periodLength, username);
        ShopOperator shopOperator = shopOperatorService.get(shopOperatorId);
        int period = Integer.valueOf(periodLength);
        String completedBatchId = null;
        if (period > MAX_SINGLE_PERIOD) {
            int newPeriod = period - MAX_SINGLE_PERIOD;
            LocalDate originalExportDay = LocalDate.parse(exportDay, TODAY_FORMAT);
            String newExportDay = TODAY_FORMAT.format(originalExportDay.minusDays(MAX_SINGLE_PERIOD));
            completedBatchId = baseOFDService.extractAndUploadOFDDocuments(batchId, shopOperator, exportDay, period, MAX_SINGLE_PERIOD, username);
            taskService.exportOFD(completedBatchId, newExportDay, String.valueOf(newPeriod));
        } else {
            completedBatchId = baseOFDService.extractAndUploadOFDDocuments(batchId, shopOperator, exportDay, period, period, username);
            //Data is fetched, kick off automatic BQ ingestion if OFD operator is not PeterServis (PS Strategy kicks off BQ manually)
            OFDProvider provider = shopOperator.getOfdProvider();
            if (provider != OFDProvider.PETER_SERVIS) {
                taskService.ingestOFDBatch(completedBatchId);
            } else {
                taskService.checkReceiptsQueue(completedBatchId);
            }
        }
        return new StringView("ok");
    }

    public View checkReceiptsQueue(String batchId) {
        Logger.info("Checking receipts queue for batch %s", batchId);
        Map<String, Integer> stats = receiptDocumentRepository.getBatchStats(batchId);
        Logger.info("Batch %s, stats: %s", batchId, stats);
        int queued = stats.get(QUEUED.name());
        OFDBatch ofdBatch = batchRepository.get(batchId);
        if (queued != 0) {
            Logger.warn("Not all receipts have been downloaded for batch %s. Stats: %s", batchId, stats);
        } else {
            Logger.info("All individual receipts for batch %s have been retrieved, status: %s",
                batchId, ofdBatch.getStatus());
            ofdBatch.getInfoMessages().add(OFDBatchService.ALL_DETAILS_RETRIEVED_MESSAGE);
        }
        if (ofdBatch.getStatus() == RECEIPT_SUMMARIES_RETRIEVED) {
            ofdBatch.setStatus(RECEIPT_DETAILS_RETRIEVED);
            batchService.finishBatch(ofdBatch);
            taskService.ingestOFDBatch(batchId);
            Logger.info("Scheduled ingestion task for batch %s", batchId);
        }
        return new StringView("ok");
    }

    public View ingestOFDBatch(String batchId) {
        Logger.info("Ingesting OFD data for batch %s", batchId);
        dataManagerService.ingestionStagingDataJob(batchId);
        return new StringView("ok");
    }

    public View fetchIndividualReceiptsFromOFD(String shopOperatorId, String batchId, String docRawId, String userInn, String kktRegNumber, String token) {
        Logger.debug("Fetching individual receipt %s from OFD", docRawId);
        peterServiceOFDServiceStrategy.fetchIndividualReceipt(shopOperatorId, batchId, userInn, kktRegNumber, docRawId, token);
        return new StringView("ok");
    }

    public View ingestTransactionsFile(String batchId, String fileName) {
        Logger.info("Ingesting manual upload transactions file batch %s file %s", batchId, fileName);
        dataManagerService.ingestShopOperatorTransactionsFile(batchId, fileName);
        return new StringView("ok");
    }

    public View ingestBackupData(String year, String month, String day) throws IOException {
        Logger.info("Ingesting backup data");
        LocalDate date = LocalDate.now(ZoneId.of("UTC"));
        if (year == null) {
            year = String.valueOf(date.getYear());
        }
        if (month == null) {
            month = String.format("%02d", date.getMonthValue());
        }
        if (day == null) {
            day = year + month + String.format("%02d", date.getDayOfMonth());
        }
        dataManagerService.scheduleBackupDataImport(year, month, day);
        return new StringView("ok");
    }

    public View collateOFDTransactions(String batchId) {
        Logger.info("Cleaning and collating transaction data for batch %s", batchId);
        dataManagerService.collateTransactionData(batchId);
        return new StringView("ok");
    }

    public View ingestFlatFileTransactions(String batchId) {
        Logger.info("Ingesting flat file transaction data for batch %s", batchId);
        dataManagerService.ingestFlatFileTransactions(batchId);
        return new StringView("ok");
    }

    public View combineCleanTransactions() {
        Logger.info("Combining clean transactions");
        dataManagerService.combineCleanTransactions();
        return new StringView("ok");
    }

    public View updateInsertionTime() {
        Logger.info("Updating insertion time on clean transactions");
        dataManagerService.updateInsertionTime();
        return new StringView("ok");
    }

    public View findUnmatchedSKUs() throws InterruptedException {
        Logger.info("Finding unmatched SKUs");
        dataManagerService.findUnmatchedSKUs();
        return new StringView("ok");
    }

    public View deleteOldIndividualReceipts() throws InterruptedException {
        Logger.info("Deleting old individual receipts");
        receiptDocumentRepository.deleteOldReceipts();
        return new StringView("ok");
    }

    public View downloadPassengerFeed(String feedDay) {
        Logger.info("Downloading PassengerFeed data for day %s", feedDay);
        try {
            String passengerFeedBatchId = cobraDataService.fetchPassengerFeedFiles(feedDay);
            taskService.preparePassengerFeed(passengerFeedBatchId);
        } catch (Exception e) {
            Logger.warn("Failed to retrieve PassengerFeed files: ", e.getMessage());
            throw new RuntimeException(e);
        }
        return new StringView("ok");
    }

    public View preparePassengerFeed(String batchId) {
        Logger.info("Preparing imported PassengerFeed data for batch ID %s", batchId);
        passengerFeedTransformerService.prepareFilesForIngestion(batchId);
        return new StringView("ok");
    }

    public View ingestPassengerFeed(String batchId) {
        Logger.info("Ingesting PassengerFeed data for batch ID %s", batchId);
        dataManagerService.schedulePassengerFeedImport(batchId);
        return new StringView("ok");
    }

    public View exportCurrentCategoryMapping() {
        Logger.info("Exporting current category mapping");
        try {
            dataManagerService.exportCurrentCategoryMapping();
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while exporting: ", e.getMessage());
        }
        return new StringView("ok");
    }

    public View importCategoryMappingFile(String batchId) {
        Logger.info("Importing category mapping file for batch %s", batchId);
        try {
            dataManagerService.importCategoryMappingFile(batchId);
        } catch (Exception e) {
            Logger.warn("Caught Exception while importing category mapping for batch %s: %s", batchId, e.getMessage());
        }
        return new StringView("ok");
    }

    public View exportAllocatedItems() {
        Logger.info("Exporting allocated category items");
        try {
            dataManagerService.exportAllocatedCategoryItemsToBQ();
        } catch (Exception e) {
            Logger.warn("Caught Exception while exporting allocated category items: %s", e.getMessage());
        }
        return new StringView("ok");
    }

    public View deleteOldPassengerFeedData(String batchId) {
        Logger.info("Deleting old passenger feed data for batch %s", batchId);
        dataManagerService.deleteOldPassengerFeedData(batchId);
        return new StringView("ok");
    }

    public View importCategoryMappingSheetIntoTable(String batchId) {
        Logger.info("Importing category mapping for batch %s", batchId);
        try {
            dataManagerService.importCategoryMappingSheetIntoTable(batchId);
        } catch (Exception e) {
            Logger.warn("Caught Exception while importing category mapping for batch %s: %s, %s", batchId, e, e.getMessage());
        }
        return new StringView("ok");
    }

    public View collatePassengerFeedData(String batchId) {
        Logger.info("Collating passenger feed data for batch %s", batchId);
        dataManagerService.collatePassengerFeedDada(batchId);
        return new StringView("ok");
    }

    public View combineOperatorInfoData() {
        Logger.info("Combining operator info data");
        dataManagerService.combineOperatorInfoData();
        return new StringView("ok");
    }

    public View deleteAllocatedUnmatchedSKUItemsAfterIngestion() {
        Logger.info("Removing allocated UnmatchedSKUItems");
        dataManagerService.deleteAllocatedUnmatchedSKUItemsAfterIngestion();
        return new StringView("ok");
    }

    public View ingestBatchForUnmatchedItems(String batchId) {
        Logger.info("Ingesting batch of UnmatchedSKUItem records");
        dataManagerService.ingestBatchForUnmatchedItems(batchId);
        return new StringView("ok");
    }
}
