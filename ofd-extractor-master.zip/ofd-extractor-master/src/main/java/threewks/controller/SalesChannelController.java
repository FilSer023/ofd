package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.service.SalesChannelService;
import threewks.util.RestHelper;

public class SalesChannelController {

    private final SalesChannelService salesChannelService;

    public SalesChannelController(SalesChannelService salesChannelService) {
        this.salesChannelService = salesChannelService;
    }

    @Authenticated
    public JsonView list() {
        return new JsonView(salesChannelService.list());
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView save(String name) {
        return new JsonView(salesChannelService.save(name));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView update(String id, String name) {
        return new JsonView(salesChannelService.update(id, name));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView delete(String id) {
        salesChannelService.delete(id);
        return RestHelper.noContent();
    }
}
