package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.service.SubSectionCategoryService;
import threewks.util.RestHelper;

public class SubSectionCategoryController {

    private final SubSectionCategoryService subSectionCategoryService;

    public SubSectionCategoryController(SubSectionCategoryService subSectionCategoryService) {
        this.subSectionCategoryService = subSectionCategoryService;
    }

    @Authenticated
    public JsonView search(String name) {
        return new JsonView(subSectionCategoryService.getByName(name));
    }

    @Authenticated
    public JsonView list() {
        return new JsonView(subSectionCategoryService.list());
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView save(String name) {
        return new JsonView(subSectionCategoryService.save(name));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView update(String id, String name) {
        return new JsonView(subSectionCategoryService.update(id, name));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView delete(String id) {
        subSectionCategoryService.delete(id);
        return RestHelper.noContent();
    }
}
