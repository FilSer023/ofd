package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.model.RentalArea;
import threewks.model.RentalAreaStatus;
import threewks.model.dto.RentalAreaDto;
import threewks.service.RentalAreaService;

import java.util.List;

public class RentalAreaController {
    private final RentalAreaService rentalAreaService;

    public RentalAreaController(RentalAreaService rentalAreaService) {
        this.rentalAreaService = rentalAreaService;
    }

    @Authenticated
    public JsonView listByStatus(List<String> status) {
        return new JsonView(rentalAreaService.listByStatus(status));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView save(RentalAreaDto rentalAreaDto) {
        RentalArea rentalArea = new RentalArea();
        rentalArea.setStatus(RentalAreaStatus.ACTIVE);
        rentalArea = rentalArea.fromDto(rentalAreaDto);
        return new JsonView(rentalAreaService.save(rentalArea));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView update(String rentalAreaId, RentalAreaDto rentalAreaDto) {
        RentalArea rentalArea = rentalAreaService.get(rentalAreaId);
        return new JsonView(rentalAreaService.save(rentalArea.fromDto(rentalAreaDto)));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView changeStatus(String rentalAreaId, RentalAreaStatus status) {
        RentalArea rentalArea = rentalAreaService.get(rentalAreaId);
        rentalArea.setStatus(status);
        return new JsonView(rentalAreaService.save(rentalArea));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView delete(String rentalAreaId) {
        return new JsonView(rentalAreaService.delete(rentalAreaId));
    }

    @Authenticated
    public JsonView getFreeRentalAreas() {
        return new JsonView(rentalAreaService.getFreeRentalAreas());
    }
}
