package threewks.controller;

import com.google.api.client.extensions.appengine.http.UrlFetchTransport;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.common.collect.ImmutableMap;
import com.googlecode.objectify.Key;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.view.json.JsonView;
import org.apache.commons.collections.CollectionUtils;
import threewks.model.OFDBatch;
import threewks.model.PagedResult;
import threewks.model.ReceiptDocument;
import threewks.model.ReceiptDocumentStatus;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;
import threewks.model.SubSectionCategory;
import threewks.model.TradePoint;
import threewks.model.TradePointSubSection;
import threewks.model.UnmatchedSKUItem;
import threewks.repository.AirportCatalogRepository;
import threewks.repository.OFDBatchRepository;
import threewks.repository.ReceiptDocumentRepository;
import threewks.repository.RentalAreaRepository;
import threewks.repository.ShopOperatorRepository;
import threewks.repository.SubSectionCategoryRepository;
import threewks.repository.UnmatchedSKUItemRepository;
import threewks.service.TaskService;
import threewks.service.ofd.peterservice.PeterServiceOFDServiceStrategy;
import threewks.util.RestHelper;
import threewks.util.StreamUtil;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;

public class MigrationController {

    private static final String APPLICATION_NAME = "Google Drive for OFD Extractor";
    private static final String NEW_TRANSACTIONS_PREFIX = "ofd/transactions/new/%s";
    private static final String TEMP_TRANSACTIONS_PREFIX = "ofd/transactions/temp/%s";
    private static final List<String> SCOPES = asList(DriveScopes.DRIVE, DriveScopes.DRIVE_READONLY, SheetsScopes.SPREADSHEETS);
    private static final int HUNDRED = 100;
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final AirportCatalogRepository airportCatalogRepository;
    private final RentalAreaRepository rentalAreaRepository;
    private final ShopOperatorRepository shopOperatorRepository;
    private final ReceiptDocumentRepository receiptDocumentRepository;
    private final OFDBatchRepository ofdBatchRepository;
    private final PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy;
    private final UnmatchedSKUItemRepository unmatchedSKUItemRepository;
    private final SubSectionCategoryRepository subSectionCategoryRepository;
    private final TaskService taskService;
    private final String gcsDefaultBucket;
    private final Drive driveService;
    private final Storage storage = StorageOptions.getDefaultInstance().getService();
    private final GcsService gcsService =
        GcsServiceFactory.createGcsService(
            new RetryParams.Builder()
                .initialRetryDelayMillis(10)
                .retryMaxAttempts(10)
                .totalRetryPeriodMillis(15000)
                .build());

    public MigrationController(
        AirportCatalogRepository airportCatalogRepository, RentalAreaRepository rentalAreaRepository,
        ShopOperatorRepository shopOperatorRepository, ReceiptDocumentRepository receiptDocumentRepository, OFDBatchRepository ofdBatchRepository,
        PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy, UnmatchedSKUItemRepository unmatchedSKUItemRepository,
        SubSectionCategoryRepository subSectionCategoryRepository, TaskService taskService, String gcsDefaultBucket) throws IOException {
        this.airportCatalogRepository = airportCatalogRepository;
        this.rentalAreaRepository = rentalAreaRepository;
        this.shopOperatorRepository = shopOperatorRepository;
        this.receiptDocumentRepository = receiptDocumentRepository;
        this.ofdBatchRepository = ofdBatchRepository;
        this.peterServiceOFDServiceStrategy = peterServiceOFDServiceStrategy;
        this.unmatchedSKUItemRepository = unmatchedSKUItemRepository;
        this.subSectionCategoryRepository = subSectionCategoryRepository;
        this.taskService = taskService;
        this.gcsDefaultBucket = gcsDefaultBucket;
        HttpTransport httpTransport = new UrlFetchTransport();
        JsonFactory jsonFactory = new GsonFactory();
//        GoogleCredential googleCredential = new AppIdentityCredential.AppEngineCredentialWrapper(httpTransport, jsonFactory)
//            .createScoped(DRIVE_SCOPES);
        InputStream jsonCredentials = getClass().getResourceAsStream("/dev-gcs-credentials.json");
        GoogleCredential googleCredential1 = GoogleCredential.fromStream(jsonCredentials).createScoped(SCOPES);
        driveService = new Drive.Builder(httpTransport, jsonFactory, googleCredential1)
            .setApplicationName(APPLICATION_NAME)
            .build();
    }

    public JsonView deleteUnmatchedSKUItems() {
        unmatchedSKUItemRepository.deleteAll();
        unmatchedSKUItemRepository.clearSearchIndex();
        return RestHelper.response("ok");
    }

    public JsonView updateRentalAreas() {
        List<ShopOperator> shopOperators = shopOperatorRepository.listAll();
        List<ShopOperator> toSave = new ArrayList<>();
        for (ShopOperator shopOperator : shopOperators) {
            if (shopOperator.getStatus() == ShopOperatorStatus.ARCHIVED) {
                shopOperator.getTradePoints().forEach(tradePoint -> tradePoint.setRentalAreaRef(null));
                toSave.add(shopOperator);
            }
        }
        shopOperatorRepository.put(toSave);
        return RestHelper.response("ok");
    }

    public JsonView downloadQueuedReceipts(ReceiptDocumentStatus status, String batchId, String inn, String kktRegId) {
        List<ReceiptDocument> queuedReceipts = receiptDocumentRepository.filterByStatusAndBatch(status, batchId);
        OFDBatch batch = ofdBatchRepository.get(batchId);
        ShopOperator shopOperator = batch.getShopOperator();
        String authToken = peterServiceOFDServiceStrategy.fetchAuthToken(shopOperator);
        for (ReceiptDocument receiptDocument : queuedReceipts) {
            taskService.fetchIndividualReceipts(receiptDocument.getShopOperator().getId(), batchId, inn, kktRegId, receiptDocument.getDocRawId(), authToken);
        }
        return RestHelper.response("ok");
    }

    public JsonView updateTradePoints() {
        List<ShopOperator> shopOperators = shopOperatorRepository.listAll();
        List<ShopOperator> toSave = new ArrayList<>();
        for (ShopOperator shopOperator : shopOperators) {
            List<TradePoint> tradePoints = shopOperator.getTradePoints();
            for (TradePoint tradePoint : tradePoints) {
                if (CollectionUtils.isNotEmpty(tradePoint.getCategoryAreas())) {
                    for (TradePointSubSection subSection : tradePoint.getCategoryAreas()) {
                        SubSectionCategory sectionCategory =
                            subSectionCategoryRepository.findByExactName(subSection.getCategory().getName());
                        if (sectionCategory != null) {
                            subSection.setCategoryRef(sectionCategory);
                        }
                    }
                }
            }
            toSave.add(shopOperator);
        }
        shopOperatorRepository.put(toSave);
        return RestHelper.response("ok");
    }

    public JsonView refreshOperatorSearchIndex(String operatorId) {
        ShopOperator shopOperator = shopOperatorRepository.get(operatorId);
        if (shopOperator != null) {
            List<UnmatchedSKUItem> unmatchedSKUItems = unmatchedSKUItemRepository.getByField("operatorName", shopOperator.getName());
            Date updated = new Date();
            StreamUtil.batches(unmatchedSKUItems, HUNDRED).forEach(subList -> {
                List updatedItems = subList.stream().map(unmatchedSKUItem -> unmatchedSKUItem.setUpdated(updated)).collect(Collectors.toList());
                unmatchedSKUItemRepository.put(updatedItems);
            });
            return RestHelper.response("ok");
        } else {
            return RestHelper.response("No such operator");
        }
    }

    public JsonView deleteReceiptDocuments(String days) {
        receiptDocumentRepository.deleteOlderThan(Integer.valueOf(days));
        return RestHelper.response("ok");
    }

    public JsonView deleteReceiptDocumentsByShopOperator(String operatorId, String dateFrom, String days) {
        ShopOperator shopOperator = shopOperatorRepository.get(operatorId);
        LocalDate date = LocalDate.parse(dateFrom, TODAY_FORMAT);
        receiptDocumentRepository.deleteByShopOperatorAndDateRange(shopOperator,
            Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant()), Integer.valueOf(days));
        return RestHelper.response("ok");
    }

    public JsonView reindexUnmatchedSKUItems(String cursor) {
        PagedResult<UnmatchedSKUItem> results = unmatchedSKUItemRepository.listAll(cursor);
        List<String> keys = results.getResults().stream().map(
            unmatchedSKUItem -> Key.create(unmatchedSKUItem).getName()).collect(Collectors.toList());
        if (!keys.isEmpty()) {
            Logger.info("Got %s keys for reindexing batch, starting", keys.size());
            unmatchedSKUItemRepository.reindex(keys);
        }
        String nextCursor = results.getCursorWebSafeString();
        if (nextCursor != null) {
            Logger.info("%s - queuing another batch", "reindexUnmatchedSKUItems");
            this.queueAdminTask("reindexUnmatchedSKUItems", ImmutableMap.<String, String>builder()
                .put("cursor", nextCursor)
                .build()
            );
        }

        return new JsonView("Ok");
    }

    public JsonView queueAdminTask(String taskName, Map<String, String> params) {
        Logger.info("queueAdminTask %s with params: %s", taskName, params != null ? params.toString() : "no params");
        taskService.queueAdminTask(taskName, params);
        return new JsonView("OK");
    }

}
