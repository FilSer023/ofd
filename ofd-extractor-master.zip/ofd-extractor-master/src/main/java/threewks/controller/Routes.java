package threewks.controller;

import com.threewks.thundr.route.HttpMethod;
import com.threewks.thundr.route.Router;
import threewks.framework.ref.ReferenceDataController;
import threewks.service.TaskService;

public class Routes {
    public static void addRoutes(Router router) {
        system(router);
        referenceData(router);
        api(router);
//        categoriesApi(router);
        task(router);
        cron(router);
        migration(router);

        // Keep these at the end
        notFoundRoutes(router, HttpMethod.GET, "/system/**", "/api/**", "/task/**", "/cron/**");
        router.get("/**", IndexController.class, "index");
    }

    private static void api(Router router) {
        router.put("/api/transactions/{shopOperatorId}/{exportDay}", ShopOperatorController.class, "uploadTransactions");

        router.post("/api/batch/", OFDBatchController.class, "list");
        router.put("/api/batch/{batchId}/toggle-reviewed", OFDBatchController.class, "toggleReviewed");
        router.post("/api/batch/manual", OFDBatchController.class, "startManualBatch");
        router.post("/api/batch/check", OFDBatchController.class, "checkManualBatch");

        router.post("/api/passenger-feed-batch/", PassengerFeedBatchController.class, "list");
        router.put("/api/passenger-feed-batch/{batchId}/toggle-reviewed", PassengerFeedBatchController.class, "toggleReviewed");

        router.get("/api/shop-operator/", ShopOperatorController.class, "list");
        router.get("/api/shop-operator/available", ShopOperatorController.class, "availableOperators");
        router.post("/api/shop-operator/", ShopOperatorController.class, "save");
        router.post("/api/shop-operator/check-name", ShopOperatorController.class, "checkNameAvailability");
        router.put("/api/shop-operator/{shopOperatorId}", ShopOperatorController.class, "update");
        router.put("/api/shop-operator/{shopOperatorId}/status", ShopOperatorController.class, "changeStatus");

        router.post("/api/rental-area/list", RentalAreaController.class, "listByStatus");
        router.post("/api/rental-area/", RentalAreaController.class, "save");
        router.delete("/api/rental-area/{rentalAreaId}", RentalAreaController.class, "delete");
        router.put("/api/rental-area/{rentalAreaId}", RentalAreaController.class, "update");
        router.put("/api/rental-area/{rentalAreaId}/status", RentalAreaController.class, "changeStatus");

        router.get("/api/categories/", CategoriesController.class, "download");

        router.get("/api/subsection-categories/", SubSectionCategoryController.class, "list");
        router.get("/api/subsection-categories/search", SubSectionCategoryController.class, "search");
        router.put("/api/subsection-categories/", SubSectionCategoryController.class, "save");
        router.post("/api/subsection-categories/{id}", SubSectionCategoryController.class, "update");
        router.delete("/api/subsection-categories/{id}", SubSectionCategoryController.class, "delete");

        router.get("/api/sales-channel/", SalesChannelController.class, "list");
        router.put("/api/sales-channel/", SalesChannelController.class, "save");
        router.post("/api/sales-channel/{id}", SalesChannelController.class, "update");
        router.delete("/api/sales-channel/{id}", SalesChannelController.class, "delete");

        router.get("/api/free-rental-areas/", RentalAreaController.class, "getFreeRentalAreas");

        router.get("/api/unmatched-categories", UnmatchedCategoryReportController.class, "getLatest");

        router.post("/api/unmatched-sku-item/search", UnmatchedSKUItemController.class, "search");
        router.get("/api/unmatched-sku-item/count", UnmatchedSKUItemController.class, "getCount");
        router.get("/api/unmatched-sku-item/operators", UnmatchedSKUItemController.class, "listOperatorsWithUnmatchedItems");
        router.post("/api/unmatched-sku-item/", UnmatchedSKUItemController.class, "allocate");
        router.get("/export/unmatched-sku-items", UnmatchedSKUItemController.class, "export");

        router.get("/api/config-parameter", ConfigParameterController.class, "list");
        router.post("/api/config-parameter", ConfigParameterController.class, "save");

        router.get("/api/category-mapping-batch/", CategoryMappingBatchController.class, "list");
        router.post("/api/category-mapping-batch/", CategoryMappingBatchController.class, "create");

        router.get("/api/airport-catalog/", AirportCatalogController.class, "list");
        router.post("/api/airport-catalog/", AirportCatalogController.class, "save");
        router.delete("/api/airport-catalog/{airportId}", AirportCatalogController.class, "delete");

        router.post("/api/passenger-feed/manual-upload", PassengerFeedManualUploadController.class, "startUpload");
    }

    private static void system(Router router) {
        router.get("/system/bootstrap", BootstrapController.class, "bootstrap");
        router.get("/system/bootstrapData", BootstrapController.class, "bootstrapData");
        router.get("/system/displayDriveDocuments", SystemController.class, "displayDriveDocuments");
        router.get("/system/deleteDriveDocuments", SystemController.class, "deleteDriveDocuments");
    }

    private static void referenceData(Router router) {
        router.get("/api/reference-data", ReferenceDataController.class, "getReferenceData");
    }


    private static void notFoundRoutes(Router router, HttpMethod method, String... routes) {
        for (String route : routes) {
            router.add(method, route, IndexController.class, "notFound", null);
        }
    }

    private static void task(Router router) {
        router.post("/task/export-ofd-data", TaskController.class, "exportOFD", TaskService.EXPORT_OFD_ROUTE);
        router.post("/task/check-receipts-queue", TaskController.class, "checkReceiptsQueue", TaskService.CHECK_RECEIPTS_QUEUE_ROUTE);
        router.post("/task/ingest-ofd-batch", TaskController.class, "ingestOFDBatch", TaskService.INGEST_OFD_BATCH_ROUTE);
        router.post("/task/fetch-individual-receipts", TaskController.class, "fetchIndividualReceiptsFromOFD", TaskService.FETCH_INDIVIDUAL_RECEIPTS_FROM_OFD_ROUTE);
        router.post("/task/collate-ofd-transactions", TaskController.class, "collateOFDTransactions", TaskService.COLLATE_OFD_TRANSACTIONS_ROUTE);
        router.post("/task/ingest-flatfile-transactions", TaskController.class, "ingestFlatFileTransactions", TaskService.INGEST_FLATFILE_TRANSACTIONS_ROUTE);
        router.post("/task/combine-clean-transactions", TaskController.class, "combineCleanTransactions", TaskService.COMBINE_CLEAN_TRANSACTIONS_ROUTE);
        router.post("/task/update-insertion-time", TaskController.class, "updateInsertionTime", TaskService.UPDATE_INSERTION_TIME_ROUTE);
        router.post("/task/ingest-transactions-file", TaskController.class, "ingestTransactionsFile", TaskService.INGEST_SHOP_OPERATOR_TRANSACTIONS_FILE_ROUTE);
        router.post("/task/find-unmatched-skus", TaskController.class, "findUnmatchedSKUs", TaskService.FIND_UNMATCHED_SKUS_ROUTE);
        router.post("/task/delete-old-individual-receipts", TaskController.class, "deleteOldIndividualReceipts", TaskService.DELETE_OLD_INDIVIDUAL_RECEIPTS_ROUTE);
        router.post("/task/download-passenger-feed-data", TaskController.class, "downloadPassengerFeed", TaskService.DOWNLOAD_PASSENGER_FEED_ROUTE);
        router.post("/task/prepare-passenger-feed-data", TaskController.class, "preparePassengerFeed", TaskService.PREPARE_PASSENGER_FEED_ROUTE);
        router.post("/task/delete-old-passenger-feed-data", TaskController.class, "deleteOldPassengerFeedData", TaskService.DELETE_OLD_PASSENGER_FEED_DATA_ROUTE);
        router.post("/task/ingest-passenger-feed-data", TaskController.class, "ingestPassengerFeed", TaskService.INGEST_PASSENGER_FEED_ROUTE);
        router.post("/task/export-current-category-mapping", TaskController.class, "exportCurrentCategoryMapping", TaskService.EXPORT_CURRENT_CATEGORY_MAPPING_ROUTE);
        router.post("/task/import-category-mapping", TaskController.class, "importCategoryMappingFile", TaskService.IMPORT_CATEGORY_MAPPING_FILE_ROUTE);
        router.post("/task/import-category-report", TaskController.class, "exportAllocatedItems", TaskService.EXPORT_ALLOCATED_ITEMS_ROUTE);
        router.post("/task/ingest-backup-data", TaskController.class, "ingestBackupData", TaskService.INGEST_BACKUP_DATA_ROUTE);
        router.post("/task/ingest-batch-for-unmatched-items", TaskController.class, "ingestBatchForUnmatchedItems", TaskService.INGEST_BATCH_FOR_UNMATCHED_ITEMS_ROUTE);
        router.post("/task/collate-passenger-feed-data", TaskController.class, "collatePassengerFeedData", TaskService.COLLATE_PASSENGER_FEED_DATA_ROUTE);
        router.post("/task/combine-operator-info-data", TaskController.class, "combineOperatorInfoData", TaskService.COMBINE_OPERATOR_INFO_DATA_ROUTE);
        router.post("/task/import-category-mapping-sheet", TaskController.class, "importCategoryMappingSheetIntoTable", TaskService.IMPORT_CATEGORY_MAPPING_SHEET_ROUTE);
        router.post("/task/delete-allocated-unmatched-sku-items", TaskController.class, "deleteAllocatedUnmatchedSKUItemsAfterIngestion", TaskService.DELETE_ALLOCATED_UNMATCHED_SKU_ITEMS_ROUTE);
    }

    private static void cron(Router router) {
        router.get("/cron/export-ofd-data", CronController.class, "exportOFD");
        router.get("/cron/combine-clean-transactions", CronController.class, "combineCleanTransactions");
        router.get("/cron/update-insertion-time", CronController.class, "updateInsertionTime");
        router.get("/cron/find-unmatched-skus", CronController.class, "findUnmatchedSKUs");
        router.get("/cron/download-passenger-feed-data", CronController.class, "downloadPassengerFeed");
        router.get("/cron/export-current-category-mapping", CronController.class, "exportCurrentCategoryMapping");
        router.get("/cron/ingest-backup-data", CronController.class, "ingestBackupData");
        router.get("/cron/combine-operator-info-data", CronController.class, "combineOperatorInfoData");
        router.get("/cron/delete-old-individual-receipts", CronController.class, "deleteOldIndividualReceipts");
    }

    private static void migration(Router router) {
        router.get("/admin/migration/deleteUnmatchedSKUItems", MigrationController.class, "deleteUnmatchedSKUItems");
        router.get("/admin/migration/updateRentalAreas", MigrationController.class, "updateRentalAreas");
        router.get("/admin/migration/refreshOperatorSearchIndex", MigrationController.class, "refreshOperatorSearchIndex");
        router.get("/admin/migration/updateTradePoints", MigrationController.class, "updateTradePoints");
        router.post("/admin/migration/downloadQueuedReceipts", MigrationController.class, "downloadQueuedReceipts");
        router.post("/admin/migration/deleteReceiptDocuments", MigrationController.class, "deleteReceiptDocuments");
        router.post("/admin/migration/deleteReceiptDocumentsByShopOperator", MigrationController.class, "deleteReceiptDocumentsByShopOperator");
        router.post("/admin/migration/reindexUnmatchedSKUItems", MigrationController.class, "reindexUnmatchedSKUItems");
    }

}
