package threewks.controller;

import com.threewks.thundr.user.Roles;
import com.threewks.thundr.user.controller.Authenticated;
import com.threewks.thundr.user.controller.Authorised;
import com.threewks.thundr.view.json.JsonView;
import threewks.framework.usermanager.model.AppRoles;
import threewks.framework.usermanager.model.AppUser;
import threewks.model.CategoryMappingBatch;
import threewks.model.dto.CategoryMappingBatchDTO;
import threewks.service.CategoryMappingBatchService;

import java.util.stream.Collectors;

public class CategoryMappingBatchController {
    private final CategoryMappingBatchService categoryMappingBatchService;

    public CategoryMappingBatchController(CategoryMappingBatchService categoryMappingBatchService) {
        this.categoryMappingBatchService = categoryMappingBatchService;
    }

    @Authenticated
    public JsonView list() {
        return new JsonView(this.categoryMappingBatchService.getRecentBatches().stream()
            .map(batch -> CategoryMappingBatchDTO.from(batch)).collect(Collectors.toList()));
    }

    @Authenticated
    @Authorised(any = {AppRoles.Administrator, Roles.Super})
    public JsonView create(CategoryMappingBatchDTO categoryMappingBatch, AppUser user) {
        CategoryMappingBatch batch = new CategoryMappingBatch();
        batch.setAttachment(categoryMappingBatch.getAttachment());
        batch.setStartedBy(user.getName());
        batch.setShareDocument(categoryMappingBatch.isShareDocument());
        batch.setStartedByUser(user);
        return new JsonView(categoryMappingBatchService.startBatch(batch));
    }
}
