package threewks.model;

import com.googlecode.objectify.Ref;
import com.googlecode.objectify.annotation.Cache;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.util.IdUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Cache(expirationSeconds = 120)
public class OFDBatch {

    private String startedBy;

    public static class SearchFields {
        public static final String TimeFinished = "timeFinished";
        public static final String TimeStarted = "timeStarted";
        public static final String Status = "status";
    }

    @Id
    private String id;

    @Index
    private Date timeStarted;

    @Index
    private Date timeFinished;

    private List<Date> timeContinued = new ArrayList<>();

    @Index
    private Ref<ShopOperator> shopOperator;

    @Index
    private BatchStatus status;

    @Index
    private String batchDay;

    private Integer periodLength;

    private Integer receiptsRetrieved = 0;

    private List<String> notes = new ArrayList<>();

    private boolean reviewed;

    private List<String> errorMessages = new ArrayList<>();

    private List<String> infoMessages = new ArrayList<>();

    public OFDBatch() {

    }

    public OFDBatch(ShopOperator shopOperator) {
        this.id = IdUtil.generateUniqueId();
        this.status = BatchStatus.NEW;
        this.shopOperator = Ref.create(shopOperator);
    }

    public String getId() {
        return id;
    }

    public OFDBatch setId(String id) {
        this.id = id;
        return this;
    }

    public Date getTimeStarted() {
        return timeStarted;
    }

    public OFDBatch setTimeStarted(Date timeStarted) {
        this.timeStarted = timeStarted;
        return this;
    }

    public Date getTimeFinished() {
        return timeFinished;
    }

    public OFDBatch setTimeFinished(Date timeFinished) {
        this.timeFinished = timeFinished;
        return this;
    }

    public BatchStatus getStatus() {
        return status;
    }

    public OFDBatch setStatus(BatchStatus status) {
        this.status = status;
        return this;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public OFDBatch setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
        return this;
    }

    public ShopOperator getShopOperator() {
        return shopOperator.get();
    }

    public OFDBatch setShopOperator(ShopOperator shopOperator) {
        this.shopOperator = Ref.create(shopOperator);
        return this;
    }

    public String getBatchDay() {
        return batchDay;
    }

    public OFDBatch setBatchDay(String batchDay) {
        this.batchDay = batchDay;
        return this;
    }

    public List<String> getInfoMessages() {
        return infoMessages;
    }

    public OFDBatch setInfoMessages(List<String> infoMessages) {
        this.infoMessages = infoMessages;
        return this;
    }

    public List<Date> getTimeContinued() {
        return timeContinued;
    }

    public OFDBatch setTimeContinued(List<Date> timeContinued) {
        this.timeContinued = timeContinued;
        return this;
    }

    public Integer getPeriodLength() {
        return periodLength;
    }

    public OFDBatch setPeriodLength(Integer periodLength) {
        this.periodLength = periodLength;
        return this;
    }

    public List<String> getNotes() {
        return notes;
    }

    public OFDBatch setNotes(List<String> notes) {
        this.notes = notes;
        return this;
    }

    public boolean isReviewed() {
        return reviewed;
    }

    public OFDBatch setReviewed(boolean reviewed) {
        this.reviewed = reviewed;
        return this;
    }

    public void setStartedBy(String startedBy) {
        this.startedBy = startedBy;
    }

    public String getStartedBy() {
        return startedBy;
    }

    public Integer getReceiptsRetrieved() {
        return receiptsRetrieved;
    }

    public OFDBatch setReceiptsRetrieved(Integer receiptsRetrieved) {
        this.receiptsRetrieved = receiptsRetrieved;
        return this;
    }

    public OFDBatch addReceiptsRetrieved(int howMany) {
        this.receiptsRetrieved += howMany;
        return this;
    }
}
