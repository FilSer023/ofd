package threewks.model;

import com.googlecode.objectify.Ref;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import threewks.model.dto.RentalAreaDto;
import threewks.util.IdUtil;

import java.math.BigDecimal;
import java.util.List;

@Entity
public class RentalArea {

    @Id
    private String id;

    @Index
    private String name;

    private String floor;

    @Index
    private RentalAreaStatus status;

    @Index
    private Airport airport;

    @Index
    private Ref<AirportCatalog> airportCatalog;

    private DateTime created;

    @Deprecated
    private String area;

    private BigDecimal areaSize;

    private RentalAreaZone zone;

    private List<String> gates;

    public RentalArea() {
        this.id = IdUtil.generateUniqueId();
        this.status = RentalAreaStatus.ACTIVE;
    }

    public String getId() {
        return id;
    }

    public DateTime getCreated() {
        return created;
    }

    public void setCreated(DateTime created) {
        this.created = created;
    }

    public String getName() {
        return name;
    }

    public RentalArea setName(String name) {
        this.name = name;
        return this;
    }

    public String getFloor() {
        return floor;
    }

    public RentalArea setFloor(String floor) {
        this.floor = floor;
        return this;
    }

    public RentalAreaStatus getStatus() {
        return status;
    }

    public RentalArea setStatus(RentalAreaStatus status) {
        this.status = status;
        return this;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public Airport getAirport() {
        return airport;
    }

    public RentalArea setAirport(Airport airport) {
        this.airport = airport;
        return this;
    }

    public RentalAreaZone getZone() {
        return zone;
    }

    public void setZone(RentalAreaZone zone) {
        this.zone = zone;
    }

    public List<String> getGates() {
        return gates;
    }

    public void setGates(List<String> gates) {
        this.gates = gates;
    }

    public AirportCatalog getAirportCatalog() {
        return (airportCatalog != null) ? airportCatalog.get() : null;
    }

    public RentalArea setAirportCatalog(AirportCatalog airportCatalog) {
        this.airportCatalog = Ref.create(airportCatalog);
        return this;
    }

    public BigDecimal getAreaSize() {
        return areaSize;
    }

    public RentalArea setAreaSize(BigDecimal areaSize) {
        this.areaSize = areaSize;
        return this;
    }

    public RentalArea fromDto(RentalAreaDto rentalAreaDto) {
        if (StringUtils.isNotEmpty(rentalAreaDto.getId())) {
            this.id = rentalAreaDto.getId();
        }
        this.setName(rentalAreaDto.getName());
        this.setArea(rentalAreaDto.getArea());
        this.setStatus(rentalAreaDto.getStatus());
        this.setAirport(rentalAreaDto.getAirport());
        this.setZone(rentalAreaDto.getZone());
        this.setGates(rentalAreaDto.getGates());
        this.setAreaSize(rentalAreaDto.getAreaSize());
        this.setAirportCatalog(rentalAreaDto.getAirportCatalog());
        return this;
    }
}
