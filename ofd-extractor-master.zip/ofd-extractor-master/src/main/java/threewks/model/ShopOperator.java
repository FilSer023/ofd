package threewks.model;

import com.googlecode.objectify.Ref;
import com.googlecode.objectify.annotation.Cache;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import org.joda.time.DateTime;
import threewks.util.IdUtil;

import java.util.ArrayList;
import java.util.List;

@Entity
@Cache
public class ShopOperator {

    @Id
    private String id;

    @Index
    private String name;

    private String apiToken;
    private String ofdUsername;
    private String ofdPassword;
    private String inn;
    private OFDProvider ofdProvider;
    private String uploadKey;

    private List<TradePoint> tradePoints = new ArrayList<>();

    @Index
    private ShopOperatorStatus status;

    private DateTime created;

    @Index
    private List<Ref<RentalArea>> rentalAreas = new ArrayList<>();

    public ShopOperator() {
        this.id = IdUtil.generateUniqueId();
        this.status = ShopOperatorStatus.NEW;
    }

    public String getId() {
        return id;
    }

    public DateTime getCreated() {
        return created;
    }

    public void setCreated(DateTime created) {
        this.created = created;
    }

    public String getName() {
        return name;
    }

    public ShopOperator setName(String name) {
        this.name = name;
        return this;
    }

    public ShopOperatorStatus getStatus() {
        return status;
    }

    public ShopOperator setStatus(ShopOperatorStatus status) {
        this.status = status;
        return this;
    }

    public String getApiToken() {
        return apiToken;
    }

    public ShopOperator setApiToken(String apiToken) {
        this.apiToken = apiToken;
        return this;
    }

    public OFDProvider getOfdProvider() {
        return ofdProvider;
    }

    public ShopOperator setOfdProvider(OFDProvider ofdProvider) {
        this.ofdProvider = ofdProvider;
        return this;
    }


    public List<RentalArea> getRentalAreas() {
        List<RentalArea> rentalAreas = new ArrayList<>();
        if (this.tradePoints != null) {
            for (TradePoint tradePoint : tradePoints) {
                if (tradePoint != null && tradePoint.getRentalAreaRef() != null) {
                    rentalAreas.add(tradePoint.getRentalAreaRef());
                }
            }
        }
        return rentalAreas;
    }

    public ShopOperator setRentalAreas(List<RentalArea> rentalAreas) {
        this.rentalAreas = new ArrayList<>();
        if (rentalAreas != null)
            for (RentalArea rentalArea : rentalAreas) {
                this.rentalAreas.add(Ref.create(rentalArea));
            }
        return this;

    }

    public String getUploadKey() {
        return uploadKey;
    }

    public void setUploadKey(String uploadKey) {
        this.uploadKey = uploadKey;
    }

    public String getInn() {
        return inn;
    }

    public ShopOperator setInn(String inn) {
        this.inn = inn;
        return this;
    }

    public List<TradePoint> getTradePoints() {
        return tradePoints;
    }

    public ShopOperator setTradePoints(List<TradePoint> tradePoints) {
        this.tradePoints = tradePoints;
        return this;
    }

    public String getOfdUsername() {
        return ofdUsername;
    }

    public ShopOperator setOfdUsername(String ofdUsername) {
        this.ofdUsername = ofdUsername;
        return this;
    }

    public String getOfdPassword() {
        return ofdPassword;
    }

    public ShopOperator setOfdPassword(String ofdPassword) {
        this.ofdPassword = ofdPassword;
        return this;
    }
}
