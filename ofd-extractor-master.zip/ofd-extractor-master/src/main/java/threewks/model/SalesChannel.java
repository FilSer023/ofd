package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.util.IdUtil;

@Entity
public class SalesChannel {

    @Id
    private String id;

    @Index
    private String name;

    public SalesChannel() {
        this.id = IdUtil.generateUniqueId();
    }

    public String getId() {
        return id;
    }

    public SalesChannel setId(String id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public SalesChannel setName(String name) {
        this.name = name;
        return this;
    }
}
