package threewks.model;

import org.joda.time.DateTime;

public class KKTFiscalDrive {
    private String kktRegId;
    private String fiscalDriveNumber;
    private DateTime dateAdded;

    public KKTFiscalDrive() {
    }

    public KKTFiscalDrive(String kktRegId, String fiscalDriveNumber) {
        this.kktRegId = kktRegId;
        this.fiscalDriveNumber = fiscalDriveNumber;
    }

    public String getKktRegId() {
        return kktRegId;
    }

    public String getFiscalDriveNumber() {
        return fiscalDriveNumber;
    }

    public DateTime getDateAdded() {
        return dateAdded;
    }

    public KKTFiscalDrive setDateAdded(DateTime dateAdded) {
        this.dateAdded = dateAdded;
        return this;
    }

    @Override
    public String toString() {
        return "KKTFiscalDrive{" +
            "kktRegId='" + kktRegId + '\'' +
            ", fiscalDriveNumber='" + fiscalDriveNumber + '\'' +
            ", dateAdded='" + dateAdded + '\'' +
            '}';
    }
}
