package threewks.model;

import threewks.framework.ref.ReferenceData;

import java.util.Arrays;
import java.util.List;

public enum Airport implements ReferenceData {

    AAQ("Анапа", 1),
    AER("Сочи", 2),
    GDZ("Геленджик", 3),
    KRR("Краснодар", 4);

    private final String description;
    private final int sortOrder;

    Airport(String description, int sortOrder) {
        this.description = description;
        this.sortOrder = sortOrder;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public static List<String> getAirportNames() {
        return Arrays.asList(AAQ.name(), AAQ.name(), GDZ.name(), KRR.name());
    }

}
