package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.util.IdUtil;

import java.util.*;

@Entity
public class PassengerFeedBatch {

    private String startedBy;

    public static class SearchFields {
        public static final String TimeFinished = "timeFinished";
        public static final String TimeStarted = "timeStarted";
        public static final String Status = "status";
    }

    @Id
    private String id;

    @Index
    private Date timeStarted;

    @Index
    private Date timeFinished;

    @Index
    private PassengerFeedBatchStatus status;

    private Map<String, Integer> linesImported = new HashMap<>();
    private String feedDay;

    private List<String> notes = new ArrayList<>();

    private boolean reviewed;

    private List<String> errorMessages = new ArrayList<>();

    private List<String> infoMessages = new ArrayList<>();

    private boolean automatic = true;

    private String manualUploadAirportName;

    public PassengerFeedBatch() {
        this.id = IdUtil.generateUniqueId();
    }

    public PassengerFeedBatch(String feedDay) {
        this.feedDay = feedDay;
        this.id = IdUtil.generateUniqueId();
    }

    public String getId() {
        return id;
    }

    public String getStartedBy() {
        return startedBy;
    }

    public PassengerFeedBatch setStartedBy(String startedBy) {
        this.startedBy = startedBy;
        return this;
    }

    public Date getTimeStarted() {
        return timeStarted;
    }

    public PassengerFeedBatch setTimeStarted(Date timeStarted) {
        this.timeStarted = timeStarted;
        return this;
    }

    public Date getTimeFinished() {
        return timeFinished;
    }

    public PassengerFeedBatch setTimeFinished(Date timeFinished) {
        this.timeFinished = timeFinished;
        return this;
    }

    public String getFeedDay() {
        return feedDay;
    }

    public PassengerFeedBatch setFeedDay(String feedDay) {
        this.feedDay = feedDay;
        return this;
    }

    public List<String> getNotes() {
        return notes;
    }

    public PassengerFeedBatch setNotes(List<String> notes) {
        this.notes = notes;
        return this;
    }

    public boolean isReviewed() {
        return reviewed;
    }

    public PassengerFeedBatch setReviewed(boolean reviewed) {
        this.reviewed = reviewed;
        return this;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public PassengerFeedBatch setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
        return this;
    }

    public List<String> getInfoMessages() {
        return infoMessages;
    }

    public PassengerFeedBatch setInfoMessages(List<String> infoMessages) {
        this.infoMessages = infoMessages;
        return this;
    }

    public PassengerFeedBatchStatus getStatus() {
        return status;
    }

    public PassengerFeedBatch setStatus(PassengerFeedBatchStatus status) {
        this.status = status;
        return this;
    }

    public Map<String, Integer> getLinesImported() {
        return linesImported;
    }

    public PassengerFeedBatch setLinesImported(Map<String, Integer> linesImported) {
        this.linesImported = linesImported;
        return this;
    }

    public boolean isAutomatic() {
        return automatic;
    }

    public void setAutomatic(boolean automatic) {
        this.automatic = automatic;
    }

    public String getManualUploadAirportName() {
        return manualUploadAirportName;
    }

    public void setManualUploadAirportName(String manualUploadAirportName) {
        this.manualUploadAirportName = manualUploadAirportName;
    }
}
