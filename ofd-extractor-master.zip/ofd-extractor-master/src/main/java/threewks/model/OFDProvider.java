package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum OFDProvider implements ReferenceData {
    YARUS("Ярус"), KONTUR("Контур"), UPLOAD("Импорт файлов"), PETER_SERVIS("Петер-Сервис");

    private String description;

    private OFDProvider(String description) {
        this.description = description;
    }

    @Override
    public String getDescription() {
        return description;
    }
}
