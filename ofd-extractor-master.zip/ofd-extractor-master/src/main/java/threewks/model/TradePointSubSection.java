package threewks.model;

import com.googlecode.objectify.Ref;

import java.math.BigDecimal;

public class TradePointSubSection {

    private SubSectionCategory category;
    private Ref<SubSectionCategory> categoryRef = null;
    private BigDecimal areaSize;

    public TradePointSubSection() {
    }

    public SubSectionCategory getCategory() {
        return category;
    }

    public TradePointSubSection setCategory(SubSectionCategory category) {
        this.category = category;
        return this;
    }

    public BigDecimal getAreaSize() {
        return areaSize;
    }

    public TradePointSubSection setAreaSize(BigDecimal areaSize) {
        this.areaSize = areaSize;
        return this;
    }

    public SubSectionCategory getCategoryRef() {
        return (categoryRef != null) ? categoryRef.get() : null;
    }

    public TradePointSubSection setCategoryRef(SubSectionCategory category) {
        this.categoryRef = Ref.create(category);
        return this;
    }
}
