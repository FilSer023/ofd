package threewks.model;


import java.util.List;

public class PagedResult<E> {
    private List<E> results;
    private String cursorWebSafeString;
    private int offset;
    private boolean hasMore;

    public PagedResult() {
    }

    public PagedResult(List<E> results, String cursorWebSafeString) {
        this.results = results;
        this.cursorWebSafeString = cursorWebSafeString;
    }

    public List<E> getResults() {
        return results;
    }

    public void setResults(List<E> results) {
        this.results = results;
    }

    public String getCursorWebSafeString() {
        return cursorWebSafeString;
    }

    public void setCursorWebSafeString(String cursorWebSafeString) {
        this.cursorWebSafeString = cursorWebSafeString;
    }

    public int getOffset() {
        return offset;
    }

    public PagedResult<E> setOffset(int offset) {
        this.offset = offset;
        return this;
    }

    public boolean isHasMore() {
        return hasMore;
    }

    public PagedResult<E> setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
        return this;
    }
}
