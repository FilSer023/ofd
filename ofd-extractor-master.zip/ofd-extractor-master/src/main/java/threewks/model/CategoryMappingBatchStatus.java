package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum CategoryMappingBatchStatus implements ReferenceData {

    NEW("Новый", 1),
    STARTED("Инициирован", 2),
    EXPORT_TO_SHEET_COMPLETED("Конвертация файла завершена", 3),
    IMPORT_TO_BQ_COMPLETED("Импорт данных из таблицы в хранилище данных завершен", 4),
    ERROR("Ошибка", 5);

    private final String description;
    private final int sortOrder;

    CategoryMappingBatchStatus(String description, int sortOrder) {
        this.description = description;
        this.sortOrder = sortOrder;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public int getSortOrder() {
        return sortOrder;
    }
}
