package threewks.model;

import java.util.ArrayList;
import java.util.List;

public class MissingCategory {
    private String sku;
    private String shopOperator;
    private String price;
    private List<String> category = new ArrayList<>();
    private String inn;
    private String tradepointName;

    public MissingCategory() {
    }

    public MissingCategory(String sku, String price, String tradepointName) {
        this.sku = sku;
        this.price = price;
        this.tradepointName = tradepointName;
    }

    public String getSku() {
        return sku;
    }

    public MissingCategory setSku(String sku) {
        this.sku = sku;
        return this;
    }

    public List<String> getCategory() {
        return category;
    }

    public MissingCategory setCategory(List<String> category) {
        this.category = category;
        return this;
    }

    public String getShopOperator() {
        return shopOperator;
    }

    public MissingCategory setShopOperator(String shopOperator) {
        this.shopOperator = shopOperator;
        return this;
    }

    public String getPrice() {
        return price;
    }

    public MissingCategory setPrice(String price) {
        this.price = price;
        return this;
    }
}
