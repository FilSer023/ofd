package threewks.model.dto;

import threewks.framework.cloudstorage.attachment.model.Attachment;

public class PassengerFeedManualUploadDTO {
    private Attachment[] attachment;
    private String airport;

    public PassengerFeedManualUploadDTO() {
    }

    public Attachment getAttachment() {
        return attachment[0];
    }

    public String getAirport() {
        return airport;
    }

    public void setAirport(String airport) {
        this.airport = airport;
    }
}
