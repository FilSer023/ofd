package threewks.model.dto;

import threewks.framework.cloudstorage.attachment.AttachmentDto;
import threewks.framework.usermanager.model.AppUser;
import threewks.model.CategoryMappingBatch;
import threewks.model.CategoryMappingBatchStatus;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CategoryMappingBatchDTO {

    private static final DateFormat DATE_TIME_FORMATTER = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    private String id;

    private String timeStarted;

    private String timeFinished;

    private String startedBy;

    private boolean shareDocument;
    private AppUser startedByUser;

    private CategoryMappingBatchStatus status;

    private List<String> notes = new ArrayList<>();

    private List<String> errorMessages = new ArrayList<>();

    private List<String> infoMessages = new ArrayList<>();

    private List<AttachmentDto> attachment = new ArrayList<>();

    public CategoryMappingBatchDTO() {

    }

    public CategoryMappingBatchDTO(String id, Date timeStarted, Date timeFinished, CategoryMappingBatchStatus status,
                                   List<String> notes, List<String> errorMessages, List<String> infoMessages,
        List<AttachmentDto> attachments, String startedBy, boolean shareDocument, AppUser startedByUser) {
        this.id = id;
        if (timeStarted != null) {
            this.timeStarted = DATE_TIME_FORMATTER.format(timeStarted);
        }
        if (timeFinished != null) {
            this.timeFinished = DATE_TIME_FORMATTER.format(timeFinished);
        }
        this.status = status;
        this.notes = notes;
        this.errorMessages = errorMessages;
        this.infoMessages = infoMessages;
        this.attachment = attachments;
        this.startedBy = startedBy;
        this.shareDocument = shareDocument;
        this.startedByUser = startedByUser;
    }

    public static CategoryMappingBatchDTO from(CategoryMappingBatch categoryMappingBatch) {
        return new CategoryMappingBatchDTO(categoryMappingBatch.getId(), categoryMappingBatch.getTimeStarted(),
            categoryMappingBatch.getTimeFinished(), categoryMappingBatch.getStatus(),
            categoryMappingBatch.getNotes(), categoryMappingBatch.getErrorMessages(),
            categoryMappingBatch.getInfoMessages(), categoryMappingBatch.getAttachment(),
            categoryMappingBatch.getStartedBy(), categoryMappingBatch.isShareDocument(), categoryMappingBatch.getStartedByUser());
    }

    public String getTimeStarted() {
        return timeStarted;
    }

    public CategoryMappingBatchDTO setTimeStarted(String timeStarted) {
        this.timeStarted = timeStarted;
        return this;
    }

    public String getTimeFinished() {
        return timeFinished;
    }

    public CategoryMappingBatchDTO setTimeFinished(String timeFinished) {
        this.timeFinished = timeFinished;
        return this;
    }

    public CategoryMappingBatchStatus getStatus() {
        return status;
    }

    public CategoryMappingBatchDTO setStatus(CategoryMappingBatchStatus status) {
        this.status = status;
        return this;
    }

    public List<String> getNotes() {
        return notes;
    }

    public CategoryMappingBatchDTO setNotes(List<String> notes) {
        this.notes = notes;
        return this;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public CategoryMappingBatchDTO setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
        return this;
    }

    public List<String> getInfoMessages() {
        return infoMessages;
    }

    public CategoryMappingBatchDTO setInfoMessages(List<String> infoMessages) {
        this.infoMessages = infoMessages;
        return this;
    }

    public List<AttachmentDto> getAttachment() {
        return attachment;
    }

    public CategoryMappingBatchDTO setAttachment(List<AttachmentDto> attachment) {
        this.attachment = attachment;
        return this;
    }

    public String getStartedBy() {
        return startedBy;
    }

    public CategoryMappingBatchDTO setStartedBy(String startedBy) {
        this.startedBy = startedBy;
        return this;
    }

    public boolean isShareDocument() {
        return shareDocument;
    }

    public CategoryMappingBatchDTO setShareDocument(boolean shareDocument) {
        this.shareDocument = shareDocument;
        return this;
    }

    public AppUser getStartedByUser() {
        return startedByUser;
    }

    public CategoryMappingBatchDTO setStartedByUser(AppUser startedByUser) {
        this.startedByUser = startedByUser;
        return this;
    }
}
