package threewks.model.dto;

import threewks.model.OFDProvider;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;

import java.util.List;
import java.util.stream.Collectors;

public class ShopOperatorDto {

    private String id;
    private String name;
    private ShopOperatorStatus status;
    private String apiToken;
    private String ofdUsername;
    private String ofdPassword;
    private String uploadKey;
    private String inn;
    private OFDProvider ofdProvider;
    private List<TradePointDto> tradePoints;

    public ShopOperatorDto() {
    }

    public static ShopOperatorDto from(ShopOperator shopOperator) {
        return new ShopOperatorDto(shopOperator.getId(),
            shopOperator.getName(),
            shopOperator.getStatus(),
            shopOperator.getUploadKey(),
            shopOperator.getApiToken(),
            shopOperator.getInn(),
            shopOperator.getOfdProvider(),
            shopOperator.getTradePoints().stream()
                .map(tradePoint -> TradePointDto.CONVERT.apply(tradePoint)).collect(Collectors.toList()),
            shopOperator.getOfdUsername(),
            shopOperator.getOfdPassword());
    }

    public ShopOperatorDto(String id, String name, ShopOperatorStatus status,
        String uploadKey, String apiToken, String inn, OFDProvider ofdProvider, List<TradePointDto> tradePoints,
        String ofdUsername, String ofdPassword) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.uploadKey = uploadKey;
        this.apiToken = apiToken;
        this.inn = inn;
        this.ofdProvider = ofdProvider;
        this.tradePoints = tradePoints;
        this.ofdUsername = ofdUsername;
        this.ofdPassword = ofdPassword;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ShopOperatorStatus getStatus() {
        return status;
    }

    public String getUploadKey() {
        return uploadKey;
    }

    public String getInn() {
        return inn;
    }

    public OFDProvider getOfdProvider() {
        return ofdProvider;
    }

    public List<TradePointDto> getTradePoints() {
        return tradePoints;
    }

    public ShopOperatorDto setTradePoints(List<TradePointDto> tradePoints) {
        this.tradePoints = tradePoints;
        return this;
    }

    public String getApiToken() {
        return apiToken;
    }

    public void setApiToken(String apiToken) {
        this.apiToken = apiToken;
    }

    public String getOfdUsername() {
        return ofdUsername;
    }

    public String getOfdPassword() {
        return ofdPassword;
    }
}
