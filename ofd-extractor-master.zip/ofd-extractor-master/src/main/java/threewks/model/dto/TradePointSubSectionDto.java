package threewks.model.dto;

import threewks.model.SubSectionCategory;

import java.math.BigDecimal;

public class TradePointSubSectionDto {

    private SubSectionCategory category;
    private BigDecimal areaSize;

    public TradePointSubSectionDto() {
    }

    public SubSectionCategory getCategory() {
        return category;
    }

    public TradePointSubSectionDto setCategory(SubSectionCategory category) {
        this.category = category;
        return this;
    }

    public BigDecimal getAreaSize() {
        return areaSize;
    }

    public TradePointSubSectionDto setAreaSize(BigDecimal areaSize) {
        this.areaSize = areaSize;
        return this;
    }
}
