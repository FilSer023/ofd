package threewks.model.dto;

import org.joda.time.DateTime;
import threewks.model.Airport;
import threewks.model.AirportCatalog;
import threewks.model.RentalArea;
import threewks.model.RentalAreaStatus;
import threewks.model.RentalAreaZone;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class RentalAreaDto {

    private String id;
    private String name;
    private String floor;
    private RentalAreaStatus status;
    private DateTime created;
    private String area;
    private BigDecimal areaSize;
    private Airport airport;
    private String tenant;
    private AirportCatalog airportCatalog;
    private RentalAreaZone zone;
    private List<String> gates = new ArrayList<>();

    public RentalAreaDto() {
    }

    public static RentalAreaDto from(RentalArea rentalArea, String tenantName) {
        if (rentalArea != null) {
            return new RentalAreaDto()
                .setId(rentalArea.getId())
                .setName(rentalArea.getName())
                .setFloor(rentalArea.getFloor())
                .setStatus(rentalArea.getStatus())
                .setCreated(rentalArea.getCreated())
                .setArea(rentalArea.getArea())
                .setAreaSize(rentalArea.getAreaSize())
                .setAirport(rentalArea.getAirport())
                .setZone(rentalArea.getZone())
                .setGates(rentalArea.getGates())
                .setAirportCatalog(rentalArea.getAirportCatalog())
                .setTenant(tenantName);
        } else {
            return null;
        }
    }

    public static RentalAreaDto from(RentalArea rentalArea) {
        if (rentalArea != null) {
            return new RentalAreaDto()
                .setId(rentalArea.getId())
                .setName(rentalArea.getName())
                .setFloor(rentalArea.getFloor())
                .setStatus(rentalArea.getStatus())
                .setCreated(rentalArea.getCreated())
                .setArea(rentalArea.getArea())
                .setAreaSize(rentalArea.getAreaSize())
                .setAirport(rentalArea.getAirport())
                .setZone(rentalArea.getZone())
                .setGates(rentalArea.getGates())
                .setAirportCatalog(rentalArea.getAirportCatalog());
        } else {
            return null;
        }
    }

    public String getId() {
        return id;
    }

    public RentalAreaDto setId(String id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public RentalAreaDto setName(String name) {
        this.name = name;
        return this;
    }

    public String getFloor() {
        return floor;
    }

    public RentalAreaDto setFloor(String floor) {
        this.floor = floor;
        return this;
    }

    public RentalAreaStatus getStatus() {
        return status;
    }

    public RentalAreaDto setStatus(RentalAreaStatus status) {
        this.status = status;
        return this;
    }

    public DateTime getCreated() {
        return created;
    }

    public RentalAreaDto setCreated(DateTime created) {
        this.created = created;
        return this;
    }

    public String getArea() {
        return area;
    }

    public RentalAreaDto setArea(String area) {
        this.area = area;
        return this;
    }

    public BigDecimal getAreaSize() {
        return areaSize;
    }

    public RentalAreaDto setAreaSize(BigDecimal areaSize) {
        this.areaSize = areaSize;
        return this;
    }

    public Airport getAirport() {
        return airport;
    }

    public RentalAreaDto setAirport(Airport airport) {
        this.airport = airport;
        return this;
    }

    public RentalAreaZone getZone() {
        return zone;
    }

    public RentalAreaDto setZone(RentalAreaZone zone) {
        this.zone = zone;
        return this;
    }

    public List<String> getGates() {
        return gates;
    }

    public RentalAreaDto setGates(List<String> gates) {
        this.gates = gates;
        return this;
    }

    public AirportCatalog getAirportCatalog() {
        return airportCatalog;
    }

    public RentalAreaDto setAirportCatalog(AirportCatalog airportCatalog) {
        this.airportCatalog = airportCatalog;
        return this;
    }

    public String getTenant() {
        return tenant;
    }

    public RentalAreaDto setTenant(String tenant) {
        this.tenant = tenant;
        return this;
    }
}
