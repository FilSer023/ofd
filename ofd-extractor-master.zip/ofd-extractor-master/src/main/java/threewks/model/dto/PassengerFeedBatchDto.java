package threewks.model.dto;

import threewks.model.PassengerFeedBatch;
import threewks.model.PassengerFeedBatchStatus;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class PassengerFeedBatchDto {

    private static final DateFormat DATE_TIME_FORMATTER = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    private String id;
    private String timeStarted;
    private String timeFinished;
    private PassengerFeedBatchStatus status;
    private String feedDay;
    private Map<String, Integer> linesImported;
    private boolean reviewed;
    private List<String> errorMessages;
    private List<String> infoMessages;
    private List<String> notes;

    public PassengerFeedBatchDto() {
    }

    private PassengerFeedBatchDto(String id, Date timeStarted, Date timeFinished,
        PassengerFeedBatchStatus status, String feedDay, List<String> errorMessages,
        List<String> infoMessages, List<String> notes, boolean reviewed, Map<String, Integer> linesImported) {
        this.id = id;
        if (timeStarted != null) {
            this.timeStarted = DATE_TIME_FORMATTER.format(timeStarted);
        }
        if (timeFinished != null) {
            this.timeFinished = DATE_TIME_FORMATTER.format(timeFinished);
        }
        this.status = status;
        this.feedDay = feedDay;
        this.errorMessages = errorMessages;
        this.infoMessages = infoMessages;
        this.notes = notes;
        this.reviewed = reviewed;
        this.linesImported = linesImported;
    }

    public static PassengerFeedBatchDto from(PassengerFeedBatch passengerFeedBatch) {
        return new PassengerFeedBatchDto(passengerFeedBatch.getId(),
            passengerFeedBatch.getTimeStarted(), passengerFeedBatch.getTimeFinished(), passengerFeedBatch.getStatus(), passengerFeedBatch.getFeedDay(),
            passengerFeedBatch.getErrorMessages(), passengerFeedBatch.getInfoMessages(), passengerFeedBatch.getNotes(),
            passengerFeedBatch.isReviewed(), passengerFeedBatch.getLinesImported());
    }
}
