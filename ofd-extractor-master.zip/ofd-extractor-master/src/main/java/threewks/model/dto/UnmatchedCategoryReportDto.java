package threewks.model.dto;

import org.joda.time.DateTime;
import threewks.model.UnmatchedCategoryReport;

import java.util.List;

public class UnmatchedCategoryReportDto {
    private String id;
    private DateTime createdDate;
    private String gcsFileName;
    private Long count;
    private List<String> errorMessages;
    private boolean processed;

    public UnmatchedCategoryReportDto() {
    }

    public UnmatchedCategoryReportDto(String id, DateTime createdDate, String gcsFileName, Long count,
        List<String> errorMessages, boolean processed) {
        this.id = id;
        this.createdDate = createdDate;
        this.gcsFileName = gcsFileName;
        this.count = count;
        this.errorMessages = errorMessages;
        this.processed = processed;
    }

    public static UnmatchedCategoryReportDto from(UnmatchedCategoryReport unmatchedCategoryReport) {
        return new UnmatchedCategoryReportDto(unmatchedCategoryReport.getId(),
            unmatchedCategoryReport.getCreatedDate(),
            unmatchedCategoryReport.getGcsFileName(), unmatchedCategoryReport.getCount(),
            unmatchedCategoryReport.getErrorMessages(), unmatchedCategoryReport.isProcessed());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public DateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(DateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getGcsFileName() {
        return gcsFileName;
    }

    public void setGcsFileName(String gcsFileName) {
        this.gcsFileName = gcsFileName;
    }

    public Long getCount() {
        return count;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public UnmatchedCategoryReportDto setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
        return this;
    }

    public boolean isProcessed() {
        return processed;
    }

    public UnmatchedCategoryReportDto setProcessed(boolean processed) {
        this.processed = processed;
        return this;
    }
}
