package threewks.model.dto;

import threewks.model.ShopOperator;

import java.util.function.Function;

public class FromShopOperatorDtoToShopOperator implements Function<ShopOperatorDto, ShopOperator> {

    public static FromShopOperatorDtoToShopOperator INSTANCE = new FromShopOperatorDtoToShopOperator();


    @Override
    public ShopOperator apply(ShopOperatorDto shopOperatorDto) {
        return null;
    }
}
