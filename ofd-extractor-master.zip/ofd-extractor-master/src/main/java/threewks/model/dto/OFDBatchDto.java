package threewks.model.dto;

import threewks.model.BatchStatus;
import threewks.model.OFDBatch;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class OFDBatchDto {

    private static final DateFormat DATE_TIME_FORMATTER = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

    private String id;
    private String shopOperator;
    private String ofdProvider;
    private String timeStarted;
    private String timeFinished;
    private BatchStatus status;
    private String batchDay;
    private int periodLength;
    private int receiptsRetrieved;
    private boolean reviewed;
    private List<String> errorMessages;
    private List<String> infoMessages;
    private List<String> notes;

    public OFDBatchDto() {
    }

    private OFDBatchDto(String id, String shopOperator, String ofdProvider, Date timeStarted, Date timeFinished, int periodLength,
        int receiptsRetrieved, BatchStatus status, String batchDay, List<String> errorMessages, List<String> infoMessages, List<String> notes, boolean reviewed) {
        this.id = id;
        this.shopOperator = shopOperator;
        if (timeStarted != null) {
            this.timeStarted = DATE_TIME_FORMATTER.format(timeStarted);
        }
        if (timeFinished != null) {
            this.timeFinished = DATE_TIME_FORMATTER.format(timeFinished);
        }
        this.ofdProvider = ofdProvider;
        this.status = status;
        this.batchDay = batchDay;
        this.errorMessages = errorMessages;
        this.infoMessages = infoMessages;
        this.periodLength = periodLength;
        this.receiptsRetrieved = receiptsRetrieved;
        this.notes = notes;
        this.reviewed = reviewed;
    }

    public static OFDBatchDto from(OFDBatch ofdBatch) {
        return new OFDBatchDto(ofdBatch.getId(), ofdBatch.getShopOperator().getName(),
            ofdBatch.getShopOperator().getOfdProvider().name(),
            ofdBatch.getTimeStarted(), ofdBatch.getTimeFinished(),
            ofdBatch.getPeriodLength(), ofdBatch.getReceiptsRetrieved(), ofdBatch.getStatus(), ofdBatch.getBatchDay(),
            ofdBatch.getErrorMessages(), ofdBatch.getInfoMessages(), ofdBatch.getNotes(), ofdBatch.isReviewed());
    }
}
