package threewks.model.dto;

import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import threewks.model.KKTFiscalDrive;
import threewks.model.SalesChannel;
import threewks.model.TradePoint;
import threewks.model.TradePointSubSection;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class TradePointDto {

    private String name;
    private SalesChannel salesChannel;
    private String staffQuantity;
    private String contractNumber;
    private DateTime contractDate;
    private RentalAreaDto rentalArea;
    private List<TradePointSubSectionDto> categoryAreas;
    private List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();

    public String getName() {
        return name;
    }

    public TradePointDto setName(String name) {
        this.name = name;
        return this;
    }

    public String getStaffQuantity() {
        return staffQuantity;
    }

    public TradePointDto setStaffQuantity(String staffQuantity) {
        this.staffQuantity = staffQuantity;
        return this;
    }

    public RentalAreaDto getRentalArea() {
        return rentalArea;
    }

    public TradePointDto setRentalArea(RentalAreaDto rentalAreaRef) {
        this.rentalArea = rentalAreaRef;
        return this;
    }

    public DateTime getContractDate() {
        return contractDate;
    }

    public TradePointDto setContractDate(DateTime contractDate) {
        this.contractDate = contractDate;
        return this;
    }

    public List<KKTFiscalDrive> getKktFiscalDrives() {
        return kktFiscalDrives;
    }

    public TradePointDto setKktFiscalDrives(List<KKTFiscalDrive> kktFiscalDrives) {
        this.kktFiscalDrives = kktFiscalDrives;
        return this;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public TradePointDto setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
        return this;
    }

    public SalesChannel getSalesChannel() {
        return salesChannel;
    }

    public TradePointDto setSalesChannel(SalesChannel salesChannel) {
        this.salesChannel = salesChannel;
        return this;
    }

    public List<TradePointSubSectionDto> getCategoryAreas() {
        return categoryAreas;
    }

    public void setCategoryAreas(List<TradePointSubSectionDto> categoryAreas) {
        this.categoryAreas = categoryAreas;
    }

    public static Function<TradePoint, TradePointDto> CONVERT = tradePoint -> {
        TradePointDto tradePointDto = new TradePointDto();
        tradePointDto.setName(tradePoint.getName());
        tradePointDto.setContractDate(tradePoint.getContractDate());
        tradePointDto.setContractNumber(tradePoint.getContractNumber());
        tradePointDto.setKktFiscalDrives(tradePoint.getKktFiscalDrives());
        tradePointDto.setStaffQuantity(tradePoint.getStaffQuantity());
        tradePointDto.setRentalArea(RentalAreaDto.from(tradePoint.getRentalAreaRef(), tradePointDto.getName()));
        List<TradePointSubSectionDto> categories = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(tradePoint.getCategoryAreas())) {
            for (TradePointSubSection subSection : tradePoint.getCategoryAreas()) {
                TradePointSubSectionDto tradePointSubSection = new TradePointSubSectionDto();
                tradePointSubSection.setCategory(subSection.getCategoryRef());
                tradePointSubSection.setAreaSize(subSection.getAreaSize());
                categories.add(tradePointSubSection);
            }
        }
        tradePointDto.setCategoryAreas(categories);
        tradePointDto.setSalesChannel(tradePoint.getSalesChannel());
        return tradePointDto;
    };

    @Override
    public String toString() {
        return "TradePoint{" +
            "name='" + name + '\'' +
            ", staffQuantity='" + staffQuantity + '\'' +
            ", contractNumber='" + contractNumber + '\'' +
            ", contractDate=" + contractDate +
            ", rentalArea=" + rentalArea +
            ", salesChannel=" + salesChannel +
            ", sectionAreas=" + categoryAreas +
            ", kktFiscalDrives=" + kktFiscalDrives +
            '}';
    }
}
