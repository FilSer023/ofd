package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import com.googlecode.objectify.annotation.OnSave;
import com.googlecode.objectify.condition.IfNotNull;
import com.threewks.thundr.search.SearchIndex;
import org.apache.commons.collections.CollectionUtils;
import threewks.util.IdUtil;
import threewks.util.SearchUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Entity
public class UnmatchedSKUItem {

    private static final int MIN_LENGTH = 4;

    public static class SearchFields {
        public static final String Operator = "operatorName";
        public static final String Sku = "skuSearchableText";
    }

    @Id
    private String id;
    private List<String> categories = new ArrayList<>();

    @Index
    private boolean allocated;

    @Index
    @SearchIndex
    private String operatorName;

    @Index
    private String sku;

    @Index
    private Date created;

    @Index(IfNotNull.class)
    private Date updated;

    public UnmatchedSKUItem() {

    }

    public UnmatchedSKUItem(String sku) {
        this.sku = sku;
        this.id = IdUtil.generateUniqueId();
        this.created = new Date();
    }

    public Date getUpdated() {
        return updated;
    }

    public UnmatchedSKUItem setUpdated(Date updated) {
        this.updated = updated;
        return this;
    }

    public String getId() {
        return id;
    }

    public UnmatchedSKUItem setId(String id) {
        this.id = id;
        return this;
    }

    public List<String> getCategories() {
        return categories;
    }

    public UnmatchedSKUItem setCategories(List<String> categories) {
        this.categories = categories;
        this.allocated = CollectionUtils.isNotEmpty(categories);
        return this;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public UnmatchedSKUItem setOperatorName(String operatorName) {
        this.operatorName = operatorName;
        return this;
    }

    @SearchIndex
    public String getSkuSearchableText() {
        return SearchUtil.getSearchableText(MIN_LENGTH, sku);
    }

    public String getSku() {
        return sku;
    }

    public UnmatchedSKUItem setSku(String sku) {
        this.sku = sku;
        return this;
    }

    public Date getCreated() {
        return created;
    }

    public UnmatchedSKUItem setCreated(Date created) {
        this.created = created;
        return this;
    }

    public boolean isAllocated() {
        return allocated;
    }

    public UnmatchedSKUItem setAllocated(boolean allocated) {
        this.allocated = allocated;
        return this;
    }

    public static UnmatchedSKUItem fromBatch(BatchForUnmatchedSKUItem batchItem) {
        UnmatchedSKUItem item = new UnmatchedSKUItem()
            .setId(batchItem.getId())
            .setOperatorName(batchItem.getOperatorName())
            .setSku(batchItem.getSku())
            .setCreated(new Date());
        return item;
    }

    @OnSave
    private void updateAllocationFlag() {
        this.allocated = !this.categories.isEmpty();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UnmatchedSKUItem that = (UnmatchedSKUItem) o;
        return Objects.equals(operatorName, that.operatorName) &&
            Objects.equals(sku, that.sku);
    }

    @Override
    public int hashCode() {
        return Objects.hash(operatorName, sku);
    }
}
