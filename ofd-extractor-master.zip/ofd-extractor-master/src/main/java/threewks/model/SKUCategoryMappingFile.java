package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.util.IdUtil;

import java.util.Date;

@Entity
public class SKUCategoryMappingFile {

    @Id
    private String id;

    @Index
    private Date timeGenerated;

    private String gcsLocation;

    private Integer lines;

    public SKUCategoryMappingFile() {
        this.id = IdUtil.generateUniqueId();
    }

    public String getId() {
        return id;
    }

    public SKUCategoryMappingFile setId(String id) {
        this.id = id;
        return this;
    }

    public Date getTimeGenerated() {
        return timeGenerated;
    }

    public SKUCategoryMappingFile setTimeGenerated(Date timeGenerated) {
        this.timeGenerated = timeGenerated;
        return this;
    }

    public String getGcsLocation() {
        return gcsLocation;
    }

    public SKUCategoryMappingFile setGcsLocation(String gcsLocation) {
        this.gcsLocation = gcsLocation;
        return this;
    }

    public Integer getLines() {
        return lines;
    }

    public SKUCategoryMappingFile setLines(Integer lines) {
        this.lines = lines;
        return this;
    }
}
