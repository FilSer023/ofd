package threewks.model;

import java.util.Date;
import java.util.List;

public class RentalAgreement {
    private String agreementNumber;
    private Date agreementDate;
    private List<RentalArea> rentalAreas;

    public RentalAgreement() {
    }

    public RentalAgreement(String agreementNumber, Date agreementDate, List<RentalArea> rentalAreas) {
        this.agreementNumber = agreementNumber;
        this.agreementDate = agreementDate;
        this.rentalAreas = rentalAreas;
    }

    public String getAgreementNumber() {
        return agreementNumber;
    }

    public void setAgreementNumber(String agreementNumber) {
        this.agreementNumber = agreementNumber;
    }

    public Date getAgreementDate() {
        return agreementDate;
    }

    public void setAgreementDate(Date agreementDate) {
        this.agreementDate = agreementDate;
    }

    public List<RentalArea> getRentalAreas() {
        return rentalAreas;
    }

    public void setRentalAreas(List<RentalArea> rentalAreas) {
        this.rentalAreas = rentalAreas;
    }
}
