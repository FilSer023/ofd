package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import threewks.util.IdUtil;

import java.util.List;

@Entity
public class AirportCatalog {

    @Id
    private String id;

    private String nameIATA;

    private String description;

    private List<String> gates;

    public AirportCatalog() {
        this.id = IdUtil.generateUniqueId();
    }

    public String getId() {
        return id;
    }

    public AirportCatalog setId(String id) {
        this.id = id;
        return this;
    }

    public String getNameIATA() {
        return nameIATA;
    }

    public AirportCatalog setNameIATA(String nameIATA) {
        this.nameIATA = nameIATA;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public AirportCatalog setDescription(String description) {
        this.description = description;
        return this;
    }

    public List<String> getGates() {
        return gates;
    }

    public void setGates(List<String> gates) {
        this.gates = gates;
    }
}
