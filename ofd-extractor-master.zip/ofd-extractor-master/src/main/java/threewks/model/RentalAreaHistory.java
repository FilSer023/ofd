package threewks.model;

import com.googlecode.objectify.Ref;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.util.IdUtil;

import java.util.Date;

@Entity
public class RentalAreaHistory {

    @Id
    private String id;

    @Index
    private Ref<RentalArea> rentalArea;

    @Index
    private Date createDate;

    @Index
    private Ref<ShopOperator> currentShopOperator;

    @Index
    private Ref<ShopOperator> previousShopOperator;

    public RentalAreaHistory() {
    }

    public RentalAreaHistory(RentalArea rentalArea) {
        this.id = IdUtil.generateUniqueId();
        this.rentalArea = Ref.create(rentalArea);
    }

    public String getId() {
        return id;
    }

    public RentalAreaHistory setId(String id) {
        this.id = id;
        return this;
    }

    public RentalArea getRentalArea() {
        return rentalArea.get();
    }

    public RentalAreaHistory setRentalArea(RentalArea rentalArea) {
        this.rentalArea = Ref.create(rentalArea);
        return this;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public RentalAreaHistory setCreateDate(Date createDate) {
        this.createDate = createDate;
        return this;
    }

    public ShopOperator getCurrentShopOperator() {
        return currentShopOperator.get();
    }

    public RentalAreaHistory setCurrentShopOperator(ShopOperator currentShopOperator) {
        this.currentShopOperator = Ref.create(currentShopOperator);
        return this;
    }

    public Ref<ShopOperator> getPreviousShopOperator() {
        return previousShopOperator;
    }

    public RentalAreaHistory setPreviousShopOperator(ShopOperator previousShopOperator) {
        this.previousShopOperator = Ref.create(previousShopOperator);
        return this;
    }
}
