package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum RentalAreaStatus implements ReferenceData {

    ACTIVE("Действующая", 1),
    MAINTENANCE("На обслуживании", 2),
    ARCHIVED("Удалена", 3);

    private final String description;
    private final int sortOrder;

    RentalAreaStatus(String description, int sortOrder) {
        this.description = description;
        this.sortOrder = sortOrder;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public int getSortOrder() {
        return sortOrder;
    }

}
