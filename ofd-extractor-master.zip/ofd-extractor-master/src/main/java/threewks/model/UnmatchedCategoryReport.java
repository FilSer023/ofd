package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import org.joda.time.DateTime;
import threewks.model.dto.UnmatchedCategoryReportDto;
import threewks.util.IdUtil;

import java.util.ArrayList;
import java.util.List;

@Entity
public class UnmatchedCategoryReport {

    public static class SearchFields {
        public static final String CreatedDate = "createdDate";
    }

    @Id
    private String id;

    @Index
    private DateTime createdDate;

    @Index
    private DateTime updatedDate;

    private String gcsFileName;
    private Long count;
    private Long matchedCount;
    private boolean processed;
    private List<String> infoMessages = new ArrayList<>();
    private List<String> errorMessages = new ArrayList<>();


    public UnmatchedCategoryReport() {
        this.id = IdUtil.generateUniqueId();
    }

    public UnmatchedCategoryReport fromDto(UnmatchedCategoryReportDto unmatchedCategoryReportDto) {
        this.setCount(unmatchedCategoryReportDto.getCount());
        this.setGcsFileName(unmatchedCategoryReportDto.getGcsFileName());
        this.setCreatedDate(unmatchedCategoryReportDto.getCreatedDate());
        return this;

    }

    public String getId() {
        return id;
    }

    public DateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(DateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getGcsFileName() {
        return gcsFileName;
    }

    public void setGcsFileName(String gcsFileName) {
        this.gcsFileName = gcsFileName;
    }

    public Long getCount() {
        return count;
    }

    public UnmatchedCategoryReport setCount(Long count) {
        this.count = count;
        return this;
    }

    public DateTime getUpdatedDate() {
        return updatedDate;
    }

    public UnmatchedCategoryReport setUpdatedDate(DateTime updatedDate) {
        this.updatedDate = updatedDate;
        return this;
    }

    public boolean isProcessed() {
        return processed;
    }

    public UnmatchedCategoryReport setProcessed(boolean processed) {
        this.processed = processed;
        return this;
    }

    public List<String> getInfoMessages() {
        return infoMessages;
    }

    public UnmatchedCategoryReport setInfoMessages(List<String> infoMessages) {
        this.infoMessages = infoMessages;
        return this;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public UnmatchedCategoryReport setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
        return this;
    }

    public Long getMatchedCount() {
        return matchedCount;
    }

    public UnmatchedCategoryReport setMatchedCount(Long matchedCount) {
        this.matchedCount = matchedCount;
        return this;
    }

}
