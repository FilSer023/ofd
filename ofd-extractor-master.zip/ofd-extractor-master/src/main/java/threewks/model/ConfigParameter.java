package threewks.model;

import com.googlecode.objectify.annotation.Cache;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.util.IdUtil;

import java.util.Date;

@Entity
@Cache
public class ConfigParameter {

    @Id
    private String id;

    @Index
    private String name;

    private String value;
    private String notes;

    private Date createdDate;
    private Date updatedTime;

    public ConfigParameter() {
        this.id = IdUtil.generateUniqueId();
        this.createdDate = new Date();
    }

    public String getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public ConfigParameter setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
        return this;
    }

    public String getNotes() {
        return notes;
    }

    public ConfigParameter setNotes(String notes) {
        this.notes = notes;
        return this;
    }
}
