package threewks.model;

import com.googlecode.objectify.Ref;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.framework.cloudstorage.attachment.AttachmentDto;
import threewks.framework.usermanager.model.AppUser;
import threewks.util.IdUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class CategoryMappingBatch {
    private String startedBy;

    public static class SearchFields {
        public static final String TimeFinished = "timeFinished";
        public static final String TimeStarted = "timeStarted";
        public static final String Status = "status";
    }

    @Id
    private String id;

    @Index
    private Date timeStarted;

    @Index
    private Date timeFinished;

    private boolean shareDocument;
    private Ref<AppUser> startedByUser;

    @Index
    private CategoryMappingBatchStatus status;

    private List<String> notes = new ArrayList<>();

    private List<String> errorMessages = new ArrayList<>();

    private List<String> infoMessages = new ArrayList<>();

    private List<AttachmentDto> attachment = new ArrayList<>();

    public CategoryMappingBatch() {
        this.id = IdUtil.generateUniqueId();
    }

    public String getId() {
        return id;
    }

    public String getStartedBy() {
        return startedBy;
    }

    public CategoryMappingBatch setStartedBy(String startedBy) {
        this.startedBy = startedBy;
        return this;
    }

    public Date getTimeStarted() {
        return timeStarted;
    }

    public CategoryMappingBatch setTimeStarted(Date timeStarted) {
        this.timeStarted = timeStarted;
        return this;
    }

    public Date getTimeFinished() {
        return timeFinished;
    }

    public CategoryMappingBatch setTimeFinished(Date timeFinished) {
        this.timeFinished = timeFinished;
        return this;
    }

    public CategoryMappingBatchStatus getStatus() {
        return status;
    }

    public CategoryMappingBatch setStatus(CategoryMappingBatchStatus status) {
        this.status = status;
        return this;
    }

    public List<String> getNotes() {
        return notes;
    }

    public CategoryMappingBatch setNotes(List<String> notes) {
        this.notes = notes;
        return this;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public CategoryMappingBatch setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
        return this;
    }

    public List<String> getInfoMessages() {
        return infoMessages;
    }

    public CategoryMappingBatch setInfoMessages(List<String> infoMessages) {
        this.infoMessages = infoMessages;
        return this;
    }

    public List<AttachmentDto> getAttachment() {
        return attachment;
    }

    public CategoryMappingBatch setAttachment(List<AttachmentDto> attachment) {
        this.attachment = attachment;
        return this;
    }

    public boolean isShareDocument() {
        return shareDocument;
    }

    public CategoryMappingBatch setShareDocument(boolean shareDocument) {
        this.shareDocument = shareDocument;
        return this;
    }

    public AppUser getStartedByUser() {
        return startedByUser != null ? startedByUser.get() : null;
    }

    public CategoryMappingBatch setStartedByUser(AppUser startedByUser) {
        this.startedByUser = Ref.create(startedByUser);
        return this;
    }
}
