package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum ReceiptDocumentStatus implements ReferenceData {

    QUEUED("В очереди"), DOWNLOADED("Скачан"), ERROR("Ошибка"),
    DATA_NOT_FOUND("Информация отсутствует");

    private final String description;

    ReceiptDocumentStatus(String description) {
        this.description = description;
    }

    @Override
    public String getDescription() {
        return description;
    }
}
