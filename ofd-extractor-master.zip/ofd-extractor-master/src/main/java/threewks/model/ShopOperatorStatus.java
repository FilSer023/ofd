package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum ShopOperatorStatus implements ReferenceData {

    NEW("Новый", 0),
    ACTIVE("Действующий", 1),
    ARCHIVED("Архив", 2);

    private final String description;
    private final int sortOrder;

    ShopOperatorStatus(String description, int sortOrder) {
        this.description = description;
        this.sortOrder = sortOrder;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public int getSortOrder() {
        return sortOrder;
    }

}
