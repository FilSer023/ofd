package threewks.model;

import com.googlecode.objectify.Ref;
import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;

import java.util.Date;

@Entity
public class ReceiptDocument {

    @Id
    private String id;

    private String docRawId;

    @Index
    private Ref<ShopOperator> shopOperator;

    @Index
    private String batchId;

    @Index
    private ReceiptDocumentStatus status;

    @Index
    private Date created;
    private String kktRegId;
    private String inn;

    public String getId() {
        return id;
    }

    public ReceiptDocument setId(String id) {
        this.id = id;
        return this;
    }

    public String getDocRawId() {
        return docRawId;
    }

    public ReceiptDocument setDocRawId(String docRawId) {
        this.docRawId = docRawId;
        return this;
    }

    public ReceiptDocumentStatus getStatus() {
        return status;
    }

    public ReceiptDocument setStatus(ReceiptDocumentStatus status) {
        this.status = status;
        return this;
    }

    public Date getCreated() {
        return created;
    }

    public ReceiptDocument setCreated(Date created) {
        this.created = created;
        return this;
    }

    public String getBatchId() {
        return batchId;
    }

    public ReceiptDocument setBatchId(String batchId) {
        this.batchId = batchId;
        return this;
    }

    public ShopOperator getShopOperator() {
        return shopOperator.get();
    }

    public ReceiptDocument setShopOperator(ShopOperator shopOperator) {
        this.shopOperator = Ref.create(shopOperator);
        return this;
    }

    public ReceiptDocument setKktRegId(String kktRegId) {
        this.kktRegId = kktRegId;
        return this;
    }

    public String getKktRegId() {
        return kktRegId;
    }

    public String getInn() {
        return inn;
    }

    public ReceiptDocument setInn(String inn) {
        this.inn = inn;
        return this;
    }
}
