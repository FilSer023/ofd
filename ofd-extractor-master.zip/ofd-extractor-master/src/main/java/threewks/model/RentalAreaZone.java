package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum RentalAreaZone implements ReferenceData {

    ARRIVAL("Прибытие", 1),
    DEPARTURE("Отправление", 2);

    private final String description;
    private final int sortOrder;

    RentalAreaZone(String description, int sortOrder) {
        this.description = description;
        this.sortOrder = sortOrder;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public int getSortOrder() {
        return sortOrder;
    }

}
