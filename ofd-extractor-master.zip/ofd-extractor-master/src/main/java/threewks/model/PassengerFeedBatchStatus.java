package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum PassengerFeedBatchStatus implements ReferenceData {

    NEW("Новый", 1),
    FTP_EXPORT_COMPLETED("Выгрузка из FTP завершена", 3),
    DATA_PREPARED_FOR_IMPORT("Данные преобразованы для импорта", 4),
    DATA_IMPORTED_TO_STAGING_ZONE("Данные ручной загрузки импортированы во временное хранилище данных", 5),
    DATA_IMPORTED("Данные импортированы в хранилище данных", 6),
    ERROR("Ошибка", 7);

    private final String description;
    private final int sortOrder;

    PassengerFeedBatchStatus(String description, int sortOrder) {
        this.description = description;
        this.sortOrder = sortOrder;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public int getSortOrder() {
        return sortOrder;
    }
}
