package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import threewks.util.IdUtil;

import java.util.Date;

@Entity
public class BatchForUnmatchedSKUItem {

    @Id
    private String id;

    @Index
    private String batchId;

    @Index
    private String operatorName;

    @Index
    private String sku;

    @Index
    private Date created;

    private BatchForUnmatchedSKUItem() {

    }

    public BatchForUnmatchedSKUItem(String sku) {
        this.sku = sku;
        this.id = IdUtil.generateUniqueId();
        this.created = new Date();
    }

    public String getId() {
        return id;
    }

    public String getBatchId() {
        return batchId;
    }

    public BatchForUnmatchedSKUItem setBatchId(String batchId) {
        this.batchId = batchId;
        return this;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public BatchForUnmatchedSKUItem setOperatorName(String operatorName) {
        this.operatorName = operatorName;
        return this;
    }

    public String getSku() {
        return sku;
    }

    public BatchForUnmatchedSKUItem setSku(String sku) {
        this.sku = sku;
        return this;
    }

    public Date getCreated() {
        return created;
    }

    public BatchForUnmatchedSKUItem setCreated(Date created) {
        this.created = created;
        return this;
    }

    public static BatchForUnmatchedSKUItem batch(String batchId, UnmatchedSKUItem unmatchedSKUItem) {
        BatchForUnmatchedSKUItem item = new BatchForUnmatchedSKUItem();
        item.sku = unmatchedSKUItem.getSku();
        item.id = unmatchedSKUItem.getId();
        item.operatorName = unmatchedSKUItem.getOperatorName();
        item.batchId = batchId;
        return item;
    }
}
