package threewks.model;

import com.googlecode.objectify.annotation.Entity;
import com.googlecode.objectify.annotation.Id;
import com.googlecode.objectify.annotation.Index;
import com.threewks.thundr.search.SearchIndex;
import threewks.util.IdUtil;
import threewks.util.SearchUtil;

@Entity
public class SubSectionCategory {

    public static final int MIN_LENGTH = 3;

    public static class SearchFields {
        public static final String SearchableText = "searchableText";
    }

    @Id
    private String id;

    @Index
    private String name;

    @SearchIndex
    public String getSearchableText() {
        return SearchUtil.getSearchableText(MIN_LENGTH,
            String.format("%s", name)
        );
    }

    public SubSectionCategory() {
    }

    public String getName() {
        return name;
    }

    public SubSectionCategory setName(String name) {
        this.name = name;
        return this;
    }

    public SubSectionCategory(String name) {
        this.id = IdUtil.generateUniqueId();
        this.name = name;
    }
}
