package threewks.model;

import com.googlecode.objectify.Ref;
import org.joda.time.DateTime;
import threewks.model.dto.TradePointDto;
import threewks.model.dto.TradePointSubSectionDto;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class TradePoint {

    private String name;
    private SalesChannel salesChannel;
    private String staffQuantity;
    private String contractNumber;
    private DateTime contractDate;
    private Ref<RentalArea> rentalAreaRef;
    private List<TradePointSubSection> categoryAreas;
    private List<KKTFiscalDrive> kktFiscalDrives = new ArrayList<>();

    public String getName() {
        return name;
    }

    public TradePoint setName(String name) {
        this.name = name;
        return this;
    }

    public String getStaffQuantity() {
        return staffQuantity;
    }

    public TradePoint setStaffQuantity(String staffQuantity) {
        this.staffQuantity = staffQuantity;
        return this;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public TradePoint setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
        return this;
    }

    public DateTime getContractDate() {
        return contractDate;
    }

    public TradePoint setContractDate(DateTime contractDate) {
        this.contractDate = contractDate;
        return this;
    }

    public RentalArea getRentalAreaRef() {
        return rentalAreaRef != null ? rentalAreaRef.get() : null;
    }

    public TradePoint setRentalAreaRef(RentalArea rentalAreaRef) {
        this.rentalAreaRef = (rentalAreaRef != null) ? Ref.create(rentalAreaRef) : null;
        return this;
    }

    public List<KKTFiscalDrive> getKktFiscalDrives() {
        return kktFiscalDrives;
    }

    public TradePoint setKktFiscalDrives(List<KKTFiscalDrive> kktFiscalDrives) {
        this.kktFiscalDrives = kktFiscalDrives;
        return this;
    }

    public List<TradePointSubSection> getCategoryAreas() {
        return categoryAreas;
    }

    public void setCategoryAreas(List<TradePointSubSection> categoryAreas) {
        this.categoryAreas = categoryAreas;
    }

    public static Function<TradePointDto, TradePoint> CONVERT = tradePointDto -> {
        TradePoint tradePoint = new TradePoint();
        tradePoint.setName(tradePointDto.getName());
        tradePoint.setContractDate(tradePointDto.getContractDate());
        tradePoint.setContractNumber(tradePointDto.getContractNumber());
        tradePoint.setKktFiscalDrives(tradePointDto.getKktFiscalDrives());
        tradePoint.setStaffQuantity(tradePointDto.getStaffQuantity());
        List<TradePointSubSection> categories = new ArrayList<>();
        for (TradePointSubSectionDto subSection : tradePointDto.getCategoryAreas()) {
            TradePointSubSection tradePointSubSection = new TradePointSubSection();
            tradePointSubSection.setCategoryRef(subSection.getCategory());
            tradePointSubSection.setAreaSize(subSection.getAreaSize());
            categories.add(tradePointSubSection);
        }
        tradePoint.setCategoryAreas(categories);
        tradePoint.setSalesChannel(tradePointDto.getSalesChannel());
        if (tradePointDto.getRentalArea() != null) {
            tradePoint.setRentalAreaRef(new RentalArea().fromDto(tradePointDto.getRentalArea()));
        }
        return tradePoint;
    };

    public SalesChannel getSalesChannel() {
        return salesChannel;
    }

    public TradePoint setSalesChannel(SalesChannel salesChannel) {
        this.salesChannel = salesChannel;
        return this;
    }

    @Override
    public String toString() {
        return "TradePoint{" +
            "name='" + name + '\'' +
            ", staffQuantity='" + staffQuantity + '\'' +
            ", contractNumber='" + contractNumber + '\'' +
            ", contractDate=" + contractDate +
            ", rentalAreaRef=" + rentalAreaRef +
            ", sectionAreas=" + categoryAreas +
            ", kktFiscalDrives=" + kktFiscalDrives +
            ", salesChannel=" + salesChannel +
            '}';
    }
}
