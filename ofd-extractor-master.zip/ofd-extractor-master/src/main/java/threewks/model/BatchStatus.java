package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum BatchStatus implements ReferenceData {

    NEW("В очереди", 1),
    OFD_EXPORT_COMPLETED("Выгрузка чеков из ОФД завершена", 4),
    OFD_EXPORT_CONTINUED("Продолжен сеанс выгрузки для периода", 5),
    RECEIPT_SUMMARIES_RETRIEVED("Выгрузка отчетов из ОФД завершена", 6),
    RECEIPT_DETAILS_RETRIEVED("Выгрузка индивидуальных чеков из ОФД завершена", 6),
    DATA_IMPORTED_INTO_STAGING("Данные из ОФД импортированы во временную зону хранилища данных", 7),
    DATA_IMPORTED_INTO_CLEAN("Данные из ОФД импортированы в чистую зону хранилища данных", 8),
    NO_TRANSACTIONS_FOUND("Транзакций не найдено", 9),
    NO_NEW_TRANSACTIONS_FOUND("Все транзакции импортированы ранее", 10),
    ERROR("Ошибка", 11);

    private final String description;
    private final int sortOrder;

    BatchStatus(String description, int sortOrder) {
        this.description = description;
        this.sortOrder = sortOrder;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public int getSortOrder() {
        return sortOrder;
    }
}
