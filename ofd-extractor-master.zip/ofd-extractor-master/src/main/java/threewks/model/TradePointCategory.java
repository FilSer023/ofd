package threewks.model;

import threewks.framework.ref.ReferenceData;

public enum TradePointCategory implements ReferenceData {
    RETAIL_JV("Retail (JV)"), RETAIL_NON_JV("Retail (non-JV)");

    private String description;

    private TradePointCategory(String description) {
        this.description = description;
    }

    @Override
    public String getDescription() {
        return description;
    }
}
