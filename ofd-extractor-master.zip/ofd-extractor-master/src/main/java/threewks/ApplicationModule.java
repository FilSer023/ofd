package threewks;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.storage.StorageScopes;
import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsInputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryOptions;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.common.collect.Sets;
import com.google.gson.GsonBuilder;
import com.googlecode.objectify.ObjectifyService;
import com.googlecode.objectify.impl.translate.TranslatorFactory;
import com.threewks.thundr.clouddatastore.CloudDatastoreBackupModule;
import com.threewks.thundr.configuration.ConfigurationException;
import com.threewks.thundr.configuration.Environment;
import com.threewks.thundr.csv.CsvModule;
import com.threewks.thundr.gae.GaeModule;
import com.threewks.thundr.gae.objectify.ObjectifyModule;
import com.threewks.thundr.gmail.GmailMailer;
import com.threewks.thundr.http.StatusCode;
import com.threewks.thundr.injection.BaseModule;
import com.threewks.thundr.injection.UpdatableInjectionContext;
import com.threewks.thundr.json.GsonSupport;
import com.threewks.thundr.mail.Mailer;
import com.threewks.thundr.module.DependencyRegistry;
import com.threewks.thundr.route.Router;
import com.threewks.thundr.route.controller.FilterRegistry;
import com.threewks.thundr.session.SessionService;
import com.threewks.thundr.user.controller.SessionFilter;
import com.threewks.thundr.user.gae.UserGaeModule;
import org.apache.commons.net.ftp.FTPClient;
import sun.nio.ch.ChannelInputStream;
import threewks.controller.Routes;
import threewks.framework.cloudstorage.CloudStorageModule;
import threewks.framework.cloudstorage.attachment.AttachmentService;
import threewks.framework.filter.ExceptionMappingFilter;
import threewks.framework.objectify.BigDecimalLongTranslatorFactory;
import threewks.framework.ref.ReferenceDataService;
import threewks.framework.ref.ReferenceDataWithCode;
import threewks.framework.usermanager.UserManagerModule;
import threewks.framework.usermanager.context.SecurityContextFilter;
import threewks.framework.usermanager.context.SessionHelper;
import threewks.framework.usermanager.mail.LoggingMailer;
import threewks.model.Airport;
import threewks.model.AirportCatalog;
import threewks.model.BatchForUnmatchedSKUItem;
import threewks.model.BatchStatus;
import threewks.model.CategoryMappingBatch;
import threewks.model.CategoryMappingBatchStatus;
import threewks.model.ConfigParameter;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.model.PassengerFeedBatch;
import threewks.model.PassengerFeedBatchStatus;
import threewks.model.ReceiptDocument;
import threewks.model.RentalArea;
import threewks.model.RentalAreaStatus;
import threewks.model.RentalAreaZone;
import threewks.model.SKUCategoryMappingFile;
import threewks.model.SalesChannel;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;
import threewks.model.SubSectionCategory;
import threewks.model.TradePointCategory;
import threewks.model.UnmatchedCategoryReport;
import threewks.model.UnmatchedSKUItem;
import threewks.repository.AirportCatalogRepository;
import threewks.repository.BatchForUnmatchedSKUItemRepository;
import threewks.repository.CategoryMappingBatchRepository;
import threewks.repository.ConfigParameterRepository;
import threewks.repository.OFDBatchRepository;
import threewks.repository.PassengerFeedBatchRepository;
import threewks.repository.ReceiptDocumentRepository;
import threewks.repository.RentalAreaRepository;
import threewks.repository.SKUCategoryMappingFileRepository;
import threewks.repository.SalesChannelRepository;
import threewks.repository.ShopOperatorRepository;
import threewks.repository.SubSectionCategoryRepository;
import threewks.repository.UnmatchedCategoryReportRepository;
import threewks.repository.UnmatchedSKUItemRepository;
import threewks.service.AirportCatalogService;
import threewks.service.CategoriesService;
import threewks.service.CategoryMappingBatchService;
import threewks.service.ConfigParameterService;
import threewks.service.CsvExportService;
import threewks.service.OFDBatchService;
import threewks.service.PassengerFeedManualUploadService;
import threewks.service.RentalAreaService;
import threewks.service.SKUCategoryMappingFileService;
import threewks.service.SalesChannelService;
import threewks.service.ShopOperatorService;
import threewks.service.SubSectionCategoryService;
import threewks.service.TaskService;
import threewks.service.UnmatchedCategoryReportService;
import threewks.service.UnmatchedSKUItemService;
import threewks.service.bigquery.BQService;
import threewks.service.bigquery.BackupDataManager;
import threewks.service.bigquery.CategoriesDataManager;
import threewks.service.bigquery.DataManagerService;
import threewks.service.bigquery.PassengerFeedDataManager;
import threewks.service.bigquery.TradepointsDataManager;
import threewks.service.bigquery.TransactionDataManager;
import threewks.service.bootstrap.BootstrapService;
import threewks.service.ofd.BaseOFDService;
import threewks.service.ofd.OFDDocumentUploadService;
import threewks.service.ofd.kontur.KonturOFDServiceStrategy;
import threewks.service.ofd.peterservice.PeterServiceOFDServiceStrategy;
import threewks.service.ofd.yarus.YarusOFDServiceStrategy;
import threewks.service.passengerfeed.CobraDataService;
import threewks.service.passengerfeed.GcsFileWriter;
import threewks.service.passengerfeed.PassengerFeedBatchService;
import threewks.service.passengerfeed.PassengerFeedTransformerService;
import threewks.util.DoesNotExistException;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Set;

import static com.threewks.thundr.configuration.Environment.DEV;
import static java.util.Arrays.asList;
import static threewks.framework.filter.ExceptionMappingFilter.LogLevel.ERROR_WITH_STACKTRACE;

public class ApplicationModule extends BaseModule {

    private static final String BIGQUERY = "https://www.googleapis.com/auth/bigquery";
    private static final List<String> REQUIRED_SCOPES = asList(DriveScopes.DRIVE, DriveScopes.DRIVE_FILE, DriveScopes.DRIVE_READONLY,
        SheetsScopes.SPREADSHEETS, BIGQUERY, StorageScopes.CLOUD_PLATFORM);
    private static final List<String> DRIVE_SCOPES = asList(DriveScopes.DRIVE, DriveScopes.DRIVE_READONLY, SheetsScopes.SPREADSHEETS);
    private static final String DEV_GCS_CREDENTIALS_JSON = "dev-gcs-credentials.json";
    private static final String PROD_GCS_CREDENTIALS_JSON = "prod-gcs-credentials.json";
    private static final String GCS_DEFAULT_BUCKET_PROPERTY = "gcsDefaultBucket";
    private static final String GCS_CONF_BUCKET_PROPERTY = "gcsConfBucket";
    private static final String CREDENTIALS_DIR_PREFIX = "credentials/";
    public static final String BQ_CREDENTIALS = "bqCredentials";
    public static final String DRIVE_CREDENTIAL = "driveCredential";
    private static final String PROD = "prod";

    @Override
    public void requires(DependencyRegistry dependencyRegistry) {
        super.requires(dependencyRegistry);

        dependencyRegistry.addDependency(GaeModule.class);
        dependencyRegistry.addDependency(ObjectifyModule.class);
        dependencyRegistry.addDependency(UserGaeModule.class);
        dependencyRegistry.addDependency(UserManagerModule.class);
        dependencyRegistry.addDependency(CsvModule.class);
        dependencyRegistry.addDependency(CloudStorageModule.class);
        dependencyRegistry.addDependency(CloudDatastoreBackupModule.class);
    }

    @Override
    public void configure(UpdatableInjectionContext injectionContext) {
        super.configure(injectionContext);

        configureGsonBinding(injectionContext);
        configureObjectify();
        configureHelpers(injectionContext);
        configureFilters(injectionContext);
        configureReferenceData(injectionContext);
        configureQueues(injectionContext);
        configureGCSAndCredentials(injectionContext);
        configureBigQuery(injectionContext);
        configureRepositories(injectionContext);
        configureServices(injectionContext);

        Class<? extends Mailer> mailerClass = Environment.is(Environment.DEV) ? LoggingMailer.class : GmailMailer.class;
        injectionContext.inject(mailerClass).as(Mailer.class);
        //Diverting mailer if we need to configure
//        String divertEmailsTo = injectionContext.get(String.class, "divertEmailsTo");
//        Mailer originalMailer = injectionContext.get(Mailer.class);
//        RequestContainer requestContainer = injectionContext.get(RequestContainer.class);
//        ViewResolverRegistry viewResolverRegistry = injectionContext.get(ViewResolverRegistry.class);
//        injectionContext.inject(new DivertingMailer(divertEmailsTo, false, originalMailer,
//            viewResolverRegistry, requestContainer)).as(Mailer.class);
    }

    private void configureGsonBinding(UpdatableInjectionContext injectionContext) {
        GsonBuilder gsonBuilder = GsonSupport.createBasicGsonBuilder();
        injectionContext.inject(gsonBuilder).as(GsonBuilder.class);
    }

    private void configureGCSAndCredentials(UpdatableInjectionContext injectionContext) {
        GcsService gcsService =
            GcsServiceFactory.createGcsService(
                new RetryParams.Builder()
                    .initialRetryDelayMillis(10)
                    .retryMaxAttempts(10)
                    .totalRetryPeriodMillis(15000)
                    .build());
        injectionContext.inject(gcsService).as(GcsService.class);
        GoogleCredentials bqCredentials;
        GoogleCredential driveCredential;
        if (Environment.is(DEV)) {
            try {
                InputStream jsonCredentials = getClass().getClassLoader().getResourceAsStream(DEV_GCS_CREDENTIALS_JSON);
                bqCredentials = GoogleCredentials
                    .fromStream(jsonCredentials)
                    .createScoped(REQUIRED_SCOPES);
                jsonCredentials = getClass().getClassLoader().getResourceAsStream(DEV_GCS_CREDENTIALS_JSON);
                driveCredential = GoogleCredential.fromStream(jsonCredentials).createScoped(DRIVE_SCOPES);
            } catch (IOException e) {
                throw new ConfigurationException(e, "Credentials configuration failed: %s", e.getMessage());
            }
        } else {
            boolean isProd = Environment.get().contains(PROD);
            try {
                String gcsDefaultBucket = injectionContext.get(String.class, GCS_CONF_BUCKET_PROPERTY);
                GcsFilename gcsFilename = new GcsFilename(gcsDefaultBucket, CREDENTIALS_DIR_PREFIX + (isProd ? PROD_GCS_CREDENTIALS_JSON : DEV_GCS_CREDENTIALS_JSON));
                GcsInputChannel inputChannel = gcsService.openReadChannel(gcsFilename, 0);
                InputStream inputStream = new ChannelInputStream(inputChannel);
                bqCredentials = GoogleCredentials
                    .fromStream(inputStream)
                    .createScoped(REQUIRED_SCOPES);
                inputChannel = gcsService.openReadChannel(gcsFilename, 0);
                inputStream = new ChannelInputStream(inputChannel);
                driveCredential = GoogleCredential.fromStream(inputStream).createScoped(DRIVE_SCOPES);
            } catch (IOException e) {
                throw new ConfigurationException(e, "Credentials configuration failed: %s", e.getMessage());
            }
        }
        Storage service = StorageOptions.newBuilder().setCredentials(bqCredentials).build().getService();
        injectionContext.inject(service).as(Storage.class);
        injectionContext.inject(bqCredentials).named(BQ_CREDENTIALS).as(GoogleCredentials.class);
        injectionContext.inject(driveCredential).named(DRIVE_CREDENTIAL).as(GoogleCredential.class);
    }

    private void configureBigQuery(UpdatableInjectionContext injectionContext) {
        GoogleCredentials bqCredentials = injectionContext.get(GoogleCredentials.class, BQ_CREDENTIALS);
        BigQueryOptions options = BigQueryOptions.newBuilder()
            .setCredentials(bqCredentials)
            .build();
        BigQuery bigQuery = options
            .getService();
        injectionContext.inject(bigQuery).as(BigQuery.class);
    }

    @Override
    public void start(UpdatableInjectionContext injectionContext) {
        super.start(injectionContext);

        Router router = injectionContext.get(Router.class);
        Routes.addRoutes(router);

        // bootstrap data on local dev only
        if (Environment.is(Environment.DEV)) {
            BootstrapService bootstrapService = injectionContext.get(BootstrapService.class);
            bootstrapService.bootstrapLocal();
        }
    }

    private void configureHelpers(UpdatableInjectionContext injectionContext) {
        injectAsSelf(injectionContext, SessionHelper.class);
    }


    private void configureObjectify() {
        for (TranslatorFactory translatorFactory : objectifyTranslatorFactories()) {
            ObjectifyService.factory().getTranslators().add(translatorFactory);
        }

        for (Class<?> entityClass : objectifyEntities()) {
            ObjectifyService.register(entityClass);
        }
    }

    private void configureFilters(UpdatableInjectionContext injectionContext) {
        FilterRegistry filterRegistry = injectionContext.get(FilterRegistry.class);

        SessionService sessionService = injectionContext.get(SessionService.class);
        SessionHelper sessionHelper = injectionContext.get(SessionHelper.class);
        //noinspection unchecked
        filterRegistry.add(new SessionFilter(sessionService), "/**");

        ExceptionMappingFilter exceptionMappingFilter = new ExceptionMappingFilter()
            .withMapping(IllegalArgumentException.class, StatusCode.BadRequest)
            .withMapping(DoesNotExistException.class, StatusCode.NotFound)
            .withMapping(RuntimeException.class, StatusCode.InternalServerError, ERROR_WITH_STACKTRACE);
        filterRegistry.add(exceptionMappingFilter, "/api/**");
        filterRegistry.add(new SecurityContextFilter(sessionHelper), "/**");
    }

    private void configureQueues(UpdatableInjectionContext injectionContext) {
        // Default queue is adequate for most cases, unless of course you need fine grained control over queue behaviour
        // for specific task types in which case named queues are the way to go.
        injectionContext.inject(QueueFactory.getQueue("ofd-queue")).named("ofdQueue").as(Queue.class);
        injectionContext.inject(QueueFactory.getQueue("bq-queue")).named("bqQueue").as(Queue.class);
        injectionContext.inject(QueueFactory.getQueue("receipts-queue")).named("receiptsQueue").as(Queue.class);
        injectionContext.inject(QueueFactory.getQueue("admin-task-queue")).named("adminTaskQueue").as(Queue.class);
        injectionContext.inject(QueueFactory.getQueue("unmatched-items-index-queue")).named("unmatchedItemsIndexQueue").as(Queue.class);
    }

    private void configureRepositories(UpdatableInjectionContext injectionContext) {
        // Inject repositories here
        injectAsSelf(injectionContext,
            ShopOperatorRepository.class,
            RentalAreaRepository.class,
            SalesChannelRepository.class,
            OFDBatchRepository.class,
            UnmatchedCategoryReportRepository.class,
            SubSectionCategoryRepository.class,
            ConfigParameterRepository.class,
            PassengerFeedBatchRepository.class,
            SKUCategoryMappingFileRepository.class,
            CategoryMappingBatchRepository.class,
            UnmatchedSKUItemRepository.class,
            AirportCatalogRepository.class,
            ReceiptDocumentRepository.class,
            BatchForUnmatchedSKUItemRepository.class);
    }

    private void configureServices(UpdatableInjectionContext injectionContext) {
        injectAsSelf(injectionContext,
            FTPClient.class,
            GcsFileWriter.class,
            AttachmentService.class,
            BootstrapService.class,
            TaskService.class,
            BaseOFDService.class,
            ShopOperatorService.class,
            RentalAreaService.class,
            OFDDocumentUploadService.class,
            CobraDataService.class,
            OFDBatchService.class,
            DataManagerService.class,
            BQService.class,
            SalesChannelService.class,
            CategoriesService.class,
            UnmatchedCategoryReportService.class,
            CategoriesDataManager.class,
            TransactionDataManager.class,
            TradepointsDataManager.class,
            PassengerFeedDataManager.class,
            SubSectionCategoryService.class,
            BackupDataManager.class,
            SubSectionCategoryService.class,
            ConfigParameterService.class,
            PassengerFeedTransformerService.class,
            PassengerFeedBatchService.class,
            SKUCategoryMappingFileService.class,
            CategoryMappingBatchService.class,
            PassengerFeedManualUploadService.class,
            CategoryMappingBatchService.class,
            UnmatchedSKUItemService.class,
            AirportCatalogService.class,
            CsvExportService.class
        );
        injectionContext.inject(YarusOFDServiceStrategy.class).named("yarusOFDServiceStrategy").as(YarusOFDServiceStrategy.class);
        injectionContext.inject(KonturOFDServiceStrategy.class).named("konturOFDServiceStrategy").as(KonturOFDServiceStrategy.class);
        injectionContext.inject(PeterServiceOFDServiceStrategy.class).named("peterServiceOFDServiceStrategy").as(PeterServiceOFDServiceStrategy.class);
    }

    public static Set<Class<?>> objectifyEntities() {
        return Sets.<Class<?>>newHashSet(
            // Add any entity classes here
            ShopOperator.class,
            RentalArea.class,
            OFDBatch.class,
            UnmatchedCategoryReport.class,
            SubSectionCategory.class,
            ConfigParameter.class,
            PassengerFeedBatch.class,
            SKUCategoryMappingFile.class,
            CategoryMappingBatch.class,
            AirportCatalog.class,
            CategoryMappingBatch.class,
            SalesChannel.class,
            UnmatchedSKUItem.class,
            ReceiptDocument.class,
            BatchForUnmatchedSKUItem.class
        );
    }

    public static Set<TranslatorFactory> objectifyTranslatorFactories() {
        return Sets.newHashSet(new BigDecimalLongTranslatorFactory());
    }

    @SuppressWarnings("unchecked")
    private void configureReferenceData(UpdatableInjectionContext injectionContext) {
        ReferenceDataService referenceDataService = new ReferenceDataService()
            .withCustomTransformer(ReferenceDataWithCode.class, ReferenceDataWithCode.TO_DTO_TRANSFORMER)
            .registerClasses(
                // ReferenceData implementation classes go here
                ShopOperatorStatus.class,
                RentalAreaZone.class,
                RentalAreaStatus.class,
                Airport.class,
                OFDProvider.class,
                BatchStatus.class,
                TradePointCategory.class,
                PassengerFeedBatchStatus.class,
                CategoryMappingBatchStatus.class
            );
        injectionContext.inject(referenceDataService).as(ReferenceDataService.class);
    }

    @SuppressWarnings("unchecked")
    private static void injectAsSelf(UpdatableInjectionContext injectionContext, Class... classes) {
        for (Class clazz : classes) {
            injectionContext.inject(clazz).as(clazz);
        }
    }
}
