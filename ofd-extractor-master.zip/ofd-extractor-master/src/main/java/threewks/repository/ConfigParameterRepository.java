package threewks.repository;

import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.ConfigParameter;

import java.util.List;
import java.util.Optional;

public class ConfigParameterRepository extends StringRepository<ConfigParameter> {

    public ConfigParameterRepository(SearchConfig searchConfig) {
        super(ConfigParameter.class, searchConfig);
    }

    public Optional<ConfigParameter> getByName(String name) {
        List<ConfigParameter> configParameters = getByField("name", name);
        return Optional.ofNullable(configParameters.isEmpty() ? null : configParameters.get(0));
    }
}
