package threewks.repository;

import com.googlecode.objectify.Ref;
import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.RentalArea;
import threewks.model.RentalAreaHistory;
import threewks.model.ShopOperator;

import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class RentalAreaHistoryRepository extends StringRepository<RentalAreaHistory> {

    public RentalAreaHistoryRepository(SearchConfig searchConfig) {
        super(RentalAreaHistory.class, searchConfig);
    }

    public List<RentalAreaHistory> listByRentalArea(RentalArea rentalArea) {
        Ref<RentalArea> rentalAreaRef = Ref.create(rentalArea);
        return ofy().load().type(RentalAreaHistory.class).filter("rentalArea", rentalAreaRef).list();
    }

    public List<RentalAreaHistory> listByShopOperator(ShopOperator shopOperator) {
        Ref<ShopOperator> rentalAreaRef = Ref.create(shopOperator);
        List<RentalAreaHistory> currentOperatorValues = ofy().load().type(RentalAreaHistory.class)
            .filter("currentShopOperator", rentalAreaRef).list();
        List<RentalAreaHistory> previousOperatorValues = ofy().load().type(RentalAreaHistory.class)
            .filter("previousShopOperator", rentalAreaRef).list();
        currentOperatorValues.addAll(previousOperatorValues);
        return currentOperatorValues;
    }
}
