package threewks.repository;

import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.SKUCategoryMappingFile;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class SKUCategoryMappingFileRepository extends StringRepository<SKUCategoryMappingFile> {

    public SKUCategoryMappingFileRepository(SearchConfig searchConfig) {
        super(SKUCategoryMappingFile.class, searchConfig);
    }

    public SKUCategoryMappingFile getLatest() {
        SKUCategoryMappingFile latestFile = ofy().load().type(SKUCategoryMappingFile.class).order("-timeGenerated").first().now();
        return latestFile;
    }
}
