package threewks.repository;

import com.threewks.thundr.search.Is;
import com.threewks.thundr.search.Search;
import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.SubSectionCategory;

import java.util.List;

public class SubSectionCategoryRepository extends StringRepository<SubSectionCategory> {

    public SubSectionCategoryRepository(SearchConfig searchConfig) {
        super(SubSectionCategory.class, searchConfig);
    }

    public List<SubSectionCategory> findByName(String name) {
        Search<SubSectionCategory, String> search = search();
        search = search.field(SubSectionCategory.SearchFields.SearchableText, Is.EqualTo, name.toUpperCase());
        return search.run().getResults();
    }

    public SubSectionCategory findByExactName(String newSubsectionCategoryName) {
        return load()
            .filter("name", newSubsectionCategoryName)
            .first().now();
    }
}
