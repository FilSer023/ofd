package threewks.repository;

import com.google.appengine.api.datastore.Query.CompositeFilter;
import com.google.appengine.api.datastore.Query.CompositeFilterOperator;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.googlecode.objectify.Ref;
import com.googlecode.objectify.cmd.Query;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.search.gae.SearchConfig;
import org.apache.commons.collections.CollectionUtils;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static java.util.Arrays.asList;

public class OFDBatchRepository extends StringRepository<OFDBatch> {

    //This actually brings in 5 days - we add one more day by pushing end date forward. It's timezone-related
    private static final int RECENT_DAYS_PERIOD = 4;
    private static final String MSK_TIME_ZONE = "UTC+3";

    public OFDBatchRepository(SearchConfig searchConfig) {
        super(OFDBatch.class, searchConfig);
    }

    public boolean isRunning(ShopOperator shopOperator) {
        Query<OFDBatch> query = ofy().load().type(OFDBatch.class);
        query = query.filter("shopOperator", Ref.create(shopOperator));
        Date end = Date.from(LocalDate.now()
            .atStartOfDay(ZoneId.of(MSK_TIME_ZONE)).toInstant());
        Date start = Date.from(LocalDate.now()
            .atStartOfDay(ZoneId.of(MSK_TIME_ZONE)).minusDays(1).toInstant());
        List<Filter> dateFilters = new ArrayList<>();
        dateFilters.add(new FilterPredicate(OFDBatch.SearchFields.TimeStarted, FilterOperator.GREATER_THAN_OR_EQUAL, start));
        dateFilters.add(new FilterPredicate(OFDBatch.SearchFields.TimeStarted, FilterOperator.LESS_THAN_OR_EQUAL, end));
        Filter dateFilter = new CompositeFilter(CompositeFilterOperator.AND, dateFilters);
        query = query.filter(dateFilter);
        query = query.filter(OFDBatch.SearchFields.TimeFinished, null);
        query = query.filter("status IN", asList(BatchStatus.NEW, BatchStatus.OFD_EXPORT_CONTINUED));
        int count = query.count();
        Logger.info("isRunning for operator %s: %s", shopOperator.getName(), count);
        return count == 0;
    }

    public List<OFDBatch> getRecentBatches(int daysOffset, List<BatchStatus> filteredStatus) {
        Date end = Date.from(LocalDate.now().atStartOfDay(ZoneId.of(MSK_TIME_ZONE)).minusDays(daysOffset - 1).toInstant());
        Date start = Date.from(LocalDate.now()
            .atStartOfDay(ZoneId.of(MSK_TIME_ZONE)).minusDays(RECENT_DAYS_PERIOD + daysOffset).toInstant());
        List<Filter> dateFilters = new ArrayList<>();
        dateFilters.add(new FilterPredicate(OFDBatch.SearchFields.TimeStarted, FilterOperator.GREATER_THAN_OR_EQUAL, start));
        dateFilters.add(new FilterPredicate(OFDBatch.SearchFields.TimeStarted, FilterOperator.LESS_THAN_OR_EQUAL, end));
        Filter dateFilter = new CompositeFilter(CompositeFilterOperator.AND, dateFilters);
        Query<OFDBatch> query = ofy().load().type(OFDBatch.class);
        if (CollectionUtils.isNotEmpty(filteredStatus) && filteredStatus.stream().noneMatch(Objects::isNull)) {
            query = query.filter("status IN", filteredStatus);
        } else {
            query = query.filter(dateFilter);
        }
        List<OFDBatch> batches = query.list();
        return batches;
    }

}
