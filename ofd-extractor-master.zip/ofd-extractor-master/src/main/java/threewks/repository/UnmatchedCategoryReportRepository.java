package threewks.repository;

import com.google.appengine.api.datastore.Query.CompositeFilter;
import com.google.appengine.api.datastore.Query.CompositeFilterOperator;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.googlecode.objectify.cmd.Query;
import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.UnmatchedCategoryReport;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class UnmatchedCategoryReportRepository extends StringRepository<UnmatchedCategoryReport> {

    private static final int RECENT_DAYS_PERIOD = 1;

    public UnmatchedCategoryReportRepository(SearchConfig searchConfig) {
        super(UnmatchedCategoryReport.class, searchConfig);
    }

    public UnmatchedCategoryReport getLatest() {
        Date end = new Date();
        Date start = Date.from(LocalDate.now().minusDays(RECENT_DAYS_PERIOD)
            .atStartOfDay(ZoneId.systemDefault()).toInstant());
        List<Filter> dateFilters = new ArrayList<>();
        dateFilters.add(new FilterPredicate(UnmatchedCategoryReport.SearchFields.CreatedDate, FilterOperator.GREATER_THAN_OR_EQUAL, start));
        dateFilters.add(new FilterPredicate(UnmatchedCategoryReport.SearchFields.CreatedDate, FilterOperator.LESS_THAN_OR_EQUAL, end));
        Filter dateFilter = new CompositeFilter(CompositeFilterOperator.AND, dateFilters);
        Query<UnmatchedCategoryReport> query = ofy().load().type(UnmatchedCategoryReport.class).filter(dateFilter).order("createdDate");
        return query.first().now();
    }
}
