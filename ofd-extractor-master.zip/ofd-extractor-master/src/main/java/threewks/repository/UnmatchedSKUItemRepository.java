package threewks.repository;

import com.google.appengine.api.datastore.Cursor;
import com.google.appengine.api.datastore.QueryResultIterator;
import com.google.common.collect.Lists;
import com.googlecode.objectify.cmd.Query;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.search.Is;
import com.threewks.thundr.search.Search;
import com.threewks.thundr.search.gae.SearchConfig;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.PagedResult;
import threewks.model.UnmatchedSKUItem;
import threewks.util.StreamUtil;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class UnmatchedSKUItemRepository extends StringRepository<UnmatchedSKUItem> {

    private static final int RESULT_SIZE_LIMIT = 50;
    private static final int BATCH_SIZE = 50;

    public UnmatchedSKUItemRepository(SearchConfig searchConfig) {
        super(UnmatchedSKUItem.class, searchConfig);
    }

    public PagedResult<UnmatchedSKUItem> search(List<String> operatorNames, @Nullable String name, int offset) {
        PagedResult<UnmatchedSKUItem> pagedResult = new PagedResult<>();
        Optional<List<UnmatchedSKUItem>> items = findByOperatorAndSKU(operatorNames, name, offset);
        if (items.isPresent()) {
            List<UnmatchedSKUItem> results = items.get().stream().filter(Objects::nonNull).collect(Collectors.toList());
            pagedResult.setResults(results);
            pagedResult.setOffset(offset);
            pagedResult.setHasMore(results.size() == RESULT_SIZE_LIMIT);
        }
        return pagedResult;
    }

    public List<String> listOperatorsWithUnmatchedItems() {
        List<UnmatchedSKUItem> items = ofy().load().type(UnmatchedSKUItem.class)
            .project("operatorName")
            .distinct(true)
            .list();
        return items.stream().map(item -> item.getOperatorName()).collect(Collectors.toList());
    }

    public List<UnmatchedSKUItem> listAllocatedItems() {
        List<UnmatchedSKUItem> items = ofy().load().type(UnmatchedSKUItem.class)
            .filter("allocated", true)
            .list();
        return items;
    }

    public int getCount() {
        return ofy().load().type(UnmatchedSKUItem.class).count();
    }

    private Optional<List<UnmatchedSKUItem>> findByOperatorAndSKU(List<String> operators, String itemSKU, int offset) {
        Search<UnmatchedSKUItem, String> search = search()
            .limit(RESULT_SIZE_LIMIT)
            .offset(offset);
        if (StringUtils.isNotEmpty(itemSKU)) {
            search = search.field(UnmatchedSKUItem.SearchFields.Sku, Is.EqualTo, itemSKU.toUpperCase());
        }
        if (!CollectionUtils.isEmpty(operators)) {
            search = search.field(UnmatchedSKUItem.SearchFields.Operator, Is.EqualTo, operators);
        }
        return Optional.of(search.run().getResults());
    }

    public int reindex(List<String> keys) {
        return reindex(keys, keys.size(), batch -> batch);
    }

    public void deleteById(List<UnmatchedSKUItem> itemsToDelete) {
        List<String> idsToDelete = itemsToDelete.stream().map(unmatchedSKUItem -> unmatchedSKUItem.getId()).collect(Collectors.toList());
        StreamUtil.batches(idsToDelete, BATCH_SIZE).forEach(subList -> {
            ofy().delete().type(UnmatchedSKUItem.class).ids(subList).now();
        });
    }

    public PagedResult<UnmatchedSKUItem> listAll(String cursorStr) {

        final int resultSizeLimit = 100;
        PagedResult<UnmatchedSKUItem> pagedResult = new PagedResult<>();
        Query<UnmatchedSKUItem> query = ofy().load().type(UnmatchedSKUItem.class)
            .limit(resultSizeLimit);

        if (cursorStr != null) {
            query = query.startAt(Cursor.fromWebSafeString(cursorStr));
        }

        List<UnmatchedSKUItem> unmatchedSKUItems = Lists.newArrayList();
        QueryResultIterator<UnmatchedSKUItem> iterator = query.iterator();
        while (iterator.hasNext()) {
            unmatchedSKUItems.add(iterator.next());
        }

        pagedResult.setResults(unmatchedSKUItems);
        if (unmatchedSKUItems.size() == resultSizeLimit) {
            Cursor cursor = iterator.getCursor();
            pagedResult.setCursorWebSafeString(cursor.toWebSafeString());
        }
        Logger.info("Got %s records", unmatchedSKUItems.size());
        return pagedResult;
    }
}
