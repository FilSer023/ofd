package threewks.repository;

import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.AirportCatalog;
import threewks.model.RentalArea;
import threewks.model.RentalAreaStatus;

import java.util.List;

public class RentalAreaRepository extends StringRepository<RentalArea> {

    public RentalAreaRepository(SearchConfig searchConfig) {
        super(RentalArea.class, searchConfig);
    }

    public List<RentalArea> listByStatus(RentalAreaStatus rentalAreaStatus) {
        return getByField("status", rentalAreaStatus);
    }

    public List<RentalArea> listByAirport(AirportCatalog airportCatalog) {
        return getByField("airportCatalog", airportCatalog);
    }
}
