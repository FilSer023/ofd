package threewks.repository;

import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.SalesChannel;

public class SalesChannelRepository extends StringRepository<SalesChannel> {

    public SalesChannelRepository(SearchConfig searchConfig) {
        super(SalesChannel.class, searchConfig);
    }

}
