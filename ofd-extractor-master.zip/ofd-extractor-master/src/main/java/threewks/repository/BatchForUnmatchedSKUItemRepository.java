package threewks.repository;

import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.BatchForUnmatchedSKUItem;

import java.util.List;

public class BatchForUnmatchedSKUItemRepository extends StringRepository<BatchForUnmatchedSKUItem> {

    public BatchForUnmatchedSKUItemRepository(SearchConfig searchConfig) {
        super(BatchForUnmatchedSKUItem.class, searchConfig);
    }

    public List<BatchForUnmatchedSKUItem> listByBatch(String batchId) {
        return getByField("batchId", batchId);
    }
}
