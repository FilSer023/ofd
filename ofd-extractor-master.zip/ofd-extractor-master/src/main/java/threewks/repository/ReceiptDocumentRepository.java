package threewks.repository;

import com.google.appengine.api.datastore.QueryResultIterator;
import com.googlecode.objectify.Key;
import com.googlecode.objectify.Ref;
import com.googlecode.objectify.cmd.Query;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.ReceiptDocument;
import threewks.model.ReceiptDocumentStatus;
import threewks.model.ShopOperator;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class ReceiptDocumentRepository extends StringRepository<ReceiptDocument> {

    public static final int OLD_RECEIPT_CUTOFF_PERIOD = 60;
    public static final int DELETE_BATCH_SIZE = 200;

    public ReceiptDocumentRepository(SearchConfig searchConfig) {
        super(ReceiptDocument.class, searchConfig);
    }

    public boolean fetchedAllReceiptsForBatch(String batchId) {
        int notYetDownloaded = ofy().load().type(ReceiptDocument.class)
            .filter("batchId", batchId)
            .filter("status", ReceiptDocumentStatus.QUEUED)
            .count();
        return notYetDownloaded == 0;
    }

    public Map<String, Integer> getBatchStats(String batchId) {
        Map<String, Integer> stats = new HashMap<>();
        for (ReceiptDocumentStatus status : ReceiptDocumentStatus.values()) {
            stats.put(status.name(), getCountByBatchAndStatus(batchId, status));
        }
        return stats;
    }

    private int getCountByBatchAndStatus(String batchId, ReceiptDocumentStatus status) {
        int queued = ofy().load().type(ReceiptDocument.class)
            .filter("batchId", batchId)
            .filter("status", status)
            .count();
        return queued;
    }

    public List<ReceiptDocument> filterByStatusAndBatch(ReceiptDocumentStatus status, String batchId) {
        List<ReceiptDocument> notYetDownloaded = ofy().load().type(ReceiptDocument.class)
            .filter("batchId", batchId)
            .filter("status", status).list();
        return notYetDownloaded;
    }

    public void deleteOldReceipts() {
        deleteOlderThan(OLD_RECEIPT_CUTOFF_PERIOD);
    }

    public void deleteOlderThan(int days) {
        LocalDate date = LocalDate.now().minusDays(days);
        Date cutoffDate = Date.from(date.atStartOfDay()
            .atZone(ZoneId.systemDefault())
            .toInstant());
        Query<ReceiptDocument> query = ofy().load().type(ReceiptDocument.class)
            .filter("created <=", cutoffDate).limit(DELETE_BATCH_SIZE);
        long numDeleted = deleteQueryResultsInBatch(query);
        Logger.info("Deleting %s individual receipts", numDeleted);
    }

    public void deleteByShopOperatorAndDateRange(ShopOperator shopOperator, Date from, int days) {
        Calendar toCalendar = Calendar.getInstance();
        toCalendar.setTime(from);
        toCalendar.add(Calendar.DATE, days);
        Query<ReceiptDocument> query = ofy().load().type(ReceiptDocument.class)
            .filter("shopOperator =", Ref.create(shopOperator))
            .filter("created >=", from)
            .filter("created <=", toCalendar.getTime()).limit(DELETE_BATCH_SIZE);
        long numDeleted = deleteQueryResultsInBatch(query);
        Logger.info("Deleting %s receipts for shop operator %s and date range from %s to %s", numDeleted, shopOperator.getId(),
            from, toCalendar.getTime());
    }

    private long deleteQueryResultsInBatch(Query<ReceiptDocument> query) {
        long numDeleted = 0;
        QueryResultIterator<Key<ReceiptDocument>> iterator = query.keys().iterator();
        List<Key<ReceiptDocument>> keysToDelete = new ArrayList<>();
        while (iterator.hasNext()) {
            Key<ReceiptDocument> key = iterator.next();
            keysToDelete.add(key);
            if (!iterator.hasNext()) {
                deleteByKey(fromKeys.from(keysToDelete));
                numDeleted += keysToDelete.size();
                keysToDelete.clear();
                iterator = query.startAt(iterator.getCursor()).keys().iterator();
            }
        }
        return numDeleted;
    }
}
