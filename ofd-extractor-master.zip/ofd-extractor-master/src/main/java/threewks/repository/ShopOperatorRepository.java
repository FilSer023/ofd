package threewks.repository;

import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.RentalArea;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;

import java.util.List;

public class ShopOperatorRepository extends StringRepository<ShopOperator> {

    public ShopOperatorRepository(SearchConfig searchConfig) {
        super(ShopOperator.class, searchConfig);
    }

    public List<ShopOperator> listByStatus(ShopOperatorStatus shopOperatorStatus) {
        return getByField("status", shopOperatorStatus);
    }

    public List<ShopOperator> listByRentalArea(RentalArea rentalArea) {
        return getByField("rentalAreas", rentalArea);
    }

    public List<ShopOperator> listByName(String name) {
        return getByField("name", name);
    }
}
