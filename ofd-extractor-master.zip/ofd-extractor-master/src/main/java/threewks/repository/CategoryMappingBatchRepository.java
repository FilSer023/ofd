package threewks.repository;

import com.google.appengine.api.datastore.Query;
import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.CategoryMappingBatch;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class CategoryMappingBatchRepository extends StringRepository<CategoryMappingBatch> {

    private static final int RECENT_DAYS_PERIOD = 5;

    public CategoryMappingBatchRepository(SearchConfig searchConfig) {
        super(CategoryMappingBatch.class, searchConfig);
    }

    public List<CategoryMappingBatch> getRecentBatches() {
        Date end = new Date();
        Date start = Date.from(LocalDate.now().minusDays(RECENT_DAYS_PERIOD)
            .atStartOfDay(ZoneId.systemDefault()).toInstant());
        List<Query.Filter> dateFilters = new ArrayList<>();
        dateFilters.add(new Query.FilterPredicate(CategoryMappingBatch.SearchFields.TimeStarted, Query.FilterOperator.GREATER_THAN_OR_EQUAL, start));
        dateFilters.add(new Query.FilterPredicate(CategoryMappingBatch.SearchFields.TimeStarted, Query.FilterOperator.LESS_THAN_OR_EQUAL, end));
        Query.Filter dateFilter = new Query.CompositeFilter(Query.CompositeFilterOperator.AND, dateFilters);
        com.googlecode.objectify.cmd.Query<CategoryMappingBatch> query = ofy().load().type(CategoryMappingBatch.class).filter(dateFilter);
        List<CategoryMappingBatch> batches = query.list();
        return batches;
    }
}
