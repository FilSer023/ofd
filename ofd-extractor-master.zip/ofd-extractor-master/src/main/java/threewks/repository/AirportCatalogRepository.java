package threewks.repository;

import com.threewks.thundr.search.gae.SearchConfig;
import threewks.framework.shared.repository.StringRepository;
import threewks.model.AirportCatalog;

public class AirportCatalogRepository extends StringRepository<AirportCatalog> {
    public AirportCatalogRepository(SearchConfig searchConfig) {
        super(AirportCatalog.class, searchConfig);
    }
}
