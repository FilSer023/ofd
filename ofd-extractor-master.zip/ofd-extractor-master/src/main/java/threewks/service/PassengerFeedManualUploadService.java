package threewks.service;

import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.threewks.thundr.logger.Logger;
import threewks.framework.usermanager.model.AppUser;
import threewks.model.PassengerFeedBatch;
import threewks.model.PassengerFeedBatchStatus;
import threewks.model.dto.PassengerFeedManualUploadDTO;
import threewks.service.passengerfeed.PassengerFeedBatchService;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class PassengerFeedManualUploadService {

    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final String COBRA_PREFIX = "cobra/%s/%s/%s";
    private final GcsService gcsService;
    private final String gcsDefaultBucket;
    private final PassengerFeedBatchService passengerFeedBatchService;
    private final TaskService taskService;

    public PassengerFeedManualUploadService(GcsService gcsService, String gcsDefaultBucket, PassengerFeedBatchService passengerFeedBatchService, TaskService taskService) {
        this.gcsService = gcsService;
        this.gcsDefaultBucket = gcsDefaultBucket;
        this.passengerFeedBatchService = passengerFeedBatchService;
        this.taskService = taskService;
    }

    public void startPassengerFeedDataUpload(PassengerFeedManualUploadDTO passengerFeedManualUploadDTO, AppUser user) {
        LocalDate date = LocalDate.now(ZoneId.of("UTC"));
        String feedDay = date.format(TODAY_FORMAT);
        PassengerFeedBatch passengerFeedBatch = passengerFeedBatchService.startBatch(feedDay, user.getName());
        passengerFeedBatch.setAutomatic(false);
        passengerFeedBatch.setManualUploadAirportName(passengerFeedManualUploadDTO.getAirport());
        String fileName = String.format(COBRA_PREFIX, passengerFeedBatch.getId(), "manual", passengerFeedManualUploadDTO.getAirport() + "_ORNK.csv");
        GcsFilename attachmentFilename = new GcsFilename(passengerFeedManualUploadDTO.getAttachment().getBucket(), passengerFeedManualUploadDTO.getAttachment().getName());
        GcsFilename gcsFilename = new GcsFilename(gcsDefaultBucket, fileName);
        try {
            Logger.info("Copying manual uploaded passenger feed file from %s to %s", attachmentFilename, gcsFilename);
            gcsService.copy(attachmentFilename, gcsFilename);
            passengerFeedBatch.setStatus(PassengerFeedBatchStatus.FTP_EXPORT_COMPLETED);
        } catch (IOException e) {
            Logger.warn("Gcs file copying error: %s. BatchId: %s", e.getMessage(), passengerFeedBatch.getId());
            passengerFeedBatch.setStatus(PassengerFeedBatchStatus.ERROR);
        }
        passengerFeedBatchService.save(passengerFeedBatch);
        taskService.preparePassengerFeed(passengerFeedBatch.getId());
//        passengerFeedDataManager.ingestPassengerFeedData(passengerFeedBatch.getId());
    }
}
