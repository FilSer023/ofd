package threewks.service;

import threewks.model.PagedResult;
import threewks.model.UnmatchedSKUItem;
import threewks.repository.UnmatchedSKUItemRepository;

import javax.annotation.Nullable;
import java.util.List;

public class UnmatchedSKUItemService {
    private final UnmatchedSKUItemRepository unmatchedSKUItemRepository;
    private final TaskService taskService;
    private final CsvExportService csvExportService;

    public UnmatchedSKUItemService(UnmatchedSKUItemRepository unmatchedSKUItemRepository, TaskService taskService, CsvExportService csvExportService) {
        this.unmatchedSKUItemRepository = unmatchedSKUItemRepository;
        this.taskService = taskService;
        this.csvExportService = csvExportService;
    }

    public List<UnmatchedSKUItem> list() {
        return this.unmatchedSKUItemRepository.listAll();
    }

    public PagedResult<UnmatchedSKUItem> search(List<String> operatorNames, @Nullable String sku, @Nullable int cursor) {
        return this.unmatchedSKUItemRepository.search(operatorNames, sku, cursor);
    }

    public UnmatchedSKUItem save(UnmatchedSKUItem unmatchedSKUItem) {
        return this.unmatchedSKUItemRepository.put(unmatchedSKUItem);
    }

    public void saveAndAllocate(List<UnmatchedSKUItem> unmatchedSKUItems) {
        this.unmatchedSKUItemRepository.put(unmatchedSKUItems);
        taskService.exportAllocatedItems();
    }

    public UnmatchedSKUItem get(String id) {
        return this.unmatchedSKUItemRepository.get(id);
    }

    public int getCount() {
        return this.unmatchedSKUItemRepository.getCount();
    }

    public List<String> listOperatorsWithUnmatchedItems() {
        return this.unmatchedSKUItemRepository.listOperatorsWithUnmatchedItems();
    }

    public List<List<String>> exportUnallocated() {
        List<UnmatchedSKUItem> allItems = unmatchedSKUItemRepository.listAll();
        return csvExportService.toCsv(allItems);
    }
}
