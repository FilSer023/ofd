package threewks.service;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import threewks.model.AirportCatalog;
import threewks.model.RentalArea;
import threewks.model.RentalAreaStatus;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;
import threewks.model.TradePoint;
import threewks.model.dto.RentalAreaDto;
import threewks.repository.RentalAreaRepository;
import threewks.repository.ShopOperatorRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.googlecode.objectify.ObjectifyService.ofy;
import static java.util.Arrays.asList;

public class RentalAreaService {
    public static final String NO_TENANT = "<НЕТ>";
    private final RentalAreaRepository rentalAreaRepository;
    private final ShopOperatorService shopOperatorService;
    private final ShopOperatorRepository shopOperatorRepository;

    public RentalAreaService(RentalAreaRepository rentalAreaRepository, ShopOperatorService shopOperatorService, ShopOperatorRepository shopOperatorRepository) {
        this.rentalAreaRepository = rentalAreaRepository;
        this.shopOperatorService = shopOperatorService;
        this.shopOperatorRepository = shopOperatorRepository;
    }

    public List<RentalArea> getActiveRentalAreas() {
        return rentalAreaRepository.listByStatus(RentalAreaStatus.ACTIVE);
    }

    public List<RentalAreaDto> listByStatus(List<String> status) {
        List<RentalArea> areas = rentalAreaRepository.listAll();
        List<RentalAreaStatus> rentalAreaStatuses = new ArrayList<>();
        if (CollectionUtils.isEmpty(status)) {
            rentalAreaStatuses.addAll(asList(RentalAreaStatus.values()));
        } else {
            status.stream().forEach(statusString -> rentalAreaStatuses.add(RentalAreaStatus.valueOf(statusString)));
        }
        List<ShopOperator> shopOperators = shopOperatorRepository.listAll();
        Map<RentalArea, String> tradePoints = shopOperators.stream().flatMap(shopOperator -> shopOperator.getTradePoints().stream())
            .filter(tradePoint -> tradePoint.getRentalAreaRef() != null && StringUtils.isNotBlank(tradePoint.getName()))
            .collect(Collectors.toMap(TradePoint::getRentalAreaRef, TradePoint::getName));

        return areas
            .stream()
            .filter(rentalArea -> rentalAreaStatuses.contains(rentalArea.getStatus()))
            .map(area ->
                RentalAreaDto.from(area, tradePoints.getOrDefault(area, NO_TENANT))
            )
            .collect(Collectors.toList());
    }

    public RentalArea save(RentalArea rentalArea) {
        return ofy().transact(() -> {

            // created will be blank on initial save
            if (rentalArea.getCreated() == null) {
                rentalArea.setCreated(DateTime.now());
            }

            return rentalAreaRepository.put(rentalArea);
        });
    }

    public boolean delete(String rentalAreaId) {
        boolean deleted = false;
        RentalArea rentalArea = rentalAreaRepository.get(rentalAreaId);
        List<ShopOperator> shopOperators = shopOperatorRepository.listByRentalArea(rentalArea);
        if (CollectionUtils.isEmpty(shopOperators)) {
            rentalAreaRepository.delete(rentalArea);
            deleted = true;
        }
        return deleted;
    }

    public RentalArea get(String rentalAreaId) {
        return rentalAreaRepository.get(rentalAreaId);
    }

    public List<RentalAreaDto> getFreeRentalAreas() {
        List<RentalArea> freeAreas = getActiveRentalAreas();
        freeAreas.removeAll(getBusyRentalAreas());
        return freeAreas.stream().map(rentalArea -> RentalAreaDto.from(rentalArea)).collect(Collectors.toList());
    }

    public List<RentalArea> getByAirport(AirportCatalog airportCatalog) {
        return rentalAreaRepository.listByAirport(airportCatalog);
    }

    private List<RentalArea> getBusyRentalAreas() {
        List<RentalArea> busyRentalAreas = new ArrayList<>();
        List<ShopOperator> shopOperators = shopOperatorRepository.listAll();

        for (ShopOperator shopOperator : shopOperators) {
            if (shopOperator.getRentalAreas() != null && shopOperator.getStatus() != ShopOperatorStatus.ARCHIVED) {
                    busyRentalAreas.addAll(shopOperator.getRentalAreas());
            }
        }
        return busyRentalAreas;
    }

}
