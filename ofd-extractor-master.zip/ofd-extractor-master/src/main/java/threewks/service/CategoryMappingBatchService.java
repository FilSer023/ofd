package threewks.service;

import org.apache.commons.collections.CollectionUtils;
import threewks.model.CategoryMappingBatch;
import threewks.model.CategoryMappingBatchStatus;
import threewks.repository.CategoryMappingBatchRepository;

import java.util.Date;
import java.util.List;

public class CategoryMappingBatchService {

    private final CategoryMappingBatchRepository categoryMappingBatchRepository;
    private final TaskService taskService;

    public CategoryMappingBatchService(CategoryMappingBatchRepository categoryMappingBatchRepository, TaskService taskService) {
        this.categoryMappingBatchRepository = categoryMappingBatchRepository;
        this.taskService = taskService;
    }

    public CategoryMappingBatch find(String id) {
        return this.categoryMappingBatchRepository.get(id);
    }

    public CategoryMappingBatch save(CategoryMappingBatch categoryMappingBatch) {
        return this.categoryMappingBatchRepository.put(categoryMappingBatch);
    }

    public List<CategoryMappingBatch> getRecentBatches() {
        return this.categoryMappingBatchRepository.getRecentBatches();
    }

    public String startBatch(CategoryMappingBatch batch) {
        batch.setStatus(CategoryMappingBatchStatus.STARTED);
        batch.setTimeStarted(new Date());
        batch = this.categoryMappingBatchRepository.put(batch);
        String batchId = batch.getId();
        taskService.importCategoryMappingFile(batchId);
        return batchId;
    }

    public CategoryMappingBatch finishBatch(CategoryMappingBatch batch) {
        if (CollectionUtils.isEmpty(batch.getErrorMessages())) {
            batch.setStatus(CategoryMappingBatchStatus.IMPORT_TO_BQ_COMPLETED);
        } else {
            batch.setStatus(CategoryMappingBatchStatus.ERROR);
        }
        batch.setTimeFinished(new Date());
        return this.categoryMappingBatchRepository.put(batch);
    }
}
