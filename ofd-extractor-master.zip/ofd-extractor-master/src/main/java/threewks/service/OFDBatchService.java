package threewks.service;

import com.threewks.thundr.user.User;
import org.apache.commons.collections.CollectionUtils;
import threewks.framework.usermanager.model.AppUser;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.model.dto.OFDBatchDto;
import threewks.repository.OFDBatchRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class OFDBatchService {

    public static final String QUEUED_RECEIPTS_COUNT_MESSAGE = "Ожидают выгрузки: %s чеков";
    public static final String DOWNLOADED_RECEIPTS_COUNT_MESSAGE = "Выгружено: %s чеков с детализацией";
    public static final String ERROR_RECEIPTS_COUNT_MESSAGE = "Ошибка выгрузки чека с детализацией: %s чеков";
    public static final String ALL_DETAILS_RETRIEVED_MESSAGE = "Все чеки с детализацией выгружены";

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final String BATCH_CONTINUED_MESSAGE = "Сеанс выгрузки продолжен";
    private static final String TOGGLE_REVIEWED_MESSAGE = "%s - пользователь %s: индикатор \"рассмотренный\" изменен на значение \"%s\"";

    private final OFDBatchRepository ofdBatchRepository;

    public OFDBatchService(OFDBatchRepository ofdBatchRepository) {
        this.ofdBatchRepository = ofdBatchRepository;
    }

    public List<OFDBatch> getRecentBatches(int daysOffset, List<BatchStatus> filteredStatus) {
        return this.ofdBatchRepository.getRecentBatches(daysOffset, filteredStatus);
    }

    public OFDBatch find(String id) {
        return this.ofdBatchRepository.get(id);
    }

    public boolean batchInProgress(ShopOperator shopOperator) {
        return ofdBatchRepository.isRunning(shopOperator);
    }

    public OFDBatch continueBatch(String id) {
        OFDBatch batch = ofdBatchRepository.get(id);
        batch.setStatus(BatchStatus.OFD_EXPORT_CONTINUED);
        batch.getTimeContinued().add(new Date());
        batch.getInfoMessages().add(BATCH_CONTINUED_MESSAGE);
        return ofdBatchRepository.put(batch);
    }

    public OFDBatch startBatch(ShopOperator operator, String exportDay, int fullPeriodLength, String username) {
        OFDBatch batch = new OFDBatch(operator);
        batch.setTimeStarted(new Date());
        batch.setBatchDay(exportDay);
        batch.setPeriodLength(fullPeriodLength);
        batch.setStartedBy(username);
        return ofdBatchRepository.put(batch);
    }

    public OFDBatch finishBatch(OFDBatch batch) {
        if (CollectionUtils.isEmpty(batch.getErrorMessages())) {
            if (BatchStatus.RECEIPT_SUMMARIES_RETRIEVED != batch.getStatus()) {
                batch.setStatus(BatchStatus.OFD_EXPORT_COMPLETED);
                batch.setTimeFinished(new Date());
            }
        } else {
            batch.setStatus(BatchStatus.ERROR);
            batch.setTimeFinished(new Date());
        }
        return ofdBatchRepository.put(batch);
    }

    public OFDBatch save(OFDBatch batch) {
        return ofdBatchRepository.put(batch);
    }

    public OFDBatchDto toggleReviewed(User user, String batchId) {
        AppUser appUser = (AppUser) user;
        OFDBatch batch = ofdBatchRepository.get(batchId);
        batch.setReviewed(!batch.isReviewed());
        batch.getNotes().add(String.format(TOGGLE_REVIEWED_MESSAGE, LocalDateTime.now().format(FORMATTER), appUser.getName(), batch.isReviewed()));
        return OFDBatchDto.from(ofdBatchRepository.put(batch));
    }
}
