package threewks.service;

import threewks.model.ConfigParameter;
import threewks.repository.ConfigParameterRepository;

import java.util.List;
import java.util.Optional;

public class ConfigParameterService {

    public static final String FTP_USERNAME = "FTP_USERNAME";
    public static final String FTP_PASSWORD = "FTP_PASSWORD";
    public static final String FTP_SERVER = "FTP_SERVER";
    public static final String KONTUR_API_KEY = "KONTUR_API_KEY";
    public static final String KONTUR_API_SESSION_KEY = "KONTUR_API_SESSION_KEY";
    public static final String PETER_SERVIS_USERNAME = "PETER_SERVIS_USERNAME";
    public static final String PETER_SERVIS_PASSWORD = "PETER_SERVIS_PASSWORD";

    private final ConfigParameterRepository configParameterRepository;

    public ConfigParameterService(ConfigParameterRepository configParameterRepository) {
        this.configParameterRepository = configParameterRepository;
    }

    public List<ConfigParameter> list() {
        return this.configParameterRepository.listAll();
    }

    public ConfigParameter get(String configParameterId) {
        return this.configParameterRepository.get(configParameterId);
    }

    public Optional<ConfigParameter> getByName(String name) {
        return this.configParameterRepository.getByName(name);
    }

    public ConfigParameter save(ConfigParameter configParameter) {
        return this.configParameterRepository.put(configParameter);
    }

    public String getConfigValueOrDefault(String configParameterName, String defaultValue) {
        Optional<ConfigParameter> configParameter = getByName(configParameterName);
        String value = null;
        if (configParameter.isPresent()) {
            value = configParameter.get().getValue();
        } else {
            value = defaultValue;
        }
        return value;
    }
}
