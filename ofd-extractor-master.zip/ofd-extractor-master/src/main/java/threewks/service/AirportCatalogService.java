package threewks.service;

import threewks.model.AirportCatalog;
import threewks.model.RentalArea;
import threewks.repository.AirportCatalogRepository;

import java.util.List;

public class AirportCatalogService {
    private final AirportCatalogRepository airportCatalogRepository;
    private final RentalAreaService rentalAreaService;

    public AirportCatalogService(AirportCatalogRepository airportCatalogRepository, RentalAreaService rentalAreaService) {
        this.airportCatalogRepository = airportCatalogRepository;
        this.rentalAreaService = rentalAreaService;
    }

    public List<AirportCatalog> list() {
        return this.airportCatalogRepository.listAll();
    }

    public AirportCatalog save(AirportCatalog airportCatalog) {
        return this.airportCatalogRepository.put(airportCatalog);
    }

    public AirportCatalog get(String id) {
        return this.airportCatalogRepository.get(id);
    }

    public boolean delete(String id) {
        boolean deleted = false;
        AirportCatalog airportCatalog = airportCatalogRepository.get(id);
        List<RentalArea> airportRentalAreas = rentalAreaService.getByAirport(airportCatalog);
        if (airportRentalAreas.isEmpty()) {
            airportCatalogRepository.delete(airportCatalog);
            deleted = true;
        }
        return deleted;
    }
}
