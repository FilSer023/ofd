package threewks.service;

import org.joda.time.DateTime;
import threewks.model.UnmatchedCategoryReport;
import threewks.repository.UnmatchedCategoryReportRepository;

import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class UnmatchedCategoryReportService {

    private UnmatchedCategoryReportRepository unmatchedCategoryReportRepository;

    public UnmatchedCategoryReportService(UnmatchedCategoryReportRepository unmatchedCategoryReportRepository) {
        this.unmatchedCategoryReportRepository = unmatchedCategoryReportRepository;
    }

    public List<UnmatchedCategoryReport> list() {
        return unmatchedCategoryReportRepository.listAll();
    }

    public UnmatchedCategoryReport getLatest() {
        return unmatchedCategoryReportRepository.getLatest();
    }

    public UnmatchedCategoryReport save(UnmatchedCategoryReport unmatchedCategoryReport) {
        return ofy().transact(() -> {

            if (unmatchedCategoryReport.getCreatedDate() == null) {
                unmatchedCategoryReport.setCreatedDate(DateTime.now());
            }
            unmatchedCategoryReport.setUpdatedDate(DateTime.now());
            return unmatchedCategoryReportRepository.put(unmatchedCategoryReport);
        });

    }
}
