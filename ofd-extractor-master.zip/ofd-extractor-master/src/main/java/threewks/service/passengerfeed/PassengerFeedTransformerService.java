package threewks.service.passengerfeed;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.google.appengine.tools.cloudstorage.GcsFileOptions;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsInputChannel;
import com.google.appengine.tools.cloudstorage.GcsOutputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.io.IOUtils;
import sun.nio.ch.ChannelInputStream;
import threewks.model.AirportCatalog;
import threewks.model.PassengerFeedBatch;
import threewks.service.AirportCatalogService;
import threewks.service.TaskService;
import threewks.service.passengerfeed.model.PassengerFeedLine;
import threewks.util.Assert;

import java.io.InputStream;
import java.nio.channels.Channels;
import java.util.List;

import static org.apache.commons.io.IOUtils.copy;
import static threewks.model.PassengerFeedBatchStatus.DATA_PREPARED_FOR_IMPORT;
import static threewks.model.PassengerFeedBatchStatus.FTP_EXPORT_COMPLETED;

public class PassengerFeedTransformerService {

    private static final String RAW_CSV_PATH = "cobra/%s/%s/%s_ORNK.csv";
    private static final String PROCESSED_JSON_PATH = "cobra/%s/%s/processed/%s.json";

    private static final CsvSchema EMPTY_SCHEMA = CsvSchema.emptySchema().withColumnSeparator(';').withoutQuoteChar().withHeader();
    private static final String FEED_FILE_PROCESSED_MESSAGE = "Файл пассажиропотока %s обработан для импорта в хранилище данных";
    private static final String PASSENGER_FEED_PREPARING_ERROR_MESSAGE = "Ошибка обработки исходного файла пассажиропотока. Проверьте корректность данных";
    private static final String PASSENGER_FEED_FILE_MISSING_MESSAGE = "Ошибка чтения исходного файла пассажиропотока. Возможно он не был импортирован";

    private final TaskService taskService;
    private final AirportCatalogService airportCatalogService;
    private final PassengerFeedBatchService passengerFeedBatchService;
    private final Gson gson;
    private final GcsFileOptions instance = GcsFileOptions.getDefaultInstance();
    private final String gcsDefaultBucket;
    private final GcsService gcsService =
        GcsServiceFactory.createGcsService(
            new RetryParams.Builder()
                .initialRetryDelayMillis(10)
                .retryMaxAttempts(10)
                .totalRetryPeriodMillis(15000)
                .build());

    public PassengerFeedTransformerService(AirportCatalogService airportCatalogService, TaskService taskService, PassengerFeedBatchService passengerFeedBatchService,
        GsonBuilder gsonBuilder,
        String gcsDefaultBucket) {
        this.airportCatalogService = airportCatalogService;
        this.taskService = taskService;
        this.passengerFeedBatchService = passengerFeedBatchService;
        this.gson = gsonBuilder.create();
        this.gcsDefaultBucket = gcsDefaultBucket;
    }

    public void prepareFilesForIngestion(String batchId) {
        PassengerFeedBatch passengerFeedBatch = passengerFeedBatchService.find(batchId);

        Assert.isTrue(FTP_EXPORT_COMPLETED == passengerFeedBatch.getStatus(),
            "Passenger feed batch must be in FTP_EXPORT_COMPLETED status, currently %s", passengerFeedBatch.getStatus());
        if (passengerFeedBatch.isAutomatic()) {
            List<AirportCatalog> airports = airportCatalogService.list();
            for (AirportCatalog airport : airports) {
                processFile(passengerFeedBatch, airport.getNameIATA());
            }
        } else {
            processFile(passengerFeedBatch, passengerFeedBatch.getManualUploadAirportName());
        }
        passengerFeedBatch.setStatus(DATA_PREPARED_FOR_IMPORT);

        passengerFeedBatchService.save(passengerFeedBatch);
        taskService.ingestPassengerFeedToBQ(passengerFeedBatch.getId());

    }

    private void processFile(PassengerFeedBatch passengerFeedBatch, String airportName) {
        ObjectMapper csvMapper = new CsvMapper();
        String gcsFilePath;
        if (passengerFeedBatch.isAutomatic()) {
            gcsFilePath = String.format(RAW_CSV_PATH, passengerFeedBatch.getId(), passengerFeedBatch.getFeedDay(), airportName);
        } else {
            gcsFilePath = String.format(RAW_CSV_PATH, passengerFeedBatch.getId(), "manual", airportName);
        }
        GcsFilename gcsFilename = new GcsFilename(gcsDefaultBucket, gcsFilePath);
        GcsInputChannel inputChannel = null;
        int linesImported = 0;
        StringBuilder newlineDelimitedJson = new StringBuilder();
        try {
            inputChannel = gcsService.openReadChannel(gcsFilename, 0);
            InputStream inputStream = new ChannelInputStream(inputChannel);
            MappingIterator<PassengerFeedLine> mappingIterator = csvMapper.readerFor(PassengerFeedLine.class).with(EMPTY_SCHEMA).readValues(inputStream);
            while (mappingIterator.hasNext()) {
                PassengerFeedLine line = mappingIterator.next();
                line.setAirportName(airportName);
                line.setBatchId(passengerFeedBatch.getId());
                newlineDelimitedJson.append(gson.toJson(line)).append(System.lineSeparator());
                linesImported++;
            }
        } catch (Exception e) {
            Logger.warn("Cannot read requested file for airport %s, caught exception: %s", airportName, e.getMessage());
            passengerFeedBatch.getErrorMessages().add(PASSENGER_FEED_FILE_MISSING_MESSAGE);
        }
        passengerFeedBatch.getLinesImported().put(airportName, linesImported);
        String processedFileName;
        if (passengerFeedBatch.isAutomatic()) {
            processedFileName = String.format(PROCESSED_JSON_PATH, passengerFeedBatch.getId(), passengerFeedBatch.getFeedDay(), airportName);
        } else {
            processedFileName = String.format(PROCESSED_JSON_PATH, passengerFeedBatch.getId(), "manual", airportName);
        }

        GcsFilename processedFile = new GcsFilename(gcsDefaultBucket, processedFileName);
        try {
            GcsOutputChannel outputChannel = gcsService.createOrReplace(processedFile, instance);
            InputStream in = IOUtils.toInputStream(newlineDelimitedJson.toString(), "UTF-8");
            copy(in, Channels.newOutputStream(outputChannel));
            outputChannel.close();
        } catch (Exception e) {
            Logger.warn("Cannot process passenger feed for airport %s, caught exception: %s", airportName, e.getMessage());
            passengerFeedBatch.getErrorMessages().add(PASSENGER_FEED_PREPARING_ERROR_MESSAGE);
        }
        passengerFeedBatch.getInfoMessages().add(String.format(FEED_FILE_PROCESSED_MESSAGE, airportName));
        Logger.info("Saved processed PassengerFeed for file %s date: %s", airportName, passengerFeedBatch.getFeedDay());
    }

}
