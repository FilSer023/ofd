package threewks.service.passengerfeed;

import com.threewks.thundr.logger.Logger;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import threewks.model.AirportCatalog;
import threewks.model.PassengerFeedBatch;
import threewks.model.PassengerFeedBatchStatus;
import threewks.service.AirportCatalogService;
import threewks.service.ConfigParameterService;

import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class CobraDataService {

    public static final String CRON_USERNAME = "cron";

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    //20180805210102
    private static final DateTimeFormatter FTP_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private static final String ERROR_MESSAGE = "Ошибка выгрузки файла пассажиропотока %s с сервера FTP: %s";
    private static final String ERROR_MESSAGE_NO_MODIFICATION_TIME = "Не удалось определить время модификации файла %s - проверьте его наличине на сервере";
    private static final String SUCCESS_MESSAGE = "Файл пассажиропотока %s успешно выгружены с сервера FTP";

    private static final String FTP_FILE_LOCATION_FORMAT = "%s_ORNK.csv";
    private static final String DIRECTORY_PREFIX = "CallCenter/%s";
    private static final String COBRA_PREFIX = "cobra/%s/%s/%s";
    private static final String FILE_TOO_OLD_MESSAGE = "Время модификации файла %s на сервере равно %s, проверьте выгрузку ОРНК. Файл не импортирован";
    private static final long ONE_DAY = 1L;

    private final AirportCatalogService airportCatalogService;
    private final FTPClient ftpClient;
    private final GcsFileWriter gcsFileWriter;
    private final ConfigParameterService configParameterService;
    private final PassengerFeedBatchService passengerFeedBatchService;
    private final String ftpServerHost;
    private final String ftpServerUser;
    private final String ftpServerPass;

    public CobraDataService(AirportCatalogService airportCatalogService, FTPClient ftpClient, ConfigParameterService configParameterService,
        PassengerFeedBatchService passengerFeedBatchService,
        String ftpServerHost, String ftpServerUser, String ftpServerPass, GcsFileWriter gcsFileWriter) {
        this.airportCatalogService = airportCatalogService;
        this.ftpClient = ftpClient;
        this.gcsFileWriter = gcsFileWriter;
        this.configParameterService = configParameterService;
        this.passengerFeedBatchService = passengerFeedBatchService;
        this.ftpServerHost = ftpServerHost;
        this.ftpServerUser = ftpServerUser;
        this.ftpServerPass = ftpServerPass;
    }

    public String fetchPassengerFeedFiles(String feedDay) throws Exception {
        String ftpServerHost = configParameterService.getConfigValueOrDefault(ConfigParameterService.FTP_SERVER, this.ftpServerHost);
        String ftpServerUser = configParameterService.getConfigValueOrDefault(ConfigParameterService.FTP_USERNAME, this.ftpServerUser);
        String ftpServerPass = configParameterService.getConfigValueOrDefault(ConfigParameterService.FTP_PASSWORD, this.ftpServerPass);

        PassengerFeedBatch passengerFeedBatch = passengerFeedBatchService.startBatch(feedDay, CRON_USERNAME);
        boolean success = false;
        ftpClient.connect(ftpServerHost, 21);
        ftpClient.login(ftpServerUser, ftpServerPass);
        ftpClient.enterLocalPassiveMode();
        ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

        OffsetDateTime cutoffTime = LocalDate.parse(feedDay, DATE_FORMAT).atStartOfDay(ZoneId.of("Europe/Moscow")).plusDays(ONE_DAY).toOffsetDateTime();
        List<AirportCatalog> airports = airportCatalogService.list();
        List<String> fileNames = airports.stream().map(airportCatalog -> String.format(FTP_FILE_LOCATION_FORMAT, airportCatalog.getNameIATA())).collect(Collectors.toList());
        for (String file : fileNames) {
            String modification = ftpClient.getModificationTime(String.format(DIRECTORY_PREFIX, file));
            if (StringUtils.isEmpty(modification)) {
                passengerFeedBatch.getErrorMessages().add(String.format(ERROR_MESSAGE_NO_MODIFICATION_TIME, file));
                continue;
            }
            OffsetDateTime lastModified = LocalDateTime.parse(modification, FTP_DATE_FORMAT)
                .atOffset(ZoneOffset.of("Z").getRules().getOffset(LocalDateTime.now()));
            if (lastModified.isBefore(cutoffTime)) {
                Logger.warn(String.format(FILE_TOO_OLD_MESSAGE, file, modification));
                passengerFeedBatch.getErrorMessages().add(String.format(FILE_TOO_OLD_MESSAGE, file, modification));
                continue;
            } else {
                InputStream inputStream = ftpClient.retrieveFileStream(String.format(DIRECTORY_PREFIX, file));
                try {
                    gcsFileWriter.writeFile(String.format(COBRA_PREFIX, passengerFeedBatch.getId(), passengerFeedBatch.getFeedDay(), file), inputStream);
                    success = ftpClient.completePendingCommand();
                    if (success) {
                        passengerFeedBatch.getInfoMessages().add(String.format(SUCCESS_MESSAGE, file));
                    }
                } catch (Exception e) {
                    Logger.error(e, "Caught exception saving Cobra file: %s", e.getMessage());
                    passengerFeedBatch.getErrorMessages().add(String.format(ERROR_MESSAGE, file, "ошибка сохранения файла " + e.getMessage()));
                }
            }
        }
        passengerFeedBatch.setStatus(PassengerFeedBatchStatus.FTP_EXPORT_COMPLETED);
        passengerFeedBatchService.save(passengerFeedBatch);
        return passengerFeedBatch.getId();
    }
}
