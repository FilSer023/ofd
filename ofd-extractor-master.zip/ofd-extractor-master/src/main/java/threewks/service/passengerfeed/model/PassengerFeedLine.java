package threewks.service.passengerfeed.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PassengerFeedLine {
    @JsonProperty("spp_id")
    private String flightId;
    @JsonProperty("nr")
    private String flightNumber;
    @JsonProperty("airline_name")
    private String airlineName;
    @JsonProperty("airline_iata")
    private String airlineIATACode;
    @JsonProperty("pv_kobra")
    private String pvKobra;
    @JsonProperty("type_schedule")
    private String scheduleType;
    @JsonProperty("type_reg")
    private String regType;
    @JsonProperty("ap_dep_crt")
    private String departureAirportRus;
    @JsonProperty("ap_dep_en")
    private String departureAirportLat;
    @JsonProperty("ap_dep_iata")
    private String departureAirportIATACode;
    @JsonProperty("ap_arr_crt")
    private String arrivalAirportRus;
    @JsonProperty("dt_plan_dep")
    private String scheduledDepartureTime;
    @JsonProperty("dt_fact_dep")
    private String factDepartureTime;
    @JsonProperty("dt_act_dep")
    private String actualDepartureTime;
    @JsonProperty("ap_arr_en")
    private String arrivalAirportLat;
    @JsonProperty("ap_arr_iata")
    private String arrivalAirportIATACode;
    @JsonProperty("dt_plan_arr")
    private String scheduledArrivalTime;
    @JsonProperty("dt_act_arr")
    private String actualArrivalTime;
    @JsonProperty("pax_vzr")
    private Integer economyClassAdultsCount;
    @JsonProperty("pax_rb")
    private Integer economyClassChildrenCount;
    @JsonProperty("pax_vzr_c")
    private Integer businessClassAdultsCount;
    @JsonProperty("pax_rb_c")
    private Integer businessClassChildrenCount;
    @JsonProperty("gate")
    private String boardingGate;
    @JsonProperty("all_seats")
    private Integer totalPassengers;
    @JsonProperty("airportName")
    private String airportName;
    @JsonProperty("batchId")
    private String batchId;

    public PassengerFeedLine() {
    }

    public String getFlightId() {
        return flightId;
    }

    public PassengerFeedLine setFlightId(String flightId) {
        this.flightId = flightId;
        return this;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public PassengerFeedLine setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
        return this;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public PassengerFeedLine setAirlineName(String airlineName) {
        this.airlineName = airlineName;
        return this;
    }

    public String getAirlineIATACode() {
        return airlineIATACode;
    }

    public PassengerFeedLine setAirlineIATACode(String airlineIATACode) {
        this.airlineIATACode = airlineIATACode;
        return this;
    }

    public String getPvKobra() {
        return pvKobra;
    }

    public PassengerFeedLine setPvKobra(String pvKobra) {
        this.pvKobra = pvKobra;
        return this;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public PassengerFeedLine setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
        return this;
    }

    public String getRegType() {
        return regType;
    }

    public PassengerFeedLine setRegType(String regType) {
        this.regType = regType;
        return this;
    }

    public String getDepartureAirportRus() {
        return departureAirportRus;
    }

    public PassengerFeedLine setDepartureAirportRus(String departureAirportRus) {
        this.departureAirportRus = departureAirportRus;
        return this;
    }

    public String getDepartureAirportLat() {
        return departureAirportLat;
    }

    public PassengerFeedLine setDepartureAirportLat(String departureAirportLat) {
        this.departureAirportLat = departureAirportLat;
        return this;
    }

    public String getDepartureAirportIATACode() {
        return departureAirportIATACode;
    }

    public PassengerFeedLine setDepartureAirportIATACode(String departureAirportIATACode) {
        this.departureAirportIATACode = departureAirportIATACode;
        return this;
    }

    public String getArrivalAirportRus() {
        return arrivalAirportRus;
    }

    public PassengerFeedLine setArrivalAirportRus(String arrivalAirportRus) {
        this.arrivalAirportRus = arrivalAirportRus;
        return this;
    }

    public String getScheduledDepartureTime() {
        return scheduledDepartureTime;
    }

    public PassengerFeedLine setScheduledDepartureTime(String scheduledDepartureTime) {
        this.scheduledDepartureTime = scheduledDepartureTime;
        return this;
    }

    public String getActualDepartureTime() {
        return actualDepartureTime;
    }

    public PassengerFeedLine setActualDepartureTime(String actualDepartureTime) {
        this.actualDepartureTime = actualDepartureTime;
        return this;
    }

    public String getFactDepartureTime() {
        return factDepartureTime;
    }

    public PassengerFeedLine setFactDepartureTime(String factDepartureTime) {
        this.factDepartureTime = factDepartureTime;
        return this;
    }

    public String getArrivalAirportLat() {
        return arrivalAirportLat;
    }

    public PassengerFeedLine setArrivalAirportLat(String arrivalAirportLat) {
        this.arrivalAirportLat = arrivalAirportLat;
        return this;
    }

    public String getArrivalAirportIATACode() {
        return arrivalAirportIATACode;
    }

    public PassengerFeedLine setArrivalAirportIATACode(String arrivalAirportIATACode) {
        this.arrivalAirportIATACode = arrivalAirportIATACode;
        return this;
    }

    public String getScheduledArrivalTime() {
        return scheduledArrivalTime;
    }

    public PassengerFeedLine setScheduledArrivalTime(String scheduledArrivalTime) {
        this.scheduledArrivalTime = scheduledArrivalTime;
        return this;
    }

    public String getActualArrivalTime() {
        return actualArrivalTime;
    }

    public PassengerFeedLine setActualArrivalTime(String actualArrivalTime) {
        this.actualArrivalTime = actualArrivalTime;
        return this;
    }

    public Integer getEconomyClassAdultsCount() {
        return economyClassAdultsCount;
    }

    public PassengerFeedLine setEconomyClassAdultsCount(Integer economyClassAdultsCount) {
        this.economyClassAdultsCount = economyClassAdultsCount;
        return this;
    }

    public Integer getEconomyClassChildrenCount() {
        return economyClassChildrenCount;
    }

    public PassengerFeedLine setEconomyClassChildrenCount(Integer economyClassChildrenCount) {
        this.economyClassChildrenCount = economyClassChildrenCount;
        return this;
    }

    public Integer getBusinessClassAdultsCount() {
        return businessClassAdultsCount;
    }

    public PassengerFeedLine setBusinessClassAdultsCount(Integer businessClassAdultsCount) {
        this.businessClassAdultsCount = businessClassAdultsCount;
        return this;
    }

    public Integer getBusinessClassChildrenCount() {
        return businessClassChildrenCount;
    }

    public PassengerFeedLine setBusinessClassChildrenCount(Integer businessClassChildrenCount) {
        this.businessClassChildrenCount = businessClassChildrenCount;
        return this;
    }

    public String getBoardingGate() {
        return boardingGate;
    }

    public PassengerFeedLine setBoardingGate(String boardingGate) {
        this.boardingGate = boardingGate;
        return this;
    }

    public Integer getTotalPassengers() {
        return totalPassengers;
    }

    public PassengerFeedLine setTotalPassengers(Integer totalPassengers) {
        this.totalPassengers = totalPassengers;
        return this;
    }

    public String getAirportName() {
        return airportName;
    }

    public PassengerFeedLine setAirportName(String airportName) {
        this.airportName = airportName;
        return this;
    }

    public String getBatchId() {
        return batchId;
    }

    public PassengerFeedLine setBatchId(String batchId) {
        this.batchId = batchId;
        return this;
    }
}
