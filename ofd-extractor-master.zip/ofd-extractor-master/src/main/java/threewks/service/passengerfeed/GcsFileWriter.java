package threewks.service.passengerfeed;

import com.google.appengine.tools.cloudstorage.GcsFileOptions;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsOutputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.Channels;

public class GcsFileWriter {

    private final GcsService gcsService;
    private final String gcsDefaultBucket;
    private final GcsFileOptions instance = GcsFileOptions.getDefaultInstance();

    public GcsFileWriter(GcsService gcsService, String gcsDefaultBucket) {
        this.gcsService = gcsService;
        this.gcsDefaultBucket = gcsDefaultBucket;
    }

    public void writeFile(String fileName, InputStream inputStream) throws IOException {
        GcsFilename gcsFilename = new GcsFilename(gcsDefaultBucket, fileName);
        GcsOutputChannel outputChannel = gcsService.createOrReplace(gcsFilename, instance);
        Logger.info("Saving file %s to %s", gcsFilename, gcsFilename.getObjectName());
        OutputStream outputStream = Channels.newOutputStream(outputChannel);
        IOUtils.copy(inputStream, outputStream);
        outputChannel.close();
        inputStream.close();
    }
}
