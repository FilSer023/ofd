package threewks.service.passengerfeed;

import com.threewks.thundr.user.User;
import org.apache.commons.collections.CollectionUtils;
import threewks.framework.usermanager.model.AppUser;
import threewks.model.PassengerFeedBatch;
import threewks.model.PassengerFeedBatchStatus;
import threewks.repository.PassengerFeedBatchRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class PassengerFeedBatchService {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final String TOGGLE_REVIEWED_MESSAGE = "%s - пользователь %s: индикатор \"обработан\" изменен на значение \"%s\"";

    private final PassengerFeedBatchRepository passengerFeedBatchRepository;

    public PassengerFeedBatchService(PassengerFeedBatchRepository passengerFeedBatchRepository) {
        this.passengerFeedBatchRepository = passengerFeedBatchRepository;
    }

    public List<PassengerFeedBatch> getRecentBatches(int daysOffset, List<PassengerFeedBatchStatus> filteredStatus) {
        return this.passengerFeedBatchRepository.getRecentBatches(daysOffset, filteredStatus);
    }

    public PassengerFeedBatch find(String id) {
        return this.passengerFeedBatchRepository.get(id);
    }

    public PassengerFeedBatch startBatch(String feedDay, String username) {
        PassengerFeedBatch batch = new PassengerFeedBatch(feedDay);
        batch.setStatus(PassengerFeedBatchStatus.FTP_EXPORT_COMPLETED);
        batch.setTimeStarted(new Date());
        batch.setStartedBy(username);
        return passengerFeedBatchRepository.put(batch);
    }

    public PassengerFeedBatch finishBatch(PassengerFeedBatch batch) {
        if (CollectionUtils.isEmpty(batch.getErrorMessages())) {
            batch.setStatus(PassengerFeedBatchStatus.DATA_IMPORTED);
        } else {
            batch.setStatus(PassengerFeedBatchStatus.ERROR);
        }
        batch.setTimeFinished(new Date());
        return passengerFeedBatchRepository.put(batch);
    }

    public PassengerFeedBatch save(PassengerFeedBatch batch) {
        return passengerFeedBatchRepository.put(batch);
    }

    public PassengerFeedBatch toggleReviewed(User user, String batchId) {
        AppUser appUser = (AppUser) user;
        PassengerFeedBatch batch = passengerFeedBatchRepository.get(batchId);
        batch.setReviewed(!batch.isReviewed());
        batch.getNotes().add(String.format(TOGGLE_REVIEWED_MESSAGE, LocalDateTime.now().format(FORMATTER), appUser.getName(), batch.isReviewed()));
        return passengerFeedBatchRepository.put(batch);
    }
}
