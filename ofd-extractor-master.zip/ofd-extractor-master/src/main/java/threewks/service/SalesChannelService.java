package threewks.service;

import threewks.model.SalesChannel;
import threewks.repository.SalesChannelRepository;

import java.util.List;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class SalesChannelService {

    private final SalesChannelRepository salesChannelRepository;

    public SalesChannelService(SalesChannelRepository salesChannelRepository) {

        this.salesChannelRepository = salesChannelRepository;
    }

    public List<SalesChannel> list() {
        List<SalesChannel> areas = salesChannelRepository.listAll();
        return areas;
    }

    public SalesChannel save(String name) {
        SalesChannel salesChannel = new SalesChannel();
        return ofy().transact(() -> {
            salesChannel.setName(name);
            return salesChannelRepository.put(salesChannel);
        });
    }

    public SalesChannel update(String id, String name) {
        SalesChannel salesChannel = salesChannelRepository.get(id);
        return ofy().transact(() -> {
            salesChannel.setName(name);
            return salesChannelRepository.put(salesChannel);
        });
    }

    public void delete(String id) {
        SalesChannel delete = salesChannelRepository.get(id);
        ofy().transact(() -> {
            salesChannelRepository.delete(delete);
        });
    }

    public SalesChannel get(String salesChannelId) {
        return salesChannelRepository.get(salesChannelId);
    }


}
