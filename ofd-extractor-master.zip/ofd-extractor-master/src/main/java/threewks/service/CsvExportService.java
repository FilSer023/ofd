package threewks.service;

import threewks.model.UnmatchedSKUItem;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CsvExportService {

    private static final String NO_CATEGORY_ASSIGNED = "Без категории";
    private static final List<String> HEADERS = Stream.of(
        "ID",
        "Артикул",
        "Арендатор",
        "Категория"
    ).collect(Collectors.toList());

    public List<List<String>> toCsv(List<UnmatchedSKUItem> items) {
        return Stream.concat(Stream.of(HEADERS),
            items.stream()
                .map(item ->
                    Stream.of(
                        item.getId(),
                        item.getSku(),
                        item.getOperatorName(),
                        NO_CATEGORY_ASSIGNED)
                        .collect(Collectors.toList())))
            .collect(Collectors.toList());
    }
}
