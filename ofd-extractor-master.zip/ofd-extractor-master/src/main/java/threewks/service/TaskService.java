package threewks.service;

import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.RetryOptions;
import com.google.appengine.api.taskqueue.TaskHandle;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.route.Route;
import com.threewks.thundr.route.Router;
import com.threewks.thundr.user.User;
import org.apache.commons.lang3.StringUtils;
import threewks.framework.usermanager.model.AppUser;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.model.ShopOperator;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class TaskService {

    public static final String EXPORT_OFD_ROUTE = "task.exportOFD";
    public static final String CHECK_RECEIPTS_QUEUE_ROUTE = "task.checkReceiptsQueue";
    public static final String INGEST_OFD_BATCH_ROUTE = "task.ingestOFDBatch";
    public static final String FETCH_INDIVIDUAL_RECEIPTS_FROM_OFD_ROUTE = "task.fetchIndividualReceiptsFromOFD";
    public static final String COLLATE_OFD_TRANSACTIONS_ROUTE = "task.collateOFDTransactions";
    public static final String INGEST_FLATFILE_TRANSACTIONS_ROUTE = "task.ingestFlatFileTransactions";
    public static final String COMBINE_CLEAN_TRANSACTIONS_ROUTE = "task.combineCleanTransactions";
    public static final String UPDATE_INSERTION_TIME_ROUTE = "task.updateInsertionTime";
    public static final String FIND_UNMATCHED_SKUS_ROUTE = "task.findUnmatchedSKUs";
    public static final String DELETE_OLD_INDIVIDUAL_RECEIPTS_ROUTE = "task.deleteOldIndividualReceiptsRoute";
    public static final String INGEST_PASSENGER_FEED_ROUTE = "task.ingestPassengerFeed";
    public static final String DOWNLOAD_PASSENGER_FEED_ROUTE = "task.downloadPassengerFeed";
    public static final String PREPARE_PASSENGER_FEED_ROUTE = "task.preparePassengerFeed";
    public static final String DELETE_OLD_PASSENGER_FEED_DATA_ROUTE = "task.deleteOldPassengerFeedData";
    public static final String EXPORT_CURRENT_CATEGORY_MAPPING_ROUTE = "task.exportCurrentCategoryMapping";
    public static final String IMPORT_CATEGORY_MAPPING_FILE_ROUTE = "task.importCategoryMappingFile";
    public static final String EXPORT_ALLOCATED_ITEMS_ROUTE = "task.exportAllocatedItems";
    public static final String INGEST_BACKUP_DATA_ROUTE = "task.ingestBackupData";
    public static final String COLLATE_PASSENGER_FEED_DATA_ROUTE = "task.collatePassengerFeedData";
    public static final String COMBINE_OPERATOR_INFO_DATA_ROUTE = "task.combineOperatorInfoData";
    public static final String DELETE_ALLOCATED_UNMATCHED_SKU_ITEMS_ROUTE = "task.deleteAllocatedUnmatchedSKUItems";
    public static final String IMPORT_CATEGORY_MAPPING_SHEET_ROUTE = "task.importCategoryMappingSheetIntoTable";
    public static final String INGEST_SHOP_OPERATOR_TRANSACTIONS_FILE_ROUTE = "task.ingestShopOperatorTransactionsFile";
    public static final String INGEST_BATCH_FOR_UNMATCHED_ITEMS_ROUTE = "task.ingestBatchForUnmatchedItems";

    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final int DO_NOT_RETRY = 1;
    private static final int ONCE = 2;
    private static final double ONE_HOUR = 60 * 60;
    public static final String CRON_USERNAME = "cron";
    private static final long WAITING_PERIOD_BEFORE_COLLATION = 45 * 1000L;
    private static final long ONE_MINUTE = 60 * 1000;
    private static final long TEN_MINUTES_IN_SECONDS = 10 * 60;
    private static final long THIRTY_MINUTES_IN_MILLISECONDS = 30 * 60 * 1000;

    private final ShopOperatorService shopOperatorService;
    private final OFDBatchService ofdBatchService;
    private final Route exportOFDRoute;
    private final Route checkReceiptsQueueRoute;
    private final Route ingestOFDRoute;
    private final Route fetchIndividualReceiptsFromOFDRoute;
    private final Route ingestShopOperatorTransactionsFileRoute;
    private final Route collateOFDTransactionsRoute;
    private final Route ingestFlatFileTransactionsRoute;
    private final Route combineCleanTransactionsRoute;
    private final Route updateInsertionTimeRoute;
    private final Route findUnmatchedSKUsRoute;
    private final Route deleteOldIndividualReceiptsRoute;
    private final Route ingestPassengerFeedRoute;
    private final Route downloadPassengerFeedRoute;
    private final Route preparePassengerFeedRoute;
    private final Route exportCurrentCategoryMappingRoute;
    private final Route importCategoryMappingFileRoute;
    private final Route exportAllocatedItemsRoute;
    private final Route ingestBackupDataToBQRoute;
    private final Route collatePassengerFeedDataRoute;
    private final Route combineOperatorInfoDataRoute;
    private final Route deleteAllocatedUnmatchedSKUItemsRoute;
    private final Route deleteOldPassengerFeedDataRoute;
    private final Route importCategoryMappingSheetRoute;
    private final Route ingestBatchForUnmatchedItemsRoute;
    private final Queue ofdQueue;
    private final Queue bqQueue;
    private final Queue receiptsQueue;
    private final Queue adminTaskQueue;
    private final Queue unmatchedItemsIndexQueue;
    private final String reportPeriodDays;
    private final Router router;

    public TaskService(ShopOperatorService shopOperatorService, OFDBatchService ofdBatchService, Router router, Queue ofdQueue, Queue bqQueue,
        Queue receiptsQueue, Queue adminTaskQueue, Queue unmatchedItemsIndexQueue, String reportPeriodDays) {
        this.shopOperatorService = shopOperatorService;
        this.ofdBatchService = ofdBatchService;
        this.router = router;
        this.ofdQueue = ofdQueue;
        this.bqQueue = bqQueue;
        this.receiptsQueue = receiptsQueue;
        this.adminTaskQueue = adminTaskQueue;
        this.unmatchedItemsIndexQueue = unmatchedItemsIndexQueue;
        this.exportOFDRoute = router.getNamedRoute(EXPORT_OFD_ROUTE);
        this.checkReceiptsQueueRoute = router.getNamedRoute(CHECK_RECEIPTS_QUEUE_ROUTE);
        this.ingestOFDRoute = router.getNamedRoute(INGEST_OFD_BATCH_ROUTE);
        this.collateOFDTransactionsRoute = router.getNamedRoute(COLLATE_OFD_TRANSACTIONS_ROUTE);
        this.ingestFlatFileTransactionsRoute = router.getNamedRoute(INGEST_FLATFILE_TRANSACTIONS_ROUTE);
        this.combineCleanTransactionsRoute = router.getNamedRoute(COMBINE_CLEAN_TRANSACTIONS_ROUTE);
        this.updateInsertionTimeRoute = router.getNamedRoute(UPDATE_INSERTION_TIME_ROUTE);
        this.findUnmatchedSKUsRoute = router.getNamedRoute(FIND_UNMATCHED_SKUS_ROUTE);
        this.deleteOldIndividualReceiptsRoute = router.getNamedRoute(DELETE_OLD_INDIVIDUAL_RECEIPTS_ROUTE);
        this.ingestPassengerFeedRoute = router.getNamedRoute(INGEST_PASSENGER_FEED_ROUTE);
        this.downloadPassengerFeedRoute = router.getNamedRoute(DOWNLOAD_PASSENGER_FEED_ROUTE);
        this.preparePassengerFeedRoute = router.getNamedRoute(PREPARE_PASSENGER_FEED_ROUTE);
        this.exportCurrentCategoryMappingRoute = router.getNamedRoute(EXPORT_CURRENT_CATEGORY_MAPPING_ROUTE);
        this.importCategoryMappingFileRoute = router.getNamedRoute(IMPORT_CATEGORY_MAPPING_FILE_ROUTE);
        this.exportAllocatedItemsRoute = router.getNamedRoute(EXPORT_ALLOCATED_ITEMS_ROUTE);
        this.ingestBackupDataToBQRoute = router.getNamedRoute(INGEST_BACKUP_DATA_ROUTE);
        this.deleteOldPassengerFeedDataRoute = router.getNamedRoute(DELETE_OLD_PASSENGER_FEED_DATA_ROUTE);
        this.collatePassengerFeedDataRoute = router.getNamedRoute(COLLATE_PASSENGER_FEED_DATA_ROUTE);
        this.combineOperatorInfoDataRoute = router.getNamedRoute(COMBINE_OPERATOR_INFO_DATA_ROUTE);
        this.deleteAllocatedUnmatchedSKUItemsRoute = router.getNamedRoute(DELETE_ALLOCATED_UNMATCHED_SKU_ITEMS_ROUTE);
        this.importCategoryMappingSheetRoute = router.getNamedRoute(IMPORT_CATEGORY_MAPPING_SHEET_ROUTE);
        this.ingestShopOperatorTransactionsFileRoute = router.getNamedRoute(INGEST_SHOP_OPERATOR_TRANSACTIONS_FILE_ROUTE);
        this.fetchIndividualReceiptsFromOFDRoute = router.getNamedRoute(FETCH_INDIVIDUAL_RECEIPTS_FROM_OFD_ROUTE);
        this.ingestBatchForUnmatchedItemsRoute = router.getNamedRoute(INGEST_BATCH_FOR_UNMATCHED_ITEMS_ROUTE);
        this.reportPeriodDays = reportPeriodDays;
    }

    public void exportOFD(String batchId, String day, String periodLength) {
        Logger.info("Queuing exporting data from OFD - batch %s, day %s, period %s", batchId, day, periodLength);
        if (day == null) {
            LocalDate date = LocalDate.now(ZoneId.of("UTC"));
            day = date.format(TODAY_FORMAT);
        }
        if (periodLength == null) {
            periodLength = reportPeriodDays;
        }
        if (StringUtils.isEmpty(batchId)) {
            List<ShopOperator> activeShopOperators = shopOperatorService.getActiveShopOperators();
            for (ShopOperator shopOperator : activeShopOperators) {
                if (OFDProvider.UPLOAD != shopOperator.getOfdProvider()) {
                    scheduleShopOperatorBatch(null, day, periodLength, shopOperator.getId());
                }
            }
        } else {
            OFDBatch batch = ofdBatchService.find(batchId);
            TaskOptions taskOptions = TaskOptions.Builder.withUrl(exportOFDRoute.getRoute())
                .retryOptions(RetryOptions.Builder.withTaskRetryLimit(ONCE).minBackoffSeconds(ONE_HOUR));
            taskOptions = taskOptions
                .param("exportDay", day)
                .param("periodLength", periodLength)
                .param("shopOperatorId", batch.getShopOperator().getId())
                .param("batchId", batchId);
            queueTask(taskOptions, ofdQueue);
        }

    }

    public void checkReceiptsQueue(String batchId) {
        Logger.info("Checking individual receipts queue for batch %s", batchId);
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(checkReceiptsQueueRoute.getRoute())
            .countdownMillis(THIRTY_MINUTES_IN_MILLISECONDS)
            .retryOptions(RetryOptions.Builder
                .withTaskRetryLimit(5)
                .minBackoffSeconds(TEN_MINUTES_IN_SECONDS));
        taskOptions = taskOptions
            .param("batchId", batchId);
        queueTask(taskOptions, ofdQueue);
    }

    public void scheduleShopOperatorBatch(User user, String day, String periodLength, String shopOperatorId) {
        String username = null;
        if (user != null) {
            AppUser appUser = (AppUser) user;
            username = appUser.getEmail();
        } else {
            username = CRON_USERNAME;
        }
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(exportOFDRoute.getRoute())
            .retryOptions(RetryOptions.Builder
                .withDefaults()
                .minBackoffSeconds(TEN_MINUTES_IN_SECONDS));
        taskOptions = taskOptions
            .param("user", username)
            .param("exportDay", day)
            .param("periodLength", periodLength)
            .param("shopOperatorId", shopOperatorId);
        queueTask(taskOptions, ofdQueue);
    }

    public void ingestOFDBatch(String batchId) {

        TaskOptions taskOptions = TaskOptions.Builder.withUrl(ingestOFDRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY))
            .param("batchId", batchId);
        queueTask(taskOptions, bqQueue);
    }

    public void collateOFDTransactions(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(collateOFDTransactionsRoute.getRoute())
            .param("batchId", batchId)
            .countdownMillis(WAITING_PERIOD_BEFORE_COLLATION)
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void ingestFlatFileTransactions(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(ingestFlatFileTransactionsRoute.getRoute())
            .param("batchId", batchId)
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void combineCleanTransactions() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(combineCleanTransactionsRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void updateInsertionTime() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(updateInsertionTimeRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void findUnmatchedSKUs() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(findUnmatchedSKUsRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void deleteOldIndividualReceipts() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(deleteOldIndividualReceiptsRoute.getRoute());
        queueTask(taskOptions, ofdQueue);
    }

    public void downloadPassengerFeed(String feedDay) {
        if (feedDay == null) {
            LocalDate date = LocalDate.now(ZoneId.of("UTC"));
            feedDay = date.format(TODAY_FORMAT);
        }
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(downloadPassengerFeedRoute.getRoute())
            .param("feedDay", feedDay);
        queueTask(taskOptions, bqQueue);
    }

    public void preparePassengerFeed(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(preparePassengerFeedRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY))
            .param("batchId", batchId);
        queueTask(taskOptions, bqQueue);
    }

    public void exportCurrentCategoryMapping() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(exportCurrentCategoryMappingRoute.getRoute());
        queueTask(taskOptions, bqQueue);
    }

    public void deleteOldPassengerFeedData(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(deleteOldPassengerFeedDataRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY))
            .param("batchId", batchId);
        queueTask(taskOptions, bqQueue);
    }

    public void ingestPassengerFeedToBQ(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(ingestPassengerFeedRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY))
            .param("batchId", batchId);
        queueTask(taskOptions, bqQueue);
    }

    public void importCategoryMappingSheetIntoTable(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(importCategoryMappingSheetRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY))
            .param("batchId", batchId);
        queueTask(taskOptions, bqQueue);
    }

    public void importCategoryMappingFile(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(importCategoryMappingFileRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY))
            .param("batchId", batchId);
        queueTask(taskOptions, bqQueue);
    }

    public void fetchIndividualReceipts(String shopOperatorId, String batchId, String userInn, String kktRegNumber, String docRawId, String token) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(fetchIndividualReceiptsFromOFDRoute.getRoute())
            .param("shopOperatorId", shopOperatorId)
            .param("batchId", batchId)
            .param("userInn", userInn)
            .param("kktRegNumber", kktRegNumber)
            .param("docRawId", docRawId)
            .param("token", token)
            .countdownMillis(ONE_MINUTE);
        queueTask(taskOptions, receiptsQueue);
    }

    public void ingestBackupDataToBQ(String year, String month, String day) {
        LocalDate date = LocalDate.now(ZoneId.of("UTC"));
        if (StringUtils.isEmpty(year)) {
            year = String.valueOf(date.getYear());
        }
        if (StringUtils.isEmpty(month)) {
            month = String.format("%02d", date.getMonthValue());
        }
        if (StringUtils.isEmpty(day)) {
            day = year + month + String.format("%02d", date.getDayOfMonth());
        }

        TaskOptions taskOptions = TaskOptions.Builder.withUrl(ingestBackupDataToBQRoute.getRoute())
            .param("year", year)
            .param("month", month)
            .param("day", day);
        queueTask(taskOptions, bqQueue);
    }

    public void exportAllocatedItems() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(exportAllocatedItemsRoute.getRoute());
        queueTask(taskOptions, bqQueue);
    }

    public void collatePassengerFeedData(String batchId) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(collatePassengerFeedDataRoute.getRoute())
            .param("batchId", batchId)
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void combineOperatorInfoData() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(combineOperatorInfoDataRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void deleteAllocatedUnmatchedSKUItemsAfterIngestion() {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(deleteAllocatedUnmatchedSKUItemsRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, bqQueue);
    }

    public void ingestShopOperatorTransactionsFile(String batchId, String fileName) {
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(ingestShopOperatorTransactionsFileRoute.getRoute())
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY))
            .param("batchId", batchId)
            .param("fileName", fileName);
        queueTask(taskOptions, bqQueue);
    }

    public void queueAdminTask(String taskName, Map<String, String> params) {
        Logger.info("queueAdminTask");

        Route adminTaskRoute = router.getNamedRoute(String.format("admin.%s", taskName));
        TaskOptions taskOptions = TaskOptions.Builder.withUrl(adminTaskRoute.getRoute());
        if (params != null) {
            for (String key : params.keySet()) {
                taskOptions = taskOptions.param(key, params.get(key));
            }
        }

        queueTask(taskOptions, adminTaskQueue);
    }

    public void ingestBatchForUnmatchedItems(String batchId) {
        Logger.info("ingestBatchForUnmatchedItems for batch %s", batchId);

        TaskOptions taskOptions = TaskOptions.Builder.withUrl(ingestBatchForUnmatchedItemsRoute.getRoute())
            .param("batchId", batchId)
            .retryOptions(RetryOptions.Builder.withTaskRetryLimit(DO_NOT_RETRY));
        queueTask(taskOptions, unmatchedItemsIndexQueue);
    }

    private void queueTask(TaskOptions taskOptions, Queue queue) {
        TaskHandle taskHandle = queue.add(ofy().getTransaction(), taskOptions);
        Logger.info("queueTask task %s on queue %s", taskHandle.getName(), queue.getQueueName());
    }
}
