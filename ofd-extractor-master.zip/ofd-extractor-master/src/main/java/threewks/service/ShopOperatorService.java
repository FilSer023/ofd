package threewks.service;

import com.google.appengine.tools.cloudstorage.GcsFileOptions;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsOutputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.threewks.thundr.http.MultipartFile;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.joda.time.DateTime;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;
import threewks.model.TradePoint;
import threewks.model.dto.ShopOperatorDto;
import threewks.repository.ShopOperatorRepository;
import threewks.util.Assert;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.stream.Collectors;

import static com.googlecode.objectify.ObjectifyService.ofy;

public class ShopOperatorService {

    private static final String SYSTEM_USER = "Загрузка файла";
    private static final String ERROR_SAVING_MANUAL_TRANSACTIONS_FILE = "Ошибка сохранения файла экспорта транзакций";
    private final ShopOperatorRepository shopOperatorRepository;
    private final OFDBatchService ofdBatchService;
    private final GcsFileOptions gcsFileOptions = GcsFileOptions.getDefaultInstance();


    private final GcsService gcsService =
        GcsServiceFactory.createGcsService(
            new RetryParams.Builder()
                .initialRetryDelayMillis(10)
                .retryMaxAttempts(10)
                .totalRetryPeriodMillis(15000)
                .build());


    public ShopOperatorService(ShopOperatorRepository shopOperatorRepository, OFDBatchService ofdBatchService) {
        this.shopOperatorRepository = shopOperatorRepository;
        this.ofdBatchService = ofdBatchService;
    }

    public List<ShopOperator> getActiveShopOperators() {
        return shopOperatorRepository.listByStatus(ShopOperatorStatus.ACTIVE);
    }

    public List<ShopOperatorDto> list() {
        List<ShopOperator> operators = shopOperatorRepository.listAll();

        return operators
            .stream()
            .map(operator ->
                ShopOperatorDto.from(operator)
            )
            .collect(Collectors.toList());
    }

    public ShopOperator save(ShopOperator shopOperator) {
        return ofy().transact(() -> {
            if (ShopOperatorStatus.ARCHIVED == shopOperator.getStatus()) {
                shopOperator.getTradePoints().forEach(tradePoint -> tradePoint.setRentalAreaRef(null));
            }
            // created will be blank on initial save
            if (shopOperator.getCreated() == null) {
                shopOperator.setCreated(DateTime.now());
            }

            return shopOperatorRepository.put(shopOperator);
        });
    }

    public ShopOperator save(ShopOperatorDto shopOperatorDto) {
        ShopOperator shopOperator = new ShopOperator();
        copyFromDto(shopOperator, shopOperatorDto);
        return save(shopOperator);
    }

    public ShopOperator update(String shopOperatorId, ShopOperatorDto shopOperatorDto) {
        ShopOperator shopOperator = shopOperatorRepository.get(shopOperatorId);
        Assert.entityExists(shopOperator, ShopOperator.class, shopOperatorId);

        copyFromDto(shopOperator, shopOperatorDto);
        return save(shopOperator);
    }

    private ShopOperator copyFromDto(ShopOperator shopOperator, ShopOperatorDto shopOperatorDto) {
        shopOperator.setName(shopOperatorDto.getName());
        shopOperator.setStatus(shopOperatorDto.getStatus());
        shopOperator.setUploadKey(shopOperatorDto.getUploadKey());
        shopOperator.setInn(shopOperatorDto.getInn());
        shopOperator.setApiToken(shopOperatorDto.getApiToken());
        shopOperator.setOfdProvider(shopOperatorDto.getOfdProvider());
        shopOperator.setOfdUsername(shopOperatorDto.getOfdUsername());
        shopOperator.setOfdPassword(shopOperatorDto.getOfdPassword());
        shopOperator.setTradePoints(shopOperatorDto.getTradePoints().stream()
            .map(tradePointDto -> TradePoint.CONVERT.apply(tradePointDto)).collect(Collectors.toList()));

        return shopOperator;
    }

    public ShopOperator get(String shopOperatorId) {
        return shopOperatorRepository.get(shopOperatorId);
    }

    public OFDBatch uploadTransactionsFile(String shopOperatorId, String exportDay,
        MultipartFile transactionsFile, GcsFilename fileName) {
        ShopOperator shopOperator = shopOperatorRepository.get(shopOperatorId);
        OFDBatch batch = ofdBatchService.startBatch(shopOperator, exportDay, 1, SYSTEM_USER);

        try {
            GcsOutputChannel outputChannel = gcsService.createOrReplace(fileName, gcsFileOptions);
            outputChannel.write(ByteBuffer.wrap(transactionsFile.getData()));
            outputChannel.close();
        } catch (IOException e) {
            Logger.error(e, "Caught exception saving operator %s transaction file for day %s: %s",
                shopOperatorId, exportDay, e.getMessage());
            batch.getErrorMessages().add(ERROR_SAVING_MANUAL_TRANSACTIONS_FILE);
        } finally {
            Logger.info("Successfully saved transactions file to GCS: %s", fileName.getObjectName());
        }
        return batch;
    }


    public List<ShopOperator> listAvailableOperators() {
        List<ShopOperator> activeOperators = this.getActiveShopOperators();

        return activeOperators;
    }

    public boolean checkNameAvailability(String name) {
        List<ShopOperator> operators = shopOperatorRepository.listByName(name);
        return CollectionUtils.isEmpty(operators);
    }
}
