package threewks.service.bigquery;

import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.ListItem;
import com.google.appengine.tools.cloudstorage.ListOptions;
import com.google.appengine.tools.cloudstorage.ListResult;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryError;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FormatOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.LegacySQLTypeName;
import com.google.cloud.bigquery.LoadJobConfiguration;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.StandardTableDefinition;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableDefinition;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableInfo;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.threeten.bp.Duration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static threewks.service.bigquery.DataManagerService.INTERNAL_DATASET_ID;

public class BackupDataManager {

    private final BigQuery bigQuery;
    private final BQService bqService;
    private final GcsService gcsService =
        GcsServiceFactory.createGcsService(
            new RetryParams.Builder()
                .initialRetryDelayMillis(10)
                .retryMaxAttempts(10)
                .totalRetryPeriodMillis(15000)
                .build());
    private final String gcsBackupBucket;

    private static final String SHOP_OPERATORS_TABLE_NAME = "shop_operators";
    private static final String RENTAL_AREAS_TABLE_NAME = "rental_area";
    private static final String SUB_SECTION_CATEGORIES_TABLE_NAME = "subsection_category";
    private static final String BACKUP_PREFIX_FOR_DAY = "DataBackup/%s/%s/";
    private static final String GCS_LOCATION_FORMAT_SHOP_OPERATORS_KIND = "gs://%s/%sall_namespaces/kind_ShopOperator/all_namespaces_kind_ShopOperator.export_metadata";
    private static final String GCS_LOCATION_FORMAT_RENTAL_AREAS_KIND = "gs://%s/%sall_namespaces/kind_RentalArea/all_namespaces_kind_RentalArea.export_metadata";
    private static final String GCS_LOCATION_FORMAT_SUB_SECTION_CATEGORIES_KIND = "gs://%s/%sall_namespaces/kind_SubSectionCategory/all_namespaces_kind_SubSectionCategory.export_metadata";
    private static final String GCS_LOCATION_FORMAT_AIRPORT_CATALOG_KIND = "gs://%s/%sall_namespaces/kind_AirportCatalog/all_namespaces_kind_AirportCatalog.export_metadata";
    private static final String GCS_LOCATION_FORMAT_RECEIPT_DOCUMENT_KIND = "gs://%s/%sall_namespaces/kind_ReceiptDocument/all_namespaces_kind_ReceiptDocument.export_metadata";
    private static final String GCS_LOCATION_FORMAT_UNMATCHED_SKU_ITEM_KIND = "gs://%s/%sall_namespaces/kind_UnmatchedSKUItem/all_namespaces_kind_UnmatchedSKUItem.export_metadata";

    private static final String OPERATOR_INFO_TABLE_NAME = "operator_info";
    private static final String OPERATOR_ID_FIELD = "id";
    private static final String OPERATOR_NAME_FIELD = "operatorName";
    private static final String OPERATOR_INN_FIELD = "operatorInn";
    private static final String TRADE_POINT_NAME_FIELD = "tradePointName";
    private static final String AREA_NAME_FIELD = "areaName";
    private static final String FISCAL_DRIVE_NUMBER_FIELD = "fiscalDriveNumber";
    private static final String KKT_REG_ID_FIELD = "kktRegId";
    private static final String OFD_PROVIDER_FIELD = "ofdProvider";

    private static final String OPERATOR_CATEGORY_INFO_TABLE_NAME = "operator_category_info";
    private static final String AIRPORTS_TABLE_NAME = "airports";
    private static final String RECEIPT_DOCUMENTS_TABLE_NAME = "receiptDocuments";
    private static final String CATEGORY_NAME_FIELD = "categoryName";
    private static final String CATEGORY_SIZE_FIELD = "categorySize";

    private static final String RENTAL_AREAS_INFO_TABLE_NAME = "rental_area_info";
    private static final String RENTAL_AREA_NAME_FIELD = "name";
    private static final String RENTAL_AREA_SIZE_FIELD = "area";
    private static final String RENTAL_AREA_STATUS_FIELD = "status";
    private static final String RENTAL_AREA_ZONE_FIELD = "zone";
    private static final String RENTAL_AREA_AIRPORT_FIELD = "airport";
    private static final String RENTAL_AREA_GATES_FIELD = "gates";
    private static final String RENTAL_AREA_ID_FIELD = "id";

    private static final String UNMATCHED_SKU_ITEM_TABLE_NAME = "unmatched_sku_items";

    private static final String COMBINE_OPERATOR_INFO_DATA_QUERY = "select o.__key__.name as id, o.name, o.inn, tp.name as tpName, \n" +
        "tp.salesChannel.name as channelName, tp.rentalAreaRef.name as areaName,  kkt.fiscalDriveNumber, kkt.kktRegId, o.ofdProvider \n" +
        "from `internal.shop_operators` o, UNNEST(tradePoints) tp, UNNEST(tp.kktFiscalDrives) kkt";

    private static final String COMBINE_OPERATOR_CATEGORIES_QUERY = "select o.__key__.name as id, o.name, ss.name as categoryName," +
        " ca.areaSize/1000000 as categorySize from `internal.shop_operators` o, `internal.subsection_category` ss, UNNEST(tradePoints) tp, UNNEST(tp.categoryAreas) ca " +
        " WHERE ca.categoryRef.name = ss.__key__.name";

    private static final String COMBINE_RENTAL_AREA_INFO_QUERY = "select ra.name, ra.areaSize/1000000 as area, ra.status, ra.zone, a.nameIATA as airport, " +
        "        ARRAY_TO_STRING(ra.gates, \",\") as gates, ra.__key__.name as id from `internal.rental_area` ra, " +
        "        `internal.airports` a  WHERE ra.airportCatalog.name = a.__key__.name";

    public BackupDataManager(BigQuery bigQuery, BQService bqService, String gcsBackupBucket) {
        this.bigQuery = bigQuery;
        this.bqService = bqService;
        this.gcsBackupBucket = gcsBackupBucket;
    }

    public void createTablesFromBackup(String year, String month, String day) throws IOException {
        String todaysBackupDirectory = findTodaysBackupDirectory(year, month, day);
        if (StringUtils.isNotEmpty(todaysBackupDirectory)) {
            ingestShopOperatorsDataIntoStaging(todaysBackupDirectory);
            ingestRentalAreasDataIntoStaging(todaysBackupDirectory);
            ingestSubSectionCategoriesDataIntoStaging(todaysBackupDirectory);
            ingestAirportCatalogDataIntoStaging(todaysBackupDirectory);
            ingestUnmatchedSKUItemsIntoStaging(todaysBackupDirectory);
            ingestReceiptDocumentsDataIntoStaging(todaysBackupDirectory);
        } else {
            Logger.warn("Could not find directory with today's backup data - please investigate");
        }
    }

    private String findTodaysBackupDirectory(String year, String month, String day) throws IOException {
        String todaysBackup = null;
        String prefix = String.format(BACKUP_PREFIX_FOR_DAY, year, month);
        ListResult backups = gcsService.list(gcsBackupBucket,
            new ListOptions.Builder()
                .setPrefix(prefix)
                .setRecursive(false)
                .build());
        while (backups.hasNext()) {
            ListItem l = backups.next();
            if (l.getName().contains(day)) {
                todaysBackup = l.getName();
                Logger.warn("Backup for today: %s", todaysBackup);
                break;
            }
        }
        return todaysBackup;
    }

    private void ingestShopOperatorsDataIntoStaging(String todaysBackup) {
        TableId tableId = prepareTable(SHOP_OPERATORS_TABLE_NAME);
        List<String> shopOperatorsFileLocations = new ArrayList<>();
        shopOperatorsFileLocations.add(String.format(GCS_LOCATION_FORMAT_SHOP_OPERATORS_KIND, gcsBackupBucket, todaysBackup));
        importBackupIntoTable(tableId, shopOperatorsFileLocations, todaysBackup);
    }

    private void ingestRentalAreasDataIntoStaging(String todaysBackup) {
        TableId tableId = prepareTable(RENTAL_AREAS_TABLE_NAME);
        List<String> rentalAreasFileLocations = new ArrayList<>();
        rentalAreasFileLocations.add(String.format(GCS_LOCATION_FORMAT_RENTAL_AREAS_KIND, gcsBackupBucket, todaysBackup));
        importBackupIntoTable(tableId, rentalAreasFileLocations, todaysBackup);
    }

    private void ingestSubSectionCategoriesDataIntoStaging(String todaysBackup) {
        TableId tableId = prepareTable(SUB_SECTION_CATEGORIES_TABLE_NAME);
        List<String> subSectionCategoriesFileLocations = new ArrayList<>();
        subSectionCategoriesFileLocations.add(String.format(GCS_LOCATION_FORMAT_SUB_SECTION_CATEGORIES_KIND, gcsBackupBucket, todaysBackup));
        importBackupIntoTable(tableId, subSectionCategoriesFileLocations, todaysBackup);
    }

    private void ingestUnmatchedSKUItemsIntoStaging(String todaysBackup) {
        TableId tableId = prepareTable(UNMATCHED_SKU_ITEM_TABLE_NAME);
        List<String> unmatchedSkuItemFileLocations = new ArrayList<>();
        unmatchedSkuItemFileLocations.add(String.format(GCS_LOCATION_FORMAT_UNMATCHED_SKU_ITEM_KIND, gcsBackupBucket, todaysBackup));
        importBackupIntoTable(tableId, unmatchedSkuItemFileLocations, todaysBackup);
    }

    private void ingestAirportCatalogDataIntoStaging(String todaysBackup) {
        TableId tableId = prepareTable(AIRPORTS_TABLE_NAME);
        List<String> airportCatalogFileLocation = new ArrayList<>();
        airportCatalogFileLocation.add(String.format(GCS_LOCATION_FORMAT_AIRPORT_CATALOG_KIND, gcsBackupBucket, todaysBackup));
        importBackupIntoTable(tableId, airportCatalogFileLocation, todaysBackup);
    }

    private void ingestReceiptDocumentsDataIntoStaging(String todaysBackup) {
        TableId tableId = prepareTable(RECEIPT_DOCUMENTS_TABLE_NAME);
        List<String> receiptDocumentsFileLocation = new ArrayList<>();
        receiptDocumentsFileLocation.add(String.format(GCS_LOCATION_FORMAT_RECEIPT_DOCUMENT_KIND, gcsBackupBucket, todaysBackup));
        importBackupIntoTable(tableId, receiptDocumentsFileLocation, todaysBackup);
    }

    private void importBackupIntoTable(TableId tableId, List<String> dataFileLocations, String todaysBackupDirectory) {
        LoadJobConfiguration loadJobConfiguration = LoadJobConfiguration.newBuilder(tableId,
            dataFileLocations)
            .setFormatOptions(FormatOptions.datastoreBackup())
            .setAutodetect(true)
            .setDestinationTable(tableId)
            .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
            .setCreateDisposition(JobInfo.CreateDisposition.CREATE_IF_NEEDED)
            .build();

        Logger.info("LoadJobConfiguration for %s: %s", tableId.getTable(), loadJobConfiguration);

        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(loadJobConfiguration).setJobId(jobId).build());
        Logger.info("Product ingestion job for %s %s has been scheduled, job ID: %s, isDone: %s", tableId.getTable(),
            todaysBackupDirectory, jobId.getJob(), queryJob.isDone());
        //Use this for debugging importing issues (schema etc)
        Job completed = null;
        try {
            completed = queryJob.waitFor(RetryOption.maxRetryDelay(Duration.ofMinutes(3)));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        List<BigQueryError> importErrors = completed.getStatus().getExecutionErrors();
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.info("Ingestion job encountered errors: %s", completed.getStatus().getExecutionErrors());
            for (BigQueryError error : completed.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
            }
        }
    }


    private TableId prepareTable(String tableName) {
        TableId tableId = TableId.of(DataManagerService.PROJECT_ID, DataManagerService.INTERNAL_DATASET_ID, tableName);

        Table existing = bigQuery.getTable(tableId, BigQuery.TableOption.fields(BigQuery.TableField.ID));
        if (existing == null || !existing.exists()) {
            TableDefinition tableDefinition = StandardTableDefinition.newBuilder().build();
            TableInfo tableInfo = TableInfo.newBuilder(tableId, tableDefinition).build();

            Table table = bigQuery.create(tableInfo);
            Logger.info("Table created: %s", table.getTableId().getTable());
        } else {
            Logger.info("Table already exists: %s", tableId);
        }
        return tableId;
    }


    public void createOperatorTables() {
        bqService.createTableFromQuery(INTERNAL_DATASET_ID, OPERATOR_INFO_TABLE_NAME, buildOperatorInfoSchema(), COMBINE_OPERATOR_INFO_DATA_QUERY);
        bqService.createTableFromQuery(INTERNAL_DATASET_ID, OPERATOR_CATEGORY_INFO_TABLE_NAME, buildOperatorCategoriesSchema(), COMBINE_OPERATOR_CATEGORIES_QUERY);
        bqService.createTableFromQuery(INTERNAL_DATASET_ID, RENTAL_AREAS_INFO_TABLE_NAME, buildRentalAreaInfoCategoriesSchema(), COMBINE_RENTAL_AREA_INFO_QUERY);
    }

    private Schema buildOperatorInfoSchema() {
        Field operatorIdField = Field.newBuilder(OPERATOR_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorNameField = Field.newBuilder(OPERATOR_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorInnField = Field.newBuilder(OPERATOR_INN_FIELD, LegacySQLTypeName.STRING).build();
        Field tradePointNameField = Field.newBuilder(TRADE_POINT_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field areaNameField = Field.newBuilder(AREA_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field fiscalDriveNumberField = Field.newBuilder(FISCAL_DRIVE_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field kktRegIdField = Field.newBuilder(KKT_REG_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field ofdProviderField = Field.newBuilder(OFD_PROVIDER_FIELD, LegacySQLTypeName.STRING).build();

        return Schema.of(operatorIdField, operatorNameField, operatorInnField, tradePointNameField, areaNameField, fiscalDriveNumberField,
            kktRegIdField, ofdProviderField);
    }

    private Schema buildOperatorCategoriesSchema() {
        Field operatorIdField = Field.newBuilder(OPERATOR_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorNameField = Field.newBuilder(OPERATOR_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field categoryNameField = Field.newBuilder(CATEGORY_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field categorySizeField = Field.newBuilder(CATEGORY_SIZE_FIELD, LegacySQLTypeName.FLOAT).build();

        return Schema.of(operatorIdField, operatorNameField, categoryNameField, categorySizeField);
    }

    private Schema buildRentalAreaInfoCategoriesSchema() {
        Field rentalAreaNameField = Field.newBuilder(RENTAL_AREA_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field rentalAreaSizeField = Field.newBuilder(RENTAL_AREA_SIZE_FIELD, LegacySQLTypeName.NUMERIC).build();
        Field rentalAreaStatusField = Field.newBuilder(RENTAL_AREA_STATUS_FIELD, LegacySQLTypeName.STRING).build();
        Field rentalAreaZoneField = Field.newBuilder(RENTAL_AREA_ZONE_FIELD, LegacySQLTypeName.STRING).build();
        Field rentalAreaAirportIdField = Field.newBuilder(RENTAL_AREA_AIRPORT_FIELD, LegacySQLTypeName.STRING).build();
        Field rentalAreaGatesField = Field.newBuilder(RENTAL_AREA_GATES_FIELD, LegacySQLTypeName.STRING).build();
        Field rentalAreaIdField = Field.newBuilder(RENTAL_AREA_ID_FIELD, LegacySQLTypeName.FLOAT).build();
        return Schema.of(rentalAreaNameField, rentalAreaSizeField, rentalAreaStatusField,
            rentalAreaZoneField, rentalAreaAirportIdField, rentalAreaGatesField, rentalAreaIdField);
    }

}
