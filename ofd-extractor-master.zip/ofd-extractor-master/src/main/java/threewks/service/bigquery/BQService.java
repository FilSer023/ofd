package threewks.service.bigquery;

import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryError;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.StandardTableDefinition;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableDefinition;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableInfo;
import com.google.cloud.bigquery.TableResult;
import com.google.cloud.bigquery.TimePartitioning;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;

import java.util.List;
import java.util.UUID;

public class BQService {

    private final BigQuery bigQuery;

    public BQService(BigQuery bigQuery) {
        this.bigQuery = bigQuery;
    }

    public TableId createTableIfNeeded(String datasetName, String tableName, Schema tableSchema) {
        TableId tableId = TableId.of(DataManagerService.PROJECT_ID, datasetName, tableName);

        Table existing = bigQuery.getTable(tableId, BigQuery.TableOption.fields(BigQuery.TableField.ID));
        if (existing == null || !existing.exists()) {
            TableDefinition tableDefinition = StandardTableDefinition.newBuilder()
                .setSchema(tableSchema)
                .setTimePartitioning(TimePartitioning.of(TimePartitioning.Type.DAY))
                .build();
            TableInfo tableInfo = TableInfo.newBuilder(tableId, tableDefinition).build();

            Table transactionsTable = bigQuery.create(tableInfo);
            Logger.info("Table created: %s", transactionsTable.getTableId().getTable());
        }
        return tableId;
    }

    public TableResult runQueryJob(String query) throws InterruptedException {
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration
            .newBuilder(query)
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());

        Logger.info("BQ job has been created, job ID %s", jobId);

        queryJob = queryJob.waitFor();

        logBigQueryJobStatus(queryJob);
        return queryJob.getQueryResults();
    }

    public static void logBigQueryJobStatus(Job queryJob) {
        if (queryJob == null) {
            Logger.warn("Job %s has been terminated, please check BQ logs", queryJob.getJobId());
            throw new RuntimeException("Job no longer exists");
        } else {
            if (queryJob.getStatus().getError() != null) {
                Logger.warn("Errors found in job %s, please check BQ logs for details: %s",
                    queryJob.getJobId(), queryJob.getStatus().getError().toString());
                throw new RuntimeException(queryJob.getStatus().getError().toString());
            } else {
                Logger.info("Job %s executed without errors", queryJob.getJobId());
            }
        }
    }

    public void createTableFromQuery(String datasetName, String tableName, Schema tableSchema, String query) {
        TableId tableId = createTableIfNeeded(datasetName, tableName, tableSchema);
        Logger.info("Starting createTableFromQuery for table %s, query %s", tableName, query);
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration
            .newBuilder(query)
            .setDestinationTable(tableId)
            .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());
        Logger.info("BQ job for createTableFromQuery has been created, job ID %s", jobId);

        try {
            queryJob = queryJob.waitFor();
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while creating table from query: ", e);
            e.printStackTrace();
        }

        logBigQueryJobStatus(queryJob);
        List<BigQueryError> importErrors = queryJob.getStatus().getExecutionErrors();
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.warn("Creating table from query data job encountered errors: %s", queryJob.getStatus().getExecutionErrors());
            for (BigQueryError error : queryJob.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
            }
        } else {
            Logger.info("Table successfully created from query");
        }
    }

}
