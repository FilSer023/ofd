package threewks.service.bigquery;

import com.google.api.gax.paging.Page;
import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryError;
import com.google.cloud.bigquery.CopyJobConfiguration;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FormatOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.LegacySQLTypeName;
import com.google.cloud.bigquery.LoadJobConfiguration;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.CopyWriter;
import com.google.cloud.storage.Storage;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.threeten.bp.Duration;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.service.OFDBatchService;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static threewks.service.bigquery.BQService.logBigQueryJobStatus;
import static threewks.service.bigquery.DataManagerService.OFD_DATASET_ID;

public class TransactionDataManager {

    private static final String ERROR_IMPORTING_CLEAN_TRANSACTIONS = "Ошибка импорта транзакций в чистую зону";
    private static final String ERROR_IMPORTING_STAGING_TRANSACTIONS = "Файл выгрузки транзакций отстуствует или содержит ошибки, импорт во временную зону не произведен";
    private static final String CLEAN_TRANSACTIONS_INSERTED_MESSAGE = "Транзакции перенесены из временной зоны в чистую зону";
    private static final String BIG_QUERY_MESSAGE_DETAILS = "Ошибка импорта BigQuery: %s %s";
    private static final Integer ZERO_RECEIPTS_RETRIEVED = 0;
    private static final int NO_FILES_TO_INGEST = 0;

    private final TaskService taskService;
    private final BigQuery bigQuery;
    private final BQService bqService;
    private final OFDBatchService ofdBatchService;
    private final ShopOperatorService shopOperatorService;
    private final String gcsDefaultBucket;
    private final Storage storage;

    private static final String TRANSACTIONS_CLEAN_TABLE_NAME_PER_OPERATOR = "transactions_clean_%s";
    private static final String TRANSACTIONS_STAGING_TABLE_NAME_PER_OPERATOR = "transactions_staging_%s";
    private static final String TRANSACTIONS_FLATFILE_TABLE_NAME_PER_OPERATOR = "transactions_flatfile_%s";
    private static final String COMBINED_TABLE_NAME = "transactions_combined";
    private static final String NEW_TRANSACTIONS_PREFIX = "ofd/transactions/new/%s";
    private static final String TEMP_TRANSACTIONS_PREFIX = "ofd/transactions/temp/%s";
    private static final String PROCESSED_TRANSACTIONS_PREFIX = "ofd/transactions/processed/%s";
    private static final String GCS_LOCATION_FORMAT_TRANSACTIONS_TEMP = "gs://%s/ofd/transactions/temp/%s/*";
    private static final String GCS_LOCATION_FORMAT_MANUAL_UPLOAD_TRANSACTIONS = "gs://%s/%s";
    private static final String INSERT_FLATFILE_TRANSACTIONS = "INSERT INTO " +
        "  `ofddata.transactions_clean_%s` (" +
        "    code, user, userInn, requestNumber, dateTime, shiftNumber, operator, kktRegId, retailAddress, nds0, " +
        "    ndsNo, nds10110, nds10, nds18118, sum, name, price, quantity, totalSum, cashTotalSum, ecashTotalSum, " +
        "    totalnds18118, fiscalDocumentNumber, fiscalDriveNumber, fiscalSign, totalnds10110, totalnds10, totalnds0, " +
        "    taxationType, operationType, shopOperatorName, ofdName, batchId) " +
        " SELECT " +
        "    NULL, NULL, NULL, receiptId, dateTime, NULL, NULL, NULL, NULL, NULL, " +
        "    NULL, NULL, NULL, NULL, lineItemTotalAfterDiscount, itemName, unitPrice, unitQuantity, lineItemTotal, lineItemTotal, NULL, " +
        "    NULL, NULL, NULL, NULL, NULL, NULL, NULL, " +
        "    NULL, operationType, '%s', 'DIRECT', '%s' " +
        " FROM " +
        "  `ofddata.transactions_flatfile_%s` t ";

    private static final String MERGE_INTO_CLEAN_TRANSACTIONS = "MERGE INTO `ofddata.transactions_clean_%s` c " +
        "USING (SELECT DISTINCT" +
        "  code, " +
        "  user, " +
        "  userInn, " +
        "  requestNumber, " +
        "  dateTime, " +
        "  shiftNumber, " +
        "  operator, " +
        "  kktRegId, " +
        "  retailAddress, " +
        "  items.nds0 AS nds0, " +
        "  items.ndsNo AS ndsNo, " +
        "  items.nds10110 AS nds10110, " +
        "  items.nds10 AS nds10, " +
        "  items.nds18118 AS nds18118, " +
        "  items.sum AS sum, " +
        "  items.name AS name, " +
        "  items.price AS price, " +
        "  items.quantity AS quantity, " +
        "  totalSum, " +
        "  cashTotalSum, " +
        "  ecashTotalSum, " +
        "  t.nds18118 AS totalnds18118, " +
        "  fiscalDocumentNumber, " +
        "  fiscalDriveNumber, " +
        "  fiscalSign, " +
        "  t.nds10110 AS totalnds10110, " +
        "  t.nds10 AS totalnds10, " +
        "  t.nds0 AS totalnds0, " +
        "  taxationType, " +
        "  operationType, " +
        "  shopOperatorName, " +
        "  ofdName, " +
        "  batchId, " +
        "  itemPos " +
        " FROM " +
        " `ofddata.transactions_staging_%s` t, " +
        " UNNEST(items) AS items WITH OFFSET AS itemPos )" +
        " NEW1 ON (c.fiscalSign = NEW1.fiscalSign AND c.dateTime = NEW1.dateTime) " +
        "WHEN NOT MATCHED THEN INSERT (code, " +
        "    user, " +
        "    userInn, " +
        "    requestNumber, " +
        "    dateTime, " +
        "    shiftNumber, " +
        "    operator, " +
        "    kktRegId, " +
        "    retailAddress, " +
        "    nds0, " +
        "    ndsNo, " +
        "    nds10110, " +
        "    nds10, " +
        "    nds18118, " +
        "    sum, " +
        "    name, " +
        "    price, " +
        "    quantity, " +
        "    totalSum, " +
        "    cashTotalSum, " +
        "    ecashTotalSum, " +
        "    totalnds18118, " +
        "    fiscalDocumentNumber, " +
        "    fiscalDriveNumber, " +
        "    fiscalSign, " +
        "    totalnds10110, " +
        "    totalnds10, " +
        "    totalnds0, " +
        "    taxationType, " +
        "    operationType, " +
        "    shopOperatorName, " +
        "    ofdName,    batchId, " +
        "     itemPos) VALUES (NEW1.code, " +
        "NEW1.user, " +
        "NEW1.userInn, " +
        "NEW1.requestNumber, " +
        "NEW1.dateTime, " +
        "NEW1.shiftNumber, " +
        "NEW1.operator, " +
        "NEW1.kktRegId, " +
        "NEW1.retailAddress, " +
        "NEW1.nds0, " +
        "NEW1.ndsNo, " +
        "NEW1.nds10110, " +
        "NEW1.nds10, " +
        "NEW1.nds18118, " +
        "NEW1.sum, " +
        "NEW1.name, " +
        "NEW1.price, " +
        "NEW1.quantity, " +
        "NEW1.totalSum, " +
        "NEW1.cashTotalSum, " +
        "NEW1.ecashTotalSum, " +
        "NEW1.totalnds18118, " +
        "NEW1.fiscalDocumentNumber, " +
        "NEW1.fiscalDriveNumber, " +
        "NEW1.fiscalSign, " +
        "NEW1.totalnds10110, " +
        "NEW1.totalnds10, " +
        "NEW1.totalnds0, " +
        "NEW1.taxationType, " +
        "NEW1.operationType, " +
        "NEW1.shopOperatorName, " +
        "NEW1.ofdName, " +
        "NEW1.batchId, " +
        "NEW1.itemPos)";
    private static final String UPDATE_INSERTION_TIME_FOR_CLEAN_TRANSACTIONS =
        "UPDATE `ofddata.transactions_combined` SET insertionTs = _PARTITIONTIME WHERE insertionTs IS NULL";

    private static final String FISCAL_SIGN_FIELD = "fiscalSign";
    private static final String DATETIME_FIELD = "dateTime";
    private static final String FISCAL_DRIVE_NUMBER_FIELD = "fiscalDriveNumber";
    private static final String FISCAL_DOCUMENT_NUMBER_FIELD = "fiscalDocumentNumber";
    private static final String NDS18118_FIELD = "nds18118";
    private static final String NDS18_FIELD = "nds18";
    private static final String NDS10110_FIELD = "nds10110";
    private static final String NDS10_FIELD = "nds10";
    private static final String NDS0_FIELD = "nds0";
    private static final String NDS_NO_FIELD = "ndsNo";
    private static final String SUM_FIELD = "sum";
    private static final String NDS_SUM_FIELD = "ndsSum";
    private static final String NAME_FIELD = "name";
    private static final String PRICE_FIELD = "price";
    private static final String QUANTITY_FIELD = "quantity";
    private static final String TOTAL_NDS0_FIELD = "totalNds0";
    private static final String TOTAL_NDS10_FIELD = "totalNds10";
    private static final String TOTAL_NDS10110_FIELD = "totalNds10110";
    private static final String TOTAL_NDS18118_FIELD = "totalNds18118";
    private static final String OPERATION_TYPE_FIELD = "operationType";
    private static final String TAXATION_TYPE_FIELD = "taxationType";
    private static final String SHOP_OPERATOR_NAME_FIELD = "shopOperatorName";
    private static final String OFD_NAME_FIELD = "ofdName";
    private static final String BATCH_ID_FIELD = "batchId";
    private static final String CASH_TOTAL_SUM_FIELD = "cashTotalSum";
    private static final String ECASH_TOTAL_SUM_FIELD = "ecashTotalSum";
    private static final String TOTAL_SUM_FIELD = "totalSum";
    private static final String CREDIT_SUM_FIELD = "creditSum";
    private static final String PREPAID_SUM_FIELD = "prepaidSum";
    private static final String PROVISION_SUM_FIELD = "provisionSum";
    private static final String RETAIL_ADDRESS_FIELD = "retailAddress";
    private static final String USER_INN_FIELD = "userInn";
    private static final String USER_FIELD = "user";
    private static final String OPERATOR_FIELD = "operator";
    private static final String SHIFT_NUMBER_FIELD = "shiftNumber";
    private static final String REQUEST_NUMBER_FIELD = "requestNumber";
    private static final String KKT_REG_ID_FIELD = "kktRegId";
    private static final String CODE_FIELD = "code";
    private static final String ITEMS_FIELD = "items";
    private static final String ITEM_POS_FIELD = "itemPos";
    private static final String INSERTION_TS_FIELD = "insertionTs";

    // Flat file fields
    private static final String OPERATOR_ID_FIELD = "operatorId";
    private static final String OPERATOR_NAME_FIELD = "operatorName";
    private static final String TERMINAL_ID_FIELD = "terminalId";
    private static final String RECEIPT_ID_FIELD = "receiptId";
    private static final String RECEIPT_TOTAL_FIELD = "receiptTotal";
    private static final String RECEIPT_TOTAL_AFTER_DISCOUNT_FIELD = "receiptTotalAfterDiscount";
    private static final String RECEIPT_ITEM_POSITION_FIELD = "positionNumber";
    private static final String ITEM_SKU_FIELD = "itemSKU";
    private static final String ITEM_NAME_FIELD = "itemName";
    private static final String PAYMENT_TYPE_FIELD = "paymentType";
    private static final String UNIT_PRICE_FIELD = "unitPrice";
    private static final String UNIT_QUANTITY_FIELD = "unitQuantity";
    private static final String UOM_FIELD = "uom";
    private static final String LINE_ITEM_TOTAL_FIELD = "lineItemTotal";
    private static final String LINE_ITEM_TOTAL_AFTER_DISCOUNT_FIELD = "lineItemTotalAfterDiscount";

    public TransactionDataManager(TaskService taskService, BigQuery bigQuery, Storage storage, BQService bqService, OFDBatchService ofdBatchService, ShopOperatorService shopOperatorService,
        String gcsDefaultBucket) {
        this.taskService = taskService;
        this.bigQuery = bigQuery;
        this.bqService = bqService;
        this.ofdBatchService = ofdBatchService;
        this.shopOperatorService = shopOperatorService;
        this.gcsDefaultBucket = gcsDefaultBucket;
        this.storage = storage;
    }

    void ingestTransactionsDataIntoStaging(String batchId) {
        OFDBatch ofdBatch = ofdBatchService.find(batchId);
        int filesToIngest = checkAvailableForIngestionFiles(ofdBatch.getShopOperator().getId());
        Logger.info("ingestTransactionsDataIntoStaging - сеанс %s, файлов для импорта: %s", batchId, filesToIngest);
        if (filesToIngest == NO_FILES_TO_INGEST) {
            Logger.info("Нет данных для импорта - возможно транзакции отсутствуют");
            ofdBatch.getErrorMessages().add("Нет данных для импорта - возможно транзакции отсутствуют");
            ofdBatch.setStatus(BatchStatus.NO_TRANSACTIONS_FOUND);
        } else {
            Logger.info("Запускается импорт данных для сеанса %s для арендатора %s во временную область", batchId, ofdBatch.getShopOperator().getName());
            TableId operatorTableId = bqService.createTableIfNeeded(OFD_DATASET_ID, String.format(TRANSACTIONS_STAGING_TABLE_NAME_PER_OPERATOR, ofdBatch.getShopOperator().getId()),
                stagingSchema());
            List<String> transactionFileLocations = new ArrayList<>();
            transactionFileLocations.add(String.format(GCS_LOCATION_FORMAT_TRANSACTIONS_TEMP, gcsDefaultBucket, ofdBatch.getShopOperator().getId()));

            LoadJobConfiguration loadJobConfiguration = LoadJobConfiguration.newBuilder(operatorTableId,
                transactionFileLocations)
                .setFormatOptions(FormatOptions.json())
                .setSchema(stagingSchema())
                .setDestinationTable(operatorTableId)
                .setMaxBadRecords(100)
                .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
                .setCreateDisposition(JobInfo.CreateDisposition.CREATE_IF_NEEDED)
                .build();

            Logger.info("LoadJobConfiguration for transactions: %s", loadJobConfiguration);

            JobId jobId = JobId.of(UUID.randomUUID().toString());
            Job queryJob = bigQuery.create(JobInfo.newBuilder(loadJobConfiguration).setJobId(jobId).build());
            Logger.info("Product ingestion job for OFD batch %s has been scheduled, job ID: %s, isDone: %s",
                batchId, jobId.getJob(), queryJob.isDone());
            //Use this for debugging importing issues (schema etc)
            Job completed = null;
            try {
                completed = queryJob.waitFor(RetryOption.maxRetryDelay(Duration.ofMinutes(3)));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            List<BigQueryError> importErrors = completed.getStatus().getExecutionErrors();
            processBigQueryExecutionErrorsForStagingImport(ofdBatch, completed, importErrors);
            taskService.collateOFDTransactions(batchId);
        }
        ofdBatchService.save(ofdBatch);
    }

    public void collateOFDTransactions(String batchId) {
        Logger.info("Starting collateOFDTransactions for batch %s", batchId);
        OFDBatch batch = ofdBatchService.find(batchId);
        if (BatchStatus.DATA_IMPORTED_INTO_STAGING != batch.getStatus()) {
            Logger.warn("Was attempting to ingest staging transactions but batch %s was not ready", batchId);
            batch.getErrorMessages().add(ERROR_IMPORTING_CLEAN_TRANSACTIONS);
            ofdBatchService.save(batch);
            return;
        }
        String tableSuffix = batch.getShopOperator().getId();
        bqService.createTableIfNeeded(OFD_DATASET_ID, String.format(TRANSACTIONS_CLEAN_TABLE_NAME_PER_OPERATOR, tableSuffix), cleanSchema());
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration
            .newBuilder(String.format(MERGE_INTO_CLEAN_TRANSACTIONS, tableSuffix, tableSuffix))
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());
        Logger.info("BQ job for inserting from Transactions_Staging has been created, job ID %s", jobId);

        try {
            queryJob = queryJob.waitFor();
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while importing staging transactions: ", e);
            e.printStackTrace();
        }

        logBigQueryJobStatus(queryJob);
        List<BigQueryError> importErrors = queryJob.getStatus().getExecutionErrors();
        processBigQueryExecutionErrorsForCleanImport(batch, queryJob, importErrors);
        ofdBatchService.save(batch);
    }

    public void combineCleanTransactions() {
        List<ShopOperator> operators = shopOperatorService.getActiveShopOperators();
        List<String> suffixes = operators.stream().map(shopOperator -> shopOperator.getId()).collect(Collectors.toList());
        List<TableId> operatorTables = suffixes.stream()
            .map(suffix -> bqService.createTableIfNeeded(OFD_DATASET_ID, String.format(TRANSACTIONS_CLEAN_TABLE_NAME_PER_OPERATOR, suffix), cleanSchema()))
            .collect(Collectors.toList());
        TableId combinedTable = bqService.createTableIfNeeded(OFD_DATASET_ID, COMBINED_TABLE_NAME, cleanSchema());

        CopyJobConfiguration copyJobConfiguration = CopyJobConfiguration.newBuilder(combinedTable, operatorTables)
            .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(copyJobConfiguration).setJobId(jobId).build());
        Logger.info("BQ job for combining operator clean transactions has been created, job ID %s", jobId);

        try {
            queryJob = queryJob.waitFor();
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while combining clean transactions: ", e);
            e.printStackTrace();
        }

        logBigQueryJobStatus(queryJob);
    }

    public void updateInsertionTime() {
        try {
            bqService.runQueryJob(UPDATE_INSERTION_TIME_FOR_CLEAN_TRANSACTIONS);
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while updating insertion timestamp for clean transactions: %s, %s", e, e.getMessage());
        }
    }

    public void ingestShopOperatorTransactionsFile(String batchId, String fileName) {
        OFDBatch ofdBatch = ofdBatchService.find(batchId);
        TableId operatorTableId = bqService.createTableIfNeeded(OFD_DATASET_ID, String.format(TRANSACTIONS_FLATFILE_TABLE_NAME_PER_OPERATOR, ofdBatch.getShopOperator().getId()),
            flatFileSchema());

        List<String> transactionFileLocations = new ArrayList<>();
        transactionFileLocations.add(String.format(GCS_LOCATION_FORMAT_MANUAL_UPLOAD_TRANSACTIONS, gcsDefaultBucket, fileName));

        LoadJobConfiguration loadJobConfiguration = LoadJobConfiguration.newBuilder(operatorTableId,
            transactionFileLocations)
            .setFormatOptions(FormatOptions.csv())
            .setSchema(flatFileSchema())
            .setDestinationTable(operatorTableId)
            .setMaxBadRecords(100)
            .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
            .setCreateDisposition(JobInfo.CreateDisposition.CREATE_IF_NEEDED)
            .build();

        Logger.info("LoadJobConfiguration for manual upload transactions: %s", loadJobConfiguration);

        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(loadJobConfiguration).setJobId(jobId).build());
        Logger.info("Manual transaction ingestion job for OFD batch %s has been scheduled, job ID: %s, isDone: %s",
            batchId, jobId.getJob(), queryJob.isDone());
        //Use this for debugging importing issues (schema etc)
        Job completed = null;
        try {
            completed = queryJob.waitFor(RetryOption.maxRetryDelay(Duration.ofMinutes(3)));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        List<BigQueryError> importErrors = completed.getStatus().getExecutionErrors();
        processBigQueryExecutionErrorsForStagingImport(ofdBatch, completed, importErrors);
        ofdBatchService.save(ofdBatch);
        taskService.ingestFlatFileTransactions(batchId);
    }

    public void ingestFlatFileTransactionsIntoClean(String batchId) {
        Logger.info("Starting ingestFlatFileTransactionsIntoClean for batch %s", batchId);
        OFDBatch batch = ofdBatchService.find(batchId);
        String tableSuffix = batch.getShopOperator().getId();
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration
            .newBuilder(String.format(INSERT_FLATFILE_TRANSACTIONS, tableSuffix, batch.getShopOperator().getName(), batchId, tableSuffix))
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());
        Logger.info("BQ job for inserting from flat file table has been created, job ID %s", jobId);

        try {
            queryJob = queryJob.waitFor();
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while importing flat file transactions: ", e);
            e.printStackTrace();
        }

        logBigQueryJobStatus(queryJob);
        List<BigQueryError> importErrors = queryJob.getStatus().getExecutionErrors();
        processBigQueryExecutionErrorsForCleanImport(batch, queryJob, importErrors);
        ofdBatchService.save(batch);
    }

    private void processBigQueryExecutionErrorsForCleanImport(OFDBatch batch, Job queryJob, List<BigQueryError> importErrors) {
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.info("Inserting clean data job encountered errors: %s", queryJob.getStatus().getExecutionErrors());
            for (BigQueryError error : queryJob.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
            }
            batch.getErrorMessages().add(ERROR_IMPORTING_CLEAN_TRANSACTIONS);
        } else {
            batch.getInfoMessages().add(String.format(CLEAN_TRANSACTIONS_INSERTED_MESSAGE));
            batch.setStatus(BatchStatus.DATA_IMPORTED_INTO_CLEAN);
        }
    }

    private void processBigQueryExecutionErrorsForStagingImport(OFDBatch ofdBatch, Job completed, List<BigQueryError> importErrors) {
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.info("Ingestion job encountered errors: %s", completed.getStatus().getExecutionErrors());
            for (BigQueryError error : completed.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
                ofdBatch.getErrorMessages().add(String.format(BIG_QUERY_MESSAGE_DETAILS, error.getMessage(), error.getLocation()));
            }
            ofdBatch.getErrorMessages().add(ERROR_IMPORTING_STAGING_TRANSACTIONS);
        } else {
            ofdBatch.setStatus(BatchStatus.DATA_IMPORTED_INTO_STAGING);
            moveProcessedTransactionFiles(ofdBatch.getShopOperator().getId());
            Logger.info("Files for operator %s have been moved to processed folder", ofdBatch.getShopOperator().getId());
        }
    }

    private int checkAvailableForIngestionFiles(String shopOperatorId) {
        String tempTransactionsPrefix = String.format(TEMP_TRANSACTIONS_PREFIX, shopOperatorId);
        Page<Blob> availableFiles = storage.list(gcsDefaultBucket,
            Storage.BlobListOption.prefix(tempTransactionsPrefix));
        int filesAvailable = 0;
        for (Blob blob : availableFiles.iterateAll()) {
            filesAvailable++;
        }
        return filesAvailable;
    }

    private void moveProcessedTransactionFiles(String shopOperatorId) {
        String tempTransactionsPrefix = String.format(TEMP_TRANSACTIONS_PREFIX, shopOperatorId);
        String processedTransactionsPrefix = String.format(PROCESSED_TRANSACTIONS_PREFIX, shopOperatorId);
        moveFilesToFolder(tempTransactionsPrefix, processedTransactionsPrefix);
    }

    private int moveFilesToFolder(String from, String tempTransactionsPrefix) {
        Logger.info("Moving files with prefix %s", from);
        Page<Blob> newTransactionFiles = storage.list(gcsDefaultBucket,
            Storage.BlobListOption.prefix(from));
        int filesMoved = 0;
        for (Blob blob : newTransactionFiles.iterateAll()) {
            CopyWriter copyWriter = blob.copyTo(gcsDefaultBucket, blob.getName().replace(from, tempTransactionsPrefix));
            Blob copiedBlob = copyWriter.getResult();
            blob.delete();
            filesMoved++;
        }
        return filesMoved;
    }

    private Schema stagingSchema() {
        Field fiscalSignField = Field.newBuilder(FISCAL_SIGN_FIELD, LegacySQLTypeName.STRING).build();
        Field dateTimeField = Field.newBuilder(DATETIME_FIELD, LegacySQLTypeName.TIMESTAMP).build();
        Field fiscalDriveNumberField = Field.newBuilder(FISCAL_DRIVE_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field fiscalDocumentNumberField = Field.newBuilder(FISCAL_DOCUMENT_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field nds18118Field = Field.newBuilder(NDS18118_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nds18Field = Field.newBuilder(NDS18_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nds10110Field = Field.newBuilder(NDS10110_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nds10Field = Field.newBuilder(NDS10_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nds0Field = Field.newBuilder(NDS0_FIELD, LegacySQLTypeName.INTEGER).build();
        Field cashTotalSumField = Field.newBuilder(CASH_TOTAL_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field codeField = Field.newBuilder(CODE_FIELD, LegacySQLTypeName.STRING).build();
        Field ecashTotalSumField = Field.newBuilder(ECASH_TOTAL_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field retailAddressField = Field.newBuilder(RETAIL_ADDRESS_FIELD, LegacySQLTypeName.STRING).build();
        Field userInnField = Field.newBuilder(USER_INN_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorField = Field.newBuilder(OPERATOR_FIELD, LegacySQLTypeName.STRING).build();
        Field shiftNumberField = Field.newBuilder(SHIFT_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field requestNumberField = Field.newBuilder(REQUEST_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field totalSumField = Field.newBuilder(TOTAL_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field prepaidSumField = Field.newBuilder(PREPAID_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field creditSumField = Field.newBuilder(CREDIT_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field provisionSumField = Field.newBuilder(PROVISION_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field userField = Field.newBuilder(USER_FIELD, LegacySQLTypeName.STRING).build();
        Field kktRegIdField = Field.newBuilder(KKT_REG_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field taxationTypeField = Field.newBuilder(TAXATION_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field operationTypeField = Field.newBuilder(OPERATION_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field shopOperatorNameField = Field.newBuilder(SHOP_OPERATOR_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field ofdNameField = Field.newBuilder(OFD_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field batchIdField = Field.newBuilder(BATCH_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field itemsField = Field.newBuilder(ITEMS_FIELD, LegacySQLTypeName.RECORD,
            Field.of("nds0", LegacySQLTypeName.INTEGER), Field.of("ndsNo", LegacySQLTypeName.INTEGER),
            Field.of("nds10110", LegacySQLTypeName.INTEGER), Field.of("nds10", LegacySQLTypeName.INTEGER),
            Field.of("nds18118", LegacySQLTypeName.INTEGER), Field.of("sum", LegacySQLTypeName.INTEGER),
            Field.of("ndsSum", LegacySQLTypeName.INTEGER), Field.of("name", LegacySQLTypeName.STRING),
            Field.of("price", LegacySQLTypeName.INTEGER), Field.of("quantity", LegacySQLTypeName.STRING))
            .setMode(Field.Mode.REPEATED).build();
/*
{"code":"3","user":"ООО \"Нюанс Базэл\"","userInn":"2317071371","requestNumber":"115","dateTime":"1527359820","shiftNumber":"10",
"operationType":"1","taxationType":"1","operator":"Borodina Vic","kktRegId":"0000511370025895",
"retailAddress":"г. Сочи Адлерский район, тер. Аэропорт","items":[{"quantity":"1.0","price":5000,
"name":"Svrmnk Fiksiki Nuts","sum":5000,"nds18118":763},{"quantity":"1.0","price":1500,
"name":"M\u0026M Peanut Pouch","sum":1500,"nds10":136}],"totalSum":6500,"cashTotalSum":0,
"ecashTotalSum":6500,"nds10":136,"nds18118":763,"fiscalDocumentNumber":"519",
"fiscalDriveNumber":"8712000100089731","fiscalSign":"3450292922","shopOperatorName":"Нюанс-Базэл","ofdName":"YARUS"}

{"code":"3","userInn":"2308013662","requestNumber":"278","dateTime":"2018-07-02T23:59:00.000Z","shiftNumber":"361",
"operationType":"1","taxationType":"8","operator":"Кассир КАССИР","kktRegId":"0000857374049018",
"items":[{"quantity":"4.0","price":15000,"name":"Туборг 0,5","sum":60000,"ndsSum":0}],"totalSum":60000,
"cashTotalSum":60000,"ecashTotalSum":0,"prepaidSum":0,"creditSum":0,"provisionSum":0,"nds0":60000,
"fiscalDocumentNumber":"61420","fiscalDriveNumber":"8710000100830161","fiscalSign":"4220304023",
"shopOperatorName":"ООО \"Кафе Лето\"","ofdName":"YARUS","batchId":"1CKXD0PW21GX"}

 */

        return Schema.of(codeField, userField, userInnField, requestNumberField, dateTimeField, shiftNumberField,
            operatorField, kktRegIdField, retailAddressField, itemsField, totalSumField, cashTotalSumField, ecashTotalSumField,
            nds18118Field, nds18Field, fiscalDocumentNumberField, fiscalDriveNumberField, fiscalSignField,
            nds10110Field, nds10Field, nds0Field, prepaidSumField, creditSumField, provisionSumField, taxationTypeField,
            operationTypeField, shopOperatorNameField, ofdNameField, batchIdField);
    }

    private Schema flatFileSchema() {
        Field operatorIdField = Field.newBuilder(OPERATOR_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorNameField = Field.newBuilder(OPERATOR_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field terminalIdField = Field.newBuilder(TERMINAL_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field receiptIdField = Field.newBuilder(RECEIPT_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field dateTimeField = Field.newBuilder(DATETIME_FIELD, LegacySQLTypeName.TIMESTAMP).build();
        Field receiptTotalField = Field.newBuilder(RECEIPT_TOTAL_FIELD, LegacySQLTypeName.INTEGER).build();
        Field receiptTotalAfterDiscountField = Field.newBuilder(RECEIPT_TOTAL_AFTER_DISCOUNT_FIELD, LegacySQLTypeName.INTEGER).build();
        Field positionNumberField = Field.newBuilder(RECEIPT_ITEM_POSITION_FIELD, LegacySQLTypeName.INTEGER).build();
        Field operationTypeField = Field.newBuilder(OPERATION_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field itemSKUField = Field.newBuilder(ITEM_SKU_FIELD, LegacySQLTypeName.STRING).build();
        Field itemNameField = Field.newBuilder(ITEM_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field paymentTypeField = Field.newBuilder(PAYMENT_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field unitPriceField = Field.newBuilder(UNIT_PRICE_FIELD, LegacySQLTypeName.INTEGER).build();
        Field unitQuantityField = Field.newBuilder(UNIT_QUANTITY_FIELD, LegacySQLTypeName.STRING).build();
        Field uomField = Field.newBuilder(UOM_FIELD, LegacySQLTypeName.STRING).build();
        Field lineItemTotalField = Field.newBuilder(LINE_ITEM_TOTAL_FIELD, LegacySQLTypeName.INTEGER).build();
        Field lineItemTotalAfterDiscountField = Field.newBuilder(LINE_ITEM_TOTAL_AFTER_DISCOUNT_FIELD, LegacySQLTypeName.INTEGER).build();

        return Schema.of(operatorIdField, operatorNameField, terminalIdField, receiptIdField, dateTimeField, receiptTotalField,
            receiptTotalAfterDiscountField, positionNumberField, operationTypeField, itemSKUField, itemNameField, paymentTypeField,
            unitPriceField, unitQuantityField, uomField, lineItemTotalField, lineItemTotalAfterDiscountField);
    }

    private Schema cleanSchema() {
        Field fiscalSignField = Field.newBuilder(FISCAL_SIGN_FIELD, LegacySQLTypeName.STRING).build();
        Field dateTimeField = Field.newBuilder(DATETIME_FIELD, LegacySQLTypeName.TIMESTAMP).build();
        Field fiscalDriveNumberField = Field.newBuilder(FISCAL_DRIVE_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field fiscalDocumentNumberField = Field.newBuilder(FISCAL_DOCUMENT_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field totalNds18118Field = Field.newBuilder(TOTAL_NDS18118_FIELD, LegacySQLTypeName.INTEGER).build();
        Field totalNds10110Field = Field.newBuilder(TOTAL_NDS10110_FIELD, LegacySQLTypeName.INTEGER).build();
        Field totalNds10Field = Field.newBuilder(TOTAL_NDS10_FIELD, LegacySQLTypeName.INTEGER).build();
        Field totalNds0Field = Field.newBuilder(TOTAL_NDS0_FIELD, LegacySQLTypeName.INTEGER).build();
        Field cashTotalSumField = Field.newBuilder(CASH_TOTAL_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field codeField = Field.newBuilder(CODE_FIELD, LegacySQLTypeName.STRING).build();
        Field ecashTotalSumField = Field.newBuilder(ECASH_TOTAL_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field retailAddressField = Field.newBuilder(RETAIL_ADDRESS_FIELD, LegacySQLTypeName.STRING).build();
        Field userInnField = Field.newBuilder(USER_INN_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorField = Field.newBuilder(OPERATOR_FIELD, LegacySQLTypeName.STRING).build();
        Field shiftNumberField = Field.newBuilder(SHIFT_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field requestNumberField = Field.newBuilder(REQUEST_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field totalSumField = Field.newBuilder(TOTAL_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field prepaidSumField = Field.newBuilder(PREPAID_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field creditSumField = Field.newBuilder(CREDIT_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field provisionSumField = Field.newBuilder(PROVISION_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field userField = Field.newBuilder(USER_FIELD, LegacySQLTypeName.STRING).build();
        Field kktRegIdField = Field.newBuilder(KKT_REG_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field taxationTypeField = Field.newBuilder(TAXATION_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field operationTypeField = Field.newBuilder(OPERATION_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field shopOperatorNameField = Field.newBuilder(SHOP_OPERATOR_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field ofdNameField = Field.newBuilder(OFD_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field batchIdField = Field.newBuilder(BATCH_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field nds0Field = Field.newBuilder(NDS0_FIELD, LegacySQLTypeName.INTEGER).build();
        Field ndsNoField = Field.newBuilder(NDS_NO_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nds10110Field = Field.newBuilder(NDS10110_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nds10Field = Field.newBuilder(NDS10_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nds18118Field = Field.newBuilder(NDS18118_FIELD, LegacySQLTypeName.INTEGER).build();
        Field sumField = Field.newBuilder(SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field ndsSumField = Field.newBuilder(NDS_SUM_FIELD, LegacySQLTypeName.INTEGER).build();
        Field nameField = Field.newBuilder(NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field priceField = Field.newBuilder(PRICE_FIELD, LegacySQLTypeName.INTEGER).build();
        Field quantityField = Field.newBuilder(QUANTITY_FIELD, LegacySQLTypeName.STRING).build();
        Field itemPosField = Field.newBuilder(ITEM_POS_FIELD, LegacySQLTypeName.INTEGER).build();
        Field insertionTsField = Field.newBuilder(INSERTION_TS_FIELD, LegacySQLTypeName.TIMESTAMP).build();

        return Schema.of(codeField, userField, userInnField, requestNumberField, dateTimeField, shiftNumberField,
            operatorField, kktRegIdField, retailAddressField, totalNds18118Field, totalNds10110Field, totalNds10Field,
            totalNds0Field, totalSumField, cashTotalSumField, ecashTotalSumField,
            nds18118Field, nds10110Field, nds10Field, nds0Field, ndsNoField, sumField, ndsSumField,
            nameField, priceField, quantityField,
            fiscalDocumentNumberField, fiscalDriveNumberField, fiscalSignField,
            prepaidSumField, creditSumField, provisionSumField, taxationTypeField,
            operationTypeField, shopOperatorNameField, ofdNameField, batchIdField, itemPosField, insertionTsField);
    }

}
