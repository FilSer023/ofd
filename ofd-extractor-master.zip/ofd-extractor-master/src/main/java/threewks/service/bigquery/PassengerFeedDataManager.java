package threewks.service.bigquery;

import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.*;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.threeten.bp.Duration;
import threewks.model.PassengerFeedBatch;
import threewks.service.TaskService;
import threewks.service.passengerfeed.PassengerFeedBatchService;
import threewks.util.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static threewks.model.PassengerFeedBatchStatus.*;
import static threewks.service.bigquery.BQService.logBigQueryJobStatus;
import static threewks.service.bigquery.DataManagerService.INTERNAL_DATASET_ID;
import static threewks.service.bigquery.DataManagerService.PROJECT_ID;

public class PassengerFeedDataManager {

    private final BigQuery bigQuery;
    private final String gcsDefaultBucket;
    private final PassengerFeedBatchService passengerFeedBatchService;
    private final TaskService taskService;

    private static final String ERROR_DELETING_OLD_PASSENGER_FEED_MESSAGE = "Ошибка удаления старых данных о пассажиропотоке";
    private static final String OLD_PASSENGER_FEED_DATA_DELETED_MESSAGE = "Старые данные о пассажиропотоке удалены";
    private static final String CLEAN_PASSENGERFEED_INSERTED_MESSAGE = "Данные о пассажиропотоке перенесены из временной зоны в чистую зону";
    private static final String ERROR_IMPORTING_CLEAN_PASSENGERFEED = "Ошибка импорта данных о пассажиропотоке в чистую зону";
    private static final String DATA_IMPORTED_INTO_STAGING_ZONE_MESSAGE = "Данные пассажиропотока успешно импортированы во временное хранилище данных";
    private static final String DATA_IMPORTED_MESSAGE = "Данные пассажиропотока успешно импортированы в хранилище данных";
    private static final String PASSENGER_FEED_TABLE_NAME = "passengerfeed";
    private static final String PASSENGER_FEED_STAGING_TABLE_NAME = "passengerfeed_staging";
    private static final String GCS_LOCATION_FORMAT_PASSENGER_FEED_PROCESSED = "gs://%s/cobra/%s/%s/processed/*";

    private static final String DEPARTURE_AIRPORT_RUS_FIELD = "departureAirportRus";
    private static final String ARRIVAL_AIRPORT_RUS_FIELD = "arrivalAirportRus";
    private static final String SCHEDULE_TYPE_FIELD = "scheduleType";
    private static final String BOARDING_GATE_FIELD = "boardingGate";
    private static final String SCHEDULED_DEPARTURE_TIME_FIELD = "scheduledDepartureTime";
    private static final String ACTUAL_DEPARTURE_TIME_FIELD = "actualDepartureTime";
    private static final String FACT_DEPARTURE_TIME_FIELD = "factDepartureTime";
    private static final String SCHEDULED_ARRIVAL_TIME_FIELD = "scheduledArrivalTime";
    private static final String ACTUAL_ARRIVAL_TIME_FIELD = "actualArrivalTime";
    private static final String AIRLINE_NAME_FIELD = "airlineName";
    private static final String FLIGHT_NUMBER_FIELD = "flightNumber";
    private static final String ECONOMY_CLASS_ADULTS_COUNT_FIELD = "economyClassAdultsCount";
    private static final String BUSINESS_CLASS_ADULTS_COUNT_FIELD = "businessClassAdultsCount";
    private static final String ECONOMY_CLASS_CHILDREN_COUNT_FIELD = "economyClassChildrenCount";
    private static final String BUSINESS_CLASS_CHILDREN_COUNT_FIELD = "businessClassChildrenCount";
    private static final String FLIGHT_ID_FIELD = "flightId";
    private static final String PV_KOBRA_FIELD = "pvKobra";
    private static final String DEPARTURE_AIRPORT_LAT_FIELD = "departureAirportLat";
    private static final String ARRIVAL_AIRPORT_LAT_FIELD = "arrivalAirportLat";
    private static final String AIRLINE_IATA_CODE_FIELD = "airlineIATACode";
    private static final String DEPARTURE_AIRPORT_IATA_CODE_FIELD = "departureAirportIATACode";
    private static final String ARRIVAL_AIRPORT_IATA_CODE_FIELD = "arrivalAirportIATACode";
    private static final String REGULARITY_TYPE_FIELD = "regType";
    private static final String TOTAL_PASSENGERS_FIELD = "totalPassengers";
    private static final String AIRPORT_NAME_FIELD = "airportName";
    private static final String BATCH_ID_FIELD = "batchId";

    private static final String DELETE_OLD_PASSENGER_FEED_FOR_OVERWRITE = "DELETE FROM `internal.passengerfeed` pf\n" +
        "WHERE EXISTS (SELECT * FROM `internal.passengerfeed_staging` pfs\n" +
        "WHERE pfs.flightId = pf.flightId AND pfs.airportName = pf.airportName)";

    private static final String IMPORT_PASSENGER_FEED_TO_CLEAN_TABLE = "INSERT INTO `internal.passengerfeed` ( departureAirportRus, arrivalAirportRus, scheduleType, pvKobra, \n" +
        "boardingGate, scheduledDepartureTime, actualDepartureTime, factDepartureTime, scheduledArrivalTime, actualArrivalTime, \n" +
        "airlineName, flightNumber, businessClassAdultsCount, economyClassAdultsCount, businessClassChildrenCount, \n" +
        "economyClassChildrenCount, flightId, departureAirportLat, arrivalAirportLat, airlineIATACode, departureAirportIATACode, \n" +
        "arrivalAirportIATACode, regType, totalPassengers, airportName, batchId)\n" +
        "SELECT departureAirportRus, arrivalAirportRus, scheduleType, pvKobra, boardingGate, scheduledDepartureTime, \n" +
        "actualDepartureTime, factDepartureTime, scheduledArrivalTime, actualArrivalTime, airlineName, flightNumber, \n" +
        "businessClassAdultsCount, economyClassAdultsCount, businessClassChildrenCount, economyClassChildrenCount, \n" +
        "flightId, departureAirportLat, arrivalAirportLat, airlineIATACode, departureAirportIATACode, arrivalAirportIATACode, \n" +
        "regType, totalPassengers, airportName, batchId\n" +
        "FROM `internal.passengerfeed_staging` pfs\n" +
        "WHERE NOT EXISTS (SELECT * FROM `internal.passengerfeed` pfT WHERE pfs.flightId =  pfT.flightId AND pfs.airportName = pfT.airportName)";

    public PassengerFeedDataManager(BigQuery bigQuery, String gcsDefaultBucket, PassengerFeedBatchService passengerFeedBatchService, TaskService taskService) {
        this.bigQuery = bigQuery;
        this.gcsDefaultBucket = gcsDefaultBucket;
        this.passengerFeedBatchService = passengerFeedBatchService;
        this.taskService = taskService;
    }

    void ingestPassengerFeedData(String batchId) {
        PassengerFeedBatch passengerFeedBatch = passengerFeedBatchService.find(batchId);
        Assert.isTrue(DATA_PREPARED_FOR_IMPORT == passengerFeedBatch.getStatus(),
            "Passenger feed batch must be in DATA_PREPARED_FOR_IMPORT status, currently %s", passengerFeedBatch.getStatus());

        TableId tableId = preparePassengerFeedTable(passengerFeedBatch.isAutomatic());

        List<String> passengerFeedFileLocation = new ArrayList<>();
        JobInfo.WriteDisposition writeDisposition;

        if (passengerFeedBatch.isAutomatic()) {
            passengerFeedFileLocation.add(String.format(GCS_LOCATION_FORMAT_PASSENGER_FEED_PROCESSED, gcsDefaultBucket, passengerFeedBatch.getId(), passengerFeedBatch.getFeedDay()));
            writeDisposition = JobInfo.WriteDisposition.WRITE_APPEND;
        } else {
            passengerFeedFileLocation.add(String.format(GCS_LOCATION_FORMAT_PASSENGER_FEED_PROCESSED, gcsDefaultBucket, passengerFeedBatch.getId(), "manual"));
            writeDisposition = JobInfo.WriteDisposition.WRITE_TRUNCATE;
        }

        LoadJobConfiguration loadJobConfiguration = LoadJobConfiguration.newBuilder(tableId,
            passengerFeedFileLocation)
            .setFormatOptions(FormatOptions.json())
            .setSchema(buildPassengerFeedSchema())
            .setDestinationTable(tableId)
            .setMaxBadRecords(100)
            .setWriteDisposition(writeDisposition)
            .setCreateDisposition(JobInfo.CreateDisposition.CREATE_IF_NEEDED)
            .build();

        Logger.info("LoadJobConfiguration for passenger feed: %s", loadJobConfiguration);

        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(loadJobConfiguration).setJobId(jobId).build());
        Logger.info("Product ingestion job for passenger feed for batch ID %s has been scheduled, job ID: %s, isDone: %s",
            passengerFeedBatch.getId(), jobId.getJob(), queryJob.isDone());
        //Use this for debugging importing issues (schema etc)
        Job completed = null;
        try {
            completed = queryJob.waitFor(RetryOption.maxRetryDelay(Duration.ofMinutes(3)));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        List<BigQueryError> importErrors = completed.getStatus().getExecutionErrors();
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.info("Ingestion job encountered errors: %s", completed.getStatus().getExecutionErrors());
            for (BigQueryError error : completed.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
            }
        }
        if (passengerFeedBatch.isAutomatic()) {
            passengerFeedBatch.getInfoMessages().add(DATA_IMPORTED_MESSAGE);
            passengerFeedBatchService.finishBatch(passengerFeedBatch);
        } else {
            passengerFeedBatch.getInfoMessages().add(DATA_IMPORTED_INTO_STAGING_ZONE_MESSAGE);
            passengerFeedBatch.setStatus(DATA_IMPORTED_TO_STAGING_ZONE);
            passengerFeedBatchService.save(passengerFeedBatch);
            taskService.deleteOldPassengerFeedData(batchId);
        }
    }

    private TableId preparePassengerFeedTable(boolean isAutomatic) {
        TableId tableId;
        if (isAutomatic) {
            tableId = TableId.of(PROJECT_ID, INTERNAL_DATASET_ID, PASSENGER_FEED_TABLE_NAME);
        } else {
            tableId = TableId.of(PROJECT_ID, INTERNAL_DATASET_ID, PASSENGER_FEED_STAGING_TABLE_NAME);
        }

        Table existing = bigQuery.getTable(tableId, BigQuery.TableOption.fields(BigQuery.TableField.ID));
        if (existing == null || !existing.exists()) {
            TableDefinition tableDefinition = StandardTableDefinition.newBuilder()
                .setSchema(buildPassengerFeedSchema())
                .setTimePartitioning(TimePartitioning.of(TimePartitioning.Type.DAY))
                .build();
            TableInfo tableInfo = TableInfo.newBuilder(tableId, tableDefinition).build();

            Table passengerFeedTable = bigQuery.create(tableInfo);
            Logger.info("Passenger feed table created: %s", passengerFeedTable.getTableId().getTable());
        }
        return tableId;
    }

    private Schema buildPassengerFeedSchema() {

        Field departureAirportRusField = Field.newBuilder(DEPARTURE_AIRPORT_RUS_FIELD, LegacySQLTypeName.STRING).build();
        Field arrivalAirportRusField = Field.newBuilder(ARRIVAL_AIRPORT_RUS_FIELD, LegacySQLTypeName.STRING).build();
        Field scheduleTypeField = Field.newBuilder(SCHEDULE_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field boardingGateField = Field.newBuilder(BOARDING_GATE_FIELD, LegacySQLTypeName.STRING).build();
        Field scheduledDepartureTimeField = Field.newBuilder(SCHEDULED_DEPARTURE_TIME_FIELD, LegacySQLTypeName.STRING).build();
        Field actualDepartureTimeField = Field.newBuilder(ACTUAL_DEPARTURE_TIME_FIELD, LegacySQLTypeName.STRING).build();
        Field factDepartureTimeField = Field.newBuilder(FACT_DEPARTURE_TIME_FIELD, LegacySQLTypeName.STRING).build();
        Field scheduledArrivalTimeField = Field.newBuilder(SCHEDULED_ARRIVAL_TIME_FIELD, LegacySQLTypeName.STRING).build();
        Field actualArrivalTimeField = Field.newBuilder(ACTUAL_ARRIVAL_TIME_FIELD, LegacySQLTypeName.STRING).build();
        Field airlineNameField = Field.newBuilder(AIRLINE_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field flightNumberField = Field.newBuilder(FLIGHT_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field businessClassAdultsCountField = Field.newBuilder(BUSINESS_CLASS_ADULTS_COUNT_FIELD, LegacySQLTypeName.INTEGER).build();
        Field economyClassAdultsCountField = Field.newBuilder(ECONOMY_CLASS_ADULTS_COUNT_FIELD, LegacySQLTypeName.INTEGER).build();
        Field businessClassChildrenCountField = Field.newBuilder(BUSINESS_CLASS_CHILDREN_COUNT_FIELD, LegacySQLTypeName.INTEGER).build();
        Field economyClassChildrenCountField = Field.newBuilder(ECONOMY_CLASS_CHILDREN_COUNT_FIELD, LegacySQLTypeName.INTEGER).build();
        Field flightIdField = Field.newBuilder(FLIGHT_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field pvKobraField = Field.newBuilder(PV_KOBRA_FIELD, LegacySQLTypeName.STRING).build();
        Field departureAirportLatField = Field.newBuilder(DEPARTURE_AIRPORT_LAT_FIELD, LegacySQLTypeName.STRING).build();
        Field arrivalAirportLatField = Field.newBuilder(ARRIVAL_AIRPORT_LAT_FIELD, LegacySQLTypeName.STRING).build();
        Field airlineIATACodeField = Field.newBuilder(AIRLINE_IATA_CODE_FIELD, LegacySQLTypeName.STRING).build();
        Field departureAirportIATACodeField = Field.newBuilder(DEPARTURE_AIRPORT_IATA_CODE_FIELD, LegacySQLTypeName.STRING).build();
        Field arrivalAirportIATACodeField = Field.newBuilder(ARRIVAL_AIRPORT_IATA_CODE_FIELD, LegacySQLTypeName.STRING).build();
        Field regularityTypeField = Field.newBuilder(REGULARITY_TYPE_FIELD, LegacySQLTypeName.STRING).build();
        Field totalPassengersField = Field.newBuilder(TOTAL_PASSENGERS_FIELD, LegacySQLTypeName.INTEGER).build();
        Field airportNameField = Field.newBuilder(AIRPORT_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field batchIdField = Field.newBuilder(BATCH_ID_FIELD, LegacySQLTypeName.STRING).build();

        return Schema.of(departureAirportRusField, arrivalAirportRusField, scheduleTypeField, pvKobraField, boardingGateField,
            scheduledDepartureTimeField, actualDepartureTimeField, factDepartureTimeField, scheduledArrivalTimeField, actualArrivalTimeField, airlineNameField,
            flightNumberField, businessClassAdultsCountField, economyClassAdultsCountField, businessClassChildrenCountField, economyClassChildrenCountField,
            flightIdField, departureAirportLatField, arrivalAirportLatField, airlineIATACodeField, departureAirportIATACodeField,
            arrivalAirportIATACodeField, regularityTypeField, totalPassengersField, airportNameField, batchIdField);
    }

    public void deleteOldPassengerFeedForOverwrite(String batchId) {
        PassengerFeedBatch passengerFeedBatch = passengerFeedBatchService.find(batchId);
        Assert.isTrue(DATA_IMPORTED_TO_STAGING_ZONE == passengerFeedBatch.getStatus(),
            "Passenger feed batch must be in DATA_IMPORTED status, currently %s", passengerFeedBatch.getStatus());

        Logger.info("Starting deleting old passenger feed data for batch %s", batchId);
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration
            .newBuilder(DELETE_OLD_PASSENGER_FEED_FOR_OVERWRITE)
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());
        Logger.info("BQ job for deleting old passenger feed data has been created, job ID %s", jobId);

        try {
            queryJob = queryJob.waitFor();
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while importing staging passenger feed: ", e);
            e.printStackTrace();
        }

        logBigQueryJobStatus(queryJob);
        List<BigQueryError> importErrors = queryJob.getStatus().getExecutionErrors();
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.info("Inserting clean data job encountered errors: %s", queryJob.getStatus().getExecutionErrors());
            for (BigQueryError error : queryJob.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
            }
            passengerFeedBatch.getErrorMessages().add(ERROR_DELETING_OLD_PASSENGER_FEED_MESSAGE);
        } else {
            passengerFeedBatch.getInfoMessages().add(OLD_PASSENGER_FEED_DATA_DELETED_MESSAGE);
            Logger.info("Old passenger feed data successfully deleted");
        }
        passengerFeedBatchService.save(passengerFeedBatch);
        taskService.collatePassengerFeedData(batchId);
    }

    public void importPassengerFeedDataIntoClean(String batchId) {
        PassengerFeedBatch passengerFeedBatch = passengerFeedBatchService.find(batchId);
        Assert.isTrue(DATA_IMPORTED_TO_STAGING_ZONE == passengerFeedBatch.getStatus(),
            "Passenger feed batch must be in DATA_IMPORTED status, currently %s", passengerFeedBatch.getStatus());

        Logger.info("Starting importPassengerFeedDataIntoClean for batch %s", batchId);
        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration
            .newBuilder(IMPORT_PASSENGER_FEED_TO_CLEAN_TABLE)
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());
        Logger.info("BQ job for inserting from passenger feed_staging has been created, job ID %s", jobId);

        try {
            queryJob = queryJob.waitFor();
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while importing staging passenger feed: ", e);
            e.printStackTrace();
        }

        logBigQueryJobStatus(queryJob);
        List<BigQueryError> importErrors = queryJob.getStatus().getExecutionErrors();
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.info("Inserting clean data job encountered errors: %s", queryJob.getStatus().getExecutionErrors());
            for (BigQueryError error : queryJob.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
            }
            passengerFeedBatch.getErrorMessages().add(ERROR_IMPORTING_CLEAN_PASSENGERFEED);
        } else {
            passengerFeedBatch.getInfoMessages().add(CLEAN_PASSENGERFEED_INSERTED_MESSAGE);
            passengerFeedBatch.setStatus(DATA_IMPORTED);
            Logger.info("Passenger feed data successfully collated into clean zone");
        }
        passengerFeedBatchService.finishBatch(passengerFeedBatch);
    }
}
