package threewks.service.bigquery;

import com.google.api.client.extensions.appengine.http.UrlFetchTransport;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.InputStreamContent;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.Permission;
import com.google.appengine.tools.cloudstorage.GcsFileOptions;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsInputChannel;
import com.google.appengine.tools.cloudstorage.GcsOutputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryError;
import com.google.cloud.bigquery.ExternalTableDefinition;
import com.google.cloud.bigquery.ExtractJobConfiguration;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FieldValueList;
import com.google.cloud.bigquery.FormatOptions;
import com.google.cloud.bigquery.GoogleSheetsOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.LegacySQLTypeName;
import com.google.cloud.bigquery.LoadJobConfiguration;
import com.google.cloud.bigquery.QueryJobConfiguration;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableInfo;
import com.google.cloud.bigquery.TableResult;
import com.opencsv.CSVWriter;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.threeten.bp.Duration;
import sun.nio.ch.ChannelInputStream;
import threewks.framework.cloudstorage.attachment.AttachmentDto;
import threewks.model.BatchForUnmatchedSKUItem;
import threewks.model.CategoryMappingBatch;
import threewks.model.SKUCategoryMappingFile;
import threewks.model.UnmatchedSKUItem;
import threewks.repository.BatchForUnmatchedSKUItemRepository;
import threewks.repository.UnmatchedSKUItemRepository;
import threewks.service.CategoryMappingBatchService;
import threewks.service.SKUCategoryMappingFileService;
import threewks.service.TaskService;
import threewks.util.Assert;
import threewks.util.IdUtil;
import threewks.util.StreamUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.nio.channels.Channels;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static threewks.model.CategoryMappingBatchStatus.EXPORT_TO_SHEET_COMPLETED;
import static threewks.model.CategoryMappingBatchStatus.IMPORT_TO_BQ_COMPLETED;
import static threewks.model.CategoryMappingBatchStatus.STARTED;
import static threewks.service.bigquery.BQService.logBigQueryJobStatus;
import static threewks.service.bigquery.DataManagerService.PROJECT_ID;

public class CategoriesDataManager {

    private static final String INTERNAL_DATASET_ID = "internal";
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final DateTimeFormatter FULL_DATE_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    private static final String APPLICATION_NAME = "Google Drive for OFD Extractor";
    private static final String CATEGORIES_MAPPING_SHEET_TABLE_NAME = "categories_sheet";
    private static final String MAPPING_REPORT_TABLE_NAME = "category_mapping";
    private static final String SKU_MAPPING_TABLE = "sku_mapping";

    private static final String NEW_UNCATEGORIZED_SKU_QUERY = "SELECT DISTINCT i.name, o.name as shopOperatorName " +
        " FROM `internal.operator_info` o INNER JOIN " +
        "  `ofddata.transactions_combined` i " +
        " ON i.shopOperatorName = o.id " +
        " LEFT OUTER JOIN " +
        "  `internal.unmatched_sku_items` u " +
        "ON LOWER(i.name) = LOWER(REGEXP_REPLACE(REGEXP_REPLACE(sku, \"^'|'$\", \"\"), \"ǂ\", \";\") ) AND i.shopOperatorName = o.id " +
        "WHERE " +
        "LOWER(CONCAT(\"'\",i.name,\"'\")) NOT IN (SELECT  LOWER(sku)  FROM `internal.sku_mapping`)" +
        " AND u.sku IS NULL";

    private static final String ALLOCATED_UNMATCHED_SKU_ITEMS_QUERY = "SELECT DISTINCT __key__.name FROM `internal.unmatched_sku_items` un WHERE __key__.name " +
        "IN (SELECT id FROM `internal.sku_mapping` m WHERE __key__.name = m.id)";

    private static final String EXPORT_CURRENT_MAPPING_SQL = "SELECT id, REPLACE(REGEXP_REPLACE(sku, \";\", \"ǂ\"), \"'\", \"\") AS sku, operatorName, category FROM `internal.sku_mapping`";

    private static final String MERGE_CORRECT_CATEGORIES_FROM_SHEET_QUERY = "MERGE INTO `internal.sku_mapping` c\n" +
        "   USING (SELECT id, sku, operatorName, category FROM `internal.categories_sheet` cs \n" +
        "   WHERE cs.category IN (SELECT name FROM `internal.subsection_category` ss WHERE\n" +
        "     cs.category = ss.name)) NEW1\n" +
        "   ON (c.id = NEW1.id)\n" +
        "   WHEN MATCHED THEN UPDATE SET c.sku = NEW1.sku, c.category = NEW1.category, c.operatorName = NEW1.operatorName, c.batchId = '%s'\n" +
        "   WHEN NOT MATCHED THEN INSERT (id, sku, category, operatorName, batchId)\n" +
        "     VALUES (NEW1.id, NEW1.sku, NEW1.category, NEW1.operatorName, '%s');";

    private static final String ALLOCATED_SKU_ITEMS_TO_REMOVE_FROM_REPORT_QUERY = "SELECT id from `internal.sku_mapping` WHERE batchId = '%s'";

    private static final String CATEGORY_MAPPING_LOCATION = "gs://%s/%s";
    private static final String CATEGORY_MAPPING_FILE_PATH = "mapping/%s.csv";

    private static final String ID_NAME_FIELD = "id";
    private static final String SKU_FIELD = "sku";
    private static final String OPERATOR_NAME_FIELD = "operatorName";
    private static final String ITEM_CATEGORY_FIELD = "category";
    private static final String BATCH_ID_FIELD = "batchId";
    private static final String CSV_FORMAT = "csv";
    private static final int ID_COLUMN_INDEX = 0;
    private static final int SKU_COLUMN_INDEX = 0;
    private static final int OPERATOR_COLUMN_INDEX = 1;
    private static final String VALUE_UNSPECIFIED = "не указано";
    private static final char COMMA = ',';
    private static final char SEMICOLON = ';';
    private static final char SEMICOLON_REPLACEMENT_SYMBOL = 'ǂ';
    private static final String ALLOCATED_ITEMS_DIRECTORY_PREFIX = "allocated-items/%s.csv";
    private static final String ALLOCATED_ITEMS_LOCATION = "gs://%s/%s";
    private static final Integer HUNDRED = 100;
    private static final Integer TWO_HUNDRED = 200;
    private static final int FIRST_CATEGORY = 0;
    private static final String SINGLE_QUOTED_NAME = "'%s'";
    private static final String GOOGLE_DRIVE_LOCATION_FORMAT = "https://drive.google.com/open?id=%s";
    private static final long FIRST_ROW = 1L;
    private static final String CREATED_SHEET_MESSAGE = "Файл успешно сгенерирован: %s";
    public static final String DRIVE_PERMISSION_USER_TYPE = "user";
    public static final String DRIVE_PERMISSION_WRITER_ROLE = "writer";

    private static final String MERGING_CATEGORIES_BQ_ERROR_MESSAGE = "Ошибка импорта файла сопоставления: %s";
    private static final String COMBINED_MAPPING_TABLE_NAME = "combined_mapping";
    private static final String COMBINE_MAPPING_INFO_QUERY = " SELECT DISTINCT CONCAT(\"'\", t.name, \"'\") as sku, 'Без категории' as category, o.name FROM `ofddata.transactions_combined` t " +
        "INNER JOIN `internal.operator_info` o ON t.shopOperatorName = o.id " +
        "WHERE CONCAT(\"'\", t.name, \"'\") NOT IN (SELECT sku FROM `internal.sku_mapping` mapping) " +
        "UNION ALL " +
        "SELECT sku, category, operatorName FROM `internal.sku_mapping`";

    private final BigQuery bigQuery;
    private final BQService bqService;
    private final Drive driveService;

    private final CategoryMappingBatchService categoryMappingBatchService;
    private final SKUCategoryMappingFileService skuCategoryMappingFileService;
    private final UnmatchedSKUItemRepository unmatchedSKUItemRepository;
    private final BatchForUnmatchedSKUItemRepository batchForUnmatchedSKUItemRepository;

    private final TaskService taskService;
    private final String gcsDefaultBucket;
    private final GcsFileOptions DEFAULT_FILE_OPTIONS = new GcsFileOptions.Builder()
        .build();
    private final GcsService gcsService =
        GcsServiceFactory.createGcsService(
            new RetryParams.Builder()
                .initialRetryDelayMillis(10)
                .retryMaxAttempts(10)
                .totalRetryPeriodMillis(15000)
                .build());

    public CategoriesDataManager(BigQuery bigQuery, BQService bqService, GoogleCredential driveCredential,
        CategoryMappingBatchService categoryMappingBatchService,
        SKUCategoryMappingFileService skuCategoryMappingFileService,
        UnmatchedSKUItemRepository unmatchedSKUItemRepository, BatchForUnmatchedSKUItemRepository batchForUnmatchedSKUItemRepository, TaskService taskService,
        String gcsDefaultBucket) {
        HttpTransport httpTransport = new UrlFetchTransport();
        JsonFactory jsonFactory = new GsonFactory();
        this.bigQuery = bigQuery;
        this.bqService = bqService;
        this.categoryMappingBatchService = categoryMappingBatchService;
        this.skuCategoryMappingFileService = skuCategoryMappingFileService;
        this.unmatchedSKUItemRepository = unmatchedSKUItemRepository;
        this.batchForUnmatchedSKUItemRepository = batchForUnmatchedSKUItemRepository;
        this.taskService = taskService;
        this.gcsDefaultBucket = gcsDefaultBucket;
        this.driveService = new Drive.Builder(httpTransport, jsonFactory, driveCredential)
            .setApplicationName(APPLICATION_NAME)
            .build();
    }

    public void exportCurrentMappingFile() throws InterruptedException {
        QueryJobConfiguration queryJobConfiguration =
            QueryJobConfiguration.newBuilder(EXPORT_CURRENT_MAPPING_SQL)
                .setDestinationTable(TableId.of(INTERNAL_DATASET_ID, MAPPING_REPORT_TABLE_NAME))
                .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
                .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());

        Logger.info("BQ job for exportCurrentMappingFile has been created, job ID %s", jobId);

        queryJob = queryJob.waitFor();

        logBigQueryJobStatus(queryJob);

        String filePart = String.format(CATEGORY_MAPPING_FILE_PATH, LocalDate.now().format(TODAY_FORMAT));
        String gcsUrl = String.format(CATEGORY_MAPPING_LOCATION, gcsDefaultBucket, filePart);
        TableId tableId = TableId.of(INTERNAL_DATASET_ID, MAPPING_REPORT_TABLE_NAME);
        ExtractJobConfiguration extractJobConfiguration = ExtractJobConfiguration.newBuilder(tableId, gcsUrl)
            .setFormat(CSV_FORMAT)
            .setFieldDelimiter(String.valueOf(COMMA)).build();
        JobId extractJobId = JobId.of(UUID.randomUUID().toString());
        Job exportJob = bigQuery.create(JobInfo.newBuilder(extractJobConfiguration).setJobId(extractJobId).build());
        exportJob = exportJob.waitFor(RetryOption.totalTimeout(Duration.ofMinutes(3)));

        logBigQueryJobStatus(exportJob);

        if (exportJob != null && exportJob.getStatus().getError() == null) {
            SKUCategoryMappingFile mappingFile = skuCategoryMappingFileService.create(filePart, 0);
            Logger.info("Exported current mapping to file %s", mappingFile.getGcsLocation());
        } else {
            Logger.warn("Could not export current category mapping file");
        }

        bqService.createTableFromQuery(INTERNAL_DATASET_ID, COMBINED_MAPPING_TABLE_NAME, buildCombinedMappingInfoSchema(), COMBINE_MAPPING_INFO_QUERY);
    }

    public void exportAllocatedCategoryItemsToBQ() {
        List<UnmatchedSKUItem> distinctMatchedSKUItemsWithoutPrice = unmatchedSKUItemRepository.listAllocatedItems();
        String timeId = LocalDateTime.now().format(FULL_DATE_FORMAT);
        String fileName = String.format(ALLOCATED_ITEMS_DIRECTORY_PREFIX, timeId);
        GcsFilename gcsFilename = new GcsFilename(gcsDefaultBucket, fileName);
        try {
            GcsOutputChannel outputChannel = gcsService.createOrReplace(gcsFilename, DEFAULT_FILE_OPTIONS);
            Writer writer = Channels.newWriter(outputChannel, "UTF-8");
            CSVWriter csvWriter = new CSVWriter(writer,
                SEMICOLON,
                CSVWriter.NO_QUOTE_CHARACTER,
                CSVWriter.NO_ESCAPE_CHARACTER,
                CSVWriter.DEFAULT_LINE_END);
            for (UnmatchedSKUItem matchedSKUItem : distinctMatchedSKUItemsWithoutPrice) {
                csvWriter.writeNext(new String[]{
                    matchedSKUItem.getId(),
                    matchedSKUItem.getSku(),
                    matchedSKUItem.getOperatorName(),
                    matchedSKUItem.getCategories().get(FIRST_CATEGORY),
                    timeId
                });
            }
            csvWriter.flush();
            csvWriter.close();
            outputChannel.close();
            importAllocatedSKUMappings(fileName);
        } catch (IOException e) {
            Logger.warn("Failed to write manually matched SKUs to GCS", e);
        }
    }

    public void importCategoryMappingFile(String batchId) {
        CategoryMappingBatch batch = categoryMappingBatchService.find(batchId);
        Assert.isTrue(STARTED == batch.getStatus(),
            "CategoryMappingBatch batch must be in STARTED status, currently %s", batch.getStatus());
        generateSheetFromUploadedExcel(batch);
        taskService.importCategoryMappingSheetIntoTable(batch.getId());
    }

    public void importCategoryMappingSheetIntoTable(String batchId) {
        CategoryMappingBatch batch = categoryMappingBatchService.find(batchId);

        QueryJobConfiguration queryJobConfiguration = QueryJobConfiguration
            .newBuilder(String.format(MERGE_CORRECT_CATEGORIES_FROM_SHEET_QUERY, batchId, batchId))
            .build();
        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job queryJob = null;
        try {
            queryJob = bigQuery.create(JobInfo.newBuilder(queryJobConfiguration).setJobId(jobId).build());

            Logger.info("BQ job for merging category mapping sheet has been created, job ID %s", jobId);
            queryJob = queryJob.waitFor();
        } catch (Exception e) {
            Logger.warn("Caught Exception while merging category mapping sheet: %s, %s", e, e.getMessage());
            batch.getErrorMessages().add(String.format(MERGING_CATEGORIES_BQ_ERROR_MESSAGE, e.getMessage()));
        }

        logBigQueryJobStatus(queryJob);
        batch.setStatus(IMPORT_TO_BQ_COMPLETED);

        try {
            TableResult result = bqService.runQueryJob(String.format(ALLOCATED_SKU_ITEMS_TO_REMOVE_FROM_REPORT_QUERY, batchId));
            List<UnmatchedSKUItem> itemsToDelete = new ArrayList<>();
            for (FieldValueList values : result.iterateAll()) {
                UnmatchedSKUItem itemToDelete = new UnmatchedSKUItem()
                    .setId(values.get(ID_COLUMN_INDEX).getStringValue());
                itemsToDelete.add(itemToDelete);
            }
            unmatchedSKUItemRepository.deleteById(itemsToDelete);
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while deleting matched categories from report: %s, %s", e, e.getMessage());
        }
        taskService.exportCurrentCategoryMapping();
        categoryMappingBatchService.finishBatch(batch);
    }

    public void ingestBatchForUnmatchedItems(String batchId) {
        List<UnmatchedSKUItem> items = new ArrayList<>();
        List<BatchForUnmatchedSKUItem> batchItems = batchForUnmatchedSKUItemRepository.listByBatch(batchId);
        for (BatchForUnmatchedSKUItem batchItem : batchItems) {
            items.add(UnmatchedSKUItem.fromBatch(batchItem));
        }
        unmatchedSKUItemRepository.put(items);
        Logger.info("ingestBatchForUnmatchedItems completed for batch %s, saved %s items", batchId, items.size());
        batchForUnmatchedSKUItemRepository.delete(batchItems);
    }

    public void findUnmatchedSKUs() throws InterruptedException {
        saveNewUnmatchedItems();
    }

    private void saveNewUnmatchedItems() throws InterruptedException {
        TableResult result = bqService.runQueryJob(NEW_UNCATEGORIZED_SKU_QUERY);
        Logger.info("saveNewUnmatchedItems got %s rows", result.getTotalRows());
        UnmatchedSKUItem unmatchedSKUItem;
        List<UnmatchedSKUItem> unmatchedSKUItems = new ArrayList<>();
        for (FieldValueList values : result.iterateAll()) {
            unmatchedSKUItem = new UnmatchedSKUItem(prepareSkuValue(values.get(SKU_COLUMN_INDEX).getStringValue()))
                .setOperatorName(values.get(OPERATOR_COLUMN_INDEX).getValue().toString());
            if (!unmatchedSKUItems.contains(unmatchedSKUItem)) {
                unmatchedSKUItems.add(unmatchedSKUItem);
            }
        }
        Logger.info("Found %s unmatched SKUs, saving in batches of %s", unmatchedSKUItems.size(), TWO_HUNDRED);
        StreamUtil.batches(unmatchedSKUItems, TWO_HUNDRED).forEach(subList -> saveUnmatchedItemsBatch(subList));
    }

    private void saveUnmatchedItemsBatch(List<UnmatchedSKUItem> subList) {
        List<BatchForUnmatchedSKUItem> batch = new ArrayList<>();
        String batchId = IdUtil.generateUniqueId();
        for (UnmatchedSKUItem item : subList) {
            batch.add(BatchForUnmatchedSKUItem.batch(batchId, item));
        }
        batchForUnmatchedSKUItemRepository.put(batch);
        taskService.ingestBatchForUnmatchedItems(batchId);
    }

    private void generateSheetFromUploadedExcel(CategoryMappingBatch batch) {
        Logger.info("generateSheetFromUploadedExcel for batch %s", batch.getId());
        String fileId;
        List<AttachmentDto> attachments = batch.getAttachment();
        if (attachments.isEmpty() || attachments.size() > 1) {
            Logger.warn("Expected one attachment for category mapping");
        }
        File fileMetadata = new File();
        fileMetadata.setName(attachments.get(0).getFilename());
        fileMetadata.setMimeType("application/vnd.google-apps.spreadsheet");

        GcsFilename uploadedXls = new GcsFilename(gcsDefaultBucket, attachments.get(0).getName());
        GcsInputChannel inputChannel = null;
        try {
            inputChannel = gcsService.openReadChannel(uploadedXls, 0);
        } catch (IOException e) {
            Logger.warn("Caught IOException while reading uploaded Excel file", e.getMessage());
            batch.getErrorMessages().add("Ошибка при чтении файла Excel");
        }
        InputStream inputStream = new ChannelInputStream(inputChannel);
        InputStreamContent inputStreamContent = new InputStreamContent("application/vnd.ms-excel", inputStream);

        File file = null;
        try {
            file = driveService.files().create(fileMetadata, inputStreamContent)
                .setFields("id")
                .execute();
        } catch (IOException e) {
            Logger.warn("Caught IOException while creating Drive file: %s, %s", e, e.getMessage());
            batch.getErrorMessages().add("Ошибка при создании файла Google Drive");
            categoryMappingBatchService.save(batch);
        }
        fileId = file.getId();
        batch.getInfoMessages().add(String.format(CREATED_SHEET_MESSAGE, fileId));
        if (batch.isShareDocument()) {
            String emailToInvite = batch.getStartedByUser().getEmail();
            if (StringUtils.isNotBlank(emailToInvite)) {
                Permission invite = new Permission()
                    .setType(DRIVE_PERMISSION_USER_TYPE)
                    .setRole(DRIVE_PERMISSION_WRITER_ROLE)
                    .setEmailAddress(emailToInvite);
                try {
                    driveService.permissions().create(fileId, invite)
                        .setFields("id")
                        .execute();
                } catch (IOException e) {
                    Logger.warn("Caught IOException while sharing Drive file", e.getMessage());
                    batch.getInfoMessages().add("Не удалось предоставить доступа к сгенерированному документу Google Drive");
                }
            }
        }
        Permission userPermission = new Permission()
            .setType(DRIVE_PERMISSION_USER_TYPE)
            .setRole(DRIVE_PERMISSION_WRITER_ROLE)
            .setEmailAddress("konstantin.ilyinov@gmail.com");
        Permission user1Permission = new Permission()
            .setType(DRIVE_PERMISSION_USER_TYPE)
            .setRole(DRIVE_PERMISSION_WRITER_ROLE)
            .setEmailAddress("konstantin.ilinov@conirics.com.au");
        try {
            driveService.permissions().create(fileId, userPermission)
                .setFields("id")
                .execute();
            driveService.permissions().create(fileId, user1Permission)
                .setFields("id")
                .execute();
        } catch (IOException e) {
            Logger.warn("Caught IOException while sharing Drive file with system users", e.getMessage());
        }
        Logger.info("Google Drive file created: %s", fileId);
        TableId tableId = TableId.of(PROJECT_ID, INTERNAL_DATASET_ID, CATEGORIES_MAPPING_SHEET_TABLE_NAME);
        bigQuery.delete(tableId);
        ExternalTableDefinition tableDefinition = ExternalTableDefinition
            .of(String.format(GOOGLE_DRIVE_LOCATION_FORMAT, fileId), skuMappingSchema(),
                GoogleSheetsOptions.newBuilder().setSkipLeadingRows(FIRST_ROW).build());

        TableInfo tableInfo = TableInfo.newBuilder(tableId, tableDefinition).build();

        Table table = bigQuery.create(tableInfo);
        Logger.info("LoadJobConfiguration for ingesting category mapping sheet: %s", table);
        batch.setStatus(EXPORT_TO_SHEET_COMPLETED);
        categoryMappingBatchService.save(batch);
    }

    private void importAllocatedSKUMappings(String fileName) {
        TableId tableId = TableId.of(INTERNAL_DATASET_ID, SKU_MAPPING_TABLE);
        LoadJobConfiguration loadJobConfiguration = LoadJobConfiguration.newBuilder(tableId,
            String.format(ALLOCATED_ITEMS_LOCATION, gcsDefaultBucket, fileName))
            .setFormatOptions(FormatOptions.csv().toBuilder().setFieldDelimiter(String.valueOf(SEMICOLON)).build())
            .setSchema(skuMappingSchema())
            .setDestinationTable(tableId)
            .setMaxBadRecords(100)
            .setWriteDisposition(JobInfo.WriteDisposition.WRITE_APPEND)
            .setCreateDisposition(JobInfo.CreateDisposition.CREATE_IF_NEEDED)
            .build();

        Logger.info("LoadJobConfiguration for importing allocated items: %s", loadJobConfiguration);

        JobId jobId = JobId.of(UUID.randomUUID().toString());
        Job loadJob = bigQuery.create(JobInfo.newBuilder(loadJobConfiguration).setJobId(jobId).build());

        Job completed = null;
        try {
            completed = loadJob.waitFor(RetryOption.maxRetryDelay(Duration.ofMinutes(3)));
        } catch (InterruptedException e) {
            Logger.warn("Error occurred importing allocated items file");
        }
        List<BigQueryError> importErrors = completed.getStatus().getExecutionErrors();
        if (CollectionUtils.isNotEmpty(importErrors)) {
            Logger.warn("Importing allocated items ingestion job encountered errors: %s", completed.getStatus().getExecutionErrors());
            for (BigQueryError error : completed.getStatus().getExecutionErrors()) {
                Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
            }
        } else {
            Logger.info("Importing allocated items successfully completed");
        }
        taskService.deleteAllocatedUnmatchedSKUItemsAfterIngestion();
    }

    public void deleteAllocatedUnmatchedSKUItemsAfterIngestion() {
        try {
            TableResult result = bqService.runQueryJob(ALLOCATED_UNMATCHED_SKU_ITEMS_QUERY);
            List<UnmatchedSKUItem> itemsToDelete = new ArrayList<>();
            for (FieldValueList values : result.iterateAll()) {
                UnmatchedSKUItem itemToDelete = new UnmatchedSKUItem()
                    .setId(values.get(ID_COLUMN_INDEX).getStringValue());
                itemsToDelete.add(itemToDelete);
            }
            unmatchedSKUItemRepository.deleteById(itemsToDelete);
        } catch (InterruptedException e) {
            Logger.warn("Caught InterruptedException while deleting allocated unmatched SKU items: %s, %s", e, e.getMessage());
        }
    }

    private Schema skuMappingSchema() {
        Field idField = Field.newBuilder(ID_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field skuField = Field.newBuilder(SKU_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorField = Field.newBuilder(OPERATOR_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field categoryField = Field.newBuilder(ITEM_CATEGORY_FIELD, LegacySQLTypeName.STRING).build();
        Field batchIdField = Field.newBuilder(BATCH_ID_FIELD, LegacySQLTypeName.STRING).build();
        return Schema.of(idField, skuField, operatorField, categoryField, batchIdField);
    }

    private Schema buildCombinedMappingInfoSchema() {
        Field skuField = Field.newBuilder(SKU_FIELD, LegacySQLTypeName.STRING).build();
        Field categoryField = Field.newBuilder(ITEM_CATEGORY_FIELD, LegacySQLTypeName.STRING).build();
        Field operatorNameField = Field.newBuilder(OPERATOR_NAME_FIELD, LegacySQLTypeName.STRING).build();
        return Schema.of(skuField, categoryField, operatorNameField);
    }

    private static String prepareSkuValue(String entry) {
        if (StringUtils.isEmpty(entry)) {
            return VALUE_UNSPECIFIED;
        } else {
            entry = String.format(SINGLE_QUOTED_NAME, entry);
            if (StringUtils.containsAny(entry, SEMICOLON)) {
                return entry.replaceAll(String.valueOf(SEMICOLON), String.valueOf(SEMICOLON_REPLACEMENT_SYMBOL));
            }
        }
        return entry;
    }
}
