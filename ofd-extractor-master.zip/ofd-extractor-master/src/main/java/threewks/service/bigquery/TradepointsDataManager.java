package threewks.service.bigquery;

import com.google.cloud.RetryOption;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.BigQueryError;
import com.google.cloud.bigquery.Field;
import com.google.cloud.bigquery.FormatOptions;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.JobId;
import com.google.cloud.bigquery.JobInfo;
import com.google.cloud.bigquery.LegacySQLTypeName;
import com.google.cloud.bigquery.LoadJobConfiguration;
import com.google.cloud.bigquery.Schema;
import com.google.cloud.bigquery.StandardTableDefinition;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableDefinition;
import com.google.cloud.bigquery.TableId;
import com.google.cloud.bigquery.TableInfo;
import com.google.cloud.bigquery.TimePartitioning;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.threeten.bp.Duration;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.service.OFDBatchService;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static threewks.service.bigquery.DataManagerService.OFD_DATASET_ID;
import static threewks.service.bigquery.DataManagerService.PROJECT_ID;

public class TradepointsDataManager {

    private final BigQuery bigQuery;
    private final OFDBatchService ofdBatchService;
    private final String gcsDefaultBucket;

    private static final String TRADEPOINTS_TABLE_NAME = "tradepoints";
    private static final String GCS_LOCATION_FORMAT_TRADEPOINTS = "gs://%s/ofd/%s/%s/tradepoints/*";

    private static final String TRADEPOINT_ID_FIELD = "id";
    private static final String TRADEPOINT_NAME_FIELD = "name";
    private static final String KKT_COUNT_FIELD = "kktCount";
    private static final String TRADEPOINT_ADDRESS_FIELD = "address";

    private static final String TRADEPOINTS_KKT_TABLE_NAME = "tradepoints_kkt";
    private static final String GCS_LOCATION_FORMAT_TRADEPOINTS_KKT = "gs://%s/ofd/%s/%s/tradepoints_kkt/*";

    private static final String NAME_FIELD = "name";
    private static final String FACTORY_NUMBER_FIELD = "factoryNumber";
    private static final String REGISTER_NUMBER_KKT_FIELD = "registerNumberKkt";
    private static final String FACTORY_NUMBER_KKT_FIELD = "factoryNumberKkt";
    private static final String LAST_REQ_FIELD = "lastreq";
    private static final String STATUS_FIELD = "status";
    private static final String ACTIVATED_FIELD = "activated";

    public TradepointsDataManager(BigQuery bigQuery, OFDBatchService ofdBatchService, String gcsDefaultBucket) {
        this.bigQuery = bigQuery;
        this.ofdBatchService = ofdBatchService;
        this.gcsDefaultBucket = gcsDefaultBucket;
    }

    void ingestTradePointsData(String batchId) {
        TableId tableId = prepareTradePointsTable();
        OFDBatch ofdBatch = ofdBatchService.find(batchId);
        if (OFDProvider.YARUS != ofdBatch.getShopOperator().getOfdProvider()) {
            return;
        } else {
            List<String> tradePointFileLocations = new ArrayList<>();
            tradePointFileLocations.add(String.format(GCS_LOCATION_FORMAT_TRADEPOINTS, gcsDefaultBucket, batchId, ofdBatch.getShopOperator().getName()));

            LoadJobConfiguration loadJobConfiguration = LoadJobConfiguration.newBuilder(tableId,
                tradePointFileLocations)
                .setFormatOptions(FormatOptions.json())
                .setSchema(buildOfdTradePointsSchema())
                .setDestinationTable(tableId)
                .setMaxBadRecords(100)
                .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
                .setCreateDisposition(JobInfo.CreateDisposition.CREATE_IF_NEEDED)
                .build();

            Logger.info("LoadJobConfiguration for trade points: %s", loadJobConfiguration);

            JobId jobId = JobId.of(UUID.randomUUID().toString());
            Job queryJob = bigQuery.create(JobInfo.newBuilder(loadJobConfiguration).setJobId(jobId).build());
            Logger.info("Product ingestion job for OFD batch %s has been scheduled, job ID: %s, isDone: %s",
                batchId, jobId.getJob(), queryJob.isDone());
            //Use this for debugging importing issues (schema etc)
            Job completed = null;
            try {
                completed = queryJob.waitFor(RetryOption.maxRetryDelay(Duration.ofMinutes(3)));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            List<BigQueryError> importErrors = completed.getStatus().getExecutionErrors();
            if (CollectionUtils.isNotEmpty(importErrors)) {
                Logger.info("Ingestion job encountered errors: %s", completed.getStatus().getExecutionErrors());
                for (BigQueryError error : completed.getStatus().getExecutionErrors()) {
                    Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
                }
            }
        }
    }

    private Schema buildOfdTradePointsSchema() {

        Field idField = Field.newBuilder(TRADEPOINT_ID_FIELD, LegacySQLTypeName.STRING).build();
        Field nameField = Field.newBuilder(TRADEPOINT_NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field kktCountField = Field.newBuilder(KKT_COUNT_FIELD, LegacySQLTypeName.INTEGER).build();
        Field addressField = Field.newBuilder(TRADEPOINT_ADDRESS_FIELD, LegacySQLTypeName.STRING).build();

     /*   {"id":"43498","name":"AER Hudson Common Area","kktCount":2,
            "address":"Краснодарский край, г Сочи, тер Аэропорт "}*/

        return Schema.of(idField, nameField, kktCountField, addressField);
    }

    private TableId prepareTradePointsTable() {
        TableId tableId = TableId.of(PROJECT_ID, OFD_DATASET_ID, TRADEPOINTS_TABLE_NAME);

        Table existing = bigQuery.getTable(tableId, BigQuery.TableOption.fields(BigQuery.TableField.ID));
        if (existing == null || !existing.exists()) {
            TableDefinition tableDefinition = StandardTableDefinition.newBuilder()
                .setSchema(buildOfdTradePointsSchema())
                .setTimePartitioning(TimePartitioning.of(TimePartitioning.Type.DAY))
                .build();
            TableInfo tableInfo = TableInfo.newBuilder(tableId, tableDefinition).build();

            Table tradepointsTable = bigQuery.create(tableInfo);
            Logger.info("Trade points table created: %s", tradepointsTable.getTableId().getTable());
        }
        return tableId;
    }


    void ingestTradePointsKktData(String batchId) {
        TableId tableId = prepareTradePointsKktTable();
        OFDBatch ofdBatch = ofdBatchService.find(batchId);
        if (OFDProvider.YARUS != ofdBatch.getShopOperator().getOfdProvider()) {
            return;
        } else {
            List<String> tradePointKktFileLocations = new ArrayList<>();
            tradePointKktFileLocations.add(String.format(GCS_LOCATION_FORMAT_TRADEPOINTS_KKT, gcsDefaultBucket, batchId, ofdBatch.getShopOperator().getName()));

            LoadJobConfiguration loadJobConfiguration = LoadJobConfiguration.newBuilder(tableId,
                tradePointKktFileLocations)
                .setFormatOptions(FormatOptions.json())
                .setSchema(buildTradepointsKktSchema())
                .setDestinationTable(tableId)
                .setMaxBadRecords(100)
                .setWriteDisposition(JobInfo.WriteDisposition.WRITE_TRUNCATE)
                .setCreateDisposition(JobInfo.CreateDisposition.CREATE_IF_NEEDED)
                .build();

            Logger.info("LoadJobConfiguration for trade points: %s", loadJobConfiguration);

            JobId jobId = JobId.of(UUID.randomUUID().toString());
            Job queryJob = bigQuery.create(JobInfo.newBuilder(loadJobConfiguration).setJobId(jobId).build());
            Logger.info("TradePointsKKT ingestion job for OFD batch %s has been scheduled, job ID: %s, isDone: %s",
                batchId, jobId.getJob(), queryJob.isDone());
            //Use this for debugging importing issues (schema etc)
            Job completed = null;
            try {
                completed = queryJob.waitFor(RetryOption.maxRetryDelay(Duration.ofMinutes(3)));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            List<BigQueryError> importErrors = completed.getStatus().getExecutionErrors();
            if (CollectionUtils.isNotEmpty(importErrors)) {
                Logger.info("Ingestion job encountered errors: %s", completed.getStatus().getExecutionErrors());
                for (BigQueryError error : completed.getStatus().getExecutionErrors()) {
                    Logger.warn("BigQueryError: %s, %s, %s", error.getMessage(), error.getReason(), error.getLocation());
                }
            }
        }
    }


    private TableId prepareTradePointsKktTable() {

        TableId tableId = TableId.of(PROJECT_ID, OFD_DATASET_ID, TRADEPOINTS_KKT_TABLE_NAME);

        Table existing = bigQuery.getTable(tableId, BigQuery.TableOption.fields(BigQuery.TableField.ID));
        if (existing == null || !existing.exists()) {
            TableDefinition tableDefinition = StandardTableDefinition.newBuilder()
                .setSchema(buildTradepointsKktSchema())
                .setTimePartitioning(TimePartitioning.of(TimePartitioning.Type.DAY))
                .build();
            TableInfo tableInfo = TableInfo.newBuilder(tableId, tableDefinition).build();

            Table tradepointsKktTable = bigQuery.create(tableInfo);
            Logger.info("Trade points kkt table created: %s", tradepointsKktTable.getTableId().getTable());
        }
        return tableId;
    }


    private Schema buildTradepointsKktSchema() {
        Field nameField = Field.newBuilder(NAME_FIELD, LegacySQLTypeName.STRING).build();
        Field factoryNumberField = Field.newBuilder(FACTORY_NUMBER_FIELD, LegacySQLTypeName.STRING).build();
        Field registerNumberKktField = Field.newBuilder(REGISTER_NUMBER_KKT_FIELD, LegacySQLTypeName.STRING).build();
        Field factoryNumberKktField = Field.newBuilder(FACTORY_NUMBER_KKT_FIELD, LegacySQLTypeName.STRING).build();
        Field lastreqField = Field.newBuilder(LAST_REQ_FIELD, LegacySQLTypeName.STRING).build();
        Field statusField = Field.newBuilder(STATUS_FIELD, LegacySQLTypeName.STRING).build();
        Field activatedField = Field.newBuilder(ACTIVATED_FIELD, LegacySQLTypeName.BOOLEAN).build();

        return Schema.of(nameField, factoryNumberField, registerNumberKktField, factoryNumberKktField, lastreqField,
            statusField, activatedField);

        /*{"name":"AER Hudson com_1","factoryNumber":"8712000100089731","registerNumberKkt":"0000511370025895",
        "factoryNumberKkt":"1705659","lastreq":"2018-07-11 22:04:39,049","status":"ФД успешно обработан",
        "activated":true}*/
    }

}
