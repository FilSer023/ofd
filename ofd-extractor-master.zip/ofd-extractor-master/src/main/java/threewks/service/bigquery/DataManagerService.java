package threewks.service.bigquery;

import com.threewks.thundr.gae.GaeEnvironment;

import java.io.IOException;

public class DataManagerService {

    public static final String PROJECT_ID = GaeEnvironment.applicationId();
    public static final String OFD_DATASET_ID = "ofddata";
    public static final String INTERNAL_DATASET_ID = "internal";

    private final TransactionDataManager transactionDataManager;
    private final TradepointsDataManager tradepointsDataManager;
    private final CategoriesDataManager categoriesDataManager;
    private final PassengerFeedDataManager passengerFeedDataManager;
    private final BackupDataManager backupDataManager;

    public DataManagerService(TransactionDataManager transactionDataManager, TradepointsDataManager tradepointsDataManager,
        CategoriesDataManager categoriesDataManager, PassengerFeedDataManager passengerFeedDataManager, BackupDataManager backupDataManager) {
        this.transactionDataManager = transactionDataManager;
        this.tradepointsDataManager = tradepointsDataManager;
        this.categoriesDataManager = categoriesDataManager;
        this.passengerFeedDataManager = passengerFeedDataManager;
        this.backupDataManager = backupDataManager;
    }

    public void ingestionStagingDataJob(String batchId) {
        transactionDataManager.ingestTransactionsDataIntoStaging(batchId);
//        tradepointsDataManager.ingestTradePointsData(batchId);
//        tradepointsDataManager.ingestTradePointsKktData(batchId);
    }

    public void scheduleBackupDataImport(String year, String month, String day) throws IOException {
        backupDataManager.createTablesFromBackup(year, month, day);
    }

    public void findUnmatchedSKUs() throws InterruptedException {
        categoriesDataManager.findUnmatchedSKUs();
    }

    public void collateTransactionData(String batchId) {
        transactionDataManager.collateOFDTransactions(batchId);
    }

    public void ingestFlatFileTransactions(String batchId) {
        transactionDataManager.ingestFlatFileTransactionsIntoClean(batchId);
    }

    public void combineCleanTransactions() {
        transactionDataManager.combineCleanTransactions();
    }

    public void schedulePassengerFeedImport(String batchId) {
        passengerFeedDataManager.ingestPassengerFeedData(batchId);
    }

    public void exportCurrentCategoryMapping() throws InterruptedException {
        categoriesDataManager.exportCurrentMappingFile();
    }

    public void importCategoryMappingFile(String batchId) {
        categoriesDataManager.importCategoryMappingFile(batchId);
    }

    public void importCategoryMappingSheetIntoTable(String batchId) {
        categoriesDataManager.importCategoryMappingSheetIntoTable(batchId);
    }

    public void exportAllocatedCategoryItemsToBQ() {
        categoriesDataManager.exportAllocatedCategoryItemsToBQ();
    }

    public void deleteOldPassengerFeedData(String batchId) {
        passengerFeedDataManager.deleteOldPassengerFeedForOverwrite(batchId);
    }

    public void collatePassengerFeedDada(String batchId) {
        passengerFeedDataManager.importPassengerFeedDataIntoClean(batchId);
    }

    public void combineOperatorInfoData() {
        backupDataManager.createOperatorTables();
    }

    public void deleteAllocatedUnmatchedSKUItemsAfterIngestion() {
        categoriesDataManager.deleteAllocatedUnmatchedSKUItemsAfterIngestion();
    }

    public void ingestBatchForUnmatchedItems(String batchId) {
        categoriesDataManager.ingestBatchForUnmatchedItems(batchId);
    }

    public void ingestShopOperatorTransactionsFile(String batchId, String fileName) {
        transactionDataManager.ingestShopOperatorTransactionsFile(batchId, fileName);
    }

    public void updateInsertionTime() {
        transactionDataManager.updateInsertionTime();
    }
}
