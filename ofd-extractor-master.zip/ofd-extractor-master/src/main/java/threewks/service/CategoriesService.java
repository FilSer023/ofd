package threewks.service;

import java.util.Collections;
import java.util.List;

public class CategoriesService {

    public CategoriesService() {

    }

    public List<List<String>> download() {
        List<List<String>> data = Collections.emptyList();
        return data;
    }
}
