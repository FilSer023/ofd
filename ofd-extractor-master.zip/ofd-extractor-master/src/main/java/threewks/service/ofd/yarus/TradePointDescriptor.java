package threewks.service.ofd.yarus;

public class TradePointDescriptor {

    private String name;
    private String kktcount;
    private String addr;

    public String getName() {
        return name;
    }

    public TradePointDescriptor setName(String name) {
        this.name = name;
        return this;
    }

    public String getKktcount() {
        return kktcount;
    }

    public TradePointDescriptor setKktcount(String kktcount) {
        this.kktcount = kktcount;
        return this;
    }

    public String getAddr() {
        return addr;
    }

    public TradePointDescriptor setAddr(String addr) {
        this.addr = addr;
        return this;
    }

    @Override
    public String toString() {
        return "TradePointDescriptor{" +
            "name='" + name + '\'' +
            ", kktcount='" + kktcount + '\'' +
            ", addr='" + addr + '\'' +
            '}';
    }
}
