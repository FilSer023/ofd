package threewks.service.ofd.peterservice;

import org.apache.commons.lang3.tuple.Triple;
import threewks.service.ofd.OFDDocument;
import threewks.service.ofd.ReceiptItem;

import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

public class FromPeterServiceReceiptToOFDDocument implements BiFunction<String, Triple<String, ReceiptDetails, String>, OFDDocument> {

    private static final String OFD_NAME = "PETER-SERVIS";

    public static FromPeterServiceReceiptToOFDDocument INSTANCE = new FromPeterServiceReceiptToOFDDocument();

    @Override
    public OFDDocument apply(String batchId, Triple<String, ReceiptDetails, String> operatorAndReceiptDetails) {
        String shopOperatorName = operatorAndReceiptDetails.getLeft();
        ReceiptDetails receiptDetails = operatorAndReceiptDetails.getMiddle();
        String docRawId = operatorAndReceiptDetails.getRight();
        OFDDocument ofdDocument = new OFDDocument();
        ofdDocument.setOfdName(OFD_NAME);
        ofdDocument.setShopOperatorName(shopOperatorName);
        ofdDocument.setBatchId(batchId);
        ofdDocument.setUserInn(receiptDetails.getUserInn());
        ofdDocument.setFiscalDriveNumber(receiptDetails.getFnFactoryNumber());
        ofdDocument.setShiftNumber(String.valueOf(receiptDetails.getShiftNumber()));
        ofdDocument.setDateTime(receiptDetails.getDateTime());
        ofdDocument.setCashTotalSum(receiptDetails.getAmountCash());
        ofdDocument.setEcashTotalSum(receiptDetails.getAmountECash());
        ofdDocument.setFiscalDocumentNumber(receiptDetails.getDecimalFiscalSign());
        ofdDocument.setFiscalSign(receiptDetails.getFiscalSign());
        ofdDocument.setRequestNumber(docRawId);
        ofdDocument.setKktRegId(receiptDetails.getKktRegNumber().trim());
        ofdDocument.setOperator(receiptDetails.getOperator());
        ofdDocument.setOperationType(String.valueOf(receiptDetails.getOperationType()));
        ofdDocument.setTaxationType(String.valueOf(receiptDetails.getTaxationType()));
        ofdDocument.setNds10(receiptDetails.getNds10Total());
        ofdDocument.setNds10110(receiptDetails.getNds10Total());
        ofdDocument.setNds18(receiptDetails.getNds18Total());
        ofdDocument.setNds18118(receiptDetails.getNds18Total());
        List<ReceiptItem> receiptItemList = receiptDetails.getItems().stream().map(peterServiceReceiptItem -> {
            ReceiptItem receiptItem = new ReceiptItem();
            receiptItem.setName(peterServiceReceiptItem.getName())
                .setPrice(peterServiceReceiptItem.getPrice())
                .setQuantity(String.valueOf(peterServiceReceiptItem.getQuantity()))
                .setSum(peterServiceReceiptItem.getTotal())
                .setNds10(peterServiceReceiptItem.getNds10Total())
                .setNds10110(peterServiceReceiptItem.getNds10Total())
                .setNds18118(peterServiceReceiptItem.getNds18Total());
            return receiptItem;
        }).collect(Collectors.toList());
        ofdDocument.setItems(receiptItemList);
        return ofdDocument;
    }
}
