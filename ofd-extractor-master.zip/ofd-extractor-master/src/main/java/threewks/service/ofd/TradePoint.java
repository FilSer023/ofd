package threewks.service.ofd;

public class TradePoint {

    private String id;
    private String name;
    private String kktCount;
    private String address;

    public String getId() {
        return id;
    }

    public TradePoint setId(String id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public TradePoint setName(String name) {
        this.name = name;
        return this;
    }

    public String getKktCount() {
        return kktCount;
    }

    public TradePoint setKktCount(String kktCount) {
        this.kktCount = kktCount;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public TradePoint setAddress(String address) {
        this.address = address;
        return this;
    }

}
