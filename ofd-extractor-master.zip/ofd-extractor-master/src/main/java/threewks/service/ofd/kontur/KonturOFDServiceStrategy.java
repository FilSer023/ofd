package threewks.service.ofd.kontur;

import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.GetRequest;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Triple;
import threewks.model.BatchStatus;
import threewks.model.KKTFiscalDrive;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.model.TradePoint;
import threewks.repository.OFDBatchRepository;
import threewks.service.ConfigParameterService;
import threewks.service.ofd.OFDDocument;
import threewks.service.ofd.OFDDocumentUploadService;
import threewks.service.ofd.OFDServiceStrategy;
import threewks.util.HttpUtils;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class KonturOFDServiceStrategy extends OFDServiceStrategy {

    private static final String API_BASE_URL_FORMAT = "%s/%s";
    private static final String DOCUMENTS_URL = "v1/integration/inns/%s/kkts/%s/fss/%s/tickets?dateFrom=%s&dateTo=%s";
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final String COOKIE_HEADER_NAME = "Cookie";
    private static final String COOKIE_VALUE = "auth.sid=%s;ofd_api_key=%s";
    private static final String RECEIPT_DOCUMENT_NAME = "receipt";
    private static final int ONE_DAY = 1;

    private final String konturSessionKey;
    private final String konturApiKey;
    public static final int STATUS_CODE_OK = 200;
    public static final String UNEXPECTED_STATUS_CODE_MESSAGE = "Неверный код ответа сервера: %s";

    private final String konturBaseUrl;
    private final ConfigParameterService configParameterService;
    private final OFDBatchRepository batchRepository;
    private final OFDDocumentUploadService ofdDocumentUploadService;

    public KonturOFDServiceStrategy(GsonBuilder gsonBuilder, String konturSessionKey, String konturApiKey, String konturBaseUrl, ConfigParameterService configParameterService,
        OFDBatchRepository batchRepository, OFDDocumentUploadService ofdDocumentUploadService) throws Exception {
        super(gsonBuilder);
        this.konturSessionKey = konturSessionKey;
        this.konturApiKey = konturApiKey;
        this.konturBaseUrl = konturBaseUrl;
        this.configParameterService = configParameterService;
        this.batchRepository = batchRepository;
        this.ofdDocumentUploadService = ofdDocumentUploadService;
    }

    @Override
    public OFDBatch saveOFDDocuments(ShopOperator shopOperator, String exportDay, int period, OFDBatch batch) {
        Logger.info("KonturOFDServiceStrategy.saveOFDDocuments: from day %s for period %s back", exportDay, period);
        batch = fetchOperatorDailyInfo(shopOperator, exportDay, period, batch);
        return batch;
    }

    private OFDBatch fetchOperatorDailyInfo(ShopOperator shopOperator, String exportDay, int period, OFDBatch batch) {
        String konturApiKeyValue = configParameterService.getConfigValueOrDefault(ConfigParameterService.KONTUR_API_KEY, konturApiKey);
        String konturSessionKeyValue = configParameterService.getConfigValueOrDefault(ConfigParameterService.KONTUR_API_SESSION_KEY, konturSessionKey);
        String documentsRequestURL = null;
        HttpResponse httpResponse = null;
        String toDay = LocalDate.parse(exportDay).format(TODAY_FORMAT);
        String fromDay = LocalDate.parse(exportDay).minusDays(period).format(TODAY_FORMAT);
        String kktRegId = null;
        String fiscalDriveNumber = null;
        List<TradePoint> tradePoints = shopOperator.getTradePoints();

        for (TradePoint tradePoint : tradePoints) {
            Logger.info("Exporting data for TradePoint %s", tradePoint);
            for (KKTFiscalDrive entry : tradePoint.getKktFiscalDrives()) {
                kktRegId = entry.getKktRegId();
                fiscalDriveNumber = entry.getFiscalDriveNumber();
                if (StringUtils.isEmpty(kktRegId) || StringUtils.isEmpty(fiscalDriveNumber)) {
                    Logger.warn("У торговой точки %s есть пустые ККТ/ФН, пропускаю", tradePoint.getName());
                    continue;
                }
                documentsRequestURL = String.format(DOCUMENTS_URL, shopOperator.getInn(), kktRegId, fiscalDriveNumber, fromDay, toDay);
                GetRequest httpRequest = Unirest
                    .get(String.format(API_BASE_URL_FORMAT, konturBaseUrl, documentsRequestURL));
                httpRequest
                    .header(COOKIE_HEADER_NAME, String.format(COOKIE_VALUE, konturSessionKeyValue, konturApiKeyValue));
                HttpUtils.logRequest(httpRequest);
                try {
                    httpResponse = httpRequest.asObject(Object.class);
                    HttpUtils.logResponse(httpResponse);
                    List<OFDDocument> documents = parseResponse(batch, kktRegId, fiscalDriveNumber, httpResponse);
                    if (CollectionUtils.isNotEmpty(documents)) {
                        batch.addReceiptsRetrieved(documents.size());
                        batch = ofdDocumentUploadService.saveTransactionDocuments(shopOperator.getId(), exportDay, fiscalDriveNumber, documents, batch);
                        Logger.info("Extracted %s documents from OFD for KKT %s FN %s", documents.size(), kktRegId, fiscalDriveNumber);
                    }
                } catch (UnirestException | IOException e) {
                    Logger.warn("Caught exception retrieving OFD documents: %s", e.getMessage());
                    batch.getErrorMessages().add("Ошибка выгрузки данных из ОФД: " + e.getMessage());
                    batch.setStatus(BatchStatus.ERROR);
                    batchRepository.put(batch);
                    throw new RuntimeException("Ошибка выгрузки чеков из ОФД, сеанс будет перезапущен: ", e);
                }
            }
        }

        return batch;
    }

    private List<OFDDocument> parseResponse(OFDBatch batch, String kktRegId,
        String fiscalDriveNumber, HttpResponse<List> httpResponse) throws IOException {
        if (httpResponse.getStatus() != STATUS_CODE_OK) {
            batch.getErrorMessages().add(String.format(UNEXPECTED_STATUS_CODE_MESSAGE, httpResponse.getStatus()));
            batch.getErrorMessages().addAll(IOUtils.readLines(httpResponse.getRawBody()));
            return null;
        } else {
            List<OFDDocument> documents = new ArrayList<>();
            List<HashMap> rawData = httpResponse.getBody();
            documents.addAll(rawData.stream()
                .filter(linkedHashMap -> linkedHashMap.keySet().contains(RECEIPT_DOCUMENT_NAME))
                .map(receiptHashMap -> FromKonturReceiptToOFDDocument.INSTANCE.apply(receiptHashMap, Triple.of(batch, kktRegId, fiscalDriveNumber))).collect(Collectors.toList()));
            return documents;
        }
    }
}
