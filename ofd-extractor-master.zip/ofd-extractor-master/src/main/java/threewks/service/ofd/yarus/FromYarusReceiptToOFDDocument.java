package threewks.service.ofd.yarus;

import org.joda.time.DateTime;
import threewks.model.OFDBatch;
import threewks.service.ofd.OFDDocument;
import threewks.service.ofd.yarus.model.YarusReceipt;

import java.util.function.BiFunction;

public class FromYarusReceiptToOFDDocument implements BiFunction<OFDBatch, YarusReceipt, OFDDocument> {

    private static final String OFD_NAME = "YARUS";
    private static final Long THOUSAND = 1000L;
    public static FromYarusReceiptToOFDDocument INSTANCE = new FromYarusReceiptToOFDDocument();

    @Override
    public OFDDocument apply(OFDBatch batch, YarusReceipt yarusReceipt) {
        OFDDocument ofdDocument = new OFDDocument();
        ofdDocument.setUser(yarusReceipt.getUser());
        ofdDocument.setUserInn(yarusReceipt.getUserInn());
        ofdDocument.setCode(yarusReceipt.getCode());
        ofdDocument.setDateTime(new DateTime(Long.valueOf(yarusReceipt.getDateTime()) * THOUSAND));
        ofdDocument.setCashTotalSum(yarusReceipt.getCashTotalSum());
        ofdDocument.setEcashTotalSum(yarusReceipt.getEcashTotalSum());
        ofdDocument.setNds10110(yarusReceipt.getNds10110());
        ofdDocument.setNds18118(yarusReceipt.getNds18118());
        ofdDocument.setNds10(yarusReceipt.getNds10());
        ofdDocument.setNds18(yarusReceipt.getNds18());
        ofdDocument.setNds0(yarusReceipt.getNds0());
        ofdDocument.setOperationType(yarusReceipt.getOperationType());
        ofdDocument.setTaxationType(yarusReceipt.getTaxationType());
        ofdDocument.setKktRegId(yarusReceipt.getKktRegId());
        ofdDocument.setItems(yarusReceipt.getItems());
        ofdDocument.setShiftNumber(yarusReceipt.getShiftNumber());
        ofdDocument.setTotalSum(yarusReceipt.getTotalSum());
        ofdDocument.setOperator(yarusReceipt.getOperator());
        ofdDocument.setRequestNumber(yarusReceipt.getRequestNumber());
        ofdDocument.setRetailAddress(yarusReceipt.getRetailAddress());
        ofdDocument.setFiscalSign(yarusReceipt.getFiscalSign());
        ofdDocument.setFiscalDocumentNumber(yarusReceipt.getFiscalDocumentNumber());
        ofdDocument.setFiscalDriveNumber(yarusReceipt.getFiscalDriveNumber());
        ofdDocument.setProvisionSum(yarusReceipt.getProvisionSum());
        ofdDocument.setCreditSum(yarusReceipt.getCreditSum());
        ofdDocument.setPrepaidSum(yarusReceipt.getPrepaidSum());
        ofdDocument.setShopOperatorName(batch.getShopOperator().getId());
        ofdDocument.setOfdName(OFD_NAME);
        ofdDocument.setBatchId(batch.getId());
        return ofdDocument;
    }
}
