package threewks.service.ofd;

import com.threewks.thundr.exception.BaseException;

public class SaveGcsObjectException extends BaseException {

    private final int statusCode;

    public SaveGcsObjectException(int statusCode, String format, Object... formatArgs) {
        super(format, formatArgs);
        this.statusCode = statusCode;
    }

    public SaveGcsObjectException(String format, Object... formatArgs) {
        super(format, formatArgs);
        this.statusCode = -1;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
