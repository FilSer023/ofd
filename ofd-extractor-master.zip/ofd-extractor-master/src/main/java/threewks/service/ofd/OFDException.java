package threewks.service.ofd;

import com.threewks.thundr.exception.BaseException;

public class OFDException extends BaseException {

    private final int statusCode;

    public OFDException(int statusCode, String format, Object... formatArgs) {
        super(format, formatArgs);
        this.statusCode = statusCode;
    }

    public OFDException(String format, Object... formatArgs) {
        super(format, formatArgs);
        this.statusCode = -1;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
