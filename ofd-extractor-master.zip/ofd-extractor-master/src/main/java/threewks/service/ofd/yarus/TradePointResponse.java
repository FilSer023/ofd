package threewks.service.ofd.yarus;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

public class TradePointResponse {
    /*
    "trade_points" : {
    "43498" : {
      "name" : "AER Hudson Common Area",
      "kktcount" : 2,
      "addr" : "Краснодарский край, г Сочи, тер Аэропорт "
    }
     */

    @JsonProperty("trade_points")
    private Map<String, TradePointDescriptor> tradePoints;
    private Integer count;

    public Map<String, TradePointDescriptor> getTradePoints() {
        return tradePoints;
    }

    public TradePointResponse setTradePoints(Map<String, TradePointDescriptor> tradePoints) {
        this.tradePoints = tradePoints;
        return this;
    }

    public Integer getCount() {
        return count;
    }

    public TradePointResponse setCount(Integer count) {
        this.count = count;
        return this;
    }

    @Override
    public String toString() {
        return "TradePointResponse{" +
            "TradePoints=" + tradePoints +
            ", count=" + count +
            '}';
    }
}
