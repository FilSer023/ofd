package threewks.service.ofd;

import java.math.BigDecimal;

public class ReceiptItem {

    private String quantity;
    private BigDecimal price;
    private String name;
    private BigDecimal sum;
    private BigDecimal nds0;
    private BigDecimal nds10;
    private BigDecimal ndsNo;
    private BigDecimal ndsSum;
    private BigDecimal nds18118;
    private BigDecimal nds10110;

    public String getQuantity() {
        return quantity;
    }

    public ReceiptItem setQuantity(String quantity) {
        this.quantity = quantity;
        return this;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public ReceiptItem setPrice(BigDecimal price) {
        this.price = price;
        return this;
    }

    public String getName() {
        return name;
    }

    public ReceiptItem setName(String name) {
        this.name = name;
        return this;
    }

    public BigDecimal getSum() {
        return sum;
    }

    public ReceiptItem setSum(BigDecimal sum) {
        this.sum = sum;
        return this;
    }

    public BigDecimal getNds18118() {
        return nds18118;
    }

    public ReceiptItem setNds18118(BigDecimal nds18118) {
        this.nds18118 = nds18118;
        return this;
    }

    public BigDecimal getNds10110() {
        return nds10110;
    }

    public ReceiptItem setNds10110(BigDecimal nds10110) {
        this.nds10110 = nds10110;
        return this;
    }

    public BigDecimal getNds0() {
        return nds0;
    }

    public ReceiptItem setNds0(BigDecimal nds0) {
        this.nds0 = nds0;
        return this;
    }

    public BigDecimal getNdsNo() {
        return ndsNo;
    }

    public ReceiptItem setNdsNo(BigDecimal ndsNo) {
        this.ndsNo = ndsNo;
        return this;
    }

    public BigDecimal getNds10() {
        return nds10;
    }

    public ReceiptItem setNds10(BigDecimal nds10) {
        this.nds10 = nds10;
        return this;
    }

    public BigDecimal getNdsSum() {
        return ndsSum;
    }

    public ReceiptItem setNdsSum(BigDecimal ndsSum) {
        this.ndsSum = ndsSum;
        return this;
    }
}
