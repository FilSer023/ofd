package threewks.service.ofd.yarus;

public class GetActiveKKTForDateRequest {

    private String date;

    public GetActiveKKTForDateRequest() {
    }

    public String getDate() {
        return date;
    }

    public GetActiveKKTForDateRequest setDate(String date) {
        this.date = date;
        return this;
    }
}
