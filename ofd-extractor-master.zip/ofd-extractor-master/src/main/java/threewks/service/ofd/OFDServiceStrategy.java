package threewks.service.ofd;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.ObjectMapper;
import com.mashape.unirest.http.Unirest;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;

import java.io.IOException;

public abstract class OFDServiceStrategy {

    protected final Gson gson;

    public OFDServiceStrategy(GsonBuilder gsonBuilder) throws Exception {
        this.gson = gsonBuilder.create();
        Unirest.setHttpClient(HttpClients.custom()
            .setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, (x509Certificates, s) -> true).build())
            .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
            .build());

        ObjectMapper objectMapper = new ObjectMapper() {
            private com.fasterxml.jackson.databind.ObjectMapper jacksonObjectMapper
                = new com.fasterxml.jackson.databind.ObjectMapper()
                .registerModule(new JodaModule())
                .configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            public <T> T readValue(String value, Class<T> valueType) {
                try {
                    return jacksonObjectMapper.readValue(value, valueType);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            public String writeValue(Object value) {
                try {
                    return jacksonObjectMapper.writeValueAsString(value);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }
            }
        };

        Unirest.setObjectMapper(objectMapper);
    }

    abstract protected OFDBatch saveOFDDocuments(ShopOperator shopOperator, String exportDay, int period, OFDBatch batch);

    protected void validateResponse(HttpResponse resp) {
        int status = resp.getStatus();
        if (status < 200 || status > 300) {
            throw new OFDException(status, "A invalid response of status %s was returned: %s", status, resp.getBody());
        }
    }

}
