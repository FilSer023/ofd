package threewks.service.ofd;

import com.google.appengine.tools.cloudstorage.GcsFileOptions;
import com.google.appengine.tools.cloudstorage.GcsFilename;
import com.google.appengine.tools.cloudstorage.GcsOutputChannel;
import com.google.appengine.tools.cloudstorage.GcsService;
import com.google.appengine.tools.cloudstorage.GcsServiceFactory;
import com.google.appengine.tools.cloudstorage.RetryParams;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.io.IOUtils;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.repository.OFDBatchRepository;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static org.apache.commons.io.IOUtils.copy;

public class OFDDocumentUploadService {

    private static final String SAVED_DOCUMENTS_MESSAGE = "%s - %s документов из ФН %s";

    protected final Gson gson;
    private final GcsFileOptions instance = GcsFileOptions.getDefaultInstance();
    private final String gcsDefaultBucket;
    private final OFDBatchRepository batchRepository;
    private final static String NEW_TRANSACTIONS_LOCATION = "ofd/transactions/temp/%s/%s_%s_%s";
    private final static String EXPORT_LOCATION_INDIVIDUAL_RECEIPTS = "ofd/transactions/temp/%s/%s_%s_%s";
    private final static String EXPORT_LOCATION_TRADEPOINTS = "ofd/%s/%s/tradepoints/%s";
    private final static String EXPORT_LOCATION_TRADEPOINTS_KKT = "ofd/%s/%s/tradepoints_kkt/%s";
    private final GcsService gcsService =
        GcsServiceFactory.createGcsService(
            new RetryParams.Builder()
                .initialRetryDelayMillis(10)
                .retryMaxAttempts(10)
                .totalRetryPeriodMillis(15000)
                .build());

    public OFDDocumentUploadService(GsonBuilder gsonBuilder, String gcsDefaultBucket, OFDBatchRepository batchRepository) {
        this.gson = gsonBuilder.create();
        this.gcsDefaultBucket = gcsDefaultBucket;
        this.batchRepository = batchRepository;
    }

    public void saveIndividualReceipt(String kktRegNumber, String dateTime, String documentId, OFDDocument document, String shopOperatorId) {
        GcsFilename fileName = new GcsFilename(gcsDefaultBucket, String.format(EXPORT_LOCATION_INDIVIDUAL_RECEIPTS, shopOperatorId, dateTime, kktRegNumber, documentId));
        GcsOutputChannel outputChannel;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            outputChannel = gcsService.createOrReplace(fileName, instance);
            stringBuilder.append(gson.toJson(document)).append(System.lineSeparator());
            InputStream in = IOUtils.toInputStream(stringBuilder.toString(), "UTF-8");
            copy(in, Channels.newOutputStream(outputChannel));
            outputChannel.close();
            Logger.debug("Saved OFD document %s for KKT %s dateTime %s", documentId, kktRegNumber, dateTime);
        } catch (IOException e) {
            Logger.warn("Ошибка сохранения чека в хранилище GCS: %s", e.getMessage());
            throw new SaveGcsObjectException("Failed to save document to GCS: %s", e.getMessage());
        }
    }

    public OFDBatch saveTransactionDocuments(String shopOperatorId, String transactionDay, String fiscalDriveNumber, List<OFDDocument> documents, OFDBatch batch) {
        GcsFilename fileName = new GcsFilename(gcsDefaultBucket, String.format(NEW_TRANSACTIONS_LOCATION, shopOperatorId, transactionDay, fiscalDriveNumber, batch.getShopOperator().getId()));
        GcsOutputChannel outputChannel;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (!documents.isEmpty()) {
                outputChannel = gcsService.createOrReplace(fileName, instance);
                for (OFDDocument ofdDocument : documents) {
                    stringBuilder.append(gson.toJson(ofdDocument)).append(System.lineSeparator());
                }
                InputStream in = IOUtils.toInputStream(stringBuilder.toString(), "UTF-8");
                copy(in, Channels.newOutputStream(outputChannel));
                outputChannel.close();
                Logger.info("Saved OFD documents for operator: %s KKT FN: %s date: %s", shopOperatorId, fiscalDriveNumber, transactionDay);
                batch.getInfoMessages().add(String.format(SAVED_DOCUMENTS_MESSAGE, transactionDay, documents.size(), fiscalDriveNumber));
            }
        } catch (IOException e) {
            e.printStackTrace();
            batch.getErrorMessages().add("Ошибка сохранения кассовых документов в хранилище GCS: " + e.getMessage());
            batch.setStatus(BatchStatus.ERROR);
            batchRepository.put(batch);
        }
        return batch;
    }

    public OFDBatch saveTradePoints(String retailer, List<TradePoint> tradePoints, OFDBatch batch) {
        GcsFilename fileName = new GcsFilename(gcsDefaultBucket, String.format(EXPORT_LOCATION_TRADEPOINTS, batch.getId(), retailer, LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME)));
        GcsOutputChannel outputChannel;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (!tradePoints.isEmpty()) {
                outputChannel = gcsService.createOrReplace(fileName, instance);
                for (TradePoint tradePoint : tradePoints) {
                    stringBuilder.append(gson.toJson(tradePoint)).append(System.lineSeparator());
                }
                InputStream in = IOUtils.toInputStream(stringBuilder.toString(), "UTF-8");
                copy(in, Channels.newOutputStream(outputChannel));
                outputChannel.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            batch.getErrorMessages().add("Ошибка сохранения торговых точек арендатора в хранилище GCS: " + e.getMessage());
            batch.setStatus(BatchStatus.ERROR);
            batchRepository.put(batch);
        }
        return batch;
    }

    public OFDBatch saveTradePointKKTs(String retailer, List<TradePointKKT> tradePointKKTList, OFDBatch batch) {
        GcsFilename fileName = new GcsFilename(gcsDefaultBucket, String.format(EXPORT_LOCATION_TRADEPOINTS_KKT, batch.getId(), retailer, LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME)));
        GcsOutputChannel outputChannel;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            if (!tradePointKKTList.isEmpty()) {
                outputChannel = gcsService.createOrReplace(fileName, instance);
                for (TradePointKKT tradePoint : tradePointKKTList) {
                    stringBuilder.append(gson.toJson(tradePoint)).append(System.lineSeparator());
                }
                InputStream in = IOUtils.toInputStream(stringBuilder.toString(), "UTF-8");
                copy(in, Channels.newOutputStream(outputChannel));
                outputChannel.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            batch.getErrorMessages().add("Ошибка сохранения ККТ по торговым точкам арендатора в хранилище GCS: " + e.getMessage());
            batch.setStatus(BatchStatus.ERROR);
            batchRepository.put(batch);
        }
        return batch;
    }
}
