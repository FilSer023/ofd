package threewks.service.ofd.yarus;

import java.util.Map;

public class KKTByTradePointResponse {

    private Map<String, TradePointKKT> kkt;
    private Integer count;

    public Map<String, TradePointKKT> getKkt() {
        return kkt;
    }

    public KKTByTradePointResponse setKkt(Map<String, TradePointKKT> kkt) {
        this.kkt = kkt;
        return this;
    }

    public Integer getCount() {
        return count;
    }

    public KKTByTradePointResponse setCount(Integer count) {
        this.count = count;
        return this;
    }

    @Override
    public String toString() {
        return "KKTByTradePointResponse{" +
            "kkt=" + kkt +
            ", count=" + count +
            '}';
    }

    /*
"8712000100089731" : {
      "factory_number_fn" : "8712000100089731",
      "register_number_kkt" : "0000511370025895",
      "name" : "AER Hudson com_1",
      "lastreq" : "2018-06-16 06:58:07,717",
      "factory_number_kkt" : "1705659",
      "activated" : true,
      "status" : "ФД успешно обработан"
    }
 */
}
