package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ReceiptDetailsResponse {
    private String status;
    private List<String> errors = new ArrayList<>();
    @JsonProperty("Data")
    private ReceiptDetails receiptDetails;

    public String getStatus() {
        return status;
    }

    public ReceiptDetailsResponse setStatus(String status) {
        this.status = status;
        return this;
    }

    public ReceiptDetails getReceiptDetails() {
        return receiptDetails;
    }

    public ReceiptDetailsResponse setReceiptDetails(ReceiptDetails receiptDetails) {
        this.receiptDetails = receiptDetails;
        return this;
    }

    public List<String> getErrors() {
        return errors;
    }

    @Override
    public String toString() {
        return "ReceiptDetailsResponse{" +
            "status='" + status + '\'' +
            ", errors=" + StringUtils.join(errors, "; ") +
            ", receiptDetails=" + receiptDetails +
            '}';
    }
}
