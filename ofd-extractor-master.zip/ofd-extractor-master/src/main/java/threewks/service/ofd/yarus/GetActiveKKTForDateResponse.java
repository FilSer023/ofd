package threewks.service.ofd.yarus;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

public class GetActiveKKTForDateResponse {

    @JsonProperty("KKT")
    private Map<String, List<KKTDescriptor>> kkt;
    private Integer count;

    public Map<String, List<KKTDescriptor>> getKkt() {
        return kkt;
    }

    public GetActiveKKTForDateResponse setKkt(Map<String, List<KKTDescriptor>> kkt) {
        this.kkt = kkt;
        return this;
    }

    public Integer getCount() {
        return count;
    }

    public GetActiveKKTForDateResponse setCount(Integer count) {
        this.count = count;
        return this;
    }

    @Override
    public String toString() {
        return "GetActiveKKTForDateResponse{" +
            "kkt=" + kkt +
            ", count=" + count +
            '}';
    }

}
