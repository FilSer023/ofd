package threewks.service.ofd.yarus;

public class KKTByTradePointRequest {

    private Integer TP;

    public Integer getTP() {
        return TP;
    }

    public KKTByTradePointRequest setTP(Integer TP) {
        this.TP = TP;
        return this;
    }
}
