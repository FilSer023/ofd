package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class CreateAuthTokenRequest {

    private String login;
    private String password;

    public String getLogin() {
        return login;
    }

    public CreateAuthTokenRequest setLogin(String login) {
        this.login = login;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public CreateAuthTokenRequest setPassword(String password) {
        this.password = password;
        return this;
    }
}
