package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import org.joda.time.DateTime;

import java.math.BigDecimal;
import java.util.List;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ReceiptDetails {

    /*
    "Tag": 3,
    "User": "ООО \"ГЕКСАМЕРОН\"",
    "UserInn": "5009099508",
    "Number": 223,
    "DateTime": "2018-12-05T23:15:00",
    "ShiftNumber": 209,
    "OperationType": 1,
    "TaxationType": 1,
    "Operator": "Ли Евгения",
    "KKT_RegNumber": "0001862244038417    ",
    "FN_FactoryNumber": "9286000100149133",

    "Nds18_TotalSumm": 4409,
    "Nds10_TotalSumm": 1727,
    "Amount_Total": 47900,
    "Amount_Cash": 47900,
    "Amount_ECash": 0,
    "Document_Number": 50022,
    "FiscalSign": "MQSTNxJK",
    "DecimalFiscalSign": "2469859914",
     */

    private String tag;
    private String user;
    private String userInn;
    private int number;
    private DateTime dateTime;
    private int shiftNumber;
    private int operationType;
    private int taxationType;
    private String operator;
    @JsonProperty("KKT_RegNumber")
    private String kktRegNumber;
    @JsonProperty("FN_FactoryNumber")
    private String fnFactoryNumber;
    @JsonProperty("Nds18_TotalSumm")
    private BigDecimal nds18Total;
    @JsonProperty("Nds10_TotalSumm")
    private BigDecimal nds10Total;
    @JsonProperty("Amount_Total")
    private BigDecimal amountTotal;
    @JsonProperty("Amount_Cash")
    private BigDecimal amountCash;
    @JsonProperty("Amount_ECash")
    private BigDecimal amountECash;
    @JsonProperty("Document_Number")
    private int documentNumber;
    private String fiscalSign;
    private String DecimalFiscalSign;
    private List<ReceiptItem> items;

    public String getTag() {
        return tag;
    }

    public ReceiptDetails setTag(String tag) {
        this.tag = tag;
        return this;
    }

    public String getUser() {
        return user;
    }

    public ReceiptDetails setUser(String user) {
        this.user = user;
        return this;
    }

    public String getUserInn() {
        return userInn;
    }

    public ReceiptDetails setUserInn(String userInn) {
        this.userInn = userInn;
        return this;
    }

    public int getNumber() {
        return number;
    }

    public ReceiptDetails setNumber(int number) {
        this.number = number;
        return this;
    }

    public DateTime getDateTime() {
        return dateTime;
    }

    public ReceiptDetails setDateTime(DateTime dateTime) {
        this.dateTime = dateTime;
        return this;
    }

    public int getShiftNumber() {
        return shiftNumber;
    }

    public ReceiptDetails setShiftNumber(int shiftNumber) {
        this.shiftNumber = shiftNumber;
        return this;
    }

    public int getOperationType() {
        return operationType;
    }

    public ReceiptDetails setOperationType(int operationType) {
        this.operationType = operationType;
        return this;
    }

    public int getTaxationType() {
        return taxationType;
    }

    public ReceiptDetails setTaxationType(int taxationType) {
        this.taxationType = taxationType;
        return this;
    }

    public String getOperator() {
        return operator;
    }

    public ReceiptDetails setOperator(String operator) {
        this.operator = operator;
        return this;
    }

    public String getKktRegNumber() {
        return kktRegNumber;
    }

    public ReceiptDetails setKktRegNumber(String kktRegNumber) {
        this.kktRegNumber = kktRegNumber;
        return this;
    }

    public String getFnFactoryNumber() {
        return fnFactoryNumber;
    }

    public ReceiptDetails setFnFactoryNumber(String fnFactoryNumber) {
        this.fnFactoryNumber = fnFactoryNumber;
        return this;
    }

    public BigDecimal getNds18Total() {
        return nds18Total;
    }

    public ReceiptDetails setNds18Total(BigDecimal nds18Total) {
        this.nds18Total = nds18Total;
        return this;
    }

    public BigDecimal getNds10Total() {
        return nds10Total;
    }

    public ReceiptDetails setNds10Total(BigDecimal nds10Total) {
        this.nds10Total = nds10Total;
        return this;
    }

    public BigDecimal getAmountTotal() {
        return amountTotal;
    }

    public ReceiptDetails setAmountTotal(BigDecimal amountTotal) {
        this.amountTotal = amountTotal;
        return this;
    }

    public BigDecimal getAmountCash() {
        return amountCash;
    }

    public ReceiptDetails setAmountCash(BigDecimal amountCash) {
        this.amountCash = amountCash;
        return this;
    }

    public BigDecimal getAmountECash() {
        return amountECash;
    }

    public ReceiptDetails setAmountECash(BigDecimal amountECash) {
        this.amountECash = amountECash;
        return this;
    }

    public int getDocumentNumber() {
        return documentNumber;
    }

    public ReceiptDetails setDocumentNumber(int documentNumber) {
        this.documentNumber = documentNumber;
        return this;
    }

    public String getFiscalSign() {
        return fiscalSign;
    }

    public ReceiptDetails setFiscalSign(String fiscalSign) {
        this.fiscalSign = fiscalSign;
        return this;
    }

    public String getDecimalFiscalSign() {
        return DecimalFiscalSign;
    }

    public ReceiptDetails setDecimalFiscalSign(String decimalFiscalSign) {
        DecimalFiscalSign = decimalFiscalSign;
        return this;
    }

    public List<ReceiptItem> getItems() {
        return items;
    }

    public ReceiptDetails setItems(List<ReceiptItem> items) {
        this.items = items;
        return this;
    }

}
