package threewks.service.ofd.yarus;

import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.HttpRequestWithBody;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.ShopOperator;
import threewks.repository.OFDBatchRepository;
import threewks.service.ofd.OFDDocument;
import threewks.service.ofd.OFDDocumentUploadService;
import threewks.service.ofd.OFDServiceStrategy;
import threewks.service.ofd.yarus.model.YarusReceipt;
import threewks.util.HttpUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class YarusOFDServiceStrategy extends OFDServiceStrategy {

    private static final String API_BASE_URL_FORMAT = "%s/%s";
    private static final String OFD_API_TOKEN_HEADER_NAME = "Ofdapitoken";
    private static final String DOCUMENTS_URL = "ofdapi/v1/documents";
    private static final String KKT_BY_DATE_URL = "ofdapi/v2/KKT";
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final String NO_KKT_MATCHES_ERROR = "%s: нет активных ККТ из списка разрешенных";
    private static final String NO_RECEIPTS_MESSAGE = "%s: нет чеков за отчетный период";

    private final String yarusBaseUrl;
    private final OFDBatchRepository batchRepository;
    private final OFDDocumentUploadService ofdDocumentUploadService;

    public YarusOFDServiceStrategy(GsonBuilder gsonBuilder, String yarusBaseUrl, OFDBatchRepository batchRepository, OFDDocumentUploadService ofdDocumentUploadService) throws Exception {
        super(gsonBuilder);
        this.yarusBaseUrl = yarusBaseUrl;
        this.batchRepository = batchRepository;
        this.ofdDocumentUploadService = ofdDocumentUploadService;
    }

    //    .header("Ofdapitoken", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpbm4iOlsiMjMxNzA3MTM3MSJdfQ.1bZM27s7oV6W0GbpboNyEYDlfuzq-lGpow-qyeF5NNI")
    @Override
    public OFDBatch saveOFDDocuments(ShopOperator shopOperator, String exportDay, int period, OFDBatch batch) {
        Logger.info("YarusOFDServiceStrategy.saveOFDDocuments: shop operator %s from day %s for period %s days back",
            shopOperator.getName(), exportDay, period);

        LocalDate dateTime = null;
        for (int i = 0; i < period; i++) {
            dateTime = LocalDate.parse(exportDay).minusDays(i);
            batch = extractDocumentsForDay(shopOperator, dateTime.format(TODAY_FORMAT), batch);
        }
        return batch;
    }

    private OFDBatch extractDocumentsForDay(ShopOperator shopOperator, String day, OFDBatch batch) {
        Logger.info("YarusOFDServiceStrategy.extractDocumentsForDay: shop operator %s, day %s, batch %s", shopOperator.getName(), day, batch.getId());
        GetActiveKKTForDateRequest request = new GetActiveKKTForDateRequest();
        request.setDate(day);
        HttpRequestWithBody httpRequest = Unirest
            .post(String.format(API_BASE_URL_FORMAT, yarusBaseUrl, KKT_BY_DATE_URL));
        httpRequest
            .header(OFD_API_TOKEN_HEADER_NAME, shopOperator.getApiToken())
            .body(gson.toJson(request));
        HttpUtils.logRequest(httpRequest);
        GetActiveKKTForDateResponse activeKKTForDateResponse = null;
        List<String> shopOperatorAllowedKKTs = shopOperator.getTradePoints().stream()
            .map(tradePoint -> tradePoint.getKktFiscalDrives())
            .flatMap(kktFiscalDrives -> kktFiscalDrives.stream().map(kktFiscalDrive -> kktFiscalDrive.getKktRegId()))
            .collect(Collectors.toList());
        try {
            HttpResponse<GetActiveKKTForDateResponse> result = httpRequest.asObject(GetActiveKKTForDateResponse.class);
            activeKKTForDateResponse = result.getBody();
            Logger.info("Active KKTs for date: %s", activeKKTForDateResponse);
            if (activeKKTForDateResponse.getKkt() == null) {
                Logger.warn("No active KKTs for date: %s", request.getDate());
            } else {
                List<String> kktWithReceipts = activeKKTForDateResponse.getKkt().entrySet().stream().filter(entry ->
                    entry.getValue().stream().anyMatch(kktDescriptor -> kktDescriptor.getReceiptCount() > 0)
                ).map(entry -> entry.getKey()).collect(Collectors.toList());
                if (!kktWithReceipts.isEmpty()) {
                    List<String> activeFiscalDrivesForDay = activeKKTForDateResponse.getKkt().entrySet().stream().filter(entry ->
                        entry.getValue().stream().anyMatch(kktDescriptor -> shopOperatorAllowedKKTs.contains(kktDescriptor.getKktRegId())))
                        .map(entry -> entry.getKey()).collect(Collectors.toList());
                    if (CollectionUtils.isEmpty(activeFiscalDrivesForDay)) {
                        batch.getErrorMessages().add(String.format(NO_KKT_MATCHES_ERROR, day));
                    } else {
                        for (String activeFiscalDriveForDay : activeFiscalDrivesForDay) {
                            batch = retrieveKKTDocumentsForDay(shopOperator, activeFiscalDriveForDay, day, batch);
                        }
                    }
                } else {
                    batch.getInfoMessages().add(String.format(NO_RECEIPTS_MESSAGE, day));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Logger.warn("Caught exception while looking up active KKT for date: %s", e.getMessage());
            batch.getErrorMessages().add("Ошибка поиска активных ФН по дате: " + e.getMessage());
            batch.setStatus(BatchStatus.ERROR);
            batchRepository.put(batch);
            throw new RuntimeException("Ошибка поиска активных ФН по дате, сеанс будет перезапущен: ", e);
        }
        return batch;
    }

    private OFDBatch retrieveKKTDocumentsForDay(ShopOperator shopOperator, String fiscalDriveNumber, String exportDay, OFDBatch batch) {
        List<OFDDocument> documents = new ArrayList<>();
        HttpResponse<GetOFDDocumentsResponse> response = null;
        GetOFDDocumentsRequest request = new GetOFDDocumentsRequest();
        GetOFDDocumentsResponse ofdDocumentsResponse = null;

        try {
            request.setFiscalDriveNumber(fiscalDriveNumber);
            request.setDate(exportDay);
            HttpRequestWithBody httpRequest = Unirest
                .post(String.format(API_BASE_URL_FORMAT, yarusBaseUrl, DOCUMENTS_URL));
            httpRequest
                .header(OFD_API_TOKEN_HEADER_NAME, shopOperator.getApiToken())
                .body(gson.toJson(request));
            HttpUtils.logRequest(httpRequest);
            response = httpRequest.asObject(GetOFDDocumentsResponse.class);
            HttpUtils.logResponseHeaders(response);
            ofdDocumentsResponse = response.getBody();
            for (YarusReceipt yarusReceipt : ofdDocumentsResponse.getItems()) {
                documents.add(FromYarusReceiptToOFDDocument.INSTANCE.apply(batch, yarusReceipt));
            }
            batch.addReceiptsRetrieved(documents.size());
            batch = ofdDocumentUploadService.saveTransactionDocuments(shopOperator.getId(), exportDay, fiscalDriveNumber, documents, batch);
        } catch (UnirestException e) {
            Logger.warn("Caught exception retrieving OFD documents for day: %s", e.getMessage());
            batch.getErrorMessages().add(String.format("Ошибка выгрузки транзакций ФН %s для даты %s из ОФД: %s", fiscalDriveNumber, exportDay, e.getMessage()));
            batch.setStatus(BatchStatus.ERROR);
            batchRepository.put(batch);
            throw new RuntimeException(String.format("Ошибка выгрузки транзакций ФН %s для даты %s из ОФД, сеанс будет перезапущен", fiscalDriveNumber, exportDay), e);
        }

        return batch;
    }
}
