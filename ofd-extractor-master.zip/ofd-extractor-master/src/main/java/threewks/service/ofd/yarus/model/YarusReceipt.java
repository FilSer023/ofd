package threewks.service.ofd.yarus.model;

import threewks.service.ofd.ReceiptItem;

import java.math.BigDecimal;
import java.util.List;

public class YarusReceipt {

    private String dateTime;
    private String buyerPhoneOrAddress;
    private String code;
    private String userInn;
    private String kktRegId;
    private String shiftNumber;
    private String fiscalDocumentFormatVer;
    private BigDecimal totalSum;
    private BigDecimal cashTotalSum;
    private BigDecimal ecashTotalSum;
    private BigDecimal nds18118;
    private BigDecimal nds10110;
    private BigDecimal nds0;
    private BigDecimal nds10;
    private BigDecimal nds18;
    private BigDecimal ndsNo;
    private BigDecimal ndsSum;
    private BigDecimal provisionSum;
    private BigDecimal creditSum;
    private BigDecimal prepaidSum;
    private String operator;
    private String requestNumber;
    private String authorityUri;
    private String retailAddress;
    private String fiscalDocumentNumber;
    private String fiscalDriveNumber;
    private String fiscalSign;
    private String operationType;
    private String taxationType;
    private String user;
    private List<ReceiptItem> items;

    public String getDateTime() {
        return dateTime;
    }

    public YarusReceipt setDateTime(String dateTime) {
        this.dateTime = dateTime;
        return this;
    }

    public String getBuyerPhoneOrAddress() {
        return buyerPhoneOrAddress;
    }

    public YarusReceipt setBuyerPhoneOrAddress(String buyerPhoneOrAddress) {
        this.buyerPhoneOrAddress = buyerPhoneOrAddress;
        return this;
    }

    public String getCode() {
        return code;
    }

    public YarusReceipt setCode(String code) {
        this.code = code;
        return this;
    }

    public String getUserInn() {
        return userInn;
    }

    public YarusReceipt setUserInn(String userInn) {
        this.userInn = userInn;
        return this;
    }

    public String getKktRegId() {
        return kktRegId;
    }

    public YarusReceipt setKktRegId(String kktRegId) {
        this.kktRegId = kktRegId;
        return this;
    }

    public String getFiscalDriveNumber() {
        return fiscalDriveNumber;
    }

    public YarusReceipt setFiscalDriveNumber(String fiscalDriveNumber) {
        this.fiscalDriveNumber = fiscalDriveNumber;
        return this;
    }

    public String getShiftNumber() {
        return shiftNumber;
    }

    public YarusReceipt setShiftNumber(String shiftNumber) {
        this.shiftNumber = shiftNumber;
        return this;
    }

    public BigDecimal getCashTotalSum() {
        return cashTotalSum;
    }

    public YarusReceipt setCashTotalSum(BigDecimal cashTotalSum) {
        this.cashTotalSum = cashTotalSum;
        return this;
    }

    public String getOperator() {
        return operator;
    }

    public YarusReceipt setOperator(String operator) {
        this.operator = operator;
        return this;
    }

    public BigDecimal getTotalSum() {
        return totalSum;
    }

    public YarusReceipt setTotalSum(BigDecimal totalSum) {
        this.totalSum = totalSum;
        return this;
    }

    public String getRequestNumber() {
        return requestNumber;
    }

    public YarusReceipt setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
        return this;
    }

    public String getAuthorityUri() {
        return authorityUri;
    }

    public YarusReceipt setAuthorityUri(String authorityUri) {
        this.authorityUri = authorityUri;
        return this;
    }

    public String getRetailAddress() {
        return retailAddress;
    }

    public YarusReceipt setRetailAddress(String retailAddress) {
        this.retailAddress = retailAddress;
        return this;
    }

    public BigDecimal getEcashTotalSum() {
        return ecashTotalSum;
    }

    public YarusReceipt setEcashTotalSum(BigDecimal ecashTotalSum) {
        this.ecashTotalSum = ecashTotalSum;
        return this;
    }

    public String getFiscalDocumentNumber() {
        return fiscalDocumentNumber;
    }

    public YarusReceipt setFiscalDocumentNumber(String fiscalDocumentNumber) {
        this.fiscalDocumentNumber = fiscalDocumentNumber;
        return this;
    }

    public String getFiscalSign() {
        return fiscalSign;
    }

    public YarusReceipt setFiscalSign(String fiscalSign) {
        this.fiscalSign = fiscalSign;
        return this;
    }

    public String getOperationType() {
        return operationType;
    }

    public YarusReceipt setOperationType(String operationType) {
        this.operationType = operationType;
        return this;
    }

    public String getTaxationType() {
        return taxationType;
    }

    public YarusReceipt setTaxationType(String taxationType) {
        this.taxationType = taxationType;
        return this;
    }

    public String getUser() {
        return user;
    }

    public YarusReceipt setUser(String user) {
        this.user = user;
        return this;
    }

    public List<ReceiptItem> getItems() {
        return items;
    }

    public YarusReceipt setItems(List<ReceiptItem> items) {
        this.items = items;
        return this;
    }

    public YarusReceipt setNds18118(BigDecimal nds18118) {
        this.nds18118 = nds18118;
        return this;
    }

    public YarusReceipt setNds10110(BigDecimal nds10110) {
        this.nds10110 = nds10110;
        return this;
    }

    public BigDecimal getNds18118() {
        return nds18118;
    }

    public BigDecimal getNds10110() {
        return nds10110;
    }

    public BigDecimal getNds0() {
        return nds0;
    }

    public YarusReceipt setNds0(BigDecimal nds0) {
        this.nds0 = nds0;
        return this;
    }

    public BigDecimal getNdsNo() {
        return ndsNo;
    }

    public YarusReceipt setNdsNo(BigDecimal ndsNo) {
        this.ndsNo = ndsNo;
        return this;
    }

    public BigDecimal getNdsSum() {
        return ndsSum;
    }

    public YarusReceipt setNdsSum(BigDecimal ndsSum) {
        this.ndsSum = ndsSum;
        return this;
    }

    public BigDecimal getNds10() {
        return nds10;
    }

    public YarusReceipt setNds10(BigDecimal nds10) {
        this.nds10 = nds10;
        return this;
    }

    public BigDecimal getNds18() {
        return nds18;
    }

    public YarusReceipt setNds18(BigDecimal nds18) {
        this.nds18 = nds18;
        return this;
    }

    public BigDecimal getProvisionSum() {
        return provisionSum;
    }

    public YarusReceipt setProvisionSum(BigDecimal provisionSum) {
        this.provisionSum = provisionSum;
        return this;
    }

    public BigDecimal getCreditSum() {
        return creditSum;
    }

    public YarusReceipt setCreditSum(BigDecimal creditSum) {
        this.creditSum = creditSum;
        return this;
    }

    public BigDecimal getPrepaidSum() {
        return prepaidSum;
    }

    public YarusReceipt setPrepaidSum(BigDecimal prepaidSum) {
        this.prepaidSum = prepaidSum;
        return this;
    }

    public String getFiscalDocumentFormatVer() {
        return fiscalDocumentFormatVer;
    }

    public YarusReceipt setFiscalDocumentFormatVer(String fiscalDocumentFormatVer) {
        this.fiscalDocumentFormatVer = fiscalDocumentFormatVer;
        return this;
    }
}
