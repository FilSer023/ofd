package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.List;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class KKTListResponse {

    private String status;

    @JsonProperty("Data")
    private List<KKTInfo> kktList;

    public String getStatus() {
        return status;
    }

    public KKTListResponse setStatus(String status) {
        this.status = status;
        return this;
    }

    public List<KKTInfo> getKktList() {
        return kktList;
    }

    public KKTListResponse setKktList(List<KKTInfo> kktList) {
        this.kktList = kktList;
        return this;
    }

    @Override
    public String toString() {
        return "KKTListResponse{" +
            "status='" + status + '\'' +
            ", kktList=" + kktList +
            '}';
    }
}
