package threewks.service.ofd.yarus;

//empty request, simply for logical pairing with corresponding response object
public class TradePointRequest {

}
