package threewks.service.ofd.yarus;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TradePointKKT {

    /*
    "factory_number_fn" : "8712000100089731",
      "register_number_kkt" : "0000511370025895",
      "name" : "AER Hudson com_1",
      "lastreq" : "2018-06-16 06:58:07,717",
      "factory_number_kkt" : "1705659",
      "activated" : true,
      "status" : "ФД успешно обработан"
     */

    @JsonProperty("factory_number_fn")
    private String factoryNumberFn;

    @JsonProperty("register_number_kkt")
    private String registerNumberKkt;

    @JsonProperty("factory_number_kkt")
    private String factoryNumberKkt;

    private String name;
    private String lastreq;
    private String status;
    private boolean activated;

    public String getFactoryNumberFn() {
        return factoryNumberFn;
    }

    public TradePointKKT setFactoryNumberFn(String factoryNumberFn) {
        this.factoryNumberFn = factoryNumberFn;
        return this;
    }

    public String getRegisterNumberKkt() {
        return registerNumberKkt;
    }

    public TradePointKKT setRegisterNumberKkt(String registerNumberKkt) {
        this.registerNumberKkt = registerNumberKkt;
        return this;
    }

    public String getFactoryNumberKkt() {
        return factoryNumberKkt;
    }

    public TradePointKKT setFactoryNumberKkt(String factoryNumberKkt) {
        this.factoryNumberKkt = factoryNumberKkt;
        return this;
    }

    public String getName() {
        return name;
    }

    public TradePointKKT setName(String name) {
        this.name = name;
        return this;
    }

    public String getLastreq() {
        return lastreq;
    }

    public TradePointKKT setLastreq(String lastreq) {
        this.lastreq = lastreq;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public TradePointKKT setStatus(String status) {
        this.status = status;
        return this;
    }

    public boolean isActivated() {
        return activated;
    }

    public TradePointKKT setActivated(boolean activated) {
        this.activated = activated;
        return this;
    }

    @Override
    public String toString() {
        return "TradePointKKT{" +
            "factoryNumberFn='" + factoryNumberFn + '\'' +
            ", registerNumberKkt='" + registerNumberKkt + '\'' +
            ", factoryNumberKkt='" + factoryNumberKkt + '\'' +
            ", name='" + name + '\'' +
            ", lastreq='" + lastreq + '\'' +
            ", status='" + status + '\'' +
            ", activated=" + activated +
            '}';
    }
}
