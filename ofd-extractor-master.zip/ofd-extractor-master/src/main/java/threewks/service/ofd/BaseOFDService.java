package threewks.service.ofd;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.lang3.StringUtils;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.model.ShopOperator;
import threewks.service.OFDBatchService;
import threewks.service.ofd.kontur.KonturOFDServiceStrategy;
import threewks.service.ofd.peterservice.PeterServiceOFDServiceStrategy;
import threewks.service.ofd.yarus.YarusOFDServiceStrategy;
import threewks.util.Assert;

import java.util.HashMap;
import java.util.Map;

public class BaseOFDService {

    protected final Gson gson;
    private final OFDBatchService ofdBatchService;
    private static Map<OFDProvider, OFDServiceStrategy> STRATEGIES = new HashMap<>();

    public BaseOFDService(GsonBuilder gsonBuilder, YarusOFDServiceStrategy yarusOFDServiceStrategy,
        KonturOFDServiceStrategy konturOFDServiceStrategy, PeterServiceOFDServiceStrategy peterServiceOFDServiceStrategy, OFDBatchService ofdBatchService) {
        this.gson = gsonBuilder.create();
        this.ofdBatchService = ofdBatchService;
        STRATEGIES.put(OFDProvider.YARUS, yarusOFDServiceStrategy);
        STRATEGIES.put(OFDProvider.KONTUR, konturOFDServiceStrategy);
        STRATEGIES.put(OFDProvider.PETER_SERVIS, peterServiceOFDServiceStrategy);
    }

    public String extractAndUploadOFDDocuments(String batchId, ShopOperator retailer, String exportDay, int fullPeriodLength, int periodLength, String username) {
        OFDServiceStrategy ofdServiceStrategy = STRATEGIES.get(retailer.getOfdProvider());
        Assert.notNull(ofdServiceStrategy, "Could not find OFD strategy for ShopOperator %s - please check value", retailer.getName());
        OFDBatch batch;
        if (StringUtils.isNotEmpty(batchId)) {
            batch = ofdBatchService.continueBatch(batchId);
        } else {
            batch = ofdBatchService.startBatch(retailer, exportDay, fullPeriodLength, username);
        }
        batch = ofdServiceStrategy.saveOFDDocuments(retailer, exportDay, periodLength, batch);
        batch = ofdBatchService.finishBatch(batch);
        Logger.info("BaseOFDService.extractAndUploadOFDDocuments completed, batchId %s, retailer %s, day %s, period %s",
            batch.getId(), retailer.getName(), exportDay, periodLength);
        return batch.getId();
    }


}
