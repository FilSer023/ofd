package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.Date;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class KKTInfo {
    private String id;
    private String kktRegId;
    private String serialNumber;
    private String fnNumber;
    private Date createDate;
    private Date paymentDate;
    private Date checkDate;
    private Date activationDate;
    private Date firstDocumentDate;
    private Date contractStartDate;
    private Date lastDocOnKktDateTime;
    private Date lastDocOnOfdDateTimeUtc;

    public String getId() {
        return id;
    }

    public KKTInfo setId(String id) {
        this.id = id;
        return this;
    }

    public String getKktRegId() {
        return kktRegId;
    }

    public KKTInfo setKktRegId(String kktRegId) {
        this.kktRegId = kktRegId;
        return this;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public KKTInfo setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
        return this;
    }

    public String getFnNumber() {
        return fnNumber;
    }

    public KKTInfo setFnNumber(String fnNumber) {
        this.fnNumber = fnNumber;
        return this;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public KKTInfo setCreateDate(Date createDate) {
        this.createDate = createDate;
        return this;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public KKTInfo setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
        return this;
    }

    public Date getCheckDate() {
        return checkDate;
    }

    public KKTInfo setCheckDate(Date checkDate) {
        this.checkDate = checkDate;
        return this;
    }

    public Date getActivationDate() {
        return activationDate;
    }

    public KKTInfo setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
        return this;
    }

    public Date getFirstDocumentDate() {
        return firstDocumentDate;
    }

    public KKTInfo setFirstDocumentDate(Date firstDocumentDate) {
        this.firstDocumentDate = firstDocumentDate;
        return this;
    }

    public Date getContractStartDate() {
        return contractStartDate;
    }

    public KKTInfo setContractStartDate(Date contractStartDate) {
        this.contractStartDate = contractStartDate;
        return this;
    }

    public Date getLastDocOnKktDateTime() {
        return lastDocOnKktDateTime;
    }

    public KKTInfo setLastDocOnKktDateTime(Date lastDocOnKktDateTime) {
        this.lastDocOnKktDateTime = lastDocOnKktDateTime;
        return this;
    }

    public Date getLastDocOnOfdDateTimeUtc() {
        return lastDocOnOfdDateTimeUtc;
    }

    public KKTInfo setLastDocOnOfdDateTimeUtc(Date lastDocOnOfdDateTimeUtc) {
        this.lastDocOnOfdDateTimeUtc = lastDocOnOfdDateTimeUtc;
        return this;
    }

    @Override
    public String toString() {
        return "KKTInfo{" +
            "id='" + id + '\'' +
            ", kktRegId='" + kktRegId + '\'' +
            ", serialNumber='" + serialNumber + '\'' +
            ", fnNumber='" + fnNumber + '\'' +
            ", createDate=" + createDate +
            ", lastDocOnKktDateTime=" + lastDocOnKktDateTime +
            ", lastDocOnOfdDateTimeUtc=" + lastDocOnOfdDateTimeUtc +
            '}';
    }
}
