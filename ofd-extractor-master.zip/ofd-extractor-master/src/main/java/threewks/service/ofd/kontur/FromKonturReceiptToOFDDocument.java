package threewks.service.ofd.kontur;

import org.apache.commons.lang3.tuple.Triple;
import org.joda.time.DateTime;
import threewks.model.OFDBatch;
import threewks.service.ofd.OFDDocument;
import threewks.service.ofd.ReceiptItem;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.BiFunction;

public class FromKonturReceiptToOFDDocument implements BiFunction<HashMap<String, HashMap>, Triple<OFDBatch, String, String>, OFDDocument> {

    private static final String OFD_NAME = "KONTUR";
    private static final String RECEIPT_PROPERTY_NAME = "receipt";

    private static final String USER_FIELD = "user";
    private static final String USER_INN_FIELD = "userInn";
    private static final String REQUEST_NUMBER_FIELD = "requestNumber";
    private static final String RECEIPT_CODE_FIELD = "receiptCode";
    private static final String DATETIME_FIELD = "dateTime";
    private static final String CASH_TOTAL_SUM_FIELD = "cashTotalSum";
    private static final String ECASH_TOTAL_SUM_FIELD = "ecashTotalSum";
    private static final String TOTAL_SUM_FIELD = "totalSum";
    private static final String OPERATION_TYPE_FIELD = "operationType";
    private static final String TAXATION_TYPE_FIELD = "taxationType";
    private static final String SHIFT_NUMBER_FIELD = "shiftNumber";
    private static final String OPERATOR_FIELD = "operator";
    private static final String FISCAL_SIGN_FIELD = "fiscalSign";
    private static final String FISCAL_DOCUMENT_NUMBER_FIELD = "fiscalDocumentNumber";
    private static final String ITEMS_FIELD = "items";

    private static final String ITEM_NAME_FIELD = "name";
    private static final String ITEM_PRICE_FIELD = "price";
    private static final String ITEM_QUANTITY_FIELD = "quantity";
    private static final String ITEM_SUM_FIELD = "sum";

    public static FromKonturReceiptToOFDDocument INSTANCE = new FromKonturReceiptToOFDDocument();

    @Override
    public OFDDocument apply(HashMap<String, HashMap> receipt, Triple<OFDBatch, String, String> triple) {
        OFDDocument ofdDocument = new OFDDocument();
        HashMap<String, Object> receiptValues = receipt.get(RECEIPT_PROPERTY_NAME);
        ofdDocument.setOfdName(OFD_NAME);
        ofdDocument.setBatchId(triple.getLeft().getId());
        ofdDocument.setShopOperatorName(triple.getLeft().getShopOperator().getId());
        ofdDocument.setKktRegId(triple.getMiddle());
        ofdDocument.setFiscalDriveNumber(triple.getRight());
        ofdDocument.setUser(receiptValues.get(USER_FIELD).toString());
        ofdDocument.setUserInn(receiptValues.get(USER_INN_FIELD).toString());
        ofdDocument.setCode(receiptValues.get(RECEIPT_CODE_FIELD).toString());
        ofdDocument.setDateTime(DateTime.parse(receiptValues.get(DATETIME_FIELD).toString()));
        ofdDocument.setCashTotalSum(BigDecimal.valueOf((Integer) receiptValues.get(CASH_TOTAL_SUM_FIELD)));
        ofdDocument.setEcashTotalSum(BigDecimal.valueOf((Integer) receiptValues.get(ECASH_TOTAL_SUM_FIELD)));
        ofdDocument.setTotalSum(BigDecimal.valueOf((Integer) receiptValues.get(TOTAL_SUM_FIELD)));
        ofdDocument.setOperationType(receiptValues.get(OPERATION_TYPE_FIELD).toString());
        ofdDocument.setTaxationType(receiptValues.get(TAXATION_TYPE_FIELD).toString());
        ofdDocument.setShiftNumber(receiptValues.get(SHIFT_NUMBER_FIELD).toString());
        ofdDocument.setOperator(receiptValues.get(OPERATOR_FIELD).toString());
        ofdDocument.setRequestNumber(receiptValues.get(REQUEST_NUMBER_FIELD).toString());
        ofdDocument.setFiscalSign(receiptValues.get(FISCAL_SIGN_FIELD).toString());
        ofdDocument.setFiscalDocumentNumber(receiptValues.get(FISCAL_DOCUMENT_NUMBER_FIELD).toString());
        ofdDocument.setItems(parseItems((List<HashMap<String, Object>>) receiptValues.get(ITEMS_FIELD)));


//        HashMap

        /*

        ofdDocument.setNds10110(yarusReceipt.getNds10110());
        ofdDocument.setNds18118(yarusReceipt.getNds18118());
        ofdDocument.setNds10(yarusReceipt.getNds10());
        ofdDocument.setNds18(yarusReceipt.getNds18());
        ofdDocument.setNds0(yarusReceipt.getNds0());
        ofdDocument.setOperationType(yarusReceipt.getOperationType());
        ofdDocument.setTaxationType(yarusReceipt.getTaxationType());
        ofdDocument.setKktRegId(yarusReceipt.getKktRegId());
        ofdDocument.setItems(yarusReceipt.getItems());
        ofdDocument.setShiftNumber(yarusReceipt.getShiftNumber());
        ofdDocument.setTotalSum(yarusReceipt.getTotalSum());
        ofdDocument.setOperator(yarusReceipt.getOperator());
        ofdDocument.setRequestNumber(yarusReceipt.getRequestNumber());
        ofdDocument.setRetailAddress(yarusReceipt.getRetailAddress());
        ofdDocument.setFiscalSign(yarusReceipt.getFiscalSign());
        ofdDocument.setFiscalDocumentNumber(yarusReceipt.getFiscalDocumentNumber());
        ofdDocument.setFiscalDriveNumber(yarusReceipt.getFiscalDriveNumber());

        0 = {LinkedHashMap$Entry@4793} "receiptCode" -> "3"
1 = {LinkedHashMap$Entry@4794} "user" -> "ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ "ОЛИМПИНВЕСТ""
2 = {LinkedHashMap$Entry@4795} "userInn" -> "2320163664"
3 = {LinkedHashMap$Entry@4796} "requestNumber" -> "1"
4 = {LinkedHashMap$Entry@4797} "dateTime" -> "2018-06-08T18:14:00"
5 = {LinkedHashMap$Entry@4798} "shiftNumber" -> "2"
6 = {LinkedHashMap$Entry@4799} "operationType" -> "1"
7 = {LinkedHashMap$Entry@4800} "taxationType" -> "4"
8 = {LinkedHashMap$Entry@4801} "operator" -> "БАБУШКА-1"
9 = {LinkedHashMap$Entry@4802} "kktRegId" -> "0000418569025211    "
10 = {LinkedHashMap$Entry@4803} "fiscalDriveNumber" -> "9289000100057157"
11 = {LinkedHashMap$Entry@4804} "items" -> " size = 1"
12 = {LinkedHashMap$Entry@4805} "totalSum" -> "13000"
13 = {LinkedHashMap$Entry@4806} "cashTotalSum" -> "0"
14 = {LinkedHashMap$Entry@4807} "ecashTotalSum" -> "13000"
15 = {LinkedHashMap$Entry@4808} "fiscalDocumentNumber" -> "7"
16 = {LinkedHashMap$Entry@4809} "fiscalSign" -> "3739262599"

        ofdDocument.setUser(yarusReceipt.getUser());
        ofdDocument.setUserInn(yarusReceipt.getUserInn());

         */
        return ofdDocument;
    }

    private List<ReceiptItem> parseItems(List<HashMap<String, Object>> items) {
        List<ReceiptItem> receiptItems = new ArrayList<>();
        for (HashMap<String, Object> item : items) {
            ReceiptItem receiptItem = new ReceiptItem();
            receiptItem.setName((String) item.get(ITEM_NAME_FIELD));
            receiptItem.setPrice(BigDecimal.valueOf((Integer) item.get(ITEM_PRICE_FIELD)));
            receiptItem.setQuantity((item.get(ITEM_QUANTITY_FIELD)).toString());
            receiptItem.setSum(BigDecimal.valueOf((Integer) item.get(ITEM_SUM_FIELD)));
            receiptItems.add(receiptItem);
        }
        return receiptItems;
    }
}
