package threewks.service.ofd;

import org.joda.time.DateTime;

import java.math.BigDecimal;
import java.util.List;

/*
 * Общий класс для чеков от любого ОФД
 * Не все поля этого класса будут поддерживаться каждым ОФД, у каждого ОФД есть свой внутренний формат чека,
 * смотрите в соответствующем пакете для каждого ОФД
 */
public class OFDDocument {

    private String code;
    private String user;
    private String userInn;
    private String requestNumber;
    private DateTime dateTime;
    private String shiftNumber;
    private String operationType;
    private String taxationType;
    private String operator;
    private String operatorInn;
    private String kktRegId;
    private String machineNumber;
    private String retailAddress;
    private String retailPlace;
    private String buyerPhoneOrAddress;
    private List<ReceiptItem> items;
    private BigDecimal totalSum;
    private BigDecimal cashTotalSum;
    private BigDecimal ecashTotalSum;
    private BigDecimal prepaidSum;
    private BigDecimal creditSum;
    private BigDecimal provisionSum;
    private BigDecimal nds18;
    private BigDecimal nds10;
    private BigDecimal nds0;
    private BigDecimal ndsNo;
    private BigDecimal nds18118;
    private BigDecimal nds10110;
    private String internetSign;
    private String sellerAddress;
    private String paymentAgentType;
    private String operatorPhoneToTransfer;
    private String paymentAgentOperation;
    private String paymentAgentRemuneration;
    private String paymentAgentPhone;
    private String operatorToReceivePhone;
    private String operatorTransferName;
    private String operatorTransferAddress;
    private String operatorTransferInn;
    private String providerPhone;
    private String fiscalDocumentNumber;
    private String fiscalDriveNumber;
    private String fiscalSign;
    private String messageFiscalSign;
    private String rentalArea;
    private String shopOperatorName;
    private String ofdName;
    private String batchId;

    public String getCode() {
        return code;
    }

    public OFDDocument setCode(String code) {
        this.code = code;
        return this;
    }

    public String getUser() {
        return user;
    }

    public OFDDocument setUser(String user) {
        this.user = user;
        return this;
    }

    public String getUserInn() {
        return userInn;
    }

    public OFDDocument setUserInn(String userInn) {
        this.userInn = userInn;
        return this;
    }

    public String getRequestNumber() {
        return requestNumber;
    }

    public OFDDocument setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
        return this;
    }

    public DateTime getDateTime() {
        return dateTime;
    }

    public OFDDocument setDateTime(DateTime dateTime) {
        this.dateTime = dateTime;
        return this;
    }

    public String getShiftNumber() {
        return shiftNumber;
    }

    public OFDDocument setShiftNumber(String shiftNumber) {
        this.shiftNumber = shiftNumber;
        return this;
    }

    public String getOperationType() {
        return operationType;
    }

    public OFDDocument setOperationType(String operationType) {
        this.operationType = operationType;
        return this;
    }

    public String getTaxationType() {
        return taxationType;
    }

    public OFDDocument setTaxationType(String taxationType) {
        this.taxationType = taxationType;
        return this;
    }

    public String getOperator() {
        return operator;
    }

    public OFDDocument setOperator(String operator) {
        this.operator = operator;
        return this;
    }

    public String getOperatorInn() {
        return operatorInn;
    }

    public OFDDocument setOperatorInn(String operatorInn) {
        this.operatorInn = operatorInn;
        return this;
    }

    public String getKktRegId() {
        return kktRegId;
    }

    public OFDDocument setKktRegId(String kktRegId) {
        this.kktRegId = kktRegId;
        return this;
    }

    public String getMachineNumber() {
        return machineNumber;
    }

    public OFDDocument setMachineNumber(String machineNumber) {
        this.machineNumber = machineNumber;
        return this;
    }

    public String getRetailAddress() {
        return retailAddress;
    }

    public OFDDocument setRetailAddress(String retailAddress) {
        this.retailAddress = retailAddress;
        return this;
    }

    public String getRetailPlace() {
        return retailPlace;
    }

    public OFDDocument setRetailPlace(String retailPlace) {
        this.retailPlace = retailPlace;
        return this;
    }

    public String getBuyerPhoneOrAddress() {
        return buyerPhoneOrAddress;
    }

    public OFDDocument setBuyerPhoneOrAddress(String buyerPhoneOrAddress) {
        this.buyerPhoneOrAddress = buyerPhoneOrAddress;
        return this;
    }

    public List<ReceiptItem> getItems() {
        return items;
    }

    public OFDDocument setItems(List<ReceiptItem> items) {
        this.items = items;
        return this;
    }

    public BigDecimal getTotalSum() {
        return totalSum;
    }

    public OFDDocument setTotalSum(BigDecimal totalSum) {
        this.totalSum = totalSum;
        return this;
    }

    public BigDecimal getCashTotalSum() {
        return cashTotalSum;
    }

    public OFDDocument setCashTotalSum(BigDecimal cashTotalSum) {
        this.cashTotalSum = cashTotalSum;
        return this;
    }

    public BigDecimal getEcashTotalSum() {
        return ecashTotalSum;
    }

    public OFDDocument setEcashTotalSum(BigDecimal ecashTotalSum) {
        this.ecashTotalSum = ecashTotalSum;
        return this;
    }

    public BigDecimal getPrepaidSum() {
        return prepaidSum;
    }

    public OFDDocument setPrepaidSum(BigDecimal prepaidSum) {
        this.prepaidSum = prepaidSum;
        return this;
    }

    public BigDecimal getCreditSum() {
        return creditSum;
    }

    public OFDDocument setCreditSum(BigDecimal creditSum) {
        this.creditSum = creditSum;
        return this;
    }

    public BigDecimal getProvisionSum() {
        return provisionSum;
    }

    public OFDDocument setProvisionSum(BigDecimal provisionSum) {
        this.provisionSum = provisionSum;
        return this;
    }

    public BigDecimal getNds18() {
        return nds18;
    }

    public OFDDocument setNds18(BigDecimal nds18) {
        this.nds18 = nds18;
        return this;
    }

    public BigDecimal getNds10() {
        return nds10;
    }

    public OFDDocument setNds10(BigDecimal nds10) {
        this.nds10 = nds10;
        return this;
    }

    public BigDecimal getNds0() {
        return nds0;
    }

    public OFDDocument setNds0(BigDecimal nds0) {
        this.nds0 = nds0;
        return this;
    }

    public BigDecimal getNdsNo() {
        return ndsNo;
    }

    public OFDDocument setNdsNo(BigDecimal ndsNo) {
        this.ndsNo = ndsNo;
        return this;
    }

    public BigDecimal getNds18118() {
        return nds18118;
    }

    public OFDDocument setNds18118(BigDecimal nds18118) {
        this.nds18118 = nds18118;
        return this;
    }

    public BigDecimal getNds10110() {
        return nds10110;
    }

    public OFDDocument setNds10110(BigDecimal nds10110) {
        this.nds10110 = nds10110;
        return this;
    }

    public String getInternetSign() {
        return internetSign;
    }

    public OFDDocument setInternetSign(String internetSign) {
        this.internetSign = internetSign;
        return this;
    }

    public String getSellerAddress() {
        return sellerAddress;
    }

    public OFDDocument setSellerAddress(String sellerAddress) {
        this.sellerAddress = sellerAddress;
        return this;
    }

    public String getPaymentAgentType() {
        return paymentAgentType;
    }

    public OFDDocument setPaymentAgentType(String paymentAgentType) {
        this.paymentAgentType = paymentAgentType;
        return this;
    }

    public String getOperatorPhoneToTransfer() {
        return operatorPhoneToTransfer;
    }

    public OFDDocument setOperatorPhoneToTransfer(String operatorPhoneToTransfer) {
        this.operatorPhoneToTransfer = operatorPhoneToTransfer;
        return this;
    }

    public String getPaymentAgentOperation() {
        return paymentAgentOperation;
    }

    public OFDDocument setPaymentAgentOperation(String paymentAgentOperation) {
        this.paymentAgentOperation = paymentAgentOperation;
        return this;
    }

    public String getPaymentAgentRemuneration() {
        return paymentAgentRemuneration;
    }

    public OFDDocument setPaymentAgentRemuneration(String paymentAgentRemuneration) {
        this.paymentAgentRemuneration = paymentAgentRemuneration;
        return this;
    }

    public String getPaymentAgentPhone() {
        return paymentAgentPhone;
    }

    public OFDDocument setPaymentAgentPhone(String paymentAgentPhone) {
        this.paymentAgentPhone = paymentAgentPhone;
        return this;
    }

    public String getOperatorToReceivePhone() {
        return operatorToReceivePhone;
    }

    public OFDDocument setOperatorToReceivePhone(String operatorToReceivePhone) {
        this.operatorToReceivePhone = operatorToReceivePhone;
        return this;
    }

    public String getOperatorTransferName() {
        return operatorTransferName;
    }

    public OFDDocument setOperatorTransferName(String operatorTransferName) {
        this.operatorTransferName = operatorTransferName;
        return this;
    }

    public String getOperatorTransferAddress() {
        return operatorTransferAddress;
    }

    public OFDDocument setOperatorTransferAddress(String operatorTransferAddress) {
        this.operatorTransferAddress = operatorTransferAddress;
        return this;
    }

    public String getOperatorTransferInn() {
        return operatorTransferInn;
    }

    public OFDDocument setOperatorTransferInn(String operatorTransferInn) {
        this.operatorTransferInn = operatorTransferInn;
        return this;
    }

    public String getProviderPhone() {
        return providerPhone;
    }

    public OFDDocument setProviderPhone(String providerPhone) {
        this.providerPhone = providerPhone;
        return this;
    }

    public String getFiscalDocumentNumber() {
        return fiscalDocumentNumber;
    }

    public OFDDocument setFiscalDocumentNumber(String fiscalDocumentNumber) {
        this.fiscalDocumentNumber = fiscalDocumentNumber;
        return this;
    }

    public String getFiscalDriveNumber() {
        return fiscalDriveNumber;
    }

    public OFDDocument setFiscalDriveNumber(String fiscalDriveNumber) {
        this.fiscalDriveNumber = fiscalDriveNumber;
        return this;
    }

    public String getFiscalSign() {
        return fiscalSign;
    }

    public OFDDocument setFiscalSign(String fiscalSign) {
        this.fiscalSign = fiscalSign;
        return this;
    }

    public String getMessageFiscalSign() {
        return messageFiscalSign;
    }

    public OFDDocument setMessageFiscalSign(String messageFiscalSign) {
        this.messageFiscalSign = messageFiscalSign;
        return this;
    }

    public String getRentalArea() {
        return rentalArea;
    }

    public OFDDocument setRentalArea(String rentalArea) {
        this.rentalArea = rentalArea;
        return this;
    }

    public String getShopOperatorName() {
        return shopOperatorName;
    }

    public OFDDocument setShopOperatorName(String shopOperatorName) {
        this.shopOperatorName = shopOperatorName;
        return this;
    }

    public String getOfdName() {
        return ofdName;
    }

    public OFDDocument setOfdName(String ofdName) {
        this.ofdName = ofdName;
        return this;
    }

    public String getBatchId() {
        return batchId;
    }

    public OFDDocument setBatchId(String batchId) {
        this.batchId = batchId;
        return this;
    }
}
