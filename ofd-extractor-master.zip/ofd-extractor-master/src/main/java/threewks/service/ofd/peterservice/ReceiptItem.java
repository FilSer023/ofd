package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.math.BigDecimal;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
class ReceiptItem {

    /*
    "Name": "Блинчики с медом",
    "Price": 19000,
    "Quantity": 1,
    "Nds10_TotalSumm": 1727,
    "Total": 19000
     */

    private String name;
    private BigDecimal price;
    private int quantity;
    @JsonProperty("Nds10_TotalSumm")
    private BigDecimal nds10Total;
    @JsonProperty("Nds18_TotalSumm")
    private BigDecimal nds18Total;
    private BigDecimal total;

    public String getName() {
        return name;
    }

    public ReceiptItem setName(String name) {
        this.name = name;
        return this;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public ReceiptItem setPrice(BigDecimal price) {
        this.price = price;
        return this;
    }

    public int getQuantity() {
        return quantity;
    }

    public ReceiptItem setQuantity(int quantity) {
        this.quantity = quantity;
        return this;
    }

    public BigDecimal getNds10Total() {
        return nds10Total;
    }

    public ReceiptItem setNds10Total(BigDecimal nds10Total) {
        this.nds10Total = nds10Total;
        return this;
    }

    public BigDecimal getNds18Total() {
        return nds18Total;
    }

    public ReceiptItem setNds18Total(BigDecimal nds18Total) {
        this.nds18Total = nds18Total;
        return this;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public ReceiptItem setTotal(BigDecimal total) {
        this.total = total;
        return this;
    }
}
