package threewks.service.ofd.peterservice;

import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.GetRequest;
import com.mashape.unirest.request.HttpRequestWithBody;
import com.threewks.thundr.logger.Logger;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Triple;
import org.apache.http.HttpStatus;
import threewks.model.BatchStatus;
import threewks.model.OFDBatch;
import threewks.model.ReceiptDocument;
import threewks.model.ReceiptDocumentStatus;
import threewks.model.ShopOperator;
import threewks.repository.OFDBatchRepository;
import threewks.repository.ReceiptDocumentRepository;
import threewks.service.ConfigParameterService;
import threewks.service.OFDBatchService;
import threewks.service.ShopOperatorService;
import threewks.service.TaskService;
import threewks.service.ofd.OFDDocument;
import threewks.service.ofd.OFDDocumentUploadService;
import threewks.service.ofd.OFDServiceStrategy;
import threewks.service.ofd.SaveGcsObjectException;
import threewks.util.HttpUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class PeterServiceOFDServiceStrategy extends OFDServiceStrategy {

    private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static final String NULL_TOKEN_RECEIVED = "Получен пустой ключ доступа - проверьте имя пользователя и/или пароль";
    private static final String ERROR_DATA_NOT_FOUND = "DataNotFound";
    private final String peterServisBaseUrl;
    private final String peterServisUsername;
    private final String peterServisPassword;
    private final ShopOperatorService shopOperatorService;
    private final OFDBatchRepository batchRepository;
    private final OFDBatchService batchService;
    private final ReceiptDocumentRepository receiptDocumentRepository;
    private final OFDDocumentUploadService ofdDocumentUploadService;
    private final ConfigParameterService configParameterService;
    private final TaskService taskService;
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final String KKT_RECEIPT_LIST_URL_FORMAT = "%s/api/integration/v1/inn/%s/kkt/%s/receipts?AuthToken=%s&dateFrom=%s&dateTo=%s";
    private static final String KKT_LIST_URL_FORMAT = "%s/api/integration/v1/inn/%s/kkts?AuthToken=%s";
    private static final String RECEIPT_DETAIL_URL_FORMAT = "%s/api/integration/v1/inn/%s/kkt/%s/receipt/%s?AuthToken=%s";
    private static final String CREATE_TOKEN_URL_FORMAT = "%s/api/Authorization/CreateAuthToken";

    public PeterServiceOFDServiceStrategy(GsonBuilder gsonBuilder, String peterServisBaseUrl, String peterServisUsername, String peterServisPassword,
        ShopOperatorService shopOperatorService, OFDBatchRepository batchRepository, OFDBatchService batchService, ReceiptDocumentRepository receiptDocumentRepository,
        OFDDocumentUploadService ofdDocumentUploadService, ConfigParameterService configParameterService, TaskService taskService) throws Exception {
        super(gsonBuilder);
        this.peterServisBaseUrl = peterServisBaseUrl;
        this.peterServisUsername = peterServisUsername;
        this.peterServisPassword = peterServisPassword;
        this.shopOperatorService = shopOperatorService;
        this.batchRepository = batchRepository;
        this.batchService = batchService;
        this.receiptDocumentRepository = receiptDocumentRepository;
        this.ofdDocumentUploadService = ofdDocumentUploadService;
        this.configParameterService = configParameterService;
        this.taskService = taskService;
    }


    @Override
    public OFDBatch saveOFDDocuments(ShopOperator shopOperator, String exportDay, int period, OFDBatch batch) {
        Logger.info("PeterServiceOFDServiceStrategy.saveOFDDocuments: shop operator %s from day %s for period %s back",
            shopOperator.getName(), exportDay, period);

        String token = retrieveAuthToken(shopOperator, batch);
        if (StringUtils.isNotEmpty(token)) {
            batch = queueReceiptDownloadTasks(shopOperator, batch, token, exportDay, period);
        }

        return batch;
    }

    public void fetchIndividualReceipt(String shopOperatorId, String batchId, String userInn, String kktRegNumber, String docRawId, String token) {
        String fetchReceiptUrl = String.format(RECEIPT_DETAIL_URL_FORMAT, peterServisBaseUrl, userInn, kktRegNumber, docRawId, token);
        GetRequest httpRequest = Unirest
            .get(fetchReceiptUrl);
        HttpUtils.logRequest(httpRequest);
        ReceiptDetailsResponse receiptDetailsResponse = null;
        HttpResponse<ReceiptDetailsResponse> httpResponse = null;
        try {
            httpResponse = httpRequest.asObject(ReceiptDetailsResponse.class);
            if (httpResponse.getStatus() == HttpStatus.SC_FORBIDDEN) {
                //Token may have expired, get new one
                ShopOperator shopOperator = shopOperatorService.get(shopOperatorId);
                OFDBatch batch = batchService.find(batchId);
                String newToken = retrieveAuthToken(shopOperator, batch);
                taskService.fetchIndividualReceipts(shopOperatorId, batchId, userInn, kktRegNumber, docRawId, newToken);
            } else {
                receiptDetailsResponse = httpResponse.getBody();
                if (CollectionUtils.isNotEmpty(receiptDetailsResponse.getErrors())) {
                    Logger.warn("Error fetching individual receipt details: INN %s, KKT %s, receipt ID %s: %s", userInn, kktRegNumber, docRawId, receiptDetailsResponse);
                    if (receiptDetailsResponse.getErrors().contains(ERROR_DATA_NOT_FOUND)) {
                        throw new RuntimeException("Не удалось выгрузить чек с детализацией, будет произведена повторная попытка");
                    }
                } else {
                    ReceiptDetails receiptDetails = receiptDetailsResponse.getReceiptDetails();
                    OFDDocument document = FromPeterServiceReceiptToOFDDocument.INSTANCE.apply(batchId, Triple.of(shopOperatorId, receiptDetails, docRawId));
                    ofdDocumentUploadService.saveIndividualReceipt(kktRegNumber, document.getDateTime().toString(DATE_FORMAT), docRawId, document, shopOperatorId);
                    ReceiptDocument receiptDocument = receiptDocumentRepository.get(docRawId);
                    receiptDocument.setStatus(ReceiptDocumentStatus.DOWNLOADED);
                    receiptDocumentRepository.put(receiptDocument);
                }
            }
        } catch (UnirestException | SaveGcsObjectException e) {
            Logger.error("Caught exception while fetching individual receipt details: %s", e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private String retrieveAuthToken(ShopOperator shopOperator, OFDBatch batch) {
        String token = null;
        try {
            token = fetchAuthToken(shopOperator);
            if (StringUtils.isEmpty(token)) {
                failedToObtainAuthToken(batch, NULL_TOKEN_RECEIVED);
            }
        } catch (Exception e) {
            Logger.error("Caught exception while obtaining auth token: %s", e.getMessage());
            failedToObtainAuthToken(batch, e.getMessage());
        }
        return token;
    }

    public String fetchAuthToken(ShopOperator shopOperator) {
        CreateAuthTokenRequest createAuthTokenRequest = new CreateAuthTokenRequest();
        String username = shopOperator.getOfdUsername();
        String password = shopOperator.getOfdPassword();
        if (StringUtils.isEmpty(username)) {
            username = configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_USERNAME, peterServisUsername);
        }
        if (StringUtils.isEmpty(password)) {
            password = configParameterService.getConfigValueOrDefault(ConfigParameterService.PETER_SERVIS_PASSWORD, peterServisPassword);
        }
        createAuthTokenRequest
            .setLogin(username)
            .setPassword(password);
        String createTokenUrl = String.format(CREATE_TOKEN_URL_FORMAT, peterServisBaseUrl);
        HttpRequestWithBody httpRequest = Unirest
            .post(createTokenUrl)
            .header("Content-type", "application/json");
        httpRequest.body(gson.toJson(createAuthTokenRequest));
        HttpUtils.logRequest(httpRequest);
        String token = null;
        try {
            HttpResponse<AuthTokenResponse> response = httpRequest.asObject(AuthTokenResponse.class);
            AuthTokenResponse authTokenResponse = response.getBody();
            token = authTokenResponse.getAuthToken();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return token;
    }

    private OFDBatch queueReceiptDownloadTasks(ShopOperator shopOperator, OFDBatch batch, String token, String exportDay, int period) {
        String getKKTListUrl = String.format(KKT_LIST_URL_FORMAT, peterServisBaseUrl, shopOperator.getInn(), token);
        GetRequest httpRequest = Unirest
            .get(getKKTListUrl);
        HttpUtils.logRequest(httpRequest);
        KKTListResponse kktListResponse = null;
        HttpResponse<KKTListResponse> result = null;
        try {
            result = httpRequest.asObject(KKTListResponse.class);
            kktListResponse = result.getBody();
            Logger.info("KKTs for shop operator: %s", kktListResponse);
            List<String> registersToProcess = shopOperator.getTradePoints().stream().flatMap(tradePoint -> tradePoint.getKktFiscalDrives().stream())
                .map(kktFiscalDrive -> kktFiscalDrive.getKktRegId()).collect(Collectors.toList());

            for (KKTInfo kktInfo : kktListResponse.getKktList()) {
                if (registersToProcess.contains(kktInfo.getKktRegId())) {
                    fetchReceiptDocumentSummaryForKKT(token, shopOperator, kktInfo, exportDay, period, batch);
                }
            }
        } catch (Exception e) {
            Logger.error("Caught exception while looking up KKTs for shop operator: %s - %s", e.toString(), e.getMessage());
            batch.getErrorMessages().add("Ошибка поиска ККТ: " + e.getMessage());
            batch.setStatus(BatchStatus.ERROR);
            batchRepository.put(batch);
        }
        batch.setStatus(BatchStatus.RECEIPT_SUMMARIES_RETRIEVED);
        return batch;
    }

    private void fetchReceiptDocumentSummaryForKKT(String token, ShopOperator shopOperator, KKTInfo kktInfo, String exportDay, int period, OFDBatch batch) {
        LocalDate dateFrom = null;
        LocalDate dateTo = null;
        String getReceiptSummaryForKKTUrl = null;
        HttpResponse<ReceiptSummaryListResponse> result = null;
        ReceiptSummaryListResponse receiptSummaryListResponse = null;
        List<ReceiptDocument> dailyReceiptSummary;
        if (StringUtils.isEmpty(kktInfo.getKktRegId())) {
            Logger.info("ФН %s - отсутствует идентификатор ККТ, выгрузка чеков невозможна: %s", kktInfo.getFnNumber());
            return;
        }
        for (int i = 0; i <= period; i++) {
            dateFrom = LocalDate.parse(exportDay).minusDays(i + 1);
            dateTo = LocalDate.parse(exportDay).minusDays(i);
            getReceiptSummaryForKKTUrl = String.format(KKT_RECEIPT_LIST_URL_FORMAT, peterServisBaseUrl,
                shopOperator.getInn(), kktInfo.getKktRegId(), token,
                dateFrom.format(TODAY_FORMAT), dateTo.format(TODAY_FORMAT));
            GetRequest httpRequest = Unirest
                .get(getReceiptSummaryForKKTUrl);
            HttpUtils.logRequest(httpRequest);
            dailyReceiptSummary = new ArrayList<>();
            try {
                result = httpRequest.asObject(ReceiptSummaryListResponse.class);
                receiptSummaryListResponse = result.getBody();
                List<ReceiptSummary> receiptSummaries = receiptSummaryListResponse.getReceiptSummaryList();
                int receiptSummariesFetched = receiptSummaries.size();
                for (ReceiptSummary receiptSummary : receiptSummaries) {
                    if (receiptDocumentRepository.notExists(receiptSummary.getId())) {
                        Logger.info("Receipt doesn't exist, queueing: %s", receiptSummary.getId());
                        ReceiptDocument receiptDocument = new ReceiptDocument();
                        receiptDocument.setId(receiptSummary.getId())
                            .setBatchId(batch.getId())
                            .setDocRawId(receiptSummary.getDocRawId())
                            .setCreated(new Date())
                            .setKktRegId(kktInfo.getKktRegId())
                            .setInn(receiptSummary.getUserInn())
                            .setShopOperator(shopOperator)
                            .setStatus(ReceiptDocumentStatus.QUEUED);
                        dailyReceiptSummary.add(receiptDocument);
                        taskService.fetchIndividualReceipts(batch.getShopOperator().getId(), batch.getId(), receiptSummary.getUserInn(), receiptSummary.getKktRegNumber(), receiptSummary.getDocRawId(), token);
                    } else {
                        Logger.info("Receipt exists, skipping: %s", receiptSummary.getId());
                    }
                }
                batch.addReceiptsRetrieved(receiptSummaries.size());
                batch.getInfoMessages().add(String.format("ККТ %s: выгружено %s чеков (без детализации)", kktInfo.getKktRegId(), receiptSummariesFetched));
                Logger.info("KKT %s: выгружено %s чеков (без детализации)", kktInfo.getKktRegId(), receiptSummariesFetched);
                if (!dailyReceiptSummary.isEmpty()) {
                    receiptDocumentRepository.put(dailyReceiptSummary);
                }
            } catch (UnirestException e) {
                String errorMessage = "Ошибка выборки отчетов по ККТ: " + e.getMessage();
                Logger.error("Caught exception while retrieving receipts for KKTs for shop operator: %s", e.getMessage());
                batch.getErrorMessages().add(errorMessage);
                batch.setStatus(BatchStatus.ERROR);
                batchRepository.put(batch);
                throw new RuntimeException(errorMessage);
            }
        }
    }

    private void failedToObtainAuthToken(OFDBatch batch, String message) {
        String errorMessage = "Ошибка получения сессионного ключа доступа: " + message;
        batch.getErrorMessages().add(errorMessage);
        batch.setStatus(BatchStatus.ERROR);
        batchRepository.put(batch);
        throw new RuntimeException(errorMessage);
    }
}
