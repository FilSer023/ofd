package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ReceiptSummary {

    private String id;
    private String docRawId;
    private String userInn;
    private String kktRegNumber;
    private String receiptNumber;
    private String docShiftNumber;

    public String getId() {
        return id;
    }

    public ReceiptSummary setId(String id) {
        this.id = id;
        return this;
    }

    public String getDocRawId() {
        return docRawId;
    }

    public ReceiptSummary setDocRawId(String docRawId) {
        this.docRawId = docRawId;
        return this;
    }

    public String getReceiptNumber() {
        return receiptNumber;
    }

    public ReceiptSummary setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber;
        return this;
    }

    public String getDocShiftNumber() {
        return docShiftNumber;
    }

    public ReceiptSummary setDocShiftNumber(String docShiftNumber) {
        this.docShiftNumber = docShiftNumber;
        return this;
    }

    public String getUserInn() {
        return userInn;
    }

    public ReceiptSummary setUserInn(String userInn) {
        this.userInn = userInn;
        return this;
    }

    public String getKktRegNumber() {
        return kktRegNumber;
    }

    public ReceiptSummary setKktRegNumber(String kktRegNumber) {
        this.kktRegNumber = kktRegNumber;
        return this;
    }
}
