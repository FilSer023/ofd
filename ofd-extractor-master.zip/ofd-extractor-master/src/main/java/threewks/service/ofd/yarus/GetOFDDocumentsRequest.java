package threewks.service.ofd.yarus;

public class GetOFDDocumentsRequest {

    private String fiscalDriveNumber;
    private String date;

    public GetOFDDocumentsRequest() {
    }

    public String getFiscalDriveNumber() {
        return fiscalDriveNumber;
    }

    public GetOFDDocumentsRequest setFiscalDriveNumber(String fiscalDriveNumber) {
        this.fiscalDriveNumber = fiscalDriveNumber;
        return this;
    }

    public String getDate() {
        return date;
    }

    public GetOFDDocumentsRequest setDate(String date) {
        this.date = date;
        return this;
    }
}
