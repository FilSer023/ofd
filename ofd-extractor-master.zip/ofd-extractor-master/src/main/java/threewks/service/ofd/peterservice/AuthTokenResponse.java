package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.Date;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class AuthTokenResponse {

    private String authToken;
    private Date expirationDateUtc;

    public String getAuthToken() {
        return authToken;
    }

    public AuthTokenResponse setAuthToken(String authToken) {
        this.authToken = authToken;
        return this;
    }

    public Date getExpirationDateUtc() {
        return expirationDateUtc;
    }

    public AuthTokenResponse setExpirationDateUtc(Date expirationDateUtc) {
        this.expirationDateUtc = expirationDateUtc;
        return this;
    }
}
