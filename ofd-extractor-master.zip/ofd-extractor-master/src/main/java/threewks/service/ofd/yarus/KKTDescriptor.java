package threewks.service.ofd.yarus;

import com.fasterxml.jackson.annotation.JsonProperty;

public class KKTDescriptor {

    private String address;
    private String last;
    @JsonProperty("kktregid")
    private String kktRegId;
    private Integer turnover;
    private Integer receiptCount;

    public String getAddress() {
        return address;
    }

    public KKTDescriptor setAddress(String address) {
        this.address = address;
        return this;
    }

    public String getLast() {
        return last;
    }

    public KKTDescriptor setLast(String last) {
        this.last = last;
        return this;
    }

    public String getKktRegId() {
        return kktRegId;
    }

    public KKTDescriptor setKktRegId(String kktRegId) {
        this.kktRegId = kktRegId;
        return this;
    }

    public Integer getTurnover() {
        return turnover;
    }

    public KKTDescriptor setTurnover(Integer turnover) {
        this.turnover = turnover;
        return this;
    }

    public Integer getReceiptCount() {
        return receiptCount;
    }

    public KKTDescriptor setReceiptCount(Integer receiptCount) {
        this.receiptCount = receiptCount;
        return this;
    }

    @Override
    public String toString() {
        return "KKTDescriptor{" +
            "address='" + address + '\'' +
            ", last='" + last + '\'' +
            ", kktRegId='" + kktRegId + '\'' +
            ", turnover=" + turnover +
            ", receiptCount=" + receiptCount +
            '}';
    }

    /*
    {
      "address" : "Краснодар, ул.им. Евдокии Бершанской 355",
      "last" : "-/-/-",
      "kktregid" : "0000488670026842",
      "turnover" : 0,
      "receiptCount" : 0
    }
     */

}
