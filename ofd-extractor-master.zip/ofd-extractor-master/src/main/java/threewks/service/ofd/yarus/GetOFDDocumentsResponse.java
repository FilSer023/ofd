package threewks.service.ofd.yarus;

import threewks.service.ofd.yarus.model.YarusReceipt;

import java.util.List;

public class GetOFDDocumentsResponse {

    private List<YarusReceipt> items;
    private String count;
    private String code;
    private String desc;

    public List<YarusReceipt> getItems() {
        return items;
    }

    public GetOFDDocumentsResponse setItems(List<YarusReceipt> items) {
        this.items = items;
        return this;
    }

    public String getCode() {
        return code;
    }

    public GetOFDDocumentsResponse setCode(String code) {
        this.code = code;
        return this;
    }

    public String getDesc() {
        return desc;
    }

    public GetOFDDocumentsResponse setDesc(String desc) {
        this.desc = desc;
        return this;
    }

    public String getCount() {
        return count;
    }

    public GetOFDDocumentsResponse setCount(String count) {
        this.count = count;
        return this;
    }

    @Override
    public String toString() {
        return "GetOFDDocumentsResponse{" +
            "items=" + items +
            ", count='" + count + '\'' +
            ", code='" + code + '\'' +
            ", desc='" + desc + '\'' +
            '}';
    }
}
