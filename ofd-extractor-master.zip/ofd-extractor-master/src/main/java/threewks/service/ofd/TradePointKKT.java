package threewks.service.ofd;

public class TradePointKKT {

    private String name;
    private String factoryNumber;
    private String registerNumberKkt;
    private String factoryNumberKkt;
    private String lastreq;
    private String status;
    private boolean activated;

    public String getName() {
        return name;
    }

    public TradePointKKT setName(String name) {
        this.name = name;
        return this;
    }

    public String getFactoryNumber() {
        return factoryNumber;
    }

    public TradePointKKT setFactoryNumber(String factoryNumber) {
        this.factoryNumber = factoryNumber;
        return this;
    }

    public String getRegisterNumberKkt() {
        return registerNumberKkt;
    }

    public TradePointKKT setRegisterNumberKkt(String registerNumberKkt) {
        this.registerNumberKkt = registerNumberKkt;
        return this;
    }

    public String getFactoryNumberKkt() {
        return factoryNumberKkt;
    }

    public TradePointKKT setFactoryNumberKkt(String factoryNumberKkt) {
        this.factoryNumberKkt = factoryNumberKkt;
        return this;
    }

    public String getLastreq() {
        return lastreq;
    }

    public TradePointKKT setLastreq(String lastreq) {
        this.lastreq = lastreq;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public TradePointKKT setStatus(String status) {
        this.status = status;
        return this;
    }

    public boolean isActivated() {
        return activated;
    }

    public TradePointKKT setActivated(boolean activated) {
        this.activated = activated;
        return this;
    }
}
