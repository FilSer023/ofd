package threewks.service.ofd.peterservice;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.List;

@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ReceiptSummaryListResponse {

    private String status;

    @JsonProperty("Data")
    private List<ReceiptSummary> receiptSummaryList;

    public String getStatus() {
        return status;
    }

    public ReceiptSummaryListResponse setStatus(String status) {
        this.status = status;
        return this;
    }

    public List<ReceiptSummary> getReceiptSummaryList() {
        return receiptSummaryList;
    }

    public ReceiptSummaryListResponse setReceiptSummaryList(List<ReceiptSummary> receiptSummaryList) {
        this.receiptSummaryList = receiptSummaryList;
        return this;
    }
}
