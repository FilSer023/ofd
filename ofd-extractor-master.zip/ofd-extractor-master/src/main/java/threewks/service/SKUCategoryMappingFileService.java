package threewks.service;

import threewks.model.SKUCategoryMappingFile;
import threewks.repository.SKUCategoryMappingFileRepository;

import java.util.Date;

public class SKUCategoryMappingFileService {

    private final SKUCategoryMappingFileRepository skuCategoryMappingFileRepository;

    public SKUCategoryMappingFileService(SKUCategoryMappingFileRepository skuCategoryMappingFileRepository) {
        this.skuCategoryMappingFileRepository = skuCategoryMappingFileRepository;
    }

    public SKUCategoryMappingFile getLatest() {
        return skuCategoryMappingFileRepository.getLatest();
    }

    public SKUCategoryMappingFile create(String gcsFilePath, Integer lines) {
        SKUCategoryMappingFile skuCategoryMappingFile = new SKUCategoryMappingFile();
        skuCategoryMappingFile.setGcsLocation(gcsFilePath);
        skuCategoryMappingFile.setLines(lines);
        skuCategoryMappingFile.setTimeGenerated(new Date());
        return skuCategoryMappingFileRepository.put(skuCategoryMappingFile);
    }
}
