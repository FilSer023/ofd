package threewks.service.bootstrap;

import com.googlecode.objectify.ObjectifyService;
import com.googlecode.objectify.VoidWork;
import com.threewks.thundr.configuration.Environment;
import com.threewks.thundr.logger.Logger;
import com.threewks.thundr.user.Roles;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import threewks.framework.usermanager.model.AppUser;
import threewks.framework.usermanager.model.UserStatus;
import threewks.framework.usermanager.service.AppUserService;
import threewks.model.AirportCatalog;
import threewks.model.BatchStatus;
import threewks.model.ConfigParameter;
import threewks.model.OFDBatch;
import threewks.model.OFDProvider;
import threewks.model.PassengerFeedBatch;
import threewks.model.PassengerFeedBatchStatus;
import threewks.model.RentalArea;
import threewks.model.RentalAreaStatus;
import threewks.model.RentalAreaZone;
import threewks.model.ShopOperator;
import threewks.model.ShopOperatorStatus;
import threewks.model.UnmatchedSKUItem;
import threewks.repository.OFDBatchRepository;
import threewks.repository.PassengerFeedBatchRepository;
import threewks.repository.RentalAreaRepository;
import threewks.repository.ShopOperatorRepository;
import threewks.repository.UnmatchedSKUItemRepository;
import threewks.service.AirportCatalogService;
import threewks.service.ConfigParameterService;
import threewks.service.SubSectionCategoryService;
import threewks.service.UnmatchedCategoryReportService;
import threewks.util.Assert;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import static com.atomicleopard.expressive.Expressive.map;
import static java.util.Arrays.asList;
import static java.util.UUID.randomUUID;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;

public class BootstrapService {
    private static final String MARKER = StringUtils.repeat('#', 20);
    private static final DateTimeFormatter TODAY_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final AppUserService userService;
    private final ShopOperatorRepository shopOperatorRepository;
    private final OFDBatchRepository ofdBatchRepository;
    private final PassengerFeedBatchRepository passengerFeedBatchRepository;
    private final RentalAreaRepository rentalAreaRepository;
    private final UnmatchedSKUItemRepository unmatchedSKUItemRepository;
    private final String superAdminEmail;
    private final UnmatchedCategoryReportService unmatchedCategoryReportService;
    private final SubSectionCategoryService subSectionCategoryService;
    private final ConfigParameterService configParameterService;
    private final AirportCatalogService airportCatalogService;

    public BootstrapService(AppUserService userService, ShopOperatorRepository shopOperatorRepository, OFDBatchRepository ofdBatchRepository,
        PassengerFeedBatchRepository passengerFeedBatchRepository, RentalAreaRepository rentalAreaRepository,
        UnmatchedSKUItemRepository unmatchedSKUItemRepository, String superAdminEmail,
        UnmatchedCategoryReportService unmatchedCategoryReportService,
        SubSectionCategoryService subSectionCategoryService, ConfigParameterService configParameterService, AirportCatalogService airportCatalogService) {
        this.userService = userService;
        this.shopOperatorRepository = shopOperatorRepository;
        this.ofdBatchRepository = ofdBatchRepository;
        this.passengerFeedBatchRepository = passengerFeedBatchRepository;
        this.rentalAreaRepository = rentalAreaRepository;
        this.unmatchedSKUItemRepository = unmatchedSKUItemRepository;
        this.superAdminEmail = superAdminEmail;
        this.unmatchedCategoryReportService = unmatchedCategoryReportService;
        this.subSectionCategoryService = subSectionCategoryService;
        this.configParameterService = configParameterService;
        this.airportCatalogService = airportCatalogService;
    }

    public void bootstrapLocal() {
        Assert.isTrue(Environment.is(Environment.DEV), "This can only be run in a local dev environment");
        logStart();

        ObjectifyService.run(new VoidWork() {
            @Override
            public void vrun() {
                // Your bootstrap methods go here. Tips: do a check and only bootstrap if data not there; and add logging so you know what happened.
//                createSuperUser();
                createAirportCatalog();
                createRentalArea();
                createUnmatchedCategoryReport();
                createOFDBatch();
                createPassengerFeedBatch();
                createSubsectionCategories();
                createSampleConfigParameter();
                createUnmatchedSKUItems();
                createShopOperator();
            }
        });

        logEnd();
    }

    private void createUnmatchedSKUItems() {
        List<UnmatchedSKUItem> items = unmatchedSKUItemRepository.listAll();
        if (items.isEmpty()) {
            unmatchedSKUItemRepository.put(new UnmatchedSKUItem("Пирожок с капустой").setOperatorName("Три пескаря"));
            unmatchedSKUItemRepository.put(new UnmatchedSKUItem("Пирожок с вишней").setOperatorName("Три пескаря"));
            unmatchedSKUItemRepository.put(new UnmatchedSKUItem("Морс клюквенный").setOperatorName("Арома"));
        }
    }

    private void createPassengerFeedBatch() {
        for (int i = 0; i < 7; i++) {
            LocalDateTime date = LocalDateTime.now().minusDays(i);
            PassengerFeedBatch passengerFeedBatch = new PassengerFeedBatch(date.format(TODAY_FORMAT));
            passengerFeedBatch.setTimeStarted(Date.from(date.toInstant(ZoneOffset.UTC)));
            passengerFeedBatch.setTimeFinished(Date.from(date.plusMinutes(10).toInstant(ZoneOffset.UTC)));
            passengerFeedBatch.setStatus(i % 2 == 0 ? PassengerFeedBatchStatus.DATA_IMPORTED : PassengerFeedBatchStatus.ERROR);
            passengerFeedBatch.getLinesImported().putAll(map("KRR", 100, "AER", 140, "AAQ", 75));
            passengerFeedBatch.getInfoMessages().add("Данные пассажиропотока успешно импортированы");
            passengerFeedBatchRepository.put(passengerFeedBatch);
        }

    }

    private void createRentalArea() {
        List<RentalArea> rentalAreas = rentalAreaRepository.listAll();
        List<AirportCatalog> airports = airportCatalogService.list();
        if (rentalAreas.isEmpty()) {
            RentalArea rentalArea1 = new RentalArea();
            rentalArea1.setName("МВЛ4");
            rentalArea1.setAirportCatalog(airports.get(RandomUtils.nextInt(0, airports.size() - 1)));
            rentalArea1.setZone(RentalAreaZone.DEPARTURE);
            rentalArea1.setStatus(RentalAreaStatus.ACTIVE);
            rentalAreaRepository.put(rentalArea1);
            RentalArea rentalArea2 = new RentalArea();
            rentalArea2.setName("ВВЛ25");
            rentalArea2.setAirportCatalog(airports.get(RandomUtils.nextInt(0, airports.size() - 1)));
            rentalArea2.setZone(RentalAreaZone.DEPARTURE);
            rentalArea2.setStatus(RentalAreaStatus.ACTIVE);
            rentalAreaRepository.put(rentalArea2);
        }
    }

    private void createOFDBatch() {
        List<ShopOperator> shopOperators = shopOperatorRepository.listAll();
        List<OFDBatch> batches = ofdBatchRepository.listAll();
        if (!shopOperators.isEmpty() && batches.isEmpty()) {
            ShopOperator shopOperator = shopOperators.get(0);
            for (int i = 0; i < 5; i++) {
                OFDBatch ofdBatch1 = new OFDBatch(shopOperator);
                ofdBatch1.setTimeStarted(new DateTime().minusDays(i).toDate());
                ofdBatch1.setTimeFinished(new DateTime().minusDays(i).toDate());
                ofdBatch1.setBatchDay(SimpleDateFormat.getDateInstance().format(new DateTime().minusDays(i).toDate()));
                ofdBatch1.setStatus(BatchStatus.DATA_IMPORTED_INTO_CLEAN);
                ofdBatch1.setPeriodLength(10);
                ofdBatch1.setInfoMessages(asList("Успешно сохранил 15 документов из ФН 8710000100431387"));
                ofdBatchRepository.put(ofdBatch1);
                OFDBatch ofdBatch2 = new OFDBatch(shopOperator);
                ofdBatch2.setTimeStarted(new DateTime().minusDays(i).toDate());
                ofdBatch2.setPeriodLength(20);
                ofdBatch2.setTimeFinished(new DateTime().minusDays(i).toDate());
                ofdBatch2.setBatchDay(SimpleDateFormat.getDateInstance().format(new DateTime().minusDays(i).toDate()));
                ofdBatch2.setStatus(BatchStatus.DATA_IMPORTED_INTO_CLEAN);
                ofdBatch2.setInfoMessages(asList("Успешно сохранил 15 документов из ФН 8710000100431387"));
                ofdBatchRepository.put(ofdBatch2);
            }
            OFDBatch ofdBatchError = new OFDBatch(shopOperator);
            ofdBatchError.setTimeStarted(new DateTime().minusDays(2).toDate());
            ofdBatchError.setTimeFinished(new DateTime().minusDays(2).toDate());
            ofdBatchError.setBatchDay(SimpleDateFormat.getDateInstance().format(new DateTime().minusDays(2).toDate()));
            ofdBatchError.setStatus(BatchStatus.ERROR);
            ofdBatchError.setPeriodLength(35);
            ofdBatchError.setErrorMessages(asList("Ошибка выгрузки документов для ФН 8710000100431381"));
            ofdBatchRepository.put(ofdBatchError);
        }
    }

    private void createShopOperator() {
        List<ShopOperator> shopOperators = shopOperatorRepository.listAll();
        if (shopOperators.isEmpty()) {
            ShopOperator shopOperator = new ShopOperator();
            shopOperator
                .setName("Шоколадница")
                .setStatus(ShopOperatorStatus.ACTIVE)
                .setOfdProvider(OFDProvider.PETER_SERVIS);

//                .setEmail("krd@shokoladnitsa.ru")
//                .setPhone("7654321");
            shopOperatorRepository.put(shopOperator);
        }
    }

    private void createSampleConfigParameter() {
        ConfigParameter configParameter = new ConfigParameter();
        configParameter.setName("Ярус");
        configParameter.setValue("12345");
        configParameterService.save(configParameter);
    }

    private void createUnmatchedCategoryReport() {
//        List<UnmatchedCategoryReport> unmatchedCategoryReports = unmatchedCategoryReportService.getRecent();
//        if (unmatchedCategoryReports.isEmpty()) {
//            UnmatchedCategoryReport unmatchedCategoryReport = new UnmatchedCategoryReport();
//            unmatchedCategoryReport.setGcsFileName("UnmatchedSKU_1530103967165.csv");
//            unmatchedCategoryReport.setCount(250L);
//            MissingCategory missingCategory = new MissingCategory();
//            missingCategory.setSku("Ice Cream");
//            missingCategory.setPrice("10000");
//            missingCategory.setShopOperator("Babushka");
//            List<MissingCategory> missingCategories = new ArrayList<>();
//            missingCategories.add(missingCategory);
//            missingCategory = new MissingCategory();
//            missingCategory.setSku("Chocolate");
//            missingCategory.setPrice("10000");
//            missingCategory.setShopOperator("Toy");
//            missingCategories.add(missingCategory);
//            unmatchedCategoryReportService.save(unmatchedCategoryReport);
//
//        }
    }

    public void createAirportCatalog() {
        if (airportCatalogService.list().isEmpty()) {
            AirportCatalog airportCatalog;

            airportCatalog = new AirportCatalog();
            airportCatalog.setNameIATA("AAQ");
            airportCatalog.setDescription("Анапа");
            airportCatalogService.save(airportCatalog);

            airportCatalog = new AirportCatalog();
            airportCatalog.setNameIATA("AER");
            airportCatalog.setDescription("Сочи");
            airportCatalogService.save(airportCatalog);

            airportCatalog = new AirportCatalog();
            airportCatalog.setNameIATA("KRR");
            airportCatalog.setDescription("Краснодар");
            airportCatalogService.save(airportCatalog);
        }
    }

    public void createSuperUser() {
        if (userService.get(superAdminEmail) == null) {
            AppUser user = new AppUser(randomUUID().toString());
            user.setStatus(UserStatus.ACTIVE);
            user.setEmail(superAdminEmail);
            user.setRoles(new Roles(Roles.Super, Roles.Admin));

            String password = Environment.is(Environment.DEV)
                ? "password" : randomAlphanumeric(12);

            userService.register(user, password);

            Logger.info("Created super admin user %s with password %s.", user.getEmail(), password);
        }
    }

    private void logStart() {
        Logger.info("%1$s    LOCAL BOOTSTRAP START   %1$s\n", MARKER);
    }

    private void logEnd() {
        Logger.info("%1$s    LOCAL BOOTSTRAP END     %1$s\n", MARKER);
    }

    private void createSubsectionCategories() {
        if (subSectionCategoryService.list().size() == 0) {
            this.subSectionCategoryService.save("Аксессуары");
            this.subSectionCategoryService.save("Багаж");
            this.subSectionCategoryService.save("Косметика");
        }
    }
    /*id: "Аксессуары", description: "Аксессуары"}, {id: "Багаж", description: "Багаж"},
    {id: "Косметика", description: "Косметика"*/

}
