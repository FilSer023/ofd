package threewks.service;

import threewks.model.SubSectionCategory;
import threewks.repository.SubSectionCategoryRepository;

import java.util.List;

public class SubSectionCategoryService {

    private final SubSectionCategoryRepository subSectionCategoryRepository;

    public SubSectionCategoryService(SubSectionCategoryRepository subSectionCategoryRepository) {
        this.subSectionCategoryRepository = subSectionCategoryRepository;
    }

    public List<SubSectionCategory> getByName(String name) {
        return this.subSectionCategoryRepository.findByName(name);
    }

    public List<SubSectionCategory> list() {
        return this.subSectionCategoryRepository.listAll();
    }


    public SubSectionCategory save(String newSubsectionCategoryName) {
        SubSectionCategory existing = subSectionCategoryRepository.findByExactName(newSubsectionCategoryName);
        if (existing == null) {
            SubSectionCategory subSectionCategory = new SubSectionCategory(newSubsectionCategoryName);
            existing = subSectionCategoryRepository.put(subSectionCategory);
        }
        return existing;
    }

    public SubSectionCategory update(String id, String name) {
        SubSectionCategory existing = subSectionCategoryRepository.get(id);
        existing.setName(name);
        return subSectionCategoryRepository.put(existing);
    }

    public void delete(String id) {
        subSectionCategoryRepository.deleteByKey(id);
    }
}
