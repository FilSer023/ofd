import uiRouter, {StateProvider} from "@uirouter/angularjs";
import * as angular from "angular";

import "angular-moment";
import "angular-sanitize";
import "angular-ui-bootstrap";
import "ui-select";
import "../common/main.less";
import "angular-animate";
import "angularjs-toaster";
import "ng-tags-input";
import {AdminModule} from "./admin/admin.module";
import {AppComponent} from "./app.component";
import {GreetingsModule} from "./greetings/greetings.module";
import {ConfigModule} from "./shared/config/config.module";
import {ReferenceDataModule} from "./shared/reference-data/reference-data.module";
import {ReferenceData} from "./shared/reference-data/reference-data.service";
import {UserModule} from "./shared/user/user.module";
import "../../../../node_modules/angularjs-toaster/toaster.css";
import "../../../../node_modules/angularjs-toaster/toaster.min.css";
import {LoadingServiceModule} from "./shared/loading-service/loading-service.module";

angular
    .module("app", [
        "angularMoment",
        "ui.bootstrap",
        "ui.select",
        "ngSanitize",
        "toaster",
        "ngAnimate",
        "ngTagsInput",
        uiRouter,
        ConfigModule,
        ReferenceDataModule,
        LoadingServiceModule,
        GreetingsModule,
        AdminModule,
        UserModule
    ])
    .component("app", AppComponent)

    .config(($stateProvider: StateProvider) => {
        $stateProvider
            .state("app", {
                abstract: true,
                resolve: {
                    referenceDataInit: (referenceData: ReferenceData) => referenceData.init()
                }
            })
            .state("app.home", {
                url: "/",
                component: "app"
            });
    });
