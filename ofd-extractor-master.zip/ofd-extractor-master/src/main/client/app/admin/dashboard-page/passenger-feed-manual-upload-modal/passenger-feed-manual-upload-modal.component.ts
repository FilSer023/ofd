import {IComponentOptions, ILogService} from "angular";
import {LoadingService} from "../../../shared/loading-service/loading-service.service";
import {PassengerFeedManualUpload} from "../../model/passenger-feed-manual-upload";
import {PassengerFeedManualUploadService} from "../../service/passenger-feed-manual-upload.service";
import "./passenger-feed-manual-upload-modal.less";
import * as _ from "lodash";
import {AirportCatalog} from "../../model/catalogs/airport-catalog";


class PassengerFeedManualUploadModalController {

    public close: any;
    public dismiss: any;
    public loading: boolean;
    public resolve: any;
    public form: any;
    private passengerFeedManualUpload: PassengerFeedManualUpload;
    private airports: AirportCatalog[] = [];
    private showErrors: boolean;


    /* @ngInject */
    constructor(private $log: ILogService, private loadingService: LoadingService,
                private toaster: any,
                private passengerFeedManualUploadService: PassengerFeedManualUploadService) {
        $log.info("PassengerFeedManualUploadModalController");
    }

    public $onInit() {
        this.airports = this.resolve.airports;
        this.passengerFeedManualUpload = new PassengerFeedManualUpload();
    }

    public uploadPassengerFeedData() {
        if (this.form.$invalid) {
            this.showErrors = true;
            return;
        }
        this.loadingService.show();
        this.passengerFeedManualUploadService.startUpload(this.passengerFeedManualUpload).then(() => {
            // this.passengerFeedManualUpload = new PassengerFeedManualUpload();
            this.toaster.pop({type: "success", title: "Запрос успещно отправлен"});
        }, (reason) => {
            this.$log.info(reason);
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.loadingService.hide();
            this.close();
        });
    }

    public cancel() {
        this.dismiss({value: "cancel"});
    }

    public submit() {
        this.close();
    }

    private isAirportFieldEmpty() {
        return _.isEmpty(this.passengerFeedManualUpload.airport);
    }
}

export const PassengerFeedManualUploadModalComponent: IComponentOptions = {
    controller: PassengerFeedManualUploadModalController,
    template: require("./passenger-feed-manual-upload-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "="
    }
};
