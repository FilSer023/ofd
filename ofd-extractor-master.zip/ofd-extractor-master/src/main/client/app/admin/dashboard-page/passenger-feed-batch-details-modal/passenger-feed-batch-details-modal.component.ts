import {IComponentOptions, ILogService} from "angular";
import {Batch} from "../../model/batch";
import {LoadingService} from "../../../shared/loading-service/loading-service.service";
import {PassengerFeedBatchService} from "../../service/passenger-feed-batch.service";

class PassengerFeedBatchDetailsModalController {
    public resolve: any;
    public close: any;
    public batch: Batch;
    public dismiss: any;
    public loading: boolean;

    /* @ngInject */
    constructor(private $log: ILogService, private loadingService: LoadingService,
                private toaster: any, private passengerFeedBatchService: PassengerFeedBatchService) {
        $log.info("PassengerFeedBatchDetailsModalController");

    }


    public $onInit() {
        this.batch = this.resolve.batch;
    }

    public save() {
        this.$log.info("submit()");
        this.loadingService.show();
        this.loading = true;
        this.passengerFeedBatchService.markAsReviewed(this.batch)
            .then((updatedBatch) => {
                this.toaster.pop({type: "success", title: "Сеанс отмечен как обработанный"});
                this.close({$value: updatedBatch});
            })
            .finally(() => {
                this.loadingService.hide();
                this.loading = false;
            });
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

}


export const PassengerFeedBatchDetailsModalComponent: IComponentOptions = {
    controller: PassengerFeedBatchDetailsModalController,
    template: require("./passenger-feed-batch-details-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "="
    }
};
