import {IComponentOptions, ILogService} from "angular";
import {LoadingService} from "../../../shared/loading-service/loading-service.service";
import {BatchService} from "../../service/batch.service";
import {ShopOperator} from "../../model/shop-operator";
import * as moment from "moment";
import "./run-batch-modal.less";

const MAX_PETER_SERVIS_PERIOD_LENGTH = 35;
const MAX_OFD_PERIOD_LENGTH = 120;

class RunBatchModalController {

    public resolve: any;
    public form: any;
    public close: any;
    public dismiss: any;
    public loading: boolean;
    public showErrors: boolean;
    public showBatchParameterErrors: boolean;
    public validConfiguration: boolean;
    public invalidConfigurationMessage: string;
    public shopOperators: ShopOperator[];
    public batchDay: Date;
    public periodLength: number;
    public shopOperator: ShopOperator;
    public batchDayDate = {opened: false};
    public maxPeriodLength = 120;
    private dateOptions = {
        formatYear: "yy",
        startingDay: 1,
        maxDate: new Date(),
        ngModelOptions: {
            timezone: "MSK"
        }
    };

    /* @ngInject */
    constructor(private $log: ILogService, private loadingService: LoadingService,
                private toaster: any, private batchService: BatchService) {
        $log.info("RunBatchModalController");

    }

    public $onInit() {
        this.shopOperators = this.resolve.shopOperators;
    }

    public shopOperatorSelected($item) {
        this.$log.info("shopOperatorSelected: %o", $item);
        this.maxPeriodLength = ($item.ofdProvider === "PETER_SERVIS") ? MAX_PETER_SERVIS_PERIOD_LENGTH : MAX_OFD_PERIOD_LENGTH;
    }

    public validateManualBatch() {
        this.showBatchParameterErrors = true;
        this.loading = true;
        this.$log.info("validateManualBatch()");
        if (this.shopOperator) {
            this.batchService.validateManualBatch(this.shopOperator.id, this.periodLength).then((validConfiguration) => {
                this.validConfiguration = true;
                this.invalidConfigurationMessage = null;
                this.$log.info("manual batch parameters valid");
            }).catch((invalidConfiguration) => {
                this.validConfiguration = false;
                this.invalidConfigurationMessage = invalidConfiguration.data.message;
                this.$log.info("manual batch parameters invalid");
            }).finally(() => {
                this.loading = false;
            });
        } else {
            this.validConfiguration = false;
        }
    }

    public run() {
        this.$log.info("run()");
        if (this.form.$invalid) {
            this.showErrors = true;
            return;
        } else {
            this.loadingService.show();
            this.loading = true;
            const dayString = moment(this.batchDay).format("YYYY-MM-DD");
            this.$log.debug("Starting batch for operator %s batchDay %s, string %s", this.shopOperator, dayString);
            this.batchService.startManualBatch(this.shopOperator.id, dayString, this.periodLength)
                .then((startedBatch) => {
                    this.toaster.pop({
                        type: "success",
                        title: "Сеанс выгрузки поставлен в очередь, перезагрузите страницу через минуту чтобы увидеть его"
                    });
                    this.close({$value: startedBatch});
                })
                .catch((rejected) => {
                    const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
                    this.toaster.pop({type: "error", title: errorMessage});
                })
                .finally(() => {
                    this.loadingService.hide();
                    this.loading = false;
                });
        }
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

    private openBatchDay() {
        this.batchDayDate.opened = true;
    }
}


export const RunBatchModalComponent: IComponentOptions = {
    controller: RunBatchModalController,
    template: require("./run-batch-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "="
    }
};
