import {IComponentOptions, ILogService, IScope} from "angular";
import {Batch} from "../../model/batch";
import {LoadingService} from "../../../shared/loading-service/loading-service.service";
import {BatchService} from "../../service/batch.service";

const DEV_PROJECT_NAME = "ofd-extractor-dev";
const PROD_PROJECT_NAME = "ofd-extractor-prod";
const DEV_GCS_BUCKET_NAME = "ofd-extractor-dev.appspot.com";
const PROD_GCS_BUCKET_NAME = "ofd-extractor-prod.appspot.com";

class BatchDetailsModalController {
    public resolve: any;
    public close: any;
    public batch: Batch;
    public dismiss: any;
    public loading: boolean;

    /* @ngInject */
    constructor(private $log: ILogService, private loadingService: LoadingService,
                private $rootScope: IScope, private toaster: any, private batchService: BatchService) {
        $log.info("BatchDetailsModalController");
    }


    public $onInit() {
        this.batch = this.resolve.batch;
    }

    public save() {
        this.$log.info("submit()");
        this.loadingService.show();
        this.loading = true;
        this.batchService.markAsReviewed(this.batch)
            .then((updatedBatch) => {
                this.toaster.pop({type: "success", title: "Сохранено"});
                this.close({$value: updatedBatch});
            })
            .finally(() => {
                this.loadingService.hide();
                this.loading = false;
            });
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

}


export const BatchDetailsModalComponent: IComponentOptions = {
    controller: BatchDetailsModalController,
    template: require("./batch-details-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "="
    }
};
