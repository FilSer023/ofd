import {IComponentOptions, ILogService} from "angular";
import * as _ from "lodash";
import {Batch} from "../model/batch";
import {IModalService} from "angular-ui-bootstrap";
import {DailyReport} from "../model/daily-report";
import {ShopOperatorService} from "../../shared/shop-operator/shop-operator.service";
import "./dashboard-page.less";
import {AirportCatalogService} from "../service/airport-catalog.service";
import {LoadingService} from "../../shared/loading-service/loading-service.service";
import {BatchService} from "../service/batch.service";
import {PassengerFeedBatchService} from "../service/passenger-feed-batch.service";
import {StateService} from "@uirouter/core";
import * as moment from "moment";
import {ReferenceData} from "../../shared/reference-data/reference-data.service";

class AdminDashboardPageController {

    private loading = false;
    private selectedOfdFilter: string;
    private ofdFilter: any = {};
    private batches: Batch[] = [];
    private passengerFeedBatches: Batch[] = [];
    private selectedPassengerFeedFilter: string;
    private passengerFeedFilter: any = {};
    private dailyReports: DailyReport[] = [];
    private passengerFeedReports: DailyReport[] = [];
    private dailyReportsOpen: boolean[] = [];
    private passengerFeedReportsOpen: boolean[] = [];
    private ofdStatuses: any[];
    private passengerFeedStatuses: any[];
    private PAGE_SIZE: number = 50;

    /* @ngInject */
    constructor(private $log: ILogService,
                private loadingService: LoadingService,
                private batchService: BatchService,
                private $state: StateService,
                private shopOperatorService: ShopOperatorService,
                private airportCatalogService: AirportCatalogService,
                private referenceData: ReferenceData,
                private $uibModal: IModalService,
                private passengerFeedBatchService: PassengerFeedBatchService) {
        $log.info("AdminDashboardPageController");
    }

    public $onInit() {
        this.allocateBatchesByDays();
        this.allocatePassengerFeedBatchesByDays();
        this.ofdStatuses = this.referenceData.getAll("BatchStatus");
        this.passengerFeedStatuses = this.referenceData.getAll("PassengerFeedBatchStatus");
        this.ofdFilter = {
            daysOffset: 0,
            filteredStatus: []
        };
        this.passengerFeedFilter = {
            daysOffset: 0,
            filteredStatus: []
        };
    }

    private allocateBatchesByDays() {
        this.dailyReports = [];
        this.batches.forEach((batch) => {
            this.dailyReportsOpen.push(false);
            this.allocateBatchToReportingDay(batch);
        });
        _.forEach(this.dailyReports, (dailyReport) => {
            dailyReport.batches = _.sortBy(dailyReport.batches, (batch) => batch.shopOperator.toLowerCase());
        });

        this.dailyReports = _.sortBy(this.dailyReports).reverse();
    }

    private allocatePassengerFeedBatchesByDays() {
        this.passengerFeedReports = [];
        this.passengerFeedBatches.forEach((passengerFeedBatch) => {
            this.passengerFeedReportsOpen.push(false);
            this.allocatePassengerFeedBatchToReportingDay(passengerFeedBatch);
        });
        this.passengerFeedReports = _.sortBy(this.passengerFeedReports).reverse();
    }

    private allocatePassengerFeedBatchToReportingDay(passengerFeedBatch) {
        let existingPassengerFeedDailyReport = _.find(this.passengerFeedReports, (dailyReport) => {
            return dailyReport.reportDay === moment(passengerFeedBatch.timeStarted).format("YYYY-MM-DD");
        });
        if (existingPassengerFeedDailyReport) {
            existingPassengerFeedDailyReport.batches.push(passengerFeedBatch);
            existingPassengerFeedDailyReport.success = !_.some(existingPassengerFeedDailyReport.batches, (batch) => {
                return batch.errorMessages.length > 0 && !batch.reviewed;
            });
        } else {
            const dailyBatches = new Array<Batch>();
            dailyBatches.push(passengerFeedBatch);
            existingPassengerFeedDailyReport = new DailyReport(moment(passengerFeedBatch.timeStarted).format("YYYY-MM-DD"), dailyBatches,
                (passengerFeedBatch.errorMessages.length === 0 || passengerFeedBatch.reviewed));
            this.passengerFeedReports.push(existingPassengerFeedDailyReport);
        }
    }

    private scrollFuture() {
        this.ofdFilter.daysOffset -= 5;
        this.list();
    }

    private scrollPast() {
        this.ofdFilter.daysOffset += 5;
        this.list();
    }

    private list() {
        this.loadingService.show();
        this.batchService.list(this.ofdFilter)
            .then((resp) => {
                this.batches = resp;
            })
            .finally(() => {
                this.allocateBatchesByDays();
                this.loadingService.hide();
            });
    }

    private ofdFilterChange() {
        this.ofdFilter.filteredStatus = [this.selectedOfdFilter];
        this.ofdFilter.daysOffset = 0;
        this.list();
    }

    private runManualBatch(batch: Batch) {
        this.$uibModal.open({
            animation: true,
            component: "runBatchModal",
            resolve: {
                shopOperators: this.shopOperatorService.availableOperators()
            }
        }).result.then((updatedBatch) => {
            batch = updatedBatch;
            this.$state.reload();
        }, () => {

        });
    }

    private allocateBatchToReportingDay(batch: Batch) {
        let existingDailyReport = _.find(this.dailyReports, (dailyReport) => {
            return dailyReport.reportDay === moment(batch.timeStarted).format("YYYY-MM-DD");
        });
        if (existingDailyReport) {
            existingDailyReport.batches.push(batch);
            existingDailyReport.success = !_.some(existingDailyReport.batches, (aBatch) => {
                return aBatch.errorMessages.length > 0 && !aBatch.reviewed;
            });
            this.$log.warn("Existing daily report: %o", existingDailyReport);
        } else {
            const dailyBatches = new Array<Batch>();
            dailyBatches.push(batch);
            existingDailyReport = new DailyReport(moment(batch.timeStarted).format("YYYY-MM-DD"), dailyBatches,
                (batch.errorMessages.length === 0 || batch.reviewed));
            this.dailyReports.push(existingDailyReport);
            this.$log.warn("New daily report: %o", existingDailyReport);
        }
    }

    private displayDetails(batch: Batch) {
        this.$uibModal.open({
            animation: true,
            component: "batchDetailsModal",
            resolve: {
                batch
            }
        }).result.then((updatedBatch) => {
            this.allocateBatchToReportingDay(batch);
        }, () => {

        });
    }

    private displayPassengerFeedBatchDetails(batch: Batch) {
        this.$uibModal.open({
            animation: true,
            component: "passengerFeedBatchDetailsModal",
            resolve: {
                batch
            }
        }).result.then((updatedBatch) => {
            this.allocatePassengerFeedBatchToReportingDay(batch);
        }, () => {

        });
    }

    private runPassengerFeedManualUpload() {
        this.$uibModal.open({
            animation: true,
            component: "passengerFeedManualUploadModal",
            resolve: {
                airports: this.airportCatalogService.list()
            }
        }).result.then((manualPassengerFeedUpload) => {
            this.$state.reload();
        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    private passengerFeedFilterChange() {
        this.passengerFeedFilter.filteredStatus = [this.selectedPassengerFeedFilter];
        this.passengerFeedFilter.daysOffset = 0;
        this.listPassengerFeedBatches();
    }

    private scrollPassengerFeedFuture() {
        this.passengerFeedFilter.daysOffset -= 5;
        this.listPassengerFeedBatches();
    }

    private scrollPassengerFeedPast() {
        this.passengerFeedFilter.daysOffset += 5;
        this.listPassengerFeedBatches();
    }

    private listPassengerFeedBatches() {
        this.loadingService.show();
        this.passengerFeedBatchService.list(this.passengerFeedFilter)
            .then((resp) => {
                this.passengerFeedBatches = resp;
            })
            .finally(() => {
                this.allocatePassengerFeedBatchesByDays();
                this.loadingService.hide();
            });
    }

}

export const AdminDashboardPageComponent: IComponentOptions = {
    controller: AdminDashboardPageController,
    template: require("./dashboard-page.html"),
    bindings: {
        batches: "<",
        passengerFeedBatches: "<"
    }
};

