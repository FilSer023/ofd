import {IComponentOptions, ILogService, IRootScopeService} from "angular";
import {IModalService} from "angular-ui-bootstrap";
import {NotificationService} from "../../shared/notification/notification.service";
import {LoadingService} from "../../shared/loading-service/loading-service.service";
import {StateService} from "@uirouter/core";
import {IUser} from "../../shared/user/user.model";
import {ShopOperatorService} from "../../shared/shop-operator/shop-operator.service";
import {ShopOperator} from "../model/shop-operator";
import {RentalArea} from "../model/rental-area";
import {RentalAreaService} from "../../shared/rental-area/rental-area.service";
import {ReferenceData} from "../../shared/reference-data/reference-data.service";
import {TradePoint} from "../model/trade-point";
import "./shop-operator-modal.less";
import * as _ from "lodash";

class ShopOperatorModalController {
    public resolve: any;
    public form: any;
    public kktForms: any[];
    public tradePointForms: any[];
    public showErrors = false;
    public nameNotAvailable: boolean;
    public nameCheckInProgress = false;
    public close: any;
    public processing;
    public dismiss: any;
    public shopOperator: ShopOperator;
    public actionTypeName: string;
    public MIN_PW_LEN = 10;
    public displayCategoryAreaErrorsPresence: boolean[] = [];
    public displayTechnicalInfoDetailsErrorsPresence: boolean[] = [];

    private currentUser: IUser;
    private freeRentalAreas: RentalArea[];
    private generateKeyBtnName: string;
    private ofdProviders: any[];
    private statuses: any[];
    private tradePointDetailsOpen: boolean[] = [];
    private isFormsVerificationFailed = false;
    private ofdDetailsOpen = false;


    private dateOptions = {
        formatYear: "yy",
        minDate: new Date("01.01.1980"),
        startingDay: 1
    };

    /* @ngInject */
    constructor(private $log: ILogService,
                private $uibModal: IModalService,
                private notificationService: NotificationService,
                private loadingService: LoadingService,
                private $state: StateService,
                private $interval: any,
                private $rootScope: IRootScopeService,
                private toaster: any,
                private shopOperatorService: ShopOperatorService,
                private rentalAreaService: RentalAreaService,
                private referenceData: ReferenceData) {
        $log.info("ShopOperatorModalController");


    }


    public $onInit() {
        this.shopOperator = _.cloneDeep(this.resolve.shopOperator) || new ShopOperator();
        if (this.shopOperator.tradePoints) {
            this.shopOperator.tradePoints.forEach((tradePoint) => {
                this.tradePointDetailsOpen.push(false);
            });
        }

        this.actionTypeName = (this.shopOperator) ? "Редактирование арендатора" : "Добавление нового арендатора";
        this.generateKeyBtnName = (this.shopOperator && this.shopOperator.uploadKey) ? "Сменить" : "Сгенерировать";
        this.$log.debug("ShopOperator: %o", this.shopOperator);
        this.rentalAreaService.getFreeRentalAreas().then((rentalAreas) => {
            this.freeRentalAreas = rentalAreas;
        });
        this.ofdProviders = this.referenceData.getAll("OFDProvider");
        this.statuses = this.referenceData.getAll("ShopOperatorStatus");
    }


    public cancel() {
        this.dismiss({$value: "cancel"});
    }

    public submit() {
        this.isFormsVerificationFailed = false;
        if (this.form.$invalid || this.nameNotAvailable) {
            this.$log.info("form verification failed");
            if (this.shopOperator.ofdProvider === "YARUS" && this.shopOperator.status === "ACTIVE" && _.isEmpty(this.shopOperator.apiToken)) {
                this.ofdDetailsOpen = true;
            }
            this.toaster.pop({type: "error", title: "Пожалуйста, устраните ошибки"});
            this.isFormsVerificationFailed = true;
        }
        _.forEach(this.tradePointForms, (tradePointForm, index) => { // Проверяем формы торговых точек
            if (tradePointForm.$invalid) {
                this.tradePointDetailsOpen[index] = true;
                if (tradePointForm.subcategory != null) {
                    if (tradePointForm.subcategory.$error.required) {
                        this.displayCategoryAreaErrorsPresence[index] = true;
                    }
                }
                this.isFormsVerificationFailed = true;
            }
            if (this.kktForms[index] != null) {
                if (this.kktForms[index].$invalid) { // Проверяем форму с ККТ-ФН
                    this.tradePointDetailsOpen[index] = true;
                    this.displayTechnicalInfoDetailsErrorsPresence[index] = true;
                    this.isFormsVerificationFailed = true;
                }
            }
        });

        if (this.isFormsVerificationFailed) {
            this.showErrors = true;
            return;
        }
        this.$log.debug("Saving %o", this.shopOperator);
        if (this.shopOperator.id) {
            this.update();
        } else {
            this.save();
        }
    }

    public save() {
        this.loadingService.show();
        this.processing = true;
        this.shopOperatorService.save(this.shopOperator).then((shopOperator) => {
            this.$state.reload();
            this.toaster.pop({type: "success", title: "Арендатор добавлен"});
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.close();
            this.loadingService.hide();
        });
    }

    public update() {
        this.loadingService.show();
        this.processing = true;
        this.shopOperatorService.update(this.shopOperator).then((shopOperator) => {
            this.$state.reload();
            this.toaster.pop({type: "success", title: "Арендатор обновлен"});
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.close();
            this.loadingService.hide();
        });
    }

    public generateUploadKey(): void {
        this.$log.warn("generating upload key");
        this.shopOperator.uploadKey = this.randomPassword();
    }

    public randomPassword(length?) {
        length = length || this.MIN_PW_LEN;
        const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP1234567890";
        let pass = "";
        for (let x = 0; x < length; x++) {
            const i = Math.floor(Math.random() * chars.length);
            pass += chars.charAt(i);
        }
        return pass;
    }

    private checkOperatorName() {
        this.$interval(this.doCheckNameAvailability.bind(this), 1000, 1);
    }

    private doCheckNameAvailability() {
        this.nameCheckInProgress = true;
        this.$log.debug("checkOperatorName: %s", this.shopOperator.name);
        this.shopOperatorService.checkNameAvailability(this.shopOperator.name)
            .then((resp) => {
                this.nameNotAvailable = !resp;
            })
            .finally(() => {
                this.nameCheckInProgress = false;
            });
    }

    private addTradePoint() {
        if (this.shopOperator.tradePoints == null) {
            this.shopOperator.tradePoints = new Array<TradePoint>();
        }
        this.shopOperator.tradePoints.push(new TradePoint());

    }

    private searchAreas(name) {
        return this.freeRentalAreas.filter((el) => {
            return el.name.toLowerCase().indexOf(name.toLowerCase()) > -1;
        });
    }

}


export const ShopOperatorModalComponent: IComponentOptions = {
    controller: ShopOperatorModalController,
    template: require("./shop-operator-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "="
    }
};
