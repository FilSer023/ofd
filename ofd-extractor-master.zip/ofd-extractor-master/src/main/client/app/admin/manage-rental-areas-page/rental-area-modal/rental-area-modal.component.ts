import {IComponentOptions, ILogService} from "angular";
import {IModalService} from "angular-ui-bootstrap";
import {StateService} from "@uirouter/core";
import {RentalArea} from "../../model/rental-area";
import {RentalAreaService} from "../../../shared/rental-area/rental-area.service";
import {IUser} from "../../../shared/user/user.model";
import {NotificationService} from "../../../shared/notification/notification.service";
import {LoadingService} from "../../../shared/loading-service/loading-service.service";
import {ReferenceData} from "../../../shared/reference-data/reference-data.service";
import * as _ from "lodash";
import {AirportCatalogService} from "../../service/airport-catalog.service";
import "ui-select/dist/select.css";

class RentalAreaModalController {
    public resolve: any;
    public form: any;
    public showErrors = false;
    public close: any;
    public processing;
    public dismiss: any;
    public rentalArea: RentalArea;
    public actionTypeName: string;
    private zones: any[];
    private statuses: any[];
    private airports: any[];
    private currentUser: IUser;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $uibModal: IModalService,
                private notificationService: NotificationService,
                private loadingService: LoadingService,
                private $state: StateService,
                private $rootScope: angular.IRootScopeService,
                private toaster: any,
                private referenceData: ReferenceData,
                private airportCatalogService: AirportCatalogService,
                private rentalAreaService: RentalAreaService) {
        $log.info("RentalAreaModalController");

    }


    public $onInit() {
        this.rentalArea = _.cloneDeep(this.resolve.rentalArea);
        this.actionTypeName = (this.rentalArea) ? "Редактирование площадки" : "Добавление новой площадки";
        this.zones = this.referenceData.getAll("RentalAreaZone");
        this.statuses = this.referenceData.getAll("RentalAreaStatus");
        this.airportCatalogService.list().then((airports) => {
            this.airports = airports;
        });
        this.$log.debug("RentalArea: %o", this.rentalArea);
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

    public submit() {
        this.$log.debug("Saving %o", this.rentalArea);
        if (this.rentalArea.id) {
            this.update();
        } else {
            this.save();
        }
    }

    public save() {
        this.loadingService.show();
        this.processing = true;
        this.rentalAreaService.save(this.rentalArea).then((rentalArea) => {
            this.$state.reload();
            this.toaster.pop({type: "success", title: "Площадка добавлена"});
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.close();
            this.loadingService.hide();
        });
    }

    public update() {
        this.loadingService.show();
        this.processing = true;
        this.rentalAreaService.update(this.rentalArea).then((rentalArea) => {
            this.$state.reload();
            this.toaster.pop({type: "success", title: "Площадка обновлена"});
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.close();
            this.loadingService.hide();
        });
    }

    public clearGates() {
        this.rentalArea.gates = [];
    }


}


export const RentalAreaModalComponent: IComponentOptions = {
    controller: RentalAreaModalController,
    template: require("./rental-area-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "="
    }
};
