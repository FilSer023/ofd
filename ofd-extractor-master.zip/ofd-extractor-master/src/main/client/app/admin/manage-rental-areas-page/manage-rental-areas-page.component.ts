import {IComponentOptions, ILogService} from "angular";
import {IModalService} from "angular-ui-bootstrap";
import {NotificationService} from "../../shared/notification/notification.service";
import {UserService} from "../../shared/user/user.service";
import "./manage-rental-areas-page.less";
import * as _ from "lodash";
import {ReferenceData} from "../../shared/reference-data/reference-data.service";
import {LoadingService} from "../../shared/loading-service/loading-service.service";
import {StateService} from "@uirouter/core";
import {RentalArea} from "../model/rental-area";
import {RentalAreaService} from "../../shared/rental-area/rental-area.service";
import {Batch} from "../model/batch";
import {AirportAreasInfo} from "../model/airport-areas-info";

class ManageRentalAreasPageController {

    public sortBy: string;
    public sortByOrder: string;
    public sortReverse: boolean;
    public defaultSortBy: string;
    public defaultSortByOrder: string;
    private rentalAreas: RentalArea[] = [];
    private airportRentalAreas: AirportAreasInfo[] = [];
    private airportRentalAreasOpen: boolean[] = [];

    /* @ngInject */
    constructor(private $log: ILogService,
                private $uibModal: IModalService,
                private notificationService: NotificationService,
                private userService: UserService,
                private loadingService: LoadingService,
                private $state: StateService,
                private referenceData: ReferenceData,
                private toaster: any,
                private rentalAreaService: RentalAreaService) {
        $log.info("ManageRentalAreaPageController");
    }

    public $onInit() {
        this.rentalAreas.forEach((rentalArea) => {
            this.airportRentalAreasOpen.push(false);

            const thisAirportRentalAreas = _.find(this.airportRentalAreas, {airport: rentalArea.airportCatalog.nameIATA});
            if (thisAirportRentalAreas) {
                thisAirportRentalAreas.rentalAreas.push(rentalArea);
                this.$log.warn("Existing: %o", thisAirportRentalAreas);
            } else {
                const newAirportRentalAreas = new Array<Batch>();
                newAirportRentalAreas.push(rentalArea);
                this.airportRentalAreas.push(new AirportAreasInfo(rentalArea.airportCatalog.nameIATA, newAirportRentalAreas));
                this.$log.warn("New: %o", thisAirportRentalAreas);
            }
        });
    }

    public addRentalArea() {
        this.$uibModal.open({
            component: "rentalAreaModal",
            resolve: {}
        })
            .result.then(() => {
        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    public editRentalArea(rentalArea: RentalArea) {
        this.$uibModal.open({
            component: "rentalAreaModal",
            resolve: {
                rentalArea: rentalArea
            }
        })
            .result.then(() => {
        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    public deleteRentalArea(rentalArea: RentalArea) {
        const opts = {
            title: "Подтверждение удаления",
            body: "Вы уверены, что хотите удалить площадку?",
            yesText: "Да",
            noText: "Отмена"
        };

        this.$uibModal.open({
            component: "confirmModal",
            resolve: {
                options: opts
            }
        }).result.then(() => {
            this.rentalAreaService.deleteRentalArea(rentalArea)
                .then((resp) => {
                    const successfullyDeleted = resp;
                    if (successfullyDeleted) {
                        this.toaster.pop({type: "success", title: "Площадка удалена"});
                        this.$state.reload();
                    } else {
                        this.toaster.pop({type: "error", title: "Площадка не удалена - есть торговая точка"});
                    }
                }).catch((rejected) => {
                    const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
                    this.toaster.pop({type: "error", title: errorMessage});
                }).finally(() => {
                this.loadingService.hide();
            });

        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    public setSortBy(sortBy: string) {
        if (this.sortBy === "name" && this.sortBy === sortBy) {
            // User selected to sort by status second time. Switch to default sort order
            this.setDefaultSortOrder();
        } else if (this.sortBy === "areaSize" && this.sortBy === sortBy) {
            if (!this.sortReverse) {
                // User selected sort by 'areaSize' for second time - reverse the sort order
                this.sortReverse = true;
            } else {
                // User selected sort by 'areaSize' for third time - reset to default sort
                this.setDefaultSortOrder();
            }

        } else {
            this.sortBy = sortBy;
            this.sortReverse = false;
        }

        this.sortByOrder = (!this.sortReverse ? "" : "-") + this.sortBy;
    }

    private setDefaultSortOrder() {
        this.sortBy = this.defaultSortBy;
        this.sortByOrder = this.defaultSortByOrder;
        this.sortReverse = true;
    }

}

export const ManageRentalAreaPageComponent: IComponentOptions = {
    controller: ManageRentalAreasPageController,
    template: require("./manage-rental-areas-page.html"),
    bindings: {
        rentalAreas: "="
    }
};

