import {IComponentOptions, ILogService} from "angular";
import {IModalService} from "angular-ui-bootstrap";
import {Promise} from "es6-promise";
import {NotificationService} from "../../shared/notification/notification.service";
import {IUser} from "../../shared/user/user.model";
import {UserService} from "../../shared/user/user.service";
import "./manage-users-page.less";
import {StateService} from "@uirouter/core";

class ManageUsersPageController {

    private users: IUser[] = [];
    private loadingUsers = false;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $uibModal: IModalService,
                private notificationService: NotificationService,
                private $state: StateService,
                private userService: UserService) {
        $log.info("AdminLoginPageController");

        this.handleDelete = this.handleDelete.bind(this);
    }

    public $onInit() {
        this.loadingUsers = true;
        this.userService.list()
            .then((users) => {
                this.users = users;
                this.loadingUsers = false;
            });
    }

    public inviteUser() {
        const modalInstance = this.$uibModal.open({
            animation: true,
            component: "userInviteModal"
        });

        modalInstance.result
            .then((invite) => {
                return this.userService.invite(invite)
                    .then(() => {
                        this.notificationService.success("Пользователь приглашен");
                    });
            }, () => {
                // ignore modal dismissal
            }).catch((error) => {
                this.notificationService.error(error.message);
        }).finally(() => {
            this.$state.reload();
        });
    }

    public handleDelete(users: IUser[]) {
        const opts = {
            title: "Подтверждение удаления",
            body: "Вы уверены, что хотите удалить выбранных пользователей?",
            yesText: "Да",
            noText: "Отмена"
        };

        this.$uibModal.open({
            component: "confirmModal",
            resolve: {
                options: opts
            }
        }).result.then(() => {
            const promises = users.map((user) => this.userService.remove(user));

            Promise.all(promises)
                .then(() => {
                    this.notificationService.success("Пользователь удален");
                    this.$state.reload();
                })
                .catch((error) => {
                    this.notificationService.error(error.message);
                });
        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }
}

export const ManageUsersPageComponent: IComponentOptions = {
    controller: ManageUsersPageController,
    template: require("./manage-users-page.html")
};

