import {IComponentOptions, ILogService, IScope, IWindowService} from "angular";
import {LoadingService} from "../../shared/loading-service/loading-service.service";
import {StateService} from "@uirouter/core";
import {IModalService} from "angular-ui-bootstrap";
import "./unmatched-categories-reports-page.less";
import {UnmatchedSKUItemService} from "../service/unmatched-sku-item.service";
import {PagedResult} from "../model/paged-result";
import * as _ from "lodash";
import * as moment from "moment";
import {SubsectionCategoryService} from "../service/subsection-category.service";
import {SubsectionCategory} from "../model/catalogs/subsection-category";
import {UnmatchedCategoriesReportsService} from "../service/unmatched-categories-report.service";
import {UnmatchedCategoryReport} from "../model/unmatched-categories-report";
import {CategoryMappingBatchService} from "../service/category-mapping-batch.service";
import {CategoryMappingBatch} from "../model/catalogs/category-mapping-batch";

const DEV_GCS_BUCKET_NAME = "ofd-extractor-dev.appspot.com";
const PROD_GCS_BUCKET_NAME = "ofd-extractor-prod.appspot.com";

class UnmatchedCategoriesReportsPageController {
    public resolve: any;
    private mappingFileURL: string;
    private searchFilter: any = {};
    private searchResults: PagedResult;
    private bulkCategory: string[];
    private newCategoryMappingBatch: CategoryMappingBatch;
    private categoryMappingBatches: CategoryMappingBatch[] = [];
    private categoryMappingBatchInProgress = false;
    private operatorsWithUnmatchedItems: string[];
    private count: number;
    private unmatchedCategoryReport: UnmatchedCategoryReport;
    private categories: SubsectionCategory[] = [];
    private PAGE_SIZE: number = 50;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $rootScope: IScope,
                private $window: IWindowService,
                private loadingService: LoadingService,
                private $state: StateService,
                private $uibModal: IModalService,
                private subsectionCategoryService: SubsectionCategoryService,
                private categoryMappingBatchService: CategoryMappingBatchService,
                private unmatchedCategoriesReportsService: UnmatchedCategoriesReportsService,
                private toaster: any,
                private unmatchedSKUItemService: UnmatchedSKUItemService) {
        $log.info("UnmatchedCategoriesReportsPageController");
    }

    public $onInit() {
        this.subsectionCategoryService.list().then((categories) => {
            this.categories = categories;
        });
        this.unmatchedCategoriesReportsService.latest().then((resp) => {
            this.unmatchedCategoryReport = resp;
        });
        this.categoryMappingBatchInProgress = _.some(this.categoryMappingBatches, (batch) => {
            const isOldBatch = moment().add(-10, "minute").isAfter(batch.timeStarted);
            return (_.isNil(batch.timeFinished) && !isOldBatch) && batch.status !== "ERROR";
        });
        const today = moment().subtract(1, "day").format("DD-MM-YYYY");
        this.mappingFileURL = this.$rootScope["isDevelopment"] ?
            `https://storage.cloud.google.com/${DEV_GCS_BUCKET_NAME}/mapping/${today}.csv` :
            `https://storage.cloud.google.com/${PROD_GCS_BUCKET_NAME}/mapping/${today}.csv`;
    }

    private exportAsCsv() {
        const url = "/export/unmatched-sku-items";
        this.$window.open(url, "_blank");
    }

    private createNewCategoryMappingBatch() {
        this.loadingService.show();
        this.$log.debug("Adding new batch %o", this.newCategoryMappingBatch);
        this.categoryMappingBatchService.create(this.newCategoryMappingBatch).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.categoryMappingBatchInProgress = true;
            this.categoryMappingBatchService.list().then((batches) => {
                this.categoryMappingBatches = batches;
            });
            this.$state.reload();
        });
    }

    private displayCategoryMappingBatchDetails(categoryMappingBatch: CategoryMappingBatch) {
        this.$uibModal.open({
            animation: true,
            component: "categoryMappingBatchDetailsModal",
            resolve: {
                batch: categoryMappingBatch
            }
        }).result.then(() => {

        }, (reason) => {
            this.$log.info("modal dismissed" + reason);
        });
    }

    private searchCategories(name) {
        return this.categories.filter((el) => {
            return el.name.toLowerCase().indexOf(name.toLowerCase()) > -1;
        });
    }

    private search() {
        if (_.isNil(this.searchFilter.operatorNames) && _.isNil(this.searchFilter.productSku)) {
            this.toaster.pop({type: "error", title: "Пожалуйста введите артикул (мин. 3 символа) или выберите арендатора"});
        } else {
            this.loadingService.show();
            this.unmatchedSKUItemService.search(this.searchFilter.operatorNames,
                this.searchFilter.productSku, 0)
                .then((resp) => {
                    this.searchResults = resp;
                })
                .finally(() => {
                    this.loadingService.hide();
                });
        }
    }

    private scrollForward() {
        const offset = _.isNil(this.searchResults) ? null : this.searchResults.offset;
        this.scroll(this.searchResults.offset + this.PAGE_SIZE);
    }

    private scrollBack() {
        this.scroll(this.searchResults.offset - this.PAGE_SIZE);
    }

    private scroll(offset: number) {
        this.loadingService.show();
        this.unmatchedSKUItemService.search(this.searchFilter.operatorNames,
            this.searchFilter.productSku, offset)
            .then((resp) => {
                this.searchResults = resp;
            })
            .finally(() => {
                this.loadingService.hide();
            });
    }

    private submit() {
        this.loadingService.show();
        this.unmatchedSKUItemService.save(this.searchResults.results)
            .then((resp) => {
                this.toaster.pop({type: "success", title: "Изменения сохранены успешно"});
            }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        })
            .finally(() => {
                this.loadingService.hide();
            });
    }

    private applyToAll() {
        this.$log.debug("Applying %s", this.bulkCategory);
        _.each(this.searchResults.results, (itemToSetCategory: any) => {
            itemToSetCategory.categories = this.bulkCategory;
        });
    }

    private clearAll() {
        _.each(this.searchResults.results, (itemToClearCategory: any) => {
            itemToClearCategory.categories = [];
        });
    }

}

export const UnmatchedCategoriesReportsPageComponent: IComponentOptions = {
    controller: UnmatchedCategoriesReportsPageController,
    template: require("./unmatched-categories-reports-page.html"),
    bindings: {
        operatorsWithUnmatchedItems: "<",
        count: "<",
        categoryMappingBatches: "<"
    }
};
