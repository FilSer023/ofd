import {IComponentOptions, ILogService} from "angular";
import {CategoryMappingBatch} from "../../model/catalogs/category-mapping-batch";

class CategoryMappingBatchDetailsModalController {
    public resolve: any;
    public close: any;
    public batch: CategoryMappingBatch;
    public dismiss: any;
    public loading: boolean;

    /* @ngInject */
    constructor(private $log: ILogService) {
        $log.info("CategoryMappingBatchDetailsModalController");
    }


    public $onInit() {
        this.batch = this.resolve.batch;
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

}


export const CategoryMappingBatchDetailsModalComponent: IComponentOptions = {
    controller: CategoryMappingBatchDetailsModalController,
    template: require("./category-mapping-batch-details-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "="
    }
};
