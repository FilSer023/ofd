import {IComponentOptions, ILogService} from "angular";
import {IModalService} from "angular-ui-bootstrap";
import {NotificationService} from "../../shared/notification/notification.service";
import {IUser} from "../../shared/user/user.model";
import {UserService} from "../../shared/user/user.service";
import "./navbar.less";
import * as _ from "lodash";

class AdminNavbarController {

    private isNavCollapsed = true;
    private loggedInUser: IUser;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $uibModal: IModalService,
                private notificationService: NotificationService,
                private userService: UserService) {
        $log.info("AdminNavbarController");
    }

    // noinspection JSUnusedGlobalSymbols
    public $onInit() {
        this.userService.me()
            .then((user) => this.loggedInUser = user);
    }

    // noinspection JSUnusedGlobalSymbols
    public toggleCollapsed() {
        this.isNavCollapsed = !this.isNavCollapsed;
    }

    // noinspection JSUnusedGlobalSymbols
    public loggedInUserName() {
        if (!this.loggedInUser) {
            return "Profile";
        }
        const {name, email} = this.loggedInUser;
        return name || email;
    }

    public isSuper() {
        return _.includes(this.loggedInUser.roles, "super");
    }

    // noinspection JSUnusedGlobalSymbols
    public editProfile() {
        const modalInstance = this.$uibModal.open({
            animation: true,
            component: "userEditModal",
            resolve: {
                user: this.userService.me(),
            }
        });

        modalInstance.result
            .then((user) => {
                return this.userService.save(user)
                    .then(() => {
                        this.notificationService.success("Profile saved");
                    }).catch((rejected) => {
                        const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
                        this.notificationService.error(errorMessage);
                    });
            }, () => {
                // ignore modal dismissal
            })
            .catch((error) => {
                this.notificationService.error(error.message);
            });
    }
}

export const AdminNavbar: IComponentOptions = {
    controller: AdminNavbarController,
    template: require("./navbar.html")
};
