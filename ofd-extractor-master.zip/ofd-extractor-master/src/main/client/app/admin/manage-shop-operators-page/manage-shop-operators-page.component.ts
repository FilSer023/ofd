import {IComponentOptions, ILogService} from "angular";
import * as _ from "lodash";
import {IModalService} from "angular-ui-bootstrap";
import {NotificationService} from "../../shared/notification/notification.service";
import {UserService} from "../../shared/user/user.service";
import "./manage-shop-operators-page.less";
import {ShopOperator} from "../model/shop-operator";
import {ShopOperatorService} from "../../shared/shop-operator/shop-operator.service";
import {ReferenceData} from "../../shared/reference-data/reference-data.service";
import {LoadingService} from "../../shared/loading-service/loading-service.service";
import {StateService} from "@uirouter/core";
import {AirportReport} from "../model/airport-report";
import {AirportCatalog} from "../model/catalogs/airport-catalog";

class ManageShopOperatorsPageController {

    private shopOperators: ShopOperator[] = [];
    private loading = false;
    private shopOperatorStatuses;
    private searchText: any;
    private airports: AirportCatalog[];
    private airportStats: AirportReport[] = [];
    private airportOperatorsOpen: boolean[] = [];


    /* @ngInject */
    constructor(private $log: ILogService,
                private $uibModal: IModalService,
                private notificationService: NotificationService,
                private userService: UserService,
                private loadingService: LoadingService,
                private $state: StateService,
                private referenceData: ReferenceData,
                private toaster: any,
                private shopOperatorService: ShopOperatorService) {
        $log.info("ManageShopOperatorsPageController");
    }

    public $onInit() {
        this.airports.forEach((airport) => {
            this.airportStats.push(new AirportReport(airport.nameIATA, []));
        });
        this.airportStats.push(new AirportReport("Без классификации", []));
        this.airportOperatorsOpen.push(false, false, false, false);
        this.shopOperators.forEach((shopOperator) => {
            this.airportStats.forEach((airportStat) => {
                if (_.some(shopOperator.tradePoints, (tradePoint) => {
                    if (tradePoint.rentalArea != null && tradePoint.rentalArea.airportCatalog != null) {
                        return airportStat.airport === tradePoint.rentalArea.airportCatalog.nameIATA;
                    } else {
                        return false;
                    }
                })) {
                    airportStat.operators.push(shopOperator);
                }
            });
        });

        const operatorsWithAirports = new Array<ShopOperator>();
        this.airports.forEach((airport) => {
            operatorsWithAirports.push(..._.find(this.airportStats, ["airport", airport.nameIATA]).operators);
        });
        _.find(this.airportStats, ["airport", "Без классификации"]).operators =
            _.difference(this.shopOperators, operatorsWithAirports);
        this.shopOperatorStatuses = this.referenceData.getAll("ShopOperatorStatus");
    }

    public addShopOperator() {
        this.$uibModal.open({
            component: "shopOperatorModal",
            size: "lg",
            resolve: {}
        })
            .result.then(() => {
        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    public editShopOperator(shopOperator: ShopOperator) {
        this.$uibModal.open({
            component: "shopOperatorModal",
            size: "lg",
            resolve: {
                shopOperator: shopOperator
            }
        })
            .result.then(() => {
        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    public archiveOperator(shopOperator: ShopOperator) {
        const opts = {
            title: "Подтверждение удаления",
            body: "Вы уверены, что хотите удалить арендатора?",
            yesText: "Да",
            noText: "Отмена"
        };

        this.$uibModal.open({
            component: "confirmModal",
            resolve: {
                options: opts
            }
        }).result.then(() => {
            shopOperator.status = this.shopOperatorStatuses[2].id.toString(); //ОСТОРОЖНО, КАСТЫЛИ!

            this.shopOperatorService.changeShopOperatorStatus(shopOperator, shopOperator.status)
                .then((resp) => {
                    this.$state.reload();
                    this.toaster.pop({type: "success", title: "Арендатор удален"});
                }).catch((rejected) => {
                const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
                this.toaster.pop({type: "error", title: errorMessage});
            }).finally(() => {
                this.loadingService.hide();
            });

        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    private searchChanged() {
        if (!_.isNil(this.searchText)) {
            this.airportOperatorsOpen.forEach((o, i, a) => a[i] = true);
        }
    }

}

export const ManageShopOperatorsPageComponent: IComponentOptions = {
    controller: ManageShopOperatorsPageController,
    template: require("./manage-shop-operators-page.html"),
    bindings: {
        shopOperators: "=",
        airports: "="
    }
};

