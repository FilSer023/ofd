import {IComponentOptions, ILogService, IScope} from "angular";

class AdminLayoutController {

    private isDevelopment = false;

    /* @ngInject */
    constructor($log: ILogService, private $rootScope: IScope) {
        $log.info("AdminLayoutController");
    }

    public $onInit() {
        this.isDevelopment = this.$rootScope["isDevelopment"];
    }
}

export const AdminLayoutComponent: IComponentOptions = {
    controller: AdminLayoutController,
    template: require("./admin-layout.html")
};
