import {IComponentOptions, ILogService} from "angular";
import {IModalService} from "angular-ui-bootstrap";
import {SubsectionCategoryService} from "../service/subsection-category.service";
import {SubsectionCategory} from "../model/catalogs/subsection-category";
import "./catalogs-page.less";
import {LoadingService} from "../../shared/loading-service/loading-service.service";
import {ConfigParameter} from "../model/config-parameter";
import {ConfigParameterService} from "../service/config-parameter.service";
import {CategoriesService} from "../../shared/categories/categories.service";
import {AirportCatalog} from "../model/catalogs/airport-catalog";
import {AirportCatalogService} from "../service/airport-catalog.service";
import {SalesChannel} from "../model/catalogs/sales-channel";
import {SalesChannelService} from "../service/sales-channel.service";
import {StateService} from "@uirouter/core";
import * as _ from "lodash";

class CatalogsPageController {

    private loading = false;
    private uploading = false;
    private catalogOpen: boolean[] = [false, false, false, false];
    private subsectionCategories: SubsectionCategory[] = [];
    private salesChannels: SalesChannel[] = [];
    private configParameters: ConfigParameter[] = [];
    private airportsCatalog: AirportCatalog[] = [];
    private showEditBtnOnSubsectionCategory: boolean[] = [];
    private showEditBtnOnSalesChannel: boolean[] = [];
    private originSubsectionCategories: SubsectionCategory[] = [];
    private originSalesChannels: SalesChannel[] = [];


    /* @ngInject */
    constructor(private $log: ILogService,
                private subsectionCategoryService: SubsectionCategoryService,
                private salesChannelService: SalesChannelService,
                private loadingService: LoadingService,
                private $state: StateService,
                private toaster: any,
                private $uibModal: IModalService,
                private categoriesService: CategoriesService,
                private configParameterService: ConfigParameterService,
                private airportCatalogService: AirportCatalogService) {
        $log.info("CatalogsPageController");
    }

    public $onInit() {
        this.configParameterService.list().then((configParameters: any) => {
            this.configParameters = _.sortBy(configParameters, ((configParameter) => configParameter.name.toLowerCase()));
        });
        this.airportCatalogService.list().then((airportsCatalog: any) => {
            this.airportsCatalog = _.sortBy(airportsCatalog, ((airport) => airport.nameIATA.toLowerCase()));
        });
        // Сначала сортируем, а потом делаем локальный "слепок" массивов, чтобы проверять, нужно ли показывать кнопку редактирования
        this.salesChannels = _.sortBy(this.salesChannels, ((salesChannel) => salesChannel.name.toLowerCase()));
        this.subsectionCategories = _.sortBy(this.subsectionCategories, ((subsectionCategory) => subsectionCategory.name.toLowerCase()));

        this.originSubsectionCategories = _.cloneDeep(this.subsectionCategories);
        this.originSalesChannels = _.cloneDeep(this.salesChannels);

    }

    private addSubsectionCategory() {
        if (this.subsectionCategories == null) {
            this.subsectionCategories = [];
        }

        this.subsectionCategories.push(new SubsectionCategory());
        const subsectionCategory = new SubsectionCategory();
        subsectionCategory.name = "";
        this.originSubsectionCategories.push(subsectionCategory);
    }

    private saveSalesChannel(salesChannel: SalesChannel, index: number) {
        this.loadingService.show();
        this.salesChannelService.save(salesChannel)
            .then((saved) => {
                this.salesChannels[index] = saved;
                this.originSalesChannels[index] = _.cloneDeep(saved);
                this.showEditBtnOnSalesChannel[index] = false;
            })
            .finally(() => {
                this.loadingService.hide();
            });
    }

    private deleteSalesChannel(salesChannel: SalesChannel, index: number) {

        if (_.isUndefined(salesChannel.id) && _.isEmpty(salesChannel.name)) { // Чтобы не спрашивать подтверждения удаления
            this.localDeleteSalesChannel(index);
            return;
        }

        this.$uibModal.open({
            animation: true,
            component: "confirmDeleteSubsectionCategoryModal",
            resolve: {}
        }).result.then(() => {
                this.loadingService.show();

                if (!_.isUndefined(salesChannel.id)) {
                    this.salesChannelService.delete(salesChannel).finally(() => {
                        this.localDeleteSalesChannel(index);
                        this.loadingService.hide();
                    }).finally(() => {
                    });
                } else {
                    this.localDeleteSalesChannel(index);
                    this.loadingService.hide();
                }
            },
            (reason) => {
                this.$log.info("modal dismissed: " + reason);
            });
    }

    private addSalesChannel() {
        if (this.salesChannels == null) {
            this.salesChannels = [];
        }

        this.salesChannels.push(new SalesChannel());
        const salesChannel = new SalesChannel();
        salesChannel.name = "";
        this.originSalesChannels.push(salesChannel);
    }

    private editConfigParameter(configParameter: ConfigParameter) {
        this.$uibModal.open({
            animation: true,
            component: "newConfigParameterModal",
            resolve: {
                configParameter: configParameter
            }
        }).result.then(() => {

        }, (reason) => {
            this.$log.info("modal dismissed" + reason);
        });
    }

    private saveSubsectionCategory(subsectionCategory: SubsectionCategory, index: number) {
        this.loadingService.show();
        this.subsectionCategoryService.save(subsectionCategory).then((resp: any) => {
            this.subsectionCategories[index] = resp;
            this.originSubsectionCategories[index] = _.cloneDeep(resp);
            this.showEditBtnOnSubsectionCategory[index] = false;
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.loadingService.hide();
        });
    }

    private deleteSubsectionCategory(subsectionCategory: SubsectionCategory) {
        const index = this.subsectionCategories.indexOf(subsectionCategory);

        if (_.isUndefined(subsectionCategory.id) && _.isEmpty(subsectionCategory.name)) { // Чтобы не спрашивать подтверждения удаления
            this.localDeleteSubsectionCategory(index);
            return;
        }
        this.$uibModal.open({
            animation: true,
            component: "confirmDeleteSubsectionCategoryModal",
            resolve: {}
        }).result.then(() => {
            this.loadingService.show();

            if (!_.isUndefined(subsectionCategory.id)) {
                this.subsectionCategoryService.delete(subsectionCategory).then(() => {
                    this.localDeleteSubsectionCategory(index);
                    this.loadingService.hide();
                }).catch((rejected) => {
                    const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
                    this.toaster.pop({type: "error", title: errorMessage});
                }).finally(() => {
                });
            } else {
                this.localDeleteSubsectionCategory(index);
                this.loadingService.hide();
            }


        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    private localDeleteSubsectionCategory(index: number) {
        this.subsectionCategories.splice(index, 1);
        this.originSubsectionCategories.splice(index, 1);
        this.showEditBtnOnSubsectionCategory.splice(index, 1);
    }

    private localDeleteSalesChannel(index: number) {
        this.salesChannels.splice(index, 1);
        this.originSalesChannels.splice(index, 1);
        this.showEditBtnOnSalesChannel.splice(index, 1);
    }

    private addNewAirport() {
        this.$uibModal.open({
            animation: true,
            component: "newAirportModal",
            resolve: {}
        }).result.then(() => {

        }, (reason) => {
            this.$log.info(reason);
        });
    }

    private editAirport(airport: AirportCatalog) {
        this.$uibModal.open({
            animation: true,
            component: "newAirportModal",
            resolve: {
                airportCatalog: airport
            }
        }).result.then(() => {

        }, (reason) => {
            this.$log.info(reason);
        });
    }

    private deleteAirport(airport: AirportCatalog) {
        const opts = {
            title: "Подтверждение удаления",
            body: "Вы уверены, что хотите удалить аэропорт?",
            yesText: "Да",
            noText: "Отмена"
        };

        this.$uibModal.open({
            component: "confirmModal",
            resolve: {
                options: opts
            }
        }).result.then(() => {
            this.airportCatalogService.remove(airport)
                .then((resp) => {
                    const successfullyDeleted = resp;
                    if (successfullyDeleted) {
                        this.toaster.pop({type: "success", title: "Аэропорт удален"});
                        this.$state.reload();
                    } else {
                        this.toaster.pop({
                            type: "error",
                            title: "Аэропорт не удален - сначала удалите арендные площади"
                        });
                    }
                }).catch((rejected) => {
                    const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
                    this.toaster.pop({type: "error", title: errorMessage});
                }).finally(() => {
                    this.loadingService.hide();
                });

        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }

    private checkIsSubsectionCategoryChanged(subsectionCategory: SubsectionCategory, index: number) {
        this.showEditBtnOnSubsectionCategory[index] =
            this.subsectionCategories[index].name !== this.originSubsectionCategories[index].name && !_.isEmpty(this.subsectionCategories[index].name);
    }

    private checkIsSalesChannelChanged(salesChannel: SalesChannel, index: number) {
        this.showEditBtnOnSalesChannel[index] =
            this.salesChannels[index].name !== this.originSalesChannels[index].name && !_.isEmpty(this.salesChannels[index].name);
    }

}

export const CatalogsPageComponent: IComponentOptions = {
    controller: CatalogsPageController,
    template: require("./catalogs-page.html"),
    bindings: {
        subsectionCategories: "=",
        salesChannels: "="
    }
};

