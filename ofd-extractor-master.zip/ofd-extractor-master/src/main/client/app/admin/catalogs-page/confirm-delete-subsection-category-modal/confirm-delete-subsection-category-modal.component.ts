import {IComponentOptions, ILogService} from "angular";
import {IModalInstanceService} from "angular-ui-bootstrap";

class ConfirmDeleteSubsectionCategoryModalController {

    public modalInstance: IModalInstanceService;
    public resolve: any;
    public close: any;
    public dismiss: any;

    /* @ngInject */
    constructor(private $log: ILogService) {
    }

    public submit() {
        this.$log.info("submit()");
        this.close();
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

}

export const ConfirmDeleteSubsectionCategoryModalComponent: IComponentOptions = {
    controller: ConfirmDeleteSubsectionCategoryModalController,
    template: require("./confirm-delete-subsection-category-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "<"
    }
};
