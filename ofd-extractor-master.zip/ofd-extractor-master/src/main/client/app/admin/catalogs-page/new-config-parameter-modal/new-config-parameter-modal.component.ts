import {IComponentOptions, ILogService} from "angular";
import {ConfigParameter} from "../../model/config-parameter";
import {ConfigParameterService} from "../../service/config-parameter.service";
import {StateService} from "@uirouter/core";
import {LoadingService} from "../../../shared/loading-service/loading-service.service";
import * as _ from "lodash";

class NewConfigParameterModalController {

    public resolve: any;
    public close: any;
    public dismiss: any;
    private configParameter: ConfigParameter;

    /* @ngInject */
    constructor(private $log: ILogService,
                private configParameterService: ConfigParameterService,
                private $state: StateService,
                private toaster: any,
                private loadingService: LoadingService) {
    }

    public $onInit() {
        this.configParameter = _.cloneDeep(this.resolve.configParameter);
    }

    public save() {
        this.loadingService.show();
        this.$log.info("submit()");
        this.close();
        this.configParameterService.save(this.configParameter).then((configParameter) => {
            this.toaster.pop({type: "success", title: "Параметр успешно сохранен"});
            this.$state.reload();
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.close();
            this.loadingService.hide();
        });
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

}

export const NewConfigParameterModalComponent: IComponentOptions = {
    controller: NewConfigParameterModalController,
    template: require("./new-config-parameter-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "<"
    }
};
