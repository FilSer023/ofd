import {LoadingService} from "../../../shared/loading-service/loading-service.service";
import {StateService} from "@uirouter/core";
import {IComponentOptions, ILogService} from "angular";
import {AirportCatalogService} from "../../service/airport-catalog.service";
import {AirportCatalog} from "../../model/catalogs/airport-catalog";
import * as _ from "lodash";
import "./new-airport-modal.less";


class NewAirportModalController {

    public resolve: any;
    public close: any;
    public dismiss: any;
    private form: any;
    private showErrors: boolean;
    private airportCatalog: AirportCatalog;
    private modalTitle: string;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $state: StateService,
                private toaster: any,
                private loadingService: LoadingService,
                private airportCatalogService: AirportCatalogService) {
        $log.info("NewAirportModalController");
    }

    public $onInit() {
        this.airportCatalog = (this.resolve.airportCatalog) ? _.cloneDeep(this.resolve.airportCatalog) : new AirportCatalog();
        this.modalTitle = this.isAlreadyExistingAirport() ? "Редактирование аэропорта" : "Добавление нового аэропорта";
    }

    public submit() {
        if (this.form.$invalid) {
            this.showErrors = true;
            return;
        }
        this.save();
    }

    public save() {
        this.loadingService.show();
        this.airportCatalogService.save(this.airportCatalog).then(() => {
            this.toaster.pop({type: "success", title: "Данные успешно сохранены"});
            this.$state.reload();
        }).catch((rejected) => {
            const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
            this.toaster.pop({type: "error", title: errorMessage});
        }).finally(() => {
            this.close();
            this.loadingService.hide();
        });
    }

    public cancel() {
        this.dismiss({$value: "cancel"});
    }

    private isAlreadyExistingAirport() {
        return !_.isEmpty(this.airportCatalog.id);
    }

}

export const NewAirportModalComponent: IComponentOptions = {
    controller: NewAirportModalController,
    template: require("./new-airport-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "<"
    }
};
