import {IComponentOptions, ILogService, IScope, IWindowService} from "angular";
import {TradePoint} from "../model/trade-point";
import {RentalArea} from "../model/rental-area";
import {ReferenceData} from "../../shared/reference-data/reference-data.service";
import "./trade-point.less";
import {CategoryArea} from "../model/category-area";
import {KKTFiscalDrive} from "../model/kktFiscalDrive";
import {ShopOperator} from "../model/shop-operator";
import {SubsectionCategory} from "../model/catalogs/subsection-category";
import {SubsectionCategoryService} from "../service/subsection-category.service";
import {SalesChannelService} from "../service/sales-channel.service";
import * as _ from "lodash";
import {IModalService} from "angular-ui-bootstrap";

class TradePointController {

    public item: TradePoint;
    public shopOperator: ShopOperator;
    public freeRentalAreas: RentalArea[];
    public salesChannels: any[];
    public products: any[];
    public subsectionCategories: SubsectionCategory[];
    public kktForm: any;
    public showErrors = false;
    public tradePointForm: any;
    public displayCategoryArea = false;
    public displayTechnicalInfoDetails = false;

    private popupContractDate = {opened: false};
    private popupDateAdded = {opened: false};

    private dateOptions = {
        formatYear: "yy",
        startingDay: 1,
        ngModelOptions: {
            timezone: "MSK"
        }
    };

    /* @ngInject */
    constructor(private $log: ILogService,
                private $scope: IScope,
                private $uibModal: IModalService,
                private $window: IWindowService,
                private toaster: any,
                private referenceData: ReferenceData,
                private salesChannelService: SalesChannelService,
                private subsectionCategoryService: SubsectionCategoryService) {
    }

    public $onInit() {
        this.$log.log("TradePointController initialized");
        this.products = [{id: "Watches", description: "Watches"}, {id: "Retail", description: "Retail"}];
        this.subsectionCategoryService.list().then((subsectionCategories) => {
            this.subsectionCategories = subsectionCategories;
        });
        this.salesChannelService.list().then((channels) => {
            this.salesChannels = channels;
        });
        this.item.contractDate = _.isEmpty(this.item.contractDate) ? new Date(Date.now()) : new Date(this.item.contractDate);
        this.item.kktFiscalDrives.forEach((kktFiscalDrive) => {
            kktFiscalDrive.dateAdded = _.isEmpty(kktFiscalDrive.dateAdded) ? new Date(Date.now()) : new Date(kktFiscalDrive.dateAdded);
        });
    }

    private addCategoryArea() {
        if (this.item.categoryAreas == null) {
            this.item.categoryAreas = [];
        }

        const categoryArea = new CategoryArea();
        this.item.categoryAreas.push(categoryArea);
    }

    private addFiscalDrive() {
        if (this.item.kktFiscalDrives == null) {
            this.item.kktFiscalDrives = [];
        }

        const kktFiscalDrive = new KKTFiscalDrive();
        this.item.kktFiscalDrives.push(kktFiscalDrive);
    }

    private openContractDate() {
        this.popupContractDate.opened = true;
    }

    private openDateAdded() {
        this.popupDateAdded.opened = true;
    }

    private delete(index: number) {
        this.item.categoryAreas.splice(index, 1);

    }

    private deleteKKT(index: number) {
        this.item.kktFiscalDrives.splice(index, 1);

    }

    private getTotalSumOfAreaSections() {
        return _.sumBy(this.item.categoryAreas, (categoryArea) => {
            return categoryArea.areaSize != null ? categoryArea.areaSize : 0;
        });
    }

    private isAreaSizeExceeded() {
        return this.item.rentalArea.areaSize < this.getTotalSumOfAreaSections();
    }

    private deleteTradePoint(index) {
        const opts = {
            title: "Подтверждение удаления",
            body: "Вы уверены, что хотите удалить торговую точку?",
            yesText: "Да",
            noText: "Отмена"
        };

        this.$uibModal.open({
            component: "confirmModal",
            resolve: {
                options: opts
            }
        }).result.then(() => {
            this.shopOperator.tradePoints.splice(index, 1);

        }, (reason) => {
            this.$log.info("modal dismissed: " + reason);
        });
    }
}

export const TradePointComponent: IComponentOptions = {
    bindings: {
        index: "<",
        item: "=",
        freeRentalAreas: "<",
        shopOperator: "<",
        displayErrorState: "<",
        kktForm: "=?",
        showErrors: "<",
        tradePointForm: "=?",
        displayCategoryArea: "<",
        displayTechnicalInfoDetails: "<"
    },
    controller: TradePointController,
    template: require("./trade-point.html")
};
