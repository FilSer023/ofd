import * as angular from "angular";
import {TradePointComponent} from "./trade-point.component";

export const TradePointModule = angular
    .module("app.admin.tradePoint", [])

    .component("tradePoint", TradePointComponent)

    .name;
