export class UnmatchedSKUItem {

    constructor(public id?: string, public sku?: string, public categories?: string[],
                public operatorName?: string, public allocated?: boolean, public created?: Date, public updated?: Date) {
    }
}
