import {Batch} from "./batch";

export class DailyReport {

    constructor(public reportDay?: string, public batches?: Batch[], public success?: boolean) {

    }
}
