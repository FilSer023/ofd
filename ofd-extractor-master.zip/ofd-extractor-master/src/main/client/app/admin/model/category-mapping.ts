export class CategoryMapping {

    public airportCategory: string;
    public vendorCategory: string;

}
