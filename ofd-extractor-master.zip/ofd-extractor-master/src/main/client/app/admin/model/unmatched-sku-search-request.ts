export class UnmatchedSKUSearchRequest {

    constructor(public sku?: string, public operatorNames?: string[], public offset?: number) {
    }
}
