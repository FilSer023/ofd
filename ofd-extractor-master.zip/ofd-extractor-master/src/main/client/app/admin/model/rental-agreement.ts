import {RentalArea} from "./rental-area";

export class RentalAgreement {

    constructor(private agreementNumber?: string, private agreementDate?: Date, private rentalAreas?: RentalArea[]) {

    }
}
