export class PagedResult {

    constructor(public results?: any[], public cursorWebSafeString?: string, public offset?: number, public hasMore?: boolean) {
    }
}
