import {SubsectionCategory} from "./catalogs/subsection-category";

export class CategoryArea {

    constructor(public category?: SubsectionCategory, public areaSize?: number) {

    }
}
