export class AirportCatalog {
    constructor(public id?: string,
                public nameIATA?: string,
                public description?: string,
                public gates: string[] = []) {

    }
}
