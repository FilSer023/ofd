import {ShopOperator} from "./shop-operator";

export class AirportReport {
    constructor(public airport?: string, public operators?: ShopOperator[], public success?: boolean) {

    }
}
