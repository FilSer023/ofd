export class SubsectionCategory {

    constructor(public id?: string, public name?: string) {
    }
}
