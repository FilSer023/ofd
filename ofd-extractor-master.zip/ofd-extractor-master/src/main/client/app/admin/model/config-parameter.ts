export class ConfigParameter {
    constructor(id?: string, name?: string, value?: string, notes?: string, createdDate?: string, updatedTime?: string) {

    }
}
