import {Attachment} from "../../../shared/file-upload/attachment.model";

export class CategoryMappingBatch {

    constructor(public id?: string, public attachment?: Attachment, public timeStarted?: Date, public timeFinished?: Date,
                public status?: string, public startedBy?: string, public shareDocument?: boolean) {
    }
}
