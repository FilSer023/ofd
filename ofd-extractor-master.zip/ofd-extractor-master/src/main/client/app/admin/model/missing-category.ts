export class MissingCategory {

    constructor(public sku?: string, public shopOperator?: string, public price?: string,
                public category?: string[], public visible?: boolean, public inn?: string,
                public tradePointName?: string, rentalAreaName?: string, public airportName?: string) {
    }
}
