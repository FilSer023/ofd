import {AirportCatalog} from "./catalogs/airport-catalog";

export class RentalArea {

    constructor(public id?: string, public name?: string, public floor?: string, public status?: string,
                public created?: string, public area?: string, public areaSize?: number, public tenant?: string,
                public airport?: string, public airportCatalog?: AirportCatalog, public zone?: string, public gates?: string[]) {

    }
}
