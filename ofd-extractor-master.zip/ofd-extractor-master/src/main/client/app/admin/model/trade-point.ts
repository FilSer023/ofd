import {KKTFiscalDrive} from "./kktFiscalDrive";
import {RentalArea} from "./rental-area";
import {CategoryArea} from "./category-area";
import {SalesChannel} from "./catalogs/sales-channel";

export class TradePoint {

    constructor(
        public name?: string,
        public kktFiscalDrives: KKTFiscalDrive[] = [],
        public fiscalDrives?: string[],
        public salesChannel?: SalesChannel,
        public staffQuantity?: string,
        public rentalArea?: RentalArea,
        public contractNumber?: string,
        public contractDate: Date = new Date(),
        public categoryAreas: CategoryArea[] = []) {

    }
}
