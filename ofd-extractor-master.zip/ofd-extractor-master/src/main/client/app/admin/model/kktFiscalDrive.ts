export class KKTFiscalDrive {

    constructor(public kktRegId?: string, public fiscalDriveNumber?: string, public dateAdded?: Date) {
    }
}
