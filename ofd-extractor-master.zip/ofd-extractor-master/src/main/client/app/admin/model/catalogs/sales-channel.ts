export class SalesChannel {

    constructor(public id?: string, public name?: string) {
    }
}
