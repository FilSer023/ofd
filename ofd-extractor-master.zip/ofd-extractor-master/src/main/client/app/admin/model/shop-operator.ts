import {TradePoint} from "./trade-point";

export class ShopOperator {

    constructor(public id?: string,
                public name?: string,
                public status?: string,
                public inn?: string,
                public ofdProvider?: string,
                public tradePoints: TradePoint[] = [],
                public uploadKey?: string,
                public apiToken?: string,
                public ofdUsername?: string,
                public ofdPassword?: string) {
    }

}
