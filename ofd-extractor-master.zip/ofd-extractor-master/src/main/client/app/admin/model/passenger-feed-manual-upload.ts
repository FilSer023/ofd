import {Attachment} from "../../shared/file-upload/attachment.model";

export class PassengerFeedManualUpload {
    constructor(public attachment?: Attachment[], public airport?: string) {

    }
}
