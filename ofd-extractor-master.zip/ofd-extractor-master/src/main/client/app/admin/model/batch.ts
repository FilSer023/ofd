export class Batch {

    constructor(public id?: string, public shopOperator?: string, public timeStarted?: string, public timeFinished?: string,
                public status?: string, public batchDay?: string, public feedDay?: string, public periodLength?: number,
                public receiptsRetrieved?: number, public reviewed?: boolean, public errorMessages?: string[],
                public infoMessages?: string[], public linesImported?: any) {

    }
}
