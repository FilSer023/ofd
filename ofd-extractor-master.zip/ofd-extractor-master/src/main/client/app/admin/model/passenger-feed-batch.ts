export class PassengerFeedBatch {
    constructor(public id?: string,
                public timeStarted?: string,
                public timeFinished?: string,
                public status?: string,
                public linesImported?: any[],
                public feedDay?: string,
                public notes?: string[],
                public recieved?: boolean,
                public errorMessages?: string[],
                public infoMessages?: string[],
                public automatic?: boolean,
                public manualUploadAirportName?: string) {

    }
}
