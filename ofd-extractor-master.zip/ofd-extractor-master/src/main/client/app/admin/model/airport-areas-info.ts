import {RentalArea} from "./rental-area";

export class AirportAreasInfo {

    constructor(public airport?: string, public rentalAreas?: RentalArea[]) {

    }
}
