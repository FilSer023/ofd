import {MissingCategory} from "./missing-category";

export class UnmatchedCategoryReport {

    constructor(public id?: string, public createdDate?: Date, public gcsFileName?: string, public count?: number,
                public missingCategories?: MissingCategory[], public processed?: boolean, public errorMessages?: string[],
                public matchedCount?: number) {
    }
}
