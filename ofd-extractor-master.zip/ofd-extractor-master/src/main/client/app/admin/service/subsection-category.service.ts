import {IHttpService, ILogService, IPromise} from "angular";
import {SubsectionCategory} from "../model/catalogs/subsection-category";

export class SubsectionCategoryService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("SubsectionCategoryService");
    }

    public list(): IPromise<SubsectionCategory[]> {
        return this.$http.get("/api/subsection-categories/").then((resp: any) => {
            return resp.data;
        });
    }

    public search(name: string): IPromise<SubsectionCategory[]> {
        return this.$http.get("/api/subsection-categories/search", {params: {name}}).then((resp: any) => {
            return resp.data;
        });
    }

    public save(subsectionCategory: SubsectionCategory): IPromise<SubsectionCategory[]> {
        if (subsectionCategory.id) {
            return this.$http.post(`/api/subsection-categories/${subsectionCategory.id}`, {name: subsectionCategory.name}).then((resp: any) => {
                return resp.data;
            });
        } else {
            return this.$http.put("/api/subsection-categories/", {name: subsectionCategory.name}).then((resp: any) => {
                return resp.data;
            });
        }
    }

    public delete(subsectionCategory: SubsectionCategory): IPromise<any> {
        return this.$http.delete(`/api/subsection-categories/${subsectionCategory.id}`, {params: {id: subsectionCategory.id}}).then((resp: any) => {
            return resp.data;
        });
    }
}
