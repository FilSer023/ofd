import {IHttpService, ILogService, IPromise} from "angular";
import {PassengerFeedManualUpload} from "../model/passenger-feed-manual-upload";

export class PassengerFeedManualUploadService {
    /* @ngInject */
    constructor(private $log: ILogService, private $http: IHttpService) {
        $log.info("PassengerFeedManualUploadService");
    }

    public startUpload(passengerFeedManualUpload: PassengerFeedManualUpload): IPromise<any> {
        return this.$http.post("/api/passenger-feed/manual-upload", passengerFeedManualUpload).then((resp: any) => {
            return resp.data;
        });
    }
}
