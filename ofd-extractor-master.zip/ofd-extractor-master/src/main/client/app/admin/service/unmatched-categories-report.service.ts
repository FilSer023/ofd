import {IHttpService, ILogService, IPromise} from "angular";
import {UnmatchedCategoryReport} from "../model/unmatched-categories-report";

export class UnmatchedCategoriesReportsService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("UnmatchedCategoriesReportsService");
    }

    public latest(): IPromise<UnmatchedCategoryReport> {
        return this.$http.get("/api/unmatched-categories").then((resp: any) => {
            return resp.data;
        });
    }


}
