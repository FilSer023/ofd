import {IHttpService, ILogService, IPromise} from "angular";
import {CategoryMappingBatch} from "../model/catalogs/category-mapping-batch";

export class CategoryMappingBatchService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("CategoryMappingBatchService");
    }

    public list(): IPromise<CategoryMappingBatch[]> {
        return this.$http.get("/api/category-mapping-batch/").then((resp: any) => {
            return resp.data;
        });
    }

    public create(categoryMappingBatch: CategoryMappingBatch): IPromise<CategoryMappingBatch> {
        return this.$http.post("/api/category-mapping-batch/", categoryMappingBatch).then((resp: any) => {
            return resp.data;
        });
    }

}
