import {IHttpService, ILogService, IPromise} from "angular";
import {AirportCatalog} from "../model/catalogs/airport-catalog";

export class AirportCatalogService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("AirportCatalogService");
    }

    public list(): IPromise<AirportCatalog[]> {
        return this.$http.get("api/airport-catalog/").then((resp: any) => {
            return resp.data;
        });
    }

    public save(airportCatalog: AirportCatalog): IPromise<AirportCatalog> {
        return this.$http.post("api/airport-catalog/", airportCatalog).then((resp: any) => {
            return resp.data;
        });
    }

    public remove(airport: AirportCatalog): IPromise<boolean> {
        return this.$http.delete(`api/airport-catalog/${airport.id}`).then((resp: any) => {
            return resp.data;
        });
    }

}
