import {IHttpService, ILogService, IPromise} from "angular";
import {PassengerFeedBatch} from "../model/passenger-feed-batch";

export class PassengerFeedBatchService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("PassengerFeedBatchService");
    }

    public list(filter?: any): IPromise<PassengerFeedBatch[]> {
        return this.$http.post(`/api/passenger-feed-batch/`, filter).then((resp: any) => {
            return resp.data;
        });
    }

    public markAsReviewed(batch: PassengerFeedBatch): IPromise<PassengerFeedBatch[]> {
        return this.$http.put(`/api/passenger-feed-batch/${batch.id}/toggle-reviewed`, batch).then((resp: any) => {
            return resp.data;
        });
    }

}
