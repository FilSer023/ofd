import {IHttpService, ILogService, IPromise} from "angular";
import {PagedResult} from "../model/paged-result";
import {UnmatchedSKUItem} from "../model/unmatched-sku-item";
import {UnmatchedSKUSearchRequest} from "../model/unmatched-sku-search-request";

export class UnmatchedSKUItemService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("UnmatchedSKUItemService");
    }

    public search(operatorNames: string[], sku: string, offset: number): IPromise<PagedResult> {
        const data = new UnmatchedSKUSearchRequest(sku, operatorNames, offset);
        return this.$http.post("/api/unmatched-sku-item/search", data).then((resp: any) => {
            return resp.data;
        });
    }

    public getCount(): IPromise<number> {
        return this.$http.get("/api/unmatched-sku-item/count").then((resp: any) => {
            return resp.data;
        });
    }

    public listOperatorsWithUnmatchedItems(): IPromise<string[]> {
        return this.$http.get("/api/unmatched-sku-item/operators").then((resp: any) => {
            return resp.data;
        });
    }

    public save(unmatchedSKUItems: UnmatchedSKUItem[]): IPromise<string> {
        return this.$http.post("/api/unmatched-sku-item/", unmatchedSKUItems).then((resp: any) => {
            return resp.data;
        });
    }
}
