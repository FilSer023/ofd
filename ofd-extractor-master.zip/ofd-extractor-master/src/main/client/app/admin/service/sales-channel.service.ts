import {IHttpService, ILogService, IPromise} from "angular";
import {SalesChannel} from "../model/catalogs/sales-channel";

export class SalesChannelService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("SalesChannelService");
    }

    public list(): IPromise<SalesChannel[]> {
        return this.$http.get("/api/sales-channel/").then((resp: any) => {
            return resp.data;
        });
    }


    public save(salesChannel: SalesChannel): IPromise<SalesChannel> {
        if (salesChannel.id) {
            return this.$http.post(`/api/sales-channel/${salesChannel.id}`, {name: salesChannel.name}).then((resp: any) => {
                return resp.data;
            });
        } else {
            return this.$http.put("/api/sales-channel/", {name: salesChannel.name}).then((resp: any) => {
                return resp.data;
            });
        }
    }

    public delete(salesChannel: SalesChannel): IPromise<any> {
        return this.$http.delete(`/api/sales-channel/${salesChannel.id}`).then((resp: any) => {
            return resp.data;
        });
    }
}
