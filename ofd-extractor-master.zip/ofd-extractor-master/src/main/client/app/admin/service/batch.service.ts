import {IHttpService, ILogService, IPromise} from "angular";
import {Batch} from "../model/batch";
import {PagedResult} from "../model/paged-result";

export class BatchService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("BatchService");
    }

    public list(filter?: any): IPromise<Batch[]> {
        return this.$http.post("/api/batch/", filter).then((resp: any) => {
            return resp.data;
        });
    }

    public markAsReviewed(batch: Batch): IPromise<Batch[]> {
        return this.$http.put(`/api/batch/${batch.id}/toggle-reviewed`, batch).then((resp: any) => {
            return resp.data;
        });
    }

    public startManualBatch(shopOperatorId: string, batchDay: string, periodLength: number): IPromise<Batch[]> {
        return this.$http.post("/api/batch/manual", {shopOperatorId, batchDay, periodLength}).then((resp: any) => {
            return resp.data;
        });
    }

    public validateManualBatch(shopOperatorId: string, periodLength: number): IPromise<Batch[]> {
        return this.$http.post("/api/batch/check", {shopOperatorId, periodLength}).then((resp: any) => {
            return resp.data;
        });
    }

    public scroll(cursorStr: string): IPromise<PagedResult> {
        return this.$http.post("/api/batch/search", {cursorStr}).then((resp: any) => {
            return resp.data;
        });
    }
}
