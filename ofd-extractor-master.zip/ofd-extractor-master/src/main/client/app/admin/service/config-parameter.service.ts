import {IHttpService, ILogService, IPromise} from "angular";
import {ConfigParameter} from "../model/config-parameter";

export class ConfigParameterService {
    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService) {
        $log.info("ConfigParameterService");
    }

    public list(): IPromise<ConfigParameter> {
        return this.$http.get("/api/config-parameter").then((resp: any) => {
            return resp.data;
        });
    }

    public save(configParameter: ConfigParameter): IPromise<ConfigParameter> {
        return this.$http.post("/api/config-parameter", configParameter).then((resp: any) => {
            return resp.data;
        });
    }
}
