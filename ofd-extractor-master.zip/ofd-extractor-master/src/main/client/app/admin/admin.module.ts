import uiRouter, {StateProvider} from "@uirouter/angularjs";
import * as angular from "angular";
import {NotificationModule} from "../shared/notification/notification.module";
import {UserModule} from "../shared/user/user.module";
import {AdminLayoutComponent} from "./admin-layout.component";
import {AdminDashboardPageComponent} from "./dashboard-page/dashboard-page.component";
import {ManageUsersPageComponent} from "./manage-users-page/manage-users-page.component";
import {AdminNavbar} from "./navbar/navbar.component";
import {ManageShopOperatorsPageComponent} from "./manage-shop-operators-page/manage-shop-operators-page.component";
import {ShopOperatorService} from "../shared/shop-operator/shop-operator.service";
import {ShopOperatorModalComponent} from "./shop-operator-modal/shop-operator-modal.component";
import {LoadingService} from "../shared/loading-service/loading-service.service";
import {RentalAreaService} from "../shared/rental-area/rental-area.service";
import {ManageRentalAreaPageComponent} from "./manage-rental-areas-page/manage-rental-areas-page.component";
import {RentalAreaModalComponent} from "./manage-rental-areas-page/rental-area-modal/rental-area-modal.component";
import {CategoriesService} from "../shared/categories/categories.service";
import {UnmatchedCategoriesReportsPageComponent} from "./unmatched-categories--page/unmatched-categories-reports-page.compoonent";
import {BatchService} from "./service/batch.service";
import {BatchDetailsModalComponent} from "./dashboard-page/batch-details-modal/batch-details-modal.component";
import {CatalogsPageComponent} from "./catalogs-page/catalogs-page.component";
import {TradePointModule} from "./trade-point/trade-point.module";
import {FormFieldComponent} from "../shared/form-field/form-field.component";
import {SubsectionCategoryService} from "./service/subsection-category.service";
import {ConfirmDeleteSubsectionCategoryModalComponent} from "./catalogs-page/confirm-delete-subsection-category-modal/confirm-delete-subsection-category-modal.component";
import {RunBatchModalComponent} from "./dashboard-page/run-batch-modal/run-batch-modal.component";
import {ConfigParameterService} from "./service/config-parameter.service";
import {NewConfigParameterModalComponent} from "./catalogs-page/new-config-parameter-modal/new-config-parameter-modal.component";
import {PassengerFeedBatchService} from "./service/passenger-feed-batch.service";
import {PassengerFeedBatchDetailsModalComponent} from "./dashboard-page/passenger-feed-batch-details-modal/passenger-feed-batch-details-modal.component";
import {CategoryMappingBatchService} from "./service/category-mapping-batch.service";
import {AirportCatalogService} from "./service/airport-catalog.service";
import {NewAirportModalComponent} from "./catalogs-page/new-airport-modal/new-airport-modal.component";
import {PassengerFeedManualUploadModalComponent} from "./dashboard-page/passenger-feed-manual-upload-modal/passenger-feed-manual-upload-modal.component";
import {PassengerFeedManualUploadService} from "./service/passenger-feed-manual-upload.service";
import {SalesChannelService} from "./service/sales-channel.service";
import {UnmatchedSKUItemService} from "./service/unmatched-sku-item.service";
import {UnmatchedCategoriesReportsService} from "./service/unmatched-categories-report.service";
import {CategoryMappingBatchDetailsModalComponent} from "./unmatched-categories--page/category-mapping-batch-details-modal/category-mapping-batch-details-modal.component";

export const AdminModule = angular
    .module("admin", [uiRouter, NotificationModule, UserModule, TradePointModule])
    .service("shopOperatorService", ShopOperatorService)
    .service("loadingService", LoadingService)
    .service("rentalAreaService", RentalAreaService)
    .service("categoriesService", CategoriesService)
    .service("unmatchedSKUItemService", UnmatchedSKUItemService)
    .service("batchService", BatchService)
    .service("passengerFeedBatchService", PassengerFeedBatchService)
    .service("subsectionCategoryService", SubsectionCategoryService)
    .service("categoryMappingBatchService", CategoryMappingBatchService)
    .service("configParameterService", ConfigParameterService)
    .service("salesChannelService", SalesChannelService)
    .service("passengerFeedManualUploadService", PassengerFeedManualUploadService)
    .service("unmatchedCategoriesReportsService", UnmatchedCategoriesReportsService)
    .service("airportCatalogService", AirportCatalogService)
    .component("adminLayout", AdminLayoutComponent)
    .component("adminNavbar", AdminNavbar)
    .component("formField", FormFieldComponent)
    .component("adminDashboardPage", AdminDashboardPageComponent)
    .component("manageUsersPage", ManageUsersPageComponent)
    .component("manageShopOperatorsPage", ManageShopOperatorsPageComponent)
    .component("shopOperatorModal", ShopOperatorModalComponent)
    .component("manageRentalAreasPage", ManageRentalAreaPageComponent)
    .component("rentalAreaModal", RentalAreaModalComponent)
    .component("batchDetailsModal", BatchDetailsModalComponent)
    .component("passengerFeedBatchDetailsModal", PassengerFeedBatchDetailsModalComponent)
    .component("categoryMappingBatchDetailsModal", CategoryMappingBatchDetailsModalComponent)
    .component("runBatchModal", RunBatchModalComponent)
    .component("unmatchedCategoriesReportsPage", UnmatchedCategoriesReportsPageComponent)
    .component("catalogsPageComponent", CatalogsPageComponent)
    .component("confirmDeleteSubsectionCategoryModal", ConfirmDeleteSubsectionCategoryModalComponent)
    .component("newOfdSessionKeyModal", NewConfigParameterModalComponent)
    .component("passengerFeedManualUploadModal", PassengerFeedManualUploadModalComponent)
    .component("newConfigParameterModal", NewConfigParameterModalComponent)
    .component("newAirportModal", NewAirportModalComponent)

    .config(($stateProvider: StateProvider) => {
        $stateProvider
            .state("admin", {
                parent: "app",
                url: "/admin",
                abstract: true,
                component: "adminLayout",
            })
            .state("admin.dashboard", {
                url: "",
                views: {
                    content: {
                        component: "adminDashboardPage"
                    }
                },
                resolve: {
                    batches: (batchService: BatchService) => {
                        return batchService.list({daysOffset: 0, filteredStatus: []});
                    },
                    passengerFeedBatches: (passengerFeedBatchService: PassengerFeedBatchService) => {
                        return passengerFeedBatchService.list({daysOffset: 0, filteredStatus: []});
                    }
                }
            })
            .state("admin.shop-operators", {
                url: "/shop-operators",
                views: {
                    content: {
                        component: "manageShopOperatorsPage"
                    }
                },
                resolve: {
                    shopOperators: (shopOperatorService: ShopOperatorService) => shopOperatorService.list(),
                    airports: (airportCatalogService: AirportCatalogService) => airportCatalogService.list()
                }
            })
            .state("admin.users", {
                url: "/users",
                views: {
                    content: {
                        component: "manageUsersPage"
                    }
                }
            })
            .state("admin.rental-areas", {
                url: "/rental-areas",
                views: {
                    content: {
                        component: "manageRentalAreasPage"
                    }
                },
                resolve: {
                    rentalAreas: (rentalAreaService: RentalAreaService) => rentalAreaService.listByStatus(["ACTIVE", "MAINTENANCE", "ARCHIVED"])
                }
            })
            .state("admin.categories", {
                url: "/categories",
                views: {
                    content: {
                        component: "manageCategoriesPage"
                    }
                }
            })
            .state("admin.unmatched-categories", {
                url: "/unmatched-categories",
                views: {
                    content: {
                        component: "unmatchedCategoriesReportsPage"
                    }
                },
                resolve: {
                    operatorsWithUnmatchedItems: (unmatchedSKUItemService: UnmatchedSKUItemService) => unmatchedSKUItemService.listOperatorsWithUnmatchedItems(),
                    count: (unmatchedSKUItemService: UnmatchedSKUItemService) => unmatchedSKUItemService.getCount(),
                    categoryMappingBatches: (categoryMappingBatchService: CategoryMappingBatchService) => categoryMappingBatchService.list()
                }
            })
            .state("admin.catalogs", {
                url: "/catalogs",
                views: {
                    content: {
                        component: "catalogsPageComponent"
                    }
                },
                resolve: {
                    subsectionCategories: (subsectionCategoryService: SubsectionCategoryService) => subsectionCategoryService.list(),
                    salesChannels: (salesChannelService: SalesChannelService) => salesChannelService.list()
                }
            })
        ;
    })
    .name;
