import * as angular from "angular";
import {BytesFilter} from "./bytes.filter";

export const BytesFilterModule = angular
    .module("bytes", [])
    .filter("bytes", BytesFilter)
    .name;
