import * as _ from "lodash";

export const BytesFilter = () => {
    return (bytesString: string, precisionString: string) => {
        const bytes = _.toNumber(bytesString);
        if (isNaN(bytes) || !isFinite(bytes)) {
            return "-";
        }
        let precision = _.defaultTo(_.toNumber(precisionString), 1);

        const units = ["байт", "КБ", "МБ", "ГБ", "ТБ", "ПБ"];
        const num = Math.floor(Math.log(bytes) / Math.log(1024));

        if (num === 0) {
            precision = 0;
        }

        return (bytes / Math.pow(1024, Math.floor(num))).toFixed(precision) + " " + units[num];
    };
};
