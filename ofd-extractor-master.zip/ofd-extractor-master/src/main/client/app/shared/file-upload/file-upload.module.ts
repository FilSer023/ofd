import * as angular from "angular";
import "ng-file-upload";
import {BytesFilterModule} from "../bytes/bytes-filter.module";
import {ErrorMessageModule} from "../error-message/error-message.module";
import {AttachmentDownloadComponent} from "./attachment-download/attachment-download.component";
import {AttachmentListComponent} from "./attachment-list/attachment-list.component";
import {AttachmentPreviewComponent} from "./attachment-preview/attachment-preview.component";
import {FileUploadComponent} from "./file-upload.component";
import "./file-upload.less";

export const FileUploadModule = angular
    .module("fileUpload", ["ngFileUpload", BytesFilterModule, ErrorMessageModule])
    .component("fileUpload", FileUploadComponent)
    .component("attachmentList", AttachmentListComponent)
    .component("attachmentPreview", AttachmentPreviewComponent)
    .component("attachmentDownload", AttachmentDownloadComponent)
    .name;
