import {IComponentOptions, ILogService} from "angular";
import * as _ from "lodash";

class AttachmentPreviewController {

    private attachment: { name: string, contentType: string };
    private url: string;

    private type: string;

    /* @ngInject */
    constructor(private $log: ILogService) {
        $log.info("AttachmentPreviewController");
    }

    public $onInit() {
        this.url = `/api/attachments/${encodeURIComponent(this.attachment.name)}`;

        if (this.isImage()) {
            this.type = "image";
        } else if (this.isPdf()) {
            this.type = "pdf";
        } else {
            this.type = "unknown";
        }
    }

    private isImage(): boolean {
        const type = this.attachment.contentType;
        return _.startsWith(type, "image/");
    }

    private isPdf(): boolean {
        const type = this.attachment.contentType;
        return _.startsWith(type, "application/pdf");
    }
}

export const AttachmentPreviewComponent: IComponentOptions = {
    bindings: {
        attachment: "<"
    },
    controller: AttachmentPreviewController,
    template: require("./attachment-preview.html")
};
