/**
 * File object passed by ng-file-upload
 */
export interface NgFile {
    name: string;
    type: string;
    size: number;
}

/**
 * An item waiting to be, or newly uploaded. Queue items are moved to the model when upload is completed.
 */
export interface UploadingFile {
    file: NgFile;
    response?: CloudStorageResponse;
    progress: number;
    isUploading: boolean;
    isSuccess: boolean;
    isError: boolean;
    errorMessage?: string;
    remove?: () => void;
}

/**
 * Response object from the upload to Google Cloud Storage.
 */
export interface CloudStorageResponse {
    mediaLink: string;
    bucket: string;
    contentType: string;
    id: string;
    name: string;
    size: number;
}
