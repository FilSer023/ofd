/**
 * An uploaded file attachment.
 */
export interface Attachment {
    id: string;
    name: string;
    filename: string;
    contentType: string;
    gcsObjectName: string;
    bucket: string;
    size: number;
}
