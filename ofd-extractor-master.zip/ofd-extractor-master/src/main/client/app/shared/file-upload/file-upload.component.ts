import {IComponentOptions, IHttpService, ILogService, IPromise, IQService} from "angular";
import * as _ from "lodash";
import "ng-file-upload/index";
import {Attachment} from "./attachment.model";
import {CloudStorageResponse, NgFile, UploadingFile} from "./file-upload.model";

export const BINDINGS = {
    model: "=?",
    url: "@?",
    label: "@?",
    maxSizeMb: "@?",
    accept: "@?",
    copy: "@?",
    isSingleFileUpload: "<?",
    clearQueueOnComplete: "<?",
    showError: "=?",
    showErrorExp: "&?",
    isUploading: "=?",
    onSubmit: "&?",
    onUploadComplete: "&?",
    onUploadRemoved: "&?"
};

class FileUploadController {

    private model: Attachment[];

    private url: string;
    private maxSize: number;
    private maxSizeMb: number;
    private accept: string;
    private clearQueueOnComplete: boolean;

    private onUploadComplete: (args: object) => void;
    private onUploadRemoved: (args: object) => void;
    private onSubmit: (submitted: object) => void;

    private isUploading: boolean;

    private uploading: UploadingFile[];

    /**
     * Convert a {@link UploadingFile} to an {@link Attachment} representation for the {@link #model}.
     * @param {UploadingFile} item The item to convert.
     * @returns {Attachment} Representation.
     */
    private static toAttachment(item: UploadingFile): Attachment {
        return item === null ? null : {
            filename: item.file ? item.file.name : "",
            gcsObjectName: item.response ? item.response.mediaLink : "",
            bucket: item.response ? item.response.bucket : "",
            contentType: item.response ? item.response.contentType : "",
            id: item.response ? item.response.id : "",
            name: item.response ? item.response.name : "",
            size: item.response ? item.response.size : 0
        };
    }

    /* @ngInject */
    constructor(private $log: ILogService, private $http: IHttpService, private $q: IQService, private Upload: angular.angularFileUpload.IUploadService) {
        $log.info("FileUploadController");

        this.updateModel = this.updateModel.bind(this);
        this.addToModel = this.addToModel.bind(this);
        this.uploadFile = this.uploadFile.bind(this);
    }

    public $onInit() {
        this.model = _.defaultTo(this.model, []);
        this.url = _.defaultTo(this.url, "/storage/url");
        this.maxSizeMb = _.defaultTo(this.maxSizeMb, 1024);
        this.maxSize = _.defaultTo(this.maxSize, this.maxSizeMb * 1024 * 1024);
        this.accept = _.defaultTo(this.accept, "*");
        this.uploading = _.defaultTo(this.uploading, []);
        this.isUploading = _.defaultTo(this.isUploading, false);
    }

    /**
     * Handler for ng-file-upload's {@code ngf-select} callback. Handles the file uploading.
     * @param {Attachment[]} files The files to upload.
     */
    public uploadFiles(files: Attachment[]) {
        if (files !== undefined && files.length > 0) {
            this.isUploading = true;

            const itemPromises = _.map(files, this.uploadFile);

            this.$q.all(itemPromises).then(() => {
                this.isUploading = false;
                this.updateModel();
            });
        }

    }

    /**
     * Add an item to the upload uploading.
     * @param file The item to upload.
     * @returns {angular.IPromise<*>} Upload promise.
     */
    private uploadFile(file: NgFile): IPromise<any> {
        const item: UploadingFile = {
            file: file,
            progress: 0,
            isUploading: false,
            isSuccess: false,
            isError: false,
            remove: null,
        };

        this.uploading.push(item);

        if (file.size > this.maxSize) {
            item.isUploading = false;
            item.isError = true;
            item.errorMessage = "File size exceeds limit.";
            item.remove = () => this.removeItem(item);
            this.$log.info("item set to error:", item);
            return this.$q.when(item);
        }


        return this.$http.post(this.url, {name: file.name, type: file.type, size: file.size})
            .then((response) => {
                    item.isUploading = true;
                    const uploadUrl = response.data as string;

                    const upload = this.Upload.http({
                        method: "POST",
                        url: uploadUrl,
                        headers: {
                            "Content-Type": file.type
                        },
                        data: file
                    });

                    item.remove = () => this.removeItem(item, upload);

                    return upload.then(
                        (resp) => {
                            item.response = resp.data as CloudStorageResponse;
                            item.isUploading = false;
                            item.isSuccess = true;
                            item.progress = 100.0;
                            return item;
                        }, (error) => {
                            item.isUploading = false;
                            item.isError = true;
                            return item;
                        }, (notify) => {
                            item.progress = 90.0 * notify.loaded / notify.total;
                        });

                }, () => {
                    item.isError = true;
                }
            );
    }

    /**
     * Update the model object with changes from the uploading.
     */
    private updateModel(): void {
        this.model.length = 0;
        _.each(this.uploading, this.addToModel);
    }

    /**
     * Add a uploading item to the model.
     * @param {UploadingFile} item The item to add.
     */
    private addToModel(item: UploadingFile): void {
        if (item.isSuccess && !!item.response) {
            const attachment = FileUploadController.toAttachment(item);

            this.notifyItemUploadComplete(attachment);

            this.model.push(attachment);
            if (this.clearQueueOnComplete) {
                this.uploading = _.without(this.uploading, item);
            }
        }
    }

    /**
     * Remove an item from the upload uploading.
     * @param item The item to remove.
     * @param {angular.angularFileUpload.IUploadPromise<*>} promise Promise to the upload if the file is currently being uploaded.
     */
    private removeItem(item: UploadingFile, promise?: angular.angularFileUpload.IUploadPromise<any>): void {
        if (item.isUploading) {
            promise.abort();
        }
        _.remove(this.uploading, (current) => current === item);

        this.updateModel();
        this.notifyItemRemoved(item);
    }

    /**
     * Notify the {@code onUploadComplete} callback that the upload has completed.
     * @param file The file uploaded.
     */
    private notifyItemUploadComplete(file: Attachment): void {
        if (this.onUploadComplete) {
            this.onUploadComplete({file: file});
        }
    }

    /**
     * Notify the {@code onUploadRemoved} callback that an item has been removed.
     * @param file The item removed.
     */
    private notifyItemRemoved(file: UploadingFile): void {
        if (this.onUploadRemoved) {
            this.onUploadRemoved({file: file});
        }
    }

    /**
     * Submit the items in the uploading and clear it.
     */
    private submit(): void {
        const entries = _.clone(this.model);
        if (this.onSubmit) {
            this.onSubmit({files: entries});
        }
        this.uploading.length = 0;
        this.updateModel();
    }
}

export const FileUploadComponent: IComponentOptions = {
    bindings: BINDINGS,
    controller: FileUploadController,
    template: require("./file-upload.html")
};
