import {IComponentOptions, ILogService} from "angular";

class AttachmentListController {

    /* @ngInject */
    constructor(private $log: ILogService) {
        $log.info("AttachmentListController");
    }
}

export const AttachmentListComponent: IComponentOptions = {
    bindings: {
        list: "<"
    },
    controller: AttachmentListController,
    template: require("./attachment-list.html")
};
