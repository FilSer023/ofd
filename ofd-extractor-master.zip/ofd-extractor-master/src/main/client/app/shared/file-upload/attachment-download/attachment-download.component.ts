import {IComponentOptions, ILogService} from "angular";

class AttachmentDownloadController {

    private attachment: { name: string };
    private url: string;

    /* @ngInject */
    constructor(private $log: ILogService) {
        $log.info("AttachmentDownloadController");
    }

    public $onInit() {
        this.url = `/api/attachments/${encodeURIComponent(this.attachment.name)}`;
    }
}

export const AttachmentDownloadComponent: IComponentOptions = {
    bindings: {
        attachment: "<"
    },
    controller: AttachmentDownloadController,
    template: require("./attachment-download.html")
};
