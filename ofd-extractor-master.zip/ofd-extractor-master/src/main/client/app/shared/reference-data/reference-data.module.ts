import * as angular from "angular";
import {DescriptionFilter} from "./description.filter";
import {ReferenceData} from "./reference-data.service";

export const ReferenceDataModule = angular
    .module("referenceData", [])
    .filter("description", DescriptionFilter)
    .service("referenceData", ReferenceData)
    .name;
