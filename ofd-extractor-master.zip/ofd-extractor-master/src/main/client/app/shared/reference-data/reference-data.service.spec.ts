import {} from "jasmine";
import * as angular from "angular";
import {IHttpBackendService} from "angular";
import "angular-mocks";
import {ReferenceDataModule} from "./reference-data.module";
import {ReferenceData} from "./reference-data.service";


describe("referenceData", () => {
    let $httpBackend;
    let referenceData;
    let mockReferenceDataResponse;

    function ref(id: string, description?: string) {
        return {
            id: id,
            description: description || id
        };
    }

    beforeEach(angular.mock.module(ReferenceDataModule));

    beforeEach(angular.mock.inject((_$httpBackend_: IHttpBackendService, _referenceData_: ReferenceData) => {
        $httpBackend = _$httpBackend_;
        referenceData = _referenceData_;

        mockReferenceDataResponse = {
            MyStatus: [
                ref("NEW", "New"),
                ref("IN_PROGRESS", "In Progress"),
                ref("COMPLETE", "Complete")
            ]
        };

        $httpBackend.whenGET("/api/reference-data").respond(200, angular.toJson(mockReferenceDataResponse));
    }));

    describe("init", () => {

        it("should return promise with self", () => {
            const promise = referenceData.init();

            let promiseResult = null;
            promise.then((result) => promiseResult = result);
            $httpBackend.flush();

            expect(promiseResult).toBe(referenceData);
        });

    });

    describe("getAll", () => {
        beforeEach(() => {
            referenceData.init();
            $httpBackend.flush();
        });

        it("should get the matching items", () => {
            const result = referenceData.getAll("MyStatus");

            expect(result).toBeDefined();
            expect(result).toEqual(mockReferenceDataResponse.MyStatus);
        });

        it("should return a clone so that no mutations affect the internal cache", () => {
            const result = referenceData.getAll("MyStatus");

            expect(result[0].description).toBe("New");
            result[0].description = "Updated by some rogue client code";

            expect(referenceData.getAll("MyStatus")[0].description).toBe("New");
        });

        it("should return undefined when no matching type", () => {
            const result = referenceData.getAll("NO MATCHING TYPE");

            expect(result).not.toBeDefined();
        });

    });


    describe("get", () => {
        beforeEach(() => {
            referenceData.init();
            $httpBackend.flush();
        });

        it("should get the matching item", () => {
            const result = referenceData.get("MyStatus", "NEW");

            expect(result).toBeDefined();
            expect(result.id).toBe("NEW");
        });

        it("should return a clone so that no mutations affect the internal cache", () => {
            const result = referenceData.get("MyStatus", "NEW");

            expect(result.description).toBe("New");
            result.description = "Updated by some rogue client code";

            expect(referenceData.get("MyStatus", "NEW").description).toBe("New");
        });


        it("should return undefined when no matching item", () => {
            const result = referenceData.get("MyStatus", "Status UNDEFINED");

            expect(result).not.toBeDefined();
        });

        it("should return undefined when no matching type", () => {
            const result = referenceData.get("NO MATCHING TYPE", "Anything");

            expect(result).not.toBeDefined();
        });
    });

    describe("getDescription", () => {
        beforeEach(() => {
            referenceData.init();
            $httpBackend.flush();
        });

        it("should get the matching item description", () => {
            const result = referenceData.getDescription("MyStatus", "NEW");

            expect(result).toBe("New");
        });

        it("should return id when no matching item", () => {
            const result = referenceData.getDescription("MyStatus", "Status UNDEFINED");

            expect(result).toBe("Status UNDEFINED");
        });

        it("should return id when no matching type", () => {
            const result = referenceData.getDescription("NO MATCHING TYPE", "Anything");

            expect(result).toBe("Anything");
        });

    });



});
