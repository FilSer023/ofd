import _ = require("lodash");

export interface IReferenceDataItem {
    id: string;
    description: string;
    props: Map<string, string>;
}

export interface IReferenceDataMap {
    [key: string]: IReferenceDataItem[];
}

export class ReferenceData {

    private refData: IReferenceDataMap;

    /* @ngInject */
    constructor(private $http: ng.IHttpService, private $log: ng.ILogService) {
        $log.info("ReferenceData constructed");
    }

    public init() {
        this.$log.info("ReferenceData init()");
        return this.$http.get("/api/reference-data").then((response) => {
            this.refData = Object.freeze(response.data as IReferenceDataMap);

            return this;
        });
    }

    public getAll(type: string): IReferenceDataItem[] {
        return _.cloneDeep(this.getAllInternal(type));
    }

    public get(type: string, id: string): IReferenceDataItem {
        return _.cloneDeep(this.getObject(type, id));
    }

    // Get the corresponding description or else return the id back
    public getDescription(type: string, id: string): string {
        if (_.isNil(id)) {
            return id;
        }

        return _.get(this.getObject(type, id), "description", id);
    }


    // Internal methods return pointers to source objects. Public methods return copies to avoid source corruption/mutation.
    private getObject(type: string, id: string) {
        const referenceDataForType = this.getAllInternal(type);
        return _.find(referenceDataForType, {id: id});
    }

    private getAllInternal(type: string): IReferenceDataItem[] {
        if (_.isNil(this.refData)) {
            this.$log.error("Reference data has not been initialised. Initialise in ui-router using init() in a top-level route.");
            return undefined;
        }
        return this.refData[type];
    }

}
