import {ReferenceData} from "./reference-data.service";

/* @ngInject */
export const DescriptionFilter = (referenceData: ReferenceData) => {

  return (input: string, type: string) => referenceData.getDescription(type, input);

};
