import IProvideService = angular.auto.IProvideService;
import {TransitionService} from "@uirouter/angularjs";
import {RejectType} from "@uirouter/core";
import * as angular from "angular";
import {IHttpProvider, ILocationProvider, ILocationService, ILogService, IScope} from "angular";
import {LoadingService} from "../loading-service/loading-service.service";
import {includes} from "lodash";

const PRODUCTION_HOSTS = [
    "ofd-extractor-prod.appspot.com"
];

const isProduction = (host) => includes(PRODUCTION_HOSTS, host);


const run = ($transitions: TransitionService, $log: ILogService,
             $rootScope: IScope,
             $location: ILocationService,
             loadingService: LoadingService) => {

    $rootScope["isDevelopment"] = !isProduction($location.host());

    $transitions.onError({}, (trans: any) => {
        if (trans.error().type === RejectType.IGNORED) {
            $log.info("Transition ignored transitioning to view: %o", trans);
        } else if (trans.error().type === RejectType.SUPERSEDED) {
            $log.info("Transition superseded transitioning to view: %o", trans);
        } else {
            $log.error("Error transitioning to view: %o", trans);
        }
    });

    $transitions.onStart({}, (trans) => {
        const fromState = trans.from();
        const toState = trans.to();
        loadingService.show();

        $log.debug(`State transitioning from ${fromState.name} to ${toState.name}`);

        trans.promise.then(() => {
            loadingService.hide();
            $log.debug("transition promises resolved: ");
        });
    });
};

const ieCacheFix = ($httpProvider: IHttpProvider) => {

    // Initialize http get header defaults if required
    if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};
    }

    // Disable IE ajax request caching
    $httpProvider.defaults.headers.get["If-Modified-Since"] = 0;
};

const html5Mode = ($locationProvider: ILocationProvider) => {
    $locationProvider.html5Mode(true);
};

const templateCacheBuster = ($provide: IProvideService) => {

    const cacheBuster = Date.now().toString();

    function templateFactoryDecorator($delegate: any) {
        const fromUrl = angular.bind($delegate, $delegate.fromUrl);
        $delegate.fromUrl = (url: string, params: any) => {
            if (url !== null && angular.isDefined(url) && angular.isString(url)) {
                url += (url.indexOf("?") === -1 ? "?" : "&");
                url += "v=" + cacheBuster;
            }

            return fromUrl(url, params);
        };

        return $delegate;
    }

    $provide.decorator("$templateFactory", ["$delegate", templateFactoryDecorator]);
};

export const ConfigModule = angular
    .module("app.config", [])
    .config(ieCacheFix)
    .config(html5Mode)
    .config(templateCacheBuster)
    .run(run)
    .name;

