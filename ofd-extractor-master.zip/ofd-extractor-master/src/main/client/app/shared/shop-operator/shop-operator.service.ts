import {IHttpService, ILogService, IPromise, IQService} from "angular";
import {ShopOperator} from "../../admin/model/shop-operator";


export class ShopOperatorService {

    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService,
                private $q: IQService) {
        $log.info("ShopOperatorService");
    }

    public list(): IPromise<ShopOperator[]> {
        return this.$http.get(`/api/shop-operator/`).then((resp: any) => {
            return resp.data;
        });
    }

    public update(shopOperator: ShopOperator): IPromise<ShopOperator> {
        return this.$http.put(`/api/shop-operator/${shopOperator.id}`, shopOperator).then((resp: any) => {
            return resp.data;
        });
    }

    public changeShopOperatorStatus(shopOperator: ShopOperator, status: string): IPromise<ShopOperator> {
        return this.$http.put(`/api/shop-operator/${shopOperator.id}/status`, {status: status}).then((resp: any) => {
            return resp.data;
        });
    }

    public save(shopOperator: ShopOperator): IPromise<ShopOperator> {
        return this.$http.post("/api/shop-operator/", shopOperator).then((resp: any) => {
            return resp.data;
        });
    }

    public availableOperators(): IPromise<ShopOperator[]> {
        return this.$http.get(`/api/shop-operator/available`).then((resp: any) => {
            return resp.data;
        });
    }

    public checkNameAvailability(name: string): IPromise<boolean> {
        return this.$http.post(`/api/shop-operator/check-name`, {name}).then((resp: any) => {
            return resp.data;
        });
    }
}
