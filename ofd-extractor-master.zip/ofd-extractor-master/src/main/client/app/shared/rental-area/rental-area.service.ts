import {IHttpService, ILogService, IPromise, IQService} from "angular";
import {RentalArea} from "../../admin/model/rental-area";


export class RentalAreaService {

    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService,
                private $q: IQService) {
        $log.info("RentalAreaService");
    }

    public listByStatus(status: string[]): IPromise<RentalArea[]> {
        return this.$http.post(`/api/rental-area/list`, status).then((resp: any) => {
            return resp.data;
        });
    }

    public update(rentalArea: RentalArea): IPromise<RentalArea> {
        return this.$http.put(`/api/rental-area/${rentalArea.id}`, rentalArea).then((resp: any) => {
            return resp.data;
        });
    }

    public changeRentalAreaStatus(rentalArea: RentalArea, status: string): IPromise<RentalArea> {
        return this.$http.put(`/api/rental-area/${rentalArea.id}/status`, {status: status}).then((resp: any) => {
            return resp.data;
        });
    }

    public deleteRentalArea(rentalArea: RentalArea): IPromise<boolean> {
        return this.$http.delete(`/api/rental-area/${rentalArea.id}`).then((resp: any) => {
            return resp.data;
        });
    }

    public save(rentalArea: RentalArea): IPromise<RentalArea> {
        return this.$http.post("/api/rental-area/", rentalArea).then((resp: any) => {
            return resp.data;
        });
    }

    public getFreeRentalAreas(): IPromise<RentalArea[]> {
        return this.$http.get("/api/free-rental-areas/").then((resp: any) => {
            return resp.data;
        });
    }
}
