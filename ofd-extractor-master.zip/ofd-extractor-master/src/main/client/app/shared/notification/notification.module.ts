import "@cgross/angular-notify";
import * as angular from "angular";
import {NotificationService} from "./notification.service";

export const NotificationModule = angular
    .module("notification", ["cgNotify"])
    .service("notificationService", NotificationService)
    .name;
