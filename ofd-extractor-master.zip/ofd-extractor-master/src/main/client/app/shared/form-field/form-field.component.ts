import {IComponentOptions, ILogService} from "angular";
import "./form-field.less";

class FormFieldController {
    public readonly: boolean;
    public labelDescription: string;
    public original: string;
    public valueModel: any;

    /* @ngInject */
    constructor(private $log: ILogService) {
        if (this.readonly && (this.labelDescription == null || this.labelDescription.length <= 0)) {
            this.labelDescription = "(Read only)";
        }
    }

    public $onInit() {
        this.original = this.valueModel;
    }

    private revert() {
        this.valueModel = this.original;
    }
}

export const FormFieldComponent: IComponentOptions = {
    bindings: {
        formName: "<",
        type: "@",
        label: "@",
        labelDescription: "@",
        description: "@",
        placeholder: "@",
        name: "@",
        regex: "@",
        regexErrorMessage: "@",
        displayErrorState: "<",
        min: "<",
        max: "<",
        requiredFlag: "<",
        disabledFlag: "<",
        readonlyFlag: "<",
        updatableFlag: "<",
        progressIndicator: "<",
        autoComplete: "@",
        ngChange: "&",
        onUpdate: "&",
        hasError: "<",
        valueModel: "=",
    },
    controller: FormFieldController,
    template: require("./form-field.html")
};
