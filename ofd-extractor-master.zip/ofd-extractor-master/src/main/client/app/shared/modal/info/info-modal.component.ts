import {IComponentOptions} from "angular";
import "ui-select/dist/select.css";

export interface IInfoOpts {
    body: string;
    title?: string;
    okText?: string;
}

class InfoModalController {

    private resolve: {options: IInfoOpts};
    private options: IInfoOpts;

    public $onInit() {
        this.options = this.resolve.options;
        this.options.title = this.options.title || "Information";
        this.options.okText = this.options.okText || "OK";
    }
}

export const InfoModalComponent: IComponentOptions = {
    controller: InfoModalController,
    template: require("./info-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "<"
    }
};

