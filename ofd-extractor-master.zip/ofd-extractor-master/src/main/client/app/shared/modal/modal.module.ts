import * as angular from "angular";
import {ModalService} from "./modal.service";
import {ConfirmModalComponent} from "./confirm/confirm-modal.component";
import {InfoModalComponent} from "./info/info-modal.component";

export const ModalModule = angular
    .module("modal", ["ui.bootstrap"])
    .component("confirmModal", ConfirmModalComponent)
    .component("infoModal", InfoModalComponent)
    .service("modalService", ModalService)
    .name;
