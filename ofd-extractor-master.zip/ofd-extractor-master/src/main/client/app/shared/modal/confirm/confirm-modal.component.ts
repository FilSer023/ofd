import {IComponentOptions} from "angular";
import "ui-select/dist/select.css";

export interface IConfirmOpts {
    body: string;
    title?: string;
    noText?: string;
    yesText?: string;
}

class ConfirmModalController {

    private resolve: {options: IConfirmOpts};
    private options: IConfirmOpts;

    public $onInit() {
        this.options = this.resolve.options;
        this.options.title = this.options.title || "Вы уверены?";
        this.options.noText = this.options.noText || "Нет";
        this.options.yesText = this.options.yesText || "Да";
    }
}

export const ConfirmModalComponent: IComponentOptions = {
    controller: ConfirmModalController,
    template: require("./confirm-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&",
        resolve: "<"
    }
};

