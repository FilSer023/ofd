import {IPromise} from "angular";
import {IModalService} from "angular-ui-bootstrap";
import {IConfirmOpts} from "./confirm/confirm-modal.component";
import {IInfoOpts} from "./info/info-modal.component";

export class ModalService {

    /* @ngInject */
    constructor(private $uibModal: IModalService) {
    }

    public confirm(opts: IConfirmOpts): IPromise<any> {
        return this.$uibModal.open({
            component: "confirmModal",
            resolve: {
                options: () => opts
            },
        }).result;
    }

    public info(opts: IInfoOpts): IPromise<any> {
        return this.$uibModal.open({
            component: "infoModal",
            resolve: {
                options: () => opts
            },
        }).result;
    }

}
