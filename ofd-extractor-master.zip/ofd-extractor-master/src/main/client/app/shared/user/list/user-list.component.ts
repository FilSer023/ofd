import {IComponentOptions, ILogService} from "angular";
import {IUser} from "../user.model";
import "./user-list.less";
import {IModalService} from "angular-ui-bootstrap";
import {NotificationService} from "../../notification/notification.service";
import {UserService} from "../user.service";

interface UserListItem extends IUser {
    selected: boolean;
}

class UserListController {

    private users: UserListItem[] = [];
    private loading = false;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $uibModal: IModalService,
                private notificationService: NotificationService,
                private userService: UserService) {
        $log.info("UserListController");
    }

    public selectedUsers(): UserListItem[] {
        return this.users.filter((user) => user.selected);
    }

    public hasSelectedUsers(): boolean {
        return this.selectedUsers().length > 0;
    }

    public editUser(userToEdit) {
        const modalInstance = this.$uibModal.open({
            animation: true,
            component: "userEditModal",
            resolve: {
                user: userToEdit,
            }
        });

        modalInstance.result
            .then((user) => {
                return this.userService.save(user)
                    .then(() => {
                        this.notificationService.success("Profile saved");
                    }).catch((rejected) => {
                        const errorMessage = rejected.status === 403 ? "Ошибка доступа" : "Ошибка при совершении действия";
                        this.notificationService.error(errorMessage);
                    });
            }, () => {
                // ignore modal dismissal
            })
            .catch((error) => {
                this.notificationService.error(error.message);
            });
    }
}

export const UserListComponent: IComponentOptions = {
    controller: UserListController,
    template: require("./user-list.html"),
    bindings: {
        users: "<",
        loading: "<",
        onDelete: "<"
    }
};
