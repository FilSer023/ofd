import {IHttpService, ILogService, IPromise, IQService} from "angular";
import {ICredentials, IUser, IUserInvite, IUserRegistrationRequest} from "./user.model";

const transformToError = (response) => {
    throw new Error(response.data.message);
};

export class UserService {

    private baseUrl = "/api/v1/users";
    private loggedInUser: IUser = null;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService,
                private $q: IQService) {
        $log.info("UserService");
    }

    public isAuthenticated() {
        return this.me()
            .then(() => true)
            .catch(() => false);
    }

    public login(credentials: ICredentials): IPromise<IUser> {
        this.loggedInUser = null;

        return this.$http.post(`${this.baseUrl}/login`, credentials)
            .then((response) => {
                this.loggedInUser = response.data as IUser;
                return this.loggedInUser;
            }, transformToError);
    }

    public logout(): IPromise<void> {
        this.loggedInUser = null;
        return this.$http.post(`${this.baseUrl}/logout`, null)
            .then(() => {}, transformToError);
    }

    public me(): IPromise<IUser> {
        if (this.loggedInUser) {
            return this.$q.resolve(this.loggedInUser);
        }

        return this.$http.get(`${this.baseUrl}/me`)
            .then((response) => {
                this.loggedInUser = response.data as IUser;
                return this.loggedInUser;
            }, transformToError);
    }

    public list(): IPromise<IUser[]> {
        return this.$http.get(`${this.baseUrl}`)
            .then((response) => response.data as IUser[], transformToError);
    }

    public save(user: IUser): IPromise<IUser> {
        return this.$http.put(`${this.baseUrl}/${user.username}`, user)
            .then((response) => {
                this.loggedInUser = response.data as IUser;
                return this.loggedInUser;
            }, transformToError);
    }

    public remove(user: IUser): IPromise<void> {
        return this.$http.delete(`${this.baseUrl}/${user.username}`)
            .then(() => {}, transformToError);
    }

    public invite(userInvite: IUserInvite): IPromise<void> {
        return this.$http.post(`${this.baseUrl}/invite`, userInvite)
            .then(() => {}, transformToError);
    }

    public redeemInvite(inviteCode: string, registrationRequest: IUserRegistrationRequest): IPromise<IUser> {
        return this.$http.post(`${this.baseUrl}/invite/${inviteCode}`, registrationRequest)
            .then((response) => {
                this.loggedInUser = response.data as IUser;
                return this.loggedInUser;
            }, transformToError);
    }

    public requestMagicLink(email: string): IPromise<void> {
        return this.$http.post(`${this.baseUrl}/login/magic`, { email })
            .then(() => {}, transformToError);
    }

    public hasAnyRole(user, roles): boolean {
        return roles.some((role) => user.roles.indexOf(role) >= 0);
    }
}
