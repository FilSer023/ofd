/**
 * Login credentials definition.
 */
export interface ICredentials {
    username: string;
    password: string;
}

export interface IUser {
    username: string;
    email: string;
    name: string;
    properties: { [key: string]: string };
    roles: string[];
    created: string;
    lastLogin: string;
}

export interface IUserRegistrationRequest {
    code: string;
    name?: string;
    password?: string;
}

export interface IUserInvite {
    email?: string;
    roles?: string[];
}
