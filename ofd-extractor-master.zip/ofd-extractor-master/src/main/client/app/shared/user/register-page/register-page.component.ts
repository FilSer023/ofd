import {IComponentOptions, ILogService} from "angular";
import {StateParams} from "@uirouter/angularjs";
import {StateService} from "@uirouter/core";
import "../user.less";
import {IUserRegistrationRequest} from "../user.model";
import {UserService} from "../user.service";

interface RegisterPageParams extends StateParams {
    inviteCode?: string;
}

class RegisterPageController {
    private submitting: boolean = false;
    private userDetails: IUserRegistrationRequest;
    private errorMessage: string;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $state: StateService,
                private $stateParams: RegisterPageParams,
                private userService: UserService) {
        $log.info("RegisterPageController", $stateParams.inviteCode);
    }

    public submit() {
        this.submitting = true;
        this.errorMessage = null;

        this.userService.redeemInvite(this.$stateParams.inviteCode, this.userDetails)
            .then((user) => {
                this.submitting = false;
                this.userService.hasAnyRole(user, ["super", "admin"])
                    ? this.$state.go("admin.dashboard")
                    : this.$state.go("app.home");
            })
            .catch((error) => {
                this.submitting = false;
                this.errorMessage = error.message;
            });
    }
}

export const RegisterPageComponent: IComponentOptions = {
    controller: RegisterPageController,
    template: require("./register-page.html")
};
