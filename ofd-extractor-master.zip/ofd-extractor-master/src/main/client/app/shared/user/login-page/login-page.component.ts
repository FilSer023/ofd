import {IComponentOptions, ILogService} from "angular";
import {StateService} from "@uirouter/core";
import "../user.less";
import {ICredentials} from "../user.model";
import {UserService} from "../user.service";
import "./login-page.less";

class LoginPageController {

    private credentials: ICredentials;
    private submitting = false;
    private errorMessage: string;

    /* @ngInject */
    constructor(private $log: ILogService,
                private $state: StateService,
                private userService: UserService) {
        $log.info("ForgotPasswordPageController");
    }

    public login() {
        this.errorMessage = null;
        this.submitting = true;

        this.userService.login(this.credentials)
            .then((user) => {
                this.userService.hasAnyRole(user, ["super", "admin"])
                    ? this.$state.go("admin.dashboard")
                    : this.$state.go("app.home");
            }, (error) => {
                this.submitting = false;
                this.errorMessage = error.message;
            });
    }
}

export const LoginPageComponent: IComponentOptions = {
    controller: LoginPageController,
    template: require("./login-page.html")
};

