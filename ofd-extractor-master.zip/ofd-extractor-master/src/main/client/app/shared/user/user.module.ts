import uiRouter, {StateProvider, TransitionService} from "@uirouter/angularjs";
import * as angular from "angular";
import {ILogService} from "angular";
import {StateService} from "@uirouter/core";
import {UserEditModalComponent} from "./edit-modal/edit-modal.component";
import {ForgotPasswordPageComponent} from "./forgot-password-page/forgot-password-page.component";
import {UserInviteModalComponent} from "./invite-modal/invite-modal.component";
import {UserListComponent} from "./list/user-list.component";
import {LoginPageComponent} from "./login-page/login-page.component";
import {RegisterPageComponent} from "./register-page/register-page.component";
import {UserService} from "./user.service";

export const UserModule = angular
    .module("user", [uiRouter])
    .service("userService", UserService)
    .component("loginPage", LoginPageComponent)
    .component("forgotPasswordPage", ForgotPasswordPageComponent)
    .component("registerPage", RegisterPageComponent)
    .component("userList", UserListComponent)
    .component("userInviteModal", UserInviteModalComponent)
    .component("userEditModal", UserEditModalComponent)
    .config(($stateProvider: StateProvider) => {
        $stateProvider
            .state("user", {
                abstract: true
            })
            .state("user.login", {
                url: "/login",
                component: "loginPage"
            })
            .state("user.forgotPassword", {
                url: "/forgot-password",
                component: "forgotPasswordPage"
            })
            .state("user.register", {
                url: "/register/:inviteCode",
                component: "registerPage"
            })
            .state("user.logout", {
                url: "/logout",
                resolve: {
                    logout: ($state: StateService, userService: UserService) => {
                        return userService.logout()
                            .then(() => $state.go("user.login"));
                    }
                }
            });
    })
    .run(($transitions: TransitionService, $log: ILogService, userService: UserService) => {
        const isAdminRoute = (state) => /^admin\.(.*)/.test(state.name);

        const matchTo = (state) => {
            if (state.data != null && state.data.loginRequired === true) {
                return true;
            }
            return isAdminRoute(state);
        };

        const hasAuthorisation = (state, user) => {
            const { data } = state;

            const roles = (data && data.hasAnyRole) || (isAdminRoute(state) && ["super", "admin", "operator"]);
            if (roles && roles.length > 0) {
                return userService.hasAnyRole(user, roles);
            }

            return true;
        };

        $transitions.onStart({ to: matchTo }, (transition) => {
            return userService.isAuthenticated()
                .then((authenticated) => {
                    if (!authenticated) {
                        $log.error("Not authenticated. Redirecting to login page...");
                        return transition.router.stateService.target("user.login");
                    }

                    return userService.me().then((user) => {
                        if (!hasAuthorisation(transition.$to(), user)) {
                            // TODO redirect to 404 or 403 page??
                            $log.error("Not authorised. Redirecting to login page...", user);
                            return transition.router.stateService.target("user.login");
                        }
                    });
                });
        });
    })
    .name;
