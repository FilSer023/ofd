import {IComponentOptions, ILogService} from "angular";
import "ui-select/dist/select.css";
import {IUser} from "../user.model";

class UserEditModalController {

    private roles = ["admin", "super", "operator"];
    private resolve: any;
    private user: IUser;
    private close: (result?: any) => void;
    private dismiss: (reason?: any) => void;

    /* @ngInject */
    constructor(private $log: ILogService) {
    }

    public $onInit() {
        this.user = this.resolve.user;
    }

    public save() {
        this.close({ $value: this.user });
    }

    public cancel() {
        this.dismiss();
    }
}

export const UserEditModalComponent: IComponentOptions = {
    controller: UserEditModalController,
    template: require("./edit-modal.html"),
    bindings: {
        resolve: "<",
        close: "&",
        dismiss: "&"
    }
};

