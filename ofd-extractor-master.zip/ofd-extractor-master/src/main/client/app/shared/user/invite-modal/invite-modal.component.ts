import {IComponentOptions, ILogService} from "angular";
import "ui-select/dist/select.css";
import {IUserInvite} from "../user.model";

class UserInviteModalController {

    private roles = ["admin", "operator", "super"];
    private invite: IUserInvite = {};
    private close: (result?: any) => void;
    private dismiss: (reason?: any) => void;

    /* @ngInject */
    constructor(private $log: ILogService) {
    }

    public send() {
        this.close({ $value: this.invite });
    }

    public cancel() {
        this.dismiss();
    }
}

export const UserInviteModalComponent: IComponentOptions = {
    controller: UserInviteModalController,
    template: require("./invite-modal.html"),
    bindings: {
        close: "&",
        dismiss: "&"
    }
};
