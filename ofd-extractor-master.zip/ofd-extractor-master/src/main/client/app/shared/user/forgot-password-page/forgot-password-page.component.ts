import {IComponentOptions, ILogService} from "angular";
import "../user.less";
import {UserService} from "../user.service";
import "./forgot-password-page.less";

class ForgotPasswordPageController {

    private email: string;
    private submitting = false;
    private message: { type: string, text: string };

    /* @ngInject */
    constructor(private $log: ILogService,
                private userService: UserService) {
        $log.info("ForgotPasswordPageController");
    }

    public requestMagicLink() {
        this.message = null;
        this.submitting = true;

        this.userService.requestMagicLink(this.email)
            .then(() => {
                this.submitting = false;
                this.message = { type: "success", text: "Ссылка для сброса пароля успешно отправлена, пожалуйста проверьте почту" };
            }, (error) => {
                this.submitting = false;
                this.message = { type: "danger", text: error.message };
            });
    }
}

export const ForgotPasswordPageComponent: IComponentOptions = {
    controller: ForgotPasswordPageController,
    template: require("./forgot-password-page.html")
};
