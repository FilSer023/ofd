import {ILogService, IRootScopeService} from "angular";

export class LoadingService {

    /* @ngInject */
    constructor(private $log: ILogService, private $rootScope: IRootScopeService) {

    }

    public show() {
        this.$log.debug("show");
        this.$rootScope["stateLoading"] = true;
    }

    public hide() {
        this.$log.debug("hide");
        this.$rootScope["stateLoading"] = false;
    }
}
