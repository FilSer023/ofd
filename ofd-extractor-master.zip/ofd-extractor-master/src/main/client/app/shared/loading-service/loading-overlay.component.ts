import {IComponentOptions, ILogService} from "angular";

class LoadingOverlayController {

    /* @ngInject */
    constructor(private $log: ILogService) {
        $log.info("LoadingOverlayController");
    }
}

export const LoadingOverlayComponent: IComponentOptions = {
    controller: LoadingOverlayController,
    template: require("./loading-overlay.html")
};
