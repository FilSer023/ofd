import * as angular from "angular";
import {LoadingService} from "./loading-service.service";
import {LoadingOverlayComponent} from "./loading-overlay.component";

export const LoadingServiceModule = angular
    .module("loadingService", [])
    .component("loadingOverlay", LoadingOverlayComponent)
    .service("loadingService", LoadingService)
    .name;
