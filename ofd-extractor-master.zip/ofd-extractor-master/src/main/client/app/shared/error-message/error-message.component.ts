import {IComponentOptions, ILogService} from "angular";
import "ng-file-upload/index";
import "./error-message.less";

class ErrorMessageController {
    /* @ngInject */
    constructor(private $log: ILogService) {
        
    }
}

export const ErrorMessageComponent: IComponentOptions = {
    bindings: {
        show: "<"
    },
    controller: ErrorMessageController,
    template: require("./error-message.html"),
    transclude: true
};
