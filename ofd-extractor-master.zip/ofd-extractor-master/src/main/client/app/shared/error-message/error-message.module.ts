import * as angular from "angular";
import {ErrorMessageComponent} from "./error-message.component";

export const ErrorMessageModule = angular
    .module("errorMessage", [])
    .component("errorMessage", ErrorMessageComponent)
    .name;
