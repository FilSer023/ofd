import {IHttpService, ILogService, IPromise, IQService} from "angular";


export class CategoriesService {

    /* @ngInject */
    constructor(private $log: ILogService,
                private $http: IHttpService,
                private $q: IQService) {
        $log.info("CategoriesService");
    }

    public downloadCategories(): IPromise<any> {
        return this.$http.get("/api/categories/").then((resp: any) => {
            return resp.data;
        });
    }

}
