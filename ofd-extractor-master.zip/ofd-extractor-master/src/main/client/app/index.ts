import "@cgross/angular-notify/angular-notify.css";
import * as angular from "angular";
import "es6-promise";
import "font-awesome/css/font-awesome.css";
import * as AppModule from "./app";

// tslint:disable-next-line
let app: typeof AppModule = require("./app");

const bootstrap = () =>
    angular.bootstrap(document, ["app"], {
        strictDi: false
    });

// Enables Hot Module Replacement.
declare var module: any;
if (module.hot) {
    module.hot.accept("./app", () => {
        app = require("./app"); // ...and here's our dynamic reload
        bootstrap();
    });
}

bootstrap();
