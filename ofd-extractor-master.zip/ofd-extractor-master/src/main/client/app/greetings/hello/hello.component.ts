import {IComponentOptions, ILogService} from "angular";
import {ModalService} from "../../shared/modal/modal.service";
import {NotificationService} from "../../shared/notification/notification.service";

class HelloController {

    public message: string;
    public confirmed: boolean;

    /* @ngInject */
    constructor(private $log: ILogService, private modalService: ModalService, private notificationService: NotificationService) {
        $log.info("HelloController");
    }

    public confirm() {
        this.confirmed = false;
        this.modalService.confirm({
            body: "This is where a custom message will ask the user to please confirm something. It saves having to setup a component, html, etc every time " +
            "you want a confirmation. Everything, including the modal title, yes button text, " +
            "no button text is all customisable with sensible defaults. Only the body text is a required param"
        }).then(() => this.notificationService.success("Confirmation was received!"));
    }

    public info() {
        this.modalService.info({
            body: "This is where a custom message will go with information for the user.  It saves having to setup a component, html, etc every time " +
            "you want an informational modal. Only the body text is required, but the title and button text is also customisable (with sensible defaults)."
        });
    }

    public notifyInfo() {
        this.notificationService.info("Notification message");
    }

    public notifyInfoCustom() {
        this.notificationService.info("Notification message", {
            position: "left",
            duration: 1000,
        });
    }

    public notifySuccess() {
        this.notificationService.success("Notification message");
    }

    public notifyWarning() {
        this.notificationService.warn("Notification message");
    }

    public notifyError() {
        this.notificationService.error("Notification message");
    }


}

export const HelloComponent: IComponentOptions = {
    bindings: {
        message: "@"
    },
    controller: HelloController,
    template: require("./hello.html")
};
