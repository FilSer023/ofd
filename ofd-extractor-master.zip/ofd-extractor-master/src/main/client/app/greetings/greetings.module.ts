import uiRouter, {StateProvider} from "@uirouter/angularjs";
import angular = require("angular");
import {ReferenceDataModule} from "../shared/reference-data/reference-data.module";
import {ReferenceData} from "../shared/reference-data/reference-data.service";
import {GoodbyeComponent} from "./goodbye/goodbye.component";
import {HelloComponent} from "./hello/hello.component";
import {FileUploadModule} from "../shared/file-upload/file-upload.module";
import {ModalModule} from "../shared/modal/modal.module";
import {NotificationModule} from "../shared/notification/notification.module";

export const GreetingsModule = angular
    .module("hello", [FileUploadModule, uiRouter, ReferenceDataModule, ModalModule, NotificationModule])
    .component("hello", HelloComponent)
    .component("goodbye", GoodbyeComponent)

    .config(($stateProvider: StateProvider) => {
        $stateProvider
            .state("greetings", {
                url: "/greetings",
                abstract: true,
                resolve: {
                    referenceDataInit: (referenceData: ReferenceData) => referenceData.init()
                }
            })
            .state("greetings.hello", {
                url: "/hello",
                component: "hello",
                resolve: {
                    message: () => "Hello! From your shiny new application!"
                }
            })
            .state("greetings.goodbye", {
                url: "/goodbye",
                component: "goodbye",
                resolve: {
                    message: () => "Goodbye! Sad to see you go :("
                }
            });
    })
    .name;
