import {IComponentOptions, ILogService} from "angular";

class GoodbyeController {

    public message: string;

    /* @ngInject */
    constructor($log: ILogService) {
        $log.info("GoodbyeController");
    }

}

export const GoodbyeComponent: IComponentOptions = {
    bindings: {
        message: "@"
    },
    controller: GoodbyeController,
    template: require("./goodbye.html")
};
